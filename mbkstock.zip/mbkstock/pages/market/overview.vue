<template>
	<view>
		<HeaderPrimary isSearch></HeaderPrimary>

		<!-- <TabsPrimary :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>
		<TabsSecond :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsSecond>
		<TabsThird :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsThird> -->
		<TabsFourth :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsFourth>
		<!-- 	<TabsFifth :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		<TabsSixth :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsSixth> -->



		<view style="padding-bottom: 20px;">
			<TabOne v-if="curTab==0" ref="tab0"></TabOne>
			<MarketHot v-if="curTab==1"></MarketHot>
			<MarketKPI v-if="curTab==2"></MarketKPI>
			<MarketNews v-if="curTab==3"></MarketNews>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	// import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	// import TabsSecond from '@/components/tabs/TabsSecond.vue';
	// import TabsThird from '@/components/tabs/TabsThird.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	// import TabsFifth from '@/components/tabs/TabsFifth.vue';
	// import TabsSixth from '@/components/tabs/TabsSixth.vue';


	import TabOne from '@/components/market/TabOne.vue'
	import MarketHot from '@/components/market/MarketHot.vue'
	import MarketKPI from '@/components/market/MarketKPI.vue'
	import MarketNews from '@/components/market/MarketNews.vue';

	export default {
		components: {
			HeaderPrimary,
			// TabsPrimary,
			// TabsSecond,
			// TabsThird,
			TabsFourth,
			// TabsFifth,
			// TabsSixth,
			TabOne,
			MarketHot,
			MarketKPI,
			MarketNews,
		},
		data() {
			return {
				curTab: 0,
				// timer: null,
			}
		},
		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type);
				// this.changeTab(this.curTab);
			}
		},
		onShow() {
			console.log('onShow', this.$refs.tab0);
			// if (this.$refs.tab0) {
			// 	this.$refs.tab0.onSetTimeout();
			// }
			this.changeTab(this.curTab);
		},
		onReady() {
			console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			console.log('onHide', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},
		deactivated() {
			console.log('deactivated', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},

		methods: {
			changeTab(val) {
				if (this.$refs.tab0) {
					this.$refs.tab0.clearTimer();
				}
				this.curTab = val;
				if (this.curTab == 0) {
					if (this.$refs.tab0) {
						this.$refs.tab0.onSetTimeout();
					}
				}
			},
		},
	}
</script>