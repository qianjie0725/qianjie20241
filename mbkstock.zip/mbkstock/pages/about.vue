<!-- 关于我们 -->
<template>
	<view>
		<HeaderSecond :title="about.title" color="#333333"></HeaderSecond>

		<view style="padding: 30rpx;min-height: 80vh;">
			<view v-html="about.content"
				style="font-size:28rpx;white-space: break-spaces;line-height: 1.3;padding:10px;color:#FFFFFF"></view>
		</view>
	</view>
</template>

<script>
	import {
		getAboutInfo
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				about: {},
			};
		},
		created() {
			this.getAbout()
		},
		methods: {
			//关于我们
			async getAbout() {
				const result = await getAboutInfo();
				this.about = result.data
			},
		},
	}
</script>