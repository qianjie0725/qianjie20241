<!-- 银转证  存款 -->
<template>
	<view :style="$theme.linerGradient(180,'#30AEB2','#1C829B')" style="min-height: 100vh;">
		<HeaderSecond :title="$lang.PAGE_TITLE_DEPOSIT" color="#FFFFFF"></HeaderSecond>

		<view style="margin:30rpx;" :style="{backgroundColor:$util.RGBConvertToRGBA('#FFFFFF',70)}">
			<view :style="{backgroundColor:$util.RGBConvertToRGBA('#7fffd4',30)}" style="position: relative;">
				<view style="text-align: center;color:#333333;font-size: 28rpx;line-height: 2;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
				</view>
				<view style="position: absolute;right: 20rpx; top:50%;transform: translateY(-50%);">
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
						@click="handleShowAmount" :style="$util.setImageSize(40)" style="margin-left: auto;">
					</image>
				</view>
			</view>
			<view style="font-size: 48rpx;color:121212;font-weight: 700;text-align: center;line-height: 2;">
				{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
			</view>

			<view style="display: flex;align-items: center;justify-content: center;">
				<image src="/static/deposit_info_bg.png" mode="aspectFit" :style="$util.setImageSize(560,380)"></image>
			</view>
		</view>

		<view style="padding:0  20px 10px 20px;">
			<CustomTitle :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT" color="#FFFFFF"></CustomTitle>
			<view class="common_input_wrapper" style="background-color: #FFFFFF;">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view style="display: flex;flex-wrap:wrap;align-items: center;">
				<block v-for="(item,index) in amountList" :key="index">
					<view
						style="padding:10px;margin: 10rpx; border-radius: 6px;line-height: 1.6;flex:25%;text-align: center;"
						:style="{backgroundColor:curPos==index?'#F5B71C':'#FFFDF5',color:curPos==index? '#FFFFFF':'#666666' }"
						@click="quantity(item,index)">
						{{$util.formatNumber(item)}}
					</view>
				</block>
			</view>
			<view :style="$theme.btnCommon(true,{padding:'11px 26px',marginTop:'20rpx'})" @click="to_recharge()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>

		<view style="padding: 10px 20px;">
			<!-- <view style="font-size: 14px;font-weight: 700;text-align: center;color:#FFFFFF;">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view> -->
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="padding-bottom:6px;color:#FFFFFF;">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import {
		accountInfo,
		postDeposit
	} from '@/common/api.js';
	import {
		DEPOSIT_AMOUNTS
	} from '@/common/config.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			AccountAssets,
			CardItemPrimary,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				userInfo: {}, //
				cardThird: {},
			};
		},
		computed: {
			cardThirdLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			amountList() {
				return DEPOSIT_AMOUNTS;
			}
		},
		onLoad(option) {
			this.gaint_info()
			this.amount = this.amountList[0];
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				const result = await postDeposit({
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				}, this.$lang.DEPOSIT_POST_TIP);

				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						this.$util.linkCustomerService();
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			// //凭证
			// deletePic(event) {
			// 	this[`fileList${event.name}`].splice(event.index, 1)
			// },
			// // 新增图片
			// async afterRead(event) {
			// 	// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
			// 	let lists = [].concat(event.file)
			// 	let fileListLen = this[`fileList${event.name}`].length
			// 	lists.map((item) => {
			// 		this[`fileList${event.name}`].push({
			// 			...item,
			// 		})
			// 	})
			// 	for (let i = 0; i < lists.length; i++) {
			// 		const result = await this.uploadFilePromise(lists[i].url)
			// 		let item = this[`fileList${event.name}`][fileListLen]
			// 		this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
			// 			status: 'success',
			// 			message: '',
			// 			url: result
			// 		}))
			// 		fileListLen++
			// 	}
			// },
			//个人信息
			async gaint_info() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardThird = {
						value1: this.userInfo.money, // 可提
						value2: this.userInfo.freeze, // 冻结
						value3: this.userInfo.totalYingli, // 总盈利
					};
				} else {
					uni.$u.toast(result.message);
				}
			},

			// uploadFilePromise(url) {
			// 	// console.log(url)
			// 	pathToBase64(url).then(base64 => {
			// 			// 这就是转为base64格式的图片
			// 			this.is_url = base64
			// 			// console.log(base64)
			// 		})
			// 		.catch(error => {
			// 			console.error(error)
			// 		})
			// },
		},
	}
</script>