<!-- 펀드 비밀번호 -->
<template>
	<view>
		<!-- <view style="background-image: linear-gradient(180deg, #F5B71C, transparent);"> -->
			<HeaderSecond :title="$lang.ACCOUNT_CHANGE_PAY_PWD" color="#333333"></HeaderSecond>
		<!-- </view> -->

		<view style="margin: 20px;padding: 20px;">
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(40)">
				</image>
				<input v-model="value" type="password" :placeholder="$lang.TIP_OLD_PWD"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="value2" type="text" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="value2" type="password" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="value3" type="text" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="value3" type="password" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
			<view :style="$theme.btnCommon(true,{padding:'11px 26px'})" @click="changePassword()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import {
		putPayPwd
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isShow: false, // 密码显隐
				value: '',
				value2: "",
				value3: "",
			};
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			//修改交易密码
			async changePassword() {
				const result = await putPayPwd({
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				});
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>