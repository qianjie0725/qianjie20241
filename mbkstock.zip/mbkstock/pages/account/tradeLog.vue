<template>
	<view>
		<!-- <view style="background-color: #FFFFFF;"> -->
		<HeaderSecond :title="$lang.ACCOUNT_TRADE_LOG" color="#333333"></HeaderSecond>
		<!-- </view> -->

		<TabsThird :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsThird>

		<!-- <TabsPrimary :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsPrimary> -->

		<view style="padding: 20px 0;">
			<template v-if="curTab == 0">
				<LogTrade></LogTrade>
			</template>

			<template v-if="curTab == 1">
				<LogDeposit></LogDeposit>
			</template>

			<template v-if="curTab == 2">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsThird from '@/components/tabs/TabsThird.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsThird,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				curTab: 0,
			};
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>