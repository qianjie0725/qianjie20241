<!-- 银转证  存款 -->
<template>
	<view>
		<HeaderSecond :title="$lang.DEPOSIT" color="#CBCBCF"></HeaderSecond>

		<view style="display: flex;align-items: center;padding:4px 20px;">
			<image src="/static/kr.png" mode="aspectFit" :style="$util.setImageSize(60)"
				style="border-radius: 100px;background-color:#bdd8ffa1;padding:6px;"></image>
			<view style="padding-left: 10px;" :style="{color:$theme.TITLE}">KRW</view>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$theme.PRIMARY}">
				<text
					style="margin-right: 20px;">{{showAmount?$util.formatNumber(userInfo.money)+'원':hideAmount}}</text>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="padding:20px;" :style="{color:$theme.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
			<view class="common_btn btn_primary" style="width: 60%;margin:auto;" @click="handleCustomer()">
				고객센터에 문의하세요
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				userInfo: {},
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			// 资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			async handleCustomer() {
				this.$util.linkCustomerService();
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>