<template>
	<view>
		<HeaderPrimary isSearch></HeaderPrimary>

		<Profile :info="userInfo"></Profile>

		<view style="background-color: #F5F5F5;padding: 20rpx;margin: 20rpx;">
			<view style="display: flex;align-items: center;line-height: 2.4;">
				<image src="/static/account_center_total.png" mode="aspectFit" :style="$util.setImageSize(32)">
				</image>
				<view style="padding-left: 20rpx;color:#999999;">{{$lang.ACCOUNT_AMOUNT_TOTAL}}</view>
				<view style="padding-left: 20rpx;font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
					{{showAmount?$util.formatNumber(userInfo.totalZichan):hideAmount}}
				</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="display: flex;align-items: center;line-height: 2.4;">
				<image src="/static/account_center_avalabel.png" mode="aspectFit" :style="$util.setImageSize(32)">
				</image>
				<view style="padding-left: 20rpx;color:#999999;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}</view>
				<view style="padding-left: 20rpx;font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
					{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-around;margin-top: 20rpx;">
				<view @click="linkDeposit()"
					style="background-color: #1C829B;color:#FFFFFF;font-size: 32rpx;line-height:1.8;padding:0 80rpx;">
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
				<view @click="linkWithdraw()"
					style="background-color:#722A3E;color:#FFFFFF;font-size: 32rpx;line-height:1.8;padding:0 80rpx;">
					{{$lang.PAGE_TITLE_WITHDRAW}}
				</view>
			</view>
		</view>

		<view style="padding:0 10px;">
			<CustomTitle :title="$lang.ACCOUNT_MORE_FEATURES"></CustomTitle>
		</view>

		<NavList :list="$util.setAccountCenterList(userInfo.is_check)"></NavList>


	</view>
</template>

<script>
	import {
		ACCOUNT_WITHDRAW,
		ACCOUNT_DEPOSIT,
		ACCOUNT_ACCESS,
		SERVICE
	} from '@/common/paths.js';
	import {
		accountInfo,
		signOut
	} from '@/common/api.js';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			NavList,
			CustomTitle,
			AccountAssets,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				// isShow: false, // 显示弹层
				// value1: '', // 第一个输入框
				// value2: '', // 第二个输入框
				// value3: '', // 第三个输入框，绑卡所需
				// current: -1, // 当前显示的弹层
				// curConfig: {}, // 弹层中的配置
				// cardInfo: {}, // 银行卡信息，显示绑卡信息，或变更绑卡信息
			}
		},
		onShow() {
			this.gaint_info()
		},
		//下拉刷新
		onPullDownRefresh() {
			this.gaint_info()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},
			// 客服
			linkService() {
				uni.navigateTo({
					url: SERVICE
				})
			},

			// // 登出
			// handleSignOut() {
			// 	signOut();
			// 	try {
			// 		let version = uni.getStorageSync('version')
			// 		uni.removeStorageSync('token');
			// 		uni.setStorageSync('version', version)
			// 	} catch (e) {
			// 		// error
			// 	}
			// 	uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
			// 	setTimeout(() => {
			// 		uni.navigateTo({
			// 			url: ACCOUNT_ACCESS
			// 		});
			// 		this.$router.go(0)
			// 	}, 500)
			// },
			//用户信息
			async gaint_info() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data
				} else {
					uni.$u.toast(result.message);
				}
			},
			// // 功能列表，点击事件
			// handleClick(val) {
			// 	console.log('val:', val);
			// 	// this.current = this.$util.MODE_DIALOG.findIndex(item => item.url == val.url);
			// 	// console.log('index:', this.current);
			// 	// this.curConfig = {
			// 	// 	title: val.name,
			// 	// 	input1ph: this.current == 2 ? this.$lang.REAL_NAME : this.$lang.NEW_PWD,
			// 	// 	input2ph: this.current == 2 ? this.$lang.BANK_NAME : this.$lang.NEW_PWD2,
			// 	// 	input3ph: this.$lang.BANK_CARD,
			// 	// 	type: this.current == 2 ? 'text' : 'password',
			// 	// };
			// 	// this.isShow = true;

			// 	// // 如果是绑卡弹层，请求已绑卡信息
			// 	// if (this.current == 2 && this.cardInfo) {
			// 	// 	this.value1 = this.cardInfo.realname;
			// 	// 	this.value2 = this.cardInfo.bank_name;
			// 	// 	this.value3 = this.cardInfo.card_sn;
			// 	// }
			// },
			// handleCancel() {
			// 	this.isShow = false;
			// 	this.value1 = "";
			// 	this.value2 = "";
			// 	this.value3 = "";
			// },
			// async handleConfirm() {
			// 	// 根据当前显示弹出，分别处理。其中，变更账户密码与支付密码逻辑相同
			// 	const urls = [this.$http.API_URL.SIGNIN_PASSWORD,
			// 		this.$http.API_URL.PAY_PASSWORD,
			// 		this.$http.API_URL.BIND_BANK_CARD,
			// 	];
			// 	let tempData = {};
			// 	if (this.current == 2) {
			// 		tempData = {
			// 			realname: this.value1,
			// 			bank_name: this.value2,
			// 			card_sn: this.value3,
			// 		}
			// 	} else {
			// 		tempData = {
			// 			newpass: this.value1,
			// 			confirmpass: this.value2,
			// 		};
			// 	}
			// 	let result = await this.$http.post(urls[this.current], tempData);
			// 	if (result.data.code == 0) {
			// 		uni.$u.toast(this.current == 2 ? '은행 카드 정보가 성공적으로 제출되었습니다.' : '수정되었습니다.');
			// 		this.isShow = false;
			// 		setTimeout(() => {
			// 			uni.switchTab({
			// 				url: this.$util.PAGE_URL.ACCOUNT_CENTER
			// 			});
			// 		}, 1000)
			// 	} else {
			// 		uni.$u.toast(result.data.message);
			// 	}
			// },

			// manages() {
			// 	if (this.cardManagement) {
			// 		uni.navigateTo({
			// 			url: this.$util.PAGE_URL.ACCOUNT_BANK_CARD
			// 		});
			// 	} else {
			// 		uni.navigateTo({
			// 			//保留当前页面，跳转到应用内的某个页面
			// 			url: '/pages/my/components/bankCard/renewal'
			// 		});
			// 	}
			// },
			// //版本更新
			// Update() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/versionUpdate'
			// 	});
			// },
			// //用户协议
			// userAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/userAgreement'
			// 	});
			// },
			// //隐私协议
			// privacyAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/privacyAgreement'
			// 	});
			// },

			// //关于我们
			// aboutUs() {
			// 	uni.navigateTo({
			// 		url: this.$util.PAGE_URL.ABOUT
			// 	});
			// },
			// //实名认证
			// notCertified() {
			// 	uni.navigateTo({
			// 		url: this.$util.PAGE_URL.ACCOUNT_AUTH
			// 	});
			// },


		},
	}
</script>