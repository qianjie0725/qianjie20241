<template>
	<view :style="$theme.linerGradient(180,'#30AEB2','#1C829B')" style="min-height: 100vh;">
		<HeaderSecond :title="$lang.PAGE_TITLE_WITHDRAW" color="#FFFFFF"></HeaderSecond>

		<view style="margin:30rpx;" :style="{backgroundColor:$util.RGBConvertToRGBA('#FFFFFF',70)}">
			<view :style="{backgroundColor:$util.RGBConvertToRGBA('#7fffd4',30)}" style="position: relative;">
				<view style="text-align: center;color:#333333;font-size: 28rpx;line-height: 2;">
					{{$lang.WITHDRAW_AMOUNT}}
				</view>
				<view style="position: absolute;right: 20rpx; top:50%;transform: translateY(-50%);">
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
						@click="handleShowAmount" :style="$util.setImageSize(40)" style="margin-left: auto;">
					</image>
				</view>
			</view>
			<view style="font-size: 48rpx;color:121212;font-weight: 700;text-align: center;line-height: 2;">
				{{showAmount?$util.formatNumber(userInfo.totalZichan):hideAmount}}
			</view>

			<view style="display: flex;align-items: center;justify-content: center;">
				<image src="/static/withdraw_info.png" mode="aspectFit" :style="$util.setImageSize(560,380)"></image>
			</view>
		</view>

		<CustomTitle :title="$lang.WITHDRAW_WITH_AMOUNT" color="#FFFFFF"></CustomTitle>
		<view style="margin:0 40rpx;">
			<view class="common_input_wrapper"
				style="padding-left: 30px;margin-bottom: 20px;background-color: #FFFFFF;margin-top: 0;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;"></input>
			</view>
		</view>

		<CustomTitle :title="$lang.WITHDRAW_PAY_PWD" color="#FFFFFF"></CustomTitle>
		<view style="margin:0 40rpx;">
			<view class="common_input_wrapper"
				style="padding-left: 30px;margin-bottom: 20px;background-color: #FFFFFF;margin-top: 0;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
					:placeholder-style="$util.setPlaceholder()" style=""></input>
			</view>
		</view>

		<view style="margin:40rpx;">
			<view :style="$theme.btnCommon(true,{padding:'11px 26px',marginTop:'20rpx'})" @click="handleWithdraw()">
				{{$lang.BTN_WITHDRAW}}
			</view>
		</view>


		<view style="margin:10px; padding:0 40rpx 40rpx 40rpx;" :style="{color:$theme.TITLE}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?$theme.PRIMARY :'#FFFFFF'}">
					{{item}}
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		postWithdarw,
		accountInfo
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				const result = await postWithdarw({
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				}, this.$lang.WITHDRAWING_POST_TIP)
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						this.$util.linkCustomerService();
					}, 500)
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>