<template>
	<view >
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_DAY"></HeaderSecond>
		</view>
		

		<TabsPrimary :tabs="$lang.TRADE_AI_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<TradeAIBuy @action="changeTab"></TradeAIBuy>
		</template>
		<template v-else>
			<TradeAIOrderList></TradeAIOrderList>
		</template>
		<!-- <template v-else>
			<TradeAILog></TradeAILog>
		</template> -->
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeAIBuy from '@/components/trade/TradeAIBuy.vue';
	import TradeAIOrderList from '@/components/trade/TradeAIOrderList.vue';
	// import TradeAILog from '@/components/trade/TradeAILog.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeAIBuy,
			TradeAIOrderList,
			// TradeAILog,
		},
		data() {
			return {
				options: {},
				curTab: 0,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>