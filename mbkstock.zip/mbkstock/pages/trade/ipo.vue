<!-- 新股申购 -->
<template>
	<view :style="$theme.linerGradient(180,'#30AEB2','#1C829B')" style="min-height: 100vh;">
		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_IPO" color="#FFFFFF"></HeaderSecond>

		<TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab ==0">
			<view style="padding: 10px;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view style="margin-bottom: 20px;background-color: #FFFFFF;border-radius: 8px;padding: 10px;">
						<TradeStockItem :item="item" @action="handleDetail"></TradeStockItem>
					</view>
				</block>
			</view>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPOLog></TradeIPOLog>
		</template>
		<template v-else>
			<TradeIPOSuccessLog></TradeIPOSuccessLog>
		</template>

		<u-modal :show="show" :title="$lang.TRADE_IPO_MODAL_TITLE" @cancel="cancel" @confirm="confirm()"
			:showCancelButton='true' :content='$lang.TRADE_IPO_MODAL_CONTENT' :cancelText="$lang.BTN_CANCEL"
			:confirmText="$lang.BTN_CONFIRM">
		</u-modal>
	</view>
</template>

<script>
	import {
		getIPOList,
		postBuyIPO
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeIPOLog from '@/components/trade/TradeIPOLog.vue';
	import TradeStockItem from '@/components/trade/TradeStockItem.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIPOSuccessLog from '@/components/trade/TradeIPOSuccessLog.vue';

	export default {
		components: {
			HeaderSecond,
			EmptyData,
			TradeIPOLog,
			TradeStockItem,
			TabsPrimary,
			TradeIPOSuccessLog,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
				list: [],
				curId: '', // 当前选中数据的ID值
				show: false, // 购买前二次确认的弹层
			};
		},
		onLoad(opt) {
			this.curTab = Number(opt.type) || 0;
		},
		onShow() {
			this.getList();
		},

		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) {
					this.getList();
				}
			},

			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.curId = val;
				this.show = true;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase()
				this.show = false;
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				const result = await postBuyIPO({
					// num: this.value,
					id: this.curId,
					// price: this.price
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						this.changeTab(1);
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			async getList() {
				const result = await getIPOList({
					type: this.curTab + 1, // 传参 1或2
				})
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>