<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_EQUITY"></HeaderSecond>
		</view>

		<TabsPrimary :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<TradeEquityBuy @action="changeTab"></TradeEquityBuy>
		</template>
		<template v-else>
			<TradeEquityLog></TradeEquityLog>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeEquityBuy from '@/components/trade/TradeEquityBuy.vue';
	import TradeEquityLog from '@/components/trade/TradeEquityLog.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeEquityBuy,
			TradeEquityLog,
		},
		data() {
			return {
				curTab: 0,
			}
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>