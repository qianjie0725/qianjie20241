<!-- 日内交易 -->
<template>
	<view :style="$theme.linerGradient(180,'#30AEB2','#1C829B')" style="min-height: 100vh;">
		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_DAY" color="#FFFFFF"></HeaderSecond>

		<TabsPrimary :tabs="$lang.TRADE_DAY_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>


		<view style="padding: 10px;margin-bottom: 20px;">
			<template v-if="curTab==0">
				<TradeDayBuy @action="changeTab"></TradeDayBuy>
			</template>

			<template v-else-if="curTab==1">
				<TradeDayOrderList></TradeDayOrderList>
			</template>
			<template v-else>
				<TradeDaySuccessList></TradeDaySuccessList>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeDayBuy from '@/components/trade/TradeDayBuy.vue';
	import TradeDayOrderList from '@/components/trade/TradeDayOrderList.vue';
	import TradeDaySuccessList from '@/components/trade/TradeDaySuccessList.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeDayBuy,
			TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				options: {},
				curTab: 0,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>