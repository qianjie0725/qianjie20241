<template>
	<view class="launch">

		<view style="display: flex;align-items: center;justify-content: center;padding: 20vh 0;">
			<image src='/static/logo.jpg' :style="$util.setImageSize(260,260)" style="border-radius: 100px;">
			</image>
		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/launch_img.png" mode="aspectFit" :style="$util.setImageSize(512)"></image>
		</view> -->
		<view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 48rpx;font-family: 700;color:#722A3E;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view>

		<ProgressPrimary></ProgressPrimary>

	</view>
</template>

<script>
	import ProgressPrimary from '@/components/progress/ProgressPrimary.vue';
	export default {
		components: {
			ProgressPrimary
		},
	}
</script>

<style lang="scss">
	/* 启动页 */
	.launch {
		width: 100%;
		height: 100vh;
		background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
		position: relative;
	}
</style>