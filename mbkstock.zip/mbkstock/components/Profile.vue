<!-- 用户基本信息 -->
<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;margin:20rpx 40rpx;">
			<view :style="$theme.btnCommon(true,{width:'120rpx', height:'120rpx',borderRadius:'100px',padding:'0'})">
				<image style="border-radius: 100px;" mode="aspectFit"
					:src="info.avatar?info.avatar:'/static/avatar.png'" :style="$util.setImageSize(120)"></image>
			</view>
			<view style="flex:70%;margin-left: 20rpx;">
				<view style="font-size: 36rpx;text-align: left;padding-right: 30rpx;" :style="{color:$theme.PRIMARY}">
					{{info.real_name}}
				</view>
				<view style="font-size: 32rpx;text-align: left;color:#999999;padding-right: 30rpx;">
					{{info.p_mobile}}
				</view>
			</view>
			<view style="margin-left: auto;" @click="handleLink()">
				<view class="arrow rotate_45" :style="{borderColor:$theme.PRIMARY,...$util.setImageSize(12)}"></view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_AVATAR
	} from '@/common/paths.js';
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入信息修改页面
			handleLink() {
				uni.navigateTo({
					url: ACCOUNT_AVATAR,
				})
			},
		}
	}
</script>

<style>

</style>