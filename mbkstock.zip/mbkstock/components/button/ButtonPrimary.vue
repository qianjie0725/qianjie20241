<template>
	
</template>

<script>
	export default {
		name:'ButtonPrimary',
	}
</script>

<style>
</style>