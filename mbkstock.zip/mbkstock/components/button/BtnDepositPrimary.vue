<template>
	<view class="trade_modal_btn"
		style="background-color: #FF6700;height: 32px;line-height:32px;display: flex;align-items: center;justify-content:center;"
		@tap="link()">
		<image src="/static/center_left.png" mode="aspectFit" :style="$util.setImageSize(28)"
			style="padding-right: 20px;"></image>
		{{$lang.PAGE_TITLE_DEPOSIT}}
	</view>
</template>

<script>
	import {
		ACCOUNT_DEPOSIT,
	} from '@/common/paths.js';
	export default {
		name: 'BtnDepositPrimary',
		data() {
			return {}
		},

		methods: {
			link() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			}
		}
	}
</script>

<style>
</style>