<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
		<block v-for="(item,index) in tabs" :key='index'>
			<view
				:style="$theme.btnCommon(acitve ==index,{marginRight:index==tabs.length-1?'':'10rpx',display:'inline-block'})"
				@click="handleChange(index)">
				<!-- <image src="/static/center_left.png" mode="aspectFit" :style="$util.setImageSize(28)"
				style="padding-right: 20px;"></image> -->
				{{item}}
			</view>
		</block>
	</scroll-view>
</template>

<script>
	export default {
		name: 'TabsFifth',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		methods: {
			handleChange(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
		}
	}
</script>