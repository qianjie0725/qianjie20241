<template>
	<view>HomeFollowList</view>
</template>

<script>
	export default {
		name:'HomeFollowList',
	}
</script>
