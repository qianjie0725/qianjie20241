<template>
	<view>
		<view style="padding:24rpx 0;">
			<TabsFifth :tabs="$lang.MARKET_NEWS_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		</view>

		<view style="margin-top: 20px;padding: 0 10px;">
			<block v-for="(item,index) in list" :key="index">
				<view @click="open(item.url)"
					style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;">
					<template v-if="curTab==0">
						<image :src="item.pic" :style="$util.setImageSize(200,150)" mode="scaleToFill"
							style="border-radius: 10px;"></image>
						<view style="flex:60%;padding-left: 30px;padding-top: 10px;color: #333333;">
							<view>{{item.title}}</view>
							<view style="margin:6px;margin-top: 16px;"><text
									style="color:#999999;padding: 4px 0;">{{$util.formatDate(item.updated_at)}}</text>
							</view>
						</view>
					</template>
					<template v-else>
						<view style="flex:100%">
							<view style="color: #333333;">{{item.title}}</view>
							<view style="margin:6px;margin-top: 16px;text-align: right;color:#999999;">
								{{$util.formatDate(item.updated_at)}}
							</view>
						</view>
					</template>
				</view>
			</block>
		</view>
		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}} </view>
	</view>
</template>

<script>
	import {
		getMarketNews
	} from '@/common/api.js';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	export default {
		name: 'MarketNews',
		components: {
			TabsFifth,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			open(url) {
				window.open(url)
			},
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			async getData() {
				const result = await getMarketNews({
					current: this.curTab
				})
				console.log(result);
				if (result.code == 0) {
					if (result.data.length > 0) {
						this.list = result.data.map(item => {
							return {
								title: item.title,
								url: item.url,
								updated_at: item.updated_at,
								pic: item.pic,
							}
						});
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>