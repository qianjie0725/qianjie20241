<template>
	<view>
		<!-- <view style="padding:24rpx 0;">
			<TabsFifth :tabs="$lang.MARKET_HOT_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		</view> -->
		<!-- <ListThird :list="list"></ListThird> -->
		<ListFourth :list="list"></ListFourth>

		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}}</view>
	</view>
</template>

<script>
	import {
		getMarketHot
	} from '@/common/api.js';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import ListThird from '@/components/list/ListThird.vue';
	import ListFourth from '@/components/list/ListFourth.vue';
	export default {
		name: 'MarketHot',
		components: {
			ListThird,
			TabsFifth,
			ListFourth,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			async getData() {
				const result = await getMarketHot({
					current: this.curTab
				})
				console.log(result);
				if (result.code == 0) {
					if (result.data.length > 0) {
						this.list = result.data.map(item => {
							return {
								logo: item.logo,
								name: item.ko_name,
								code: item.code,
								price: item.close,
								rate: item.returns,
								follow: item.sc,
								gid: item.gid,
								close: item.close,
							}
						});
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>