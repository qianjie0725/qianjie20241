<template>
	<view>
		<TabsFifth :tabs="$lang.MARKET_HOT_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		<ListFourth :list="list"></ListFourth>

		<!-- <ListThird :list="list"></ListThird> -->
	</view>
</template>

<script>
	import {
		getMarketOverviewHot
	} from '@/common/api.js';
	// import ListThird from '@/components/list/ListThird.vue';
	import ListFourth from '@/components/list/ListFourth.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	export default {
		name: 'MarketHotTop',
		components: {
			// ListThird,
			ListFourth,
			TabsFifth,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			async getData() {
				console.log(this.curTab)
				const result = await getMarketOverviewHot({
					current: this.curTab
				})
				if (result.code == 0) {
					if (result.data.length > 0) {
						this.list = result.data.map(item => {
							return {
								logo: item.logo,
								name: item.ko_name,
								code: item.code,
								price: item.close,
								rate: item.returns,
								follow: item.sc,
								gid: item.gid,
								close: item.close,
							}
						});
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>