<template>
	
</template>

<script>
	import {
		TRADE_IPO
	} from '@/common/paths.js';
	export default {
		name: 'IPOSuccessAlert',
		props: {
			info: {
				type: Object,
				default: {},
			},
		},
		methods: {
			// 弹层关闭
			activeEvent() {
				console.log('??');
				this.$emit('action', false);
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: `${TRADE_IPO}?type=2`,
				})
			},
		}
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}
</style>