<template>
	
</template>

<script>
	export default {
		name: 'AlertPrimary',
		props: {},

	}
</script>

<style>
</style>