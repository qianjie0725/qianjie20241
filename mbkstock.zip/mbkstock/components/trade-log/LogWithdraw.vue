<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding:10px 16px;line-height: 1.8;margin:0;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_WITHDRAW_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view :style="{color:$theme.PRIMARY}" style="flex:40%;font-size: 18px;">
						{{$util.formatNumber(item.money)}}
					</view>
					<view style="flex:20%;text-align: right;" :style="{color:$theme.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<!-- <view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.bank_name}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.bankno}}
					</view>
				</view> -->

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.LOG_LABEL}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.LOG_LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_DW_DESC}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.LOG_LABEL}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<!-- <view style="flex:5%;">
										<image :src="item.icon" :style="$util.setImageSize(24)"></image>
									</view> -->
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_STATUS}}</view>
					<text style="flex:70%;white-space:pre-wrap;text-align: right;"
						:style="{color:item.color}">{{item.text}}</text>
				</view>
				<template v-if="item.status==0">
					<view class="trade_modal_btn"
						style="background-color:#FF6700;height: 32px;line-height:32px;width: 60%;margin: auto;margin-top: 20px;text-align: center;border-radius: 0;"
						@click="handleCancel(item.id)">
						{{$lang.BTN_CANCEL}}
					</view>
				</template>
				<template v-if="item.status==2">
					<view class="trade_modal_btn"
						style="background-color: #00A9DE;height: 32px;line-height:32px;display: flex;align-items: center;justify-content:center;width: 60%;margin: auto; margin-top: 20px;border-radius: 0;"
						@click="handleService()">
						{{$lang.BTN_SEND_SERVICE}}
						<image src="/static/service.png" mode="aspectFit" :style="$util.setImageSize(40)"
							style="padding-left: 20px;"></image>
					</view>
				</template>
			</view>
			<view style="margin: 0;padding:0;width:100vw;height: 12rpx;background-color: #F3F3F3;"></view>
		</block>
	</view>
</template>

<script>
	import {
		SERVICE
	} from '@/common/paths';
	import {
		getAccountWithdraw,
		postCancelWithdraw
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			// 联系客服
			handleService() {
				uni.navigateTo({
					url: SERVICE
				})
			},

			// 取消提现
			handleCancel(id) {
				let _this = this;
				uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					success: function(res) {
						if (res.confirm) {
							_this.qx_post(id);
						} else if (res.cancel) {}
					}
				})
			},
			async qx_post(id) {
				const result = await postCancelWithdraw({
					id: id
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async getList() {
				this.list = []; // 每次请求前，清空数组。
				const result = await getAccountWithdraw();
				console.log(result.data);
				if (result.code == 0) {
					result.data.forEach((item, index) => {
						this.list.push({
							...item,
							...this.$util.setWithdrawLogStatus(item.status),
							style: this.$theme.setStatusWithdraw(item.status),
						})
					});
					console.log(this.list);
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>

</style>