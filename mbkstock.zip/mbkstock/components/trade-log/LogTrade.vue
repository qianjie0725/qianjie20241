<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding:10px 16px;line-height: 1.8;margin:0;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_TRADE_AMOUNT_AFTER}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view style="flex:70%;font-size: 36rpx;text-align: right;" :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(item.after)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_TRADE_AMOUNT_BEFORE}}[{{$lang.CURRENCY_UNIT}}]:
					</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(item.before)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_TRADE_DW}}[{{$lang.CURRENCY_UNIT}}]：
					</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.LOG_LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_DESC}}:</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;"></view>
					<text :style="{color:$theme.LOG_LABEL}"
						style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
				</view>
			</view>
			<view style="margin: 0;padding:0;width:100vw;height: 12rpx;background-color: #F3F3F3;"></view>
		</block>
	</view>
</template>

<script>
	import {
		getAccountFinance
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				const result = await getAccountFinance();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>

</style>