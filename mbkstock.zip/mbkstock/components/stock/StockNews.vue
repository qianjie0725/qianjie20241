<template>
	<view class="common_block" style="padding: 10px;">
		<block v-for="(item,index) in list" :key="index">
			<view @click="open(item.link)" :class="index<list.length-1?'line':''"
				style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;">
				<image :src="item.image" :style="$util.setImageSize(200,150)" style="border-radius: 10px;"></image>
				<view style="flex:60%;padding-left: 10px;">
					<view>{{item.title}}</view>
					<view style="margin:6px;margin-top: 16px;"><text
							style="color:#999999;padding: 4px 0;">{{$util.formatDate(item.dt)}}</text>
					</view>
				</view>

			</view>
		</block>
	</view>
</template>

<script>
	import {
		getStockNews
	} from '@/common/api.js';
	export default {
		name: "StockNews",
		props: ['code', 'id'],
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList()
		},
		methods: {
			open(url) {
				window.open(url)
			},
			async getList() {
				const result = await getStockNews({
					code: this.code,
					time_index: this.curKLine
				});
				this.list = result.data[0];
			},
		},
	}
</script>