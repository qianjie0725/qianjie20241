<template>
	<view style="display: flex;align-items: center;flex-wrap: wrap;">
		<block v-for="(item,index) in list" :key="index">
			<view style="flex:48%;">
				<view
					style="display: flex;align-items: center;margin:10px;background-color: #3F3384;padding:30rpx;border-radius: 8rpx;"
					@click="actionEvent(item,index)">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(80)"></image>
					<text style="font-size: 28rpx;color: #FFFFFF;padding-left: 20rpx;">{{item.name}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import {
		signOut
	} from '@/common/api.js';
	import {
		ACCOUNT_ACCESS
	} from '@/common/paths.js';

	export default {
		name: 'AccountCenterList',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {};
		},
		methods: {
			actionEvent(item, index) {
				if (item.mode == 'sign_out') {
					this.handleSignOut();
					return false;
				}
				uni.navigateTo({
					url: item.url,
				})
			},
			// 登出
			handleSignOut() {
				signOut();
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>