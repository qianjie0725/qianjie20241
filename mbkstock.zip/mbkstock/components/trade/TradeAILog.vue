<template>
	<view>
		<view class="common_block" style="padding: 10px;margin-bottom: 20px;">
			<view
				style="display: flex;align-items: center;justify-content: space-around;border-bottom: 1px solid #F1f1f1;margin-bottom: 10px;">
				<block v-for="(item,index) in $lang.TRADE_AI_LOG" :key="index">
					<view style="padding:6px;margin:6px;border-radius: 6px;text-align: center;"
						:style="{color:index==curTab? '#121212':'#666',backgroundColor:curTab==index? '#ebdcff':''}"
						@click="changeTab(index)">{{item}}</view>
				</block>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view :class="index==list.length-1?'':'line'" style="margin-top:0;padding:10px 0;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="display: flex;align-items: center;">
								<view :style="{color:$theme.TITLE}">
									{{$lang.TRADE_AI_TYPE}}
								</view>
								<view style="font-size: 16px;padding-left: 10px;">
									{{$lang.TRADE_AI_TRANSFER[item.type-1]}}
								</view>
							</view>
							<view style="display: flex;align-items: center;">
								<view :style="{color:$theme.TITLE}">
									{{$lang.TRADE_AI_CYCLE_DAY}}[{{$lang.UNIT_DAY}}]
								</view>
								<view style="font-size: 16px;padding-left: 10px;">
									{{item.day}}
								</view>
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.TITLE}">
								{{$lang.TRADE_AI_TRADE_VOL}}
							</view>
							<view style="font-size: 16px;">
								{{$util.formatNumber(item.money)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.TITLE}">
								{{$lang.TRADE_AI_BALANCE}}
							</view>
							<view style="font-size: 16px;" :style="{color:$theme.PRIMARY}">
								{{$util.formatNumber(item.money_log)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;"
							:style="{color:$theme.TITLE}">
							<view>{{$lang.TRADE_DAY_CREATE_TIME}}</view>
							<view style="font-size: 12px;">
								{{item.created_at.slice(0,10)}}
							</view>
						</view>
						<!-- <view style="display: flex;align-items: center;" :style="{color:$theme.TITLE}">
							<view style="flex:30%;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
							<view style="flex:70%;font-size: 12px;text-align: right;">
								{{item.zt}}
							</view>
						</view> -->
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import {
		getTradeAILog,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeAILog',
		components: {
			EmptyData,
		},
		data() {
			return {
				curTab: 0,
				list: [],
			}
		},
		created() {
			this.getData();
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			// 申请列表
			async getData() {
				this.list = [];
				const result = await getTradeAILog({
					status: this.curTab
				});

				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>