<template>
	<view style="background-color: #FFFFFF;margin:20rpx;min-height: 100vh;">
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<view style="flex:70%;">
							<view style="padding-left: 10px;font-size: 28rpx;color:#121212;">
								{{item.name}}
							</view>
							<view style="display: flex;align-items: center;">
								<text style="font-size: 28rpx;padding-left: 10px;flex:70%"
									:style="{color:$theme.LOG_LABEL}">{{item.code}}</text>
							</view>
						</view>
						
						<view class="access_btn" @click="handleDetail(item)"
							style="padding:6rpx 24rpx;margin:0;font-size: 28rpx;line-height: 1.4;">
							{{$lang.BTN_BUY}}
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;font-weight: 700;line-height: 2.4;">
						<view style="color: #E82D28;font-size:40rpx;"> {{item.syl + ` %`}} </view>
						<view style="color: #489CE5;font-size: 32rpx;">{{item.zhouqi +` Day`}} </view>
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;color:#8f8f8f;">
						<view>{{$lang.TRADE_EA_HIGHEST_RETURN}}</view>
						<!-- <view>to give </view> -->
					</view>
				</view>
			</block>
		</view>

		<template v-if="isShow">
			<EaBuy :info="itemInfo" @action="handleClose"></EaBuy>
		</template>
	</view>
</template>

<script>
	import {
		getTradeEAMaket
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	import EaBuy from '@/components/trade/ea/EaBuy.vue';
	export default {
		name: 'EaMarket',
		components: {
			EmptyData,
			EaBuy,
		},
		data() {
			return {
				list: [],
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			handleDetail(val) {
				console.log('val:', val);
				this.isShow = true;
				this.itemInfo = val;
				// this.curId = val;
				// this.show = true;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				const result = await getTradeEAMaket();
				if (result.jj_list.length > 0) {
					// 过滤掉不合格数据，当前以【gid】字段来判定。
					this.list = result.jj_list;
				}
			},
		}
	}
</script>

<style>
</style>