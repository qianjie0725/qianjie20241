<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto">
			<view class="popup_header" style="">
				{{info.name}}
				<image src="/static/close.png" mode="aspectFit" :style="$util.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view style="padding-bottom: 30rpx;">
				<view
					style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_EA_HIGHEST_RETURN}}</text>
					<text style="color: #E82D28;"> {{info.syl + ` %`}}</text>
				</view>

				<view class="common_input_wrapper" style="padding-left: 20px;margin:30rpx 40rpx;">
					<input v-model="amount" :placeholder="$lang.TRADE_EA_BUY_AMOUNT" type="number" style="width: 80%;"
						:placeholder-style="$util.setPlaceholder()"></input>
					<view style="padding:0 4px;color: #999;">{{$lang.CURRENCY_UNIT}}</view>
				</view>

				<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TIP_AMOUNT_AVAIL}}</text>
					<text :style="{color:'#FF6700'}">
						{{availBal}} {{$lang.CURRENCY_UNIT}}</text>
				</view>

				<view class="common_btn btn_primary" style="margin: 60rpx auto; width: 80%;" @tap.stop="handleBuy()">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		postTradeEABuy,
		accountInfo
	} from '@/common/api.js';
	export default {
		name: 'EaBuy',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
				amount: "", // 金额
				availBal: 0,
			}
		},
		computed: {

		},
		created() {
			this.gerUserInfo();
		},
		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},

			async handleBuy() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				const result = await postTradeEABuy({
					id: this.info.id,
					ganggan: 1,
					price: this.amount,
				});
				console.log(result);
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						this.actionEvent();
					}, 500);
				} else {
					uni.$u.toast(result.message);
				}
			},
			async gerUserInfo() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await accountInfo();
				uni.hideLoading();
				if (result.code == 0) {
					this.availBal = this.$util.formatNumber(result.data.money);
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>