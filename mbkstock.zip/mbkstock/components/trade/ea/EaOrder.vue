<template>
	<view style="padding: 10px;background-color: #FFFFFF;margin:20rpx;min-height: 100vh;">
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
				<!-- <TradeStockItem :item="item" @action="handleDetail"></TradeStockItem> -->
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
					<view style="flex:80%;">
						<view style="padding-left: 10px;font-size: 28rpx;color:#121212;">
							{{item.goodname}}
						</view>
					</view>

					<!-- <template v-if="item.status==1">
						<view class="access_btn" @click="handleDetail(item.id)"
							style="padding:6rpx 24rpx;margin:0;font-size: 28rpx;line-height: 1.4;">
							{{$lang.BTN_SELL}}
						</view>
					</template> -->
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_AMOUNT}}</view>
					<view style="color:#121212;">{{$util.formatNumber(item.price)}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_CYCLE}}</view>
					<view style="color:#121212;">{{item.zhouqi+` Day`}} </view>
					<view>{{$lang.TRADE_EA_ORDER_PERIOD}}</view>
					<view style="color:#121212;">{{item.fudu+` %`}}</view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_SN}}</view>
					<view style="color:#121212;">{{item.ordersn}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_LEVER}}</view>
					<view style="color:#121212;">{{item.ganggan}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_RATE}}</view>
					<view style="color:#121212;">{{$util.formatNumber(item.shouyi)}}  </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_DATE}}</view>
					<view style="color:#121212;">{{item.cretime}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>{{$lang.TRADE_EA_ORDER_END_DATE}}</view>
					<view style="color:#121212;">{{item.endtime}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import {
		// postTradeEABuy,
		getTradeEAMaket
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'EaOrder',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},

		methods: {
			async handleDetail(id) {
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_EA_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.handleSell(id);
				}
			},
			// async handleSell(id) {
			// 	const result = await postTradeEABuy({
			// 		id
			// 	});
			// 	if (result.code == 0) {
			// 		// this.getData()
			// 		uni.$u.toast(result.message);
			// 	} else {
			// 		uni.$u.toast(result.message);
			// 	}
			// 	this.getList();
			// },

			async getList() {
				this.list = []; // 请求前清除数据。
				const result = await getTradeEAMaket();
				if (result.order.length > 0) {
					this.list = result.order;
				}
			}
		}
	}
</script>

<style>
</style>