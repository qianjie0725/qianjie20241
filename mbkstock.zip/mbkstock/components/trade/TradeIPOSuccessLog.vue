<template>
	<view>
		<template v-if="!list || list.length<=0">
			<view class="common_block" style="padding:10px;margin-bottom: 20px;">
				<EmptyData></EmptyData>
			</view>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="padding:10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>{{item.goods.name}}</view>
						<view style="font-size: 16px;color:seagreen;">
							<view v-if="item.status==2" class="" @click="subscription(item)">구독하다</view>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.TIP}">공모가</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;">
							{{$util.formatNumber(item.price)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.TIP}">공모수량 </view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.apply_amount)}} 주
						</view>
					</view>
					
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.TIP}">청약당첨수량</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.success)}} 주
						</view>
					</view>
					
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.TIP}">청약당첨 금액 </view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;">
							{{$util.formatNumber(item.success_num_amount)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.TIP}">기납금액</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.freeze)}} 원
						</view>
					</view>
					
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.TIP}">미납금액</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{item.success*item.price-item.freeze>0?$util.formatNumber(item.success*item.price*1-item.freeze*1):0}} 원
						</view>
					</view>
					
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.TIP}">
						<view>거래 일자</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.TIP}">
						<view>거래 코드</view>
						<view>{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import {
		getIPOSuccessList,
		postIPOPay
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeIPOSuccessLog',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		created(option) {
			this.getList()
		},
		methods: {
			// 우승기록
			async getList() {
				const result = await getIPOSuccessList();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},

			async subscription(item) {
				const result = await postIPOPay({
					id: item.id
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					if (result.data.success == 0) {
						setTimeout(() => {
							uni.navigateTo({
								url: SERVICE,
							});
						}, 500)
					} else {
						uni.redirectTo({
							url: TRADE_IPO_SUCCESS,
						});
						this.$router.go(0)
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>