// import Vue from 'vue';
/* 将一些常用的放在这里，每个项目，注释掉未使用的那些常量及函数 */
const PRIMARY = '#722A3E'; // 通常为主要配色
const SECOND = '#14102B';
const THIRD = '#FF2D30';
const RISE = PRIMARY; // 涨/跌
const FALL = '#1C829B'; // 跌/涨
const TRANSPARENT = 'transparent'; // 使用父级元素颜色

const PROGRESS_FROM = '#722A3E'; // 进度条渐变 之一
const PROGRESS_TO = '#29205E'; // 进度条渐变 之二

const LOG_LABEL = '#666666'; // 一些记录的明文颜色
const LOG_VALUE = '#333333'; // 一些记录的数据颜色

const MODAL_VALUE ='#121212'; // 持仓销售弹层

const LABEL = '#CBCBCF'; // 列表的标题
// ACCESS_TEXT: '#FFFFFF', // 标题文字	
// TITLE: '#666666', // 
// STOCK_NAME: '#121212',
// FG: ' #AFAFAF',
// SECONDARY: '#FF8C00',
// // LABEL: '#F7F7F7',
// TEXT: '#333333', // D3D3D3
// TIP: '#333333',
// PLACEHOLDER: '#CBCBCF', // 输入框占位符

// flex布局相关
const DISPLAY_FLEX = {
	display: 'flex',
	alignItems: 'center',
};

// 渐变色设置
const linerGradient = (deg, from, to) => {
	return {
		backgroundImage: `linear-gradient(${deg}deg, ${from} ,${to})`
	}
};

// 启动页加载进度条
const progress = (obj) => {
	const style = {
		position: 'absolute',
		...obj,
		...linerGradient(180, PROGRESS_FROM, PROGRESS_TO),
	};
	return style;
}

// 按钮通用样式 之一 在tabs中为激活样式
const btnCommon = (isActive, obj = {}) => {
	let style = {
		...DISPLAY_FLEX,
		justifyContent: 'center',
		borderRadius: '16rpx',
		color: isActive ? '#FFFFFF' : PRIMARY,
		fontSize: '28rpx',
		// 非激活按钮有边框，为保证同等大小，激活需要加1像素值
		padding: `${isActive?'6px 26px' :'5px 25px'}`,
	};

	if (!isActive) {
		style.border = `2px solid ${PRIMARY}`;
	} else {
		style = {
			...style,
			...linerGradient(90, PRIMARY, PRIMARY),
		}
	}
	return style = {
		...style,
		...obj,
	};
}

// 交易记录 数据状态
const setStatusWithdraw = (val) => {
	const temp = [
		linerGradient(90, '#F87D7B', '#AFF8DF'),
		linerGradient(90, '#41EB87', '#3AF5C2'),
		linerGradient(90, '#FF2D30', '#FE7FD3'),
		linerGradient(90, '#FF2D30', '#FE7FD3'),
	]
	let style = {
		borderRadius: '4rpx',
		fontSize: '24rpx',
		padding: '4rpx 12rpx',
		color: '#14102B',
		width: 'max-content',
		...temp[val],
	};
	return style;
}



// 主题，一些通用的颜色值 硬编码
export default {
	PRIMARY,
	RISE,
	FALL,
	LOG_LABEL,
	LOG_VALUE,

	linerGradient,
	progress,
	btnCommon,
	setStatusWithdraw,



};