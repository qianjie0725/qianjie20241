// 多语言的语言选项
export const LANG_LIST = [
	// {
	// 	lang: 'en',
	// 	name: 'English',
	// 	icon: 'usa-80'
	// },
	{
		lang: 'zh',
		name: '中文简体',
		icon: 'china-80'
	},
	// {
	// 	lang: 'ja',
	// 	name: '日本語',
	// 	icon: 'japan-80'
	// }, 
	{
		lang: 'ko',
		name: '한국인',
		icon: 'korea-80'
	}
];

// 充值预置额
export const DEPOSIT_AMOUNTS = [1000000, 3000000, 5000000, 10000000];

// 银行备选列表
export const LIST_BANK = [
	"NH농협은행",
	"KB국민은행",
	"신한은행",
	"우리은행",
	"IBK기업은행",
	"KEB하나은행",
	"카카오뱅크",
	"대구은행",
	"부산은행",
	"MG새마을금고",
	"우체국",
	"광주은행",
	"경남은행",
	"신협중앙회",
	"수협",
	"SC제일은행",
	"케이뱅크",
	"KDB산업은행",
	"제주은행",
	"전북은행",
	"토스뱅크",
];