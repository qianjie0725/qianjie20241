<template>
	<view class="common_block" style="margin-top:20px;padding-bottom: 6px;">
		<view
			style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
			<text style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">{{ $lang.STOCK_HOT}}</text>
			<!-- <view style="font-size: 14px;" @click="handleAllList()" :style="{color:$util.THEME.TIP}">
				{{$lang.MORE}}
				<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
			</view> -->
		</view>
		<view>
			<EmptyData v-if="list && list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view @click="handleDetail(item.code)" class="line"
					style="padding-top: 6px;margin-left:10px;display: flex;align-items: center;font-size: 16px;">
					<view style="display: inline-block;flex:6%;">
						<template v-if="!item.logo || item.logo==''">
							<view :style="$util.calcImageSize(30)" style="background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">{{item.ko_name.slice(0,1)}}</view>
						</template>
						<template v-else>
							<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(30)" style="border-radius: 100%;"></image>
						</template>	
					</view>
					<view style="display: inline-block;flex:44%;padding-left: 6px;" :style="{color:$util.THEME.TEXT}">
						{{item.ko_name}}
					</view>
					<text style="display: inline-block;flex:25%;text-align: right;padding-right: 10px;"
						:style="$util.calcStyleRiseFall(item.returns>0)">{{$util.formatNumber(item.close*1)}}
					</text>
					<view
						style="border-radius: 3px;font-weight: 700; display: inline-block;flex:25%;text-align: right;margin-right: 10px;"
						:style="$util.calcStyleRiseFall(item.returns>0,true)">
						<view style="display: inline-block;padding-right:4px;">
							{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
						</view>
						<!-- <image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
							:style="$util.calcImageSize(12)"></image> -->
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
		},
		methods: {
			handleAllList() {
				console.log('???')
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_ALL}?type=0`,
				})
			},
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {
				// if (this.list.length <= 0) {
				// 	uni.showLoading({
				// 		title: this.$lang.LOADING,
				// 	})
				// }
				const result = await this.$http.get(this.$http.API_URL.GOODS_LIST, {
					page: 1,
					gp_index: 0
				})
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>