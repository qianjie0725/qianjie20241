<!-- 个人交易 交易信息 -->
<template>
	<view>
		<view class="bg_trade_info">
			<view class="flex padding-top-10 padding-bottom-10">
				<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;"></view>
				<view class="margin-left-10 bold font-size-16" :style="{color:$util.THEME.LABEL}">205-01-{{info.uid}}
				</view>
				<view class="margin-left-5 hui font-size-10 ">[CMA]{{info.real_name}}</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding:0 10px 10px 10px;">
				<view style="font-size: 24px;font-weight: 700;" :style="{color:$util.THEME.LABEL}">
					{{$util.formatNumber(info.money)}}
				</view>
				<view class="common_btn btn_secondary" style="width: 20%;" @click="handleDeposit">{{$lang.DEPOSIT}}</view>
			</view>
		</view>

		<view class="common_block" style="padding:10px;margin:10px;">
			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.TOTAL_BUY_AMOUNT}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(info.frozen)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.VALUATION_GAIN_LOSS}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.holdYingli)}}
					</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.VALUATION_GAIN_LOSS_AMOUNT}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.guzhi)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.RATE_RESPONSE}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{info.huibao}}%
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.AMOUNT_TOTAL}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.totalZichan)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.TOTAL_GAIN}}
					</view>
					<view style="display: inline-block;padding-left: 4px;"
						:style="$util.calcStyleRiseFall(info.totalYingli>0)">
						{{$util.formatNumber(info.totalYingli)}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		data() {
			return {
				info: {},
			};
		},
		mounted() {
			this.getUserInfo()
		},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})

				if (result.data.code == 0) {
					this.info = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>