# kdbglobal

![LOGO](https://github.com/github1413/kdbglobal/raw/main/static/logo.png)

# **注意！**
- 提交前比继续进行拉取操作。
- 版本冲突时，对比代码再合并。
- 非必要，`.gitignore`中只添加忽略文件及文件夹。
- 无需上传的文件，在 `.gitignore`中按照格式添加。
 
## 环境及配置

- 安装nodejs 最新稳定版
- 安装 nvm for win版本
- HbuilderX打开项目，在项目根目录下，执行以下命令 	`npm install`
- 其他操作，与过去相同。