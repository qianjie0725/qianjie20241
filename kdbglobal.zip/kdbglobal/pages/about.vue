<!-- 关于我们 -->
<template>
	<view >
		<view class="header_wrapper_10">
			<CustomHeader :title="about.title" @action="handleBack()"></CustomHeader>
		</view>
		<view class="common_block" style="margin-top: 10px;">
			<view v-html="about.content" style="font-size: 14px;white-space: break-spaces;line-height: 1.3;padding:10px;" :style="{color:$util.THEME.TEXT}"></view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				about: ''
			};
		},
		mounted() {
			this.getAbout()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//关于我们
			async getAbout() {
				const result = await this.$http.get(this.$http.API_URL.ABOUT_US, {})
				this.about = result.data.data
			},
		},
	}
</script>