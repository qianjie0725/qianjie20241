<template>
	<view>
		<CustomHeader title="스마트 주문" @action="$u.route({type:'navigateBack'});"></CustomHeader>

		<view style="justify-content: center;width: 90%;margin-left: 5%;"
			class="radius30 padding-top-20 margin-top-10">
			<view class="flex flex-b" style="border-radius: 0 0px 14px 14px;">
				<!-- 持有记录 -->
				<view class="flex-1 justify-center flex" @click="handleOderList()" v-if="current==1">
					<view
						style="width: 100%;flex-direction: column;display: flex;justify-content: center; text-align: center;align-items: center; ">
						<u-image src="/static/lishi.png" style="" width="30" height="30"></u-image>
						<view class="margin-top-10">보유주문</view>
					</view>
				</view>
				<!-- 卖出记录 -->
				<!-- <view class="flex-1 justify-center flex" @click="handleOderList()" v-if="current==1">
					<view
						style="width: 100%;flex-direction: column;display: flex;justify-content: center; text-align: center;align-items: center; ">
						<u-image src="/static/market/order.png" style="" width="30" height="30"></u-image>
						<view class="margin-top-10">거래기록</view>
					</view>
				</view> -->
				<!-- 交易记录 -->
				<view class="flex-1 justify-center flex" @tap="handleBuyLog()" v-if="current==1">
					<view
						style="width: 100%;flex-direction: column;display: flex;justify-content: center; text-align: center;align-items: center; ">
						<u-image src="/static/order.png" width="30" height="30"></u-image>
						<view class="margin-top-10">거래기록</view>
					</view>
				</view>

			</view>
		</view>

		<view v-if="current==0">
			<shortTrade></shortTrade>
		</view>
		<view v-if="current==1">
			<blockTrade></blockTrade>
		</view>
		<view v-if="current==2">
			<discountedTransaction></discountedTransaction>
		</view>
		<view v-if="current==3">
			<applyPurchase :newShares_list2='newShares_list2' :newShares_list='newShares_list'></applyPurchase>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import shortTrade from "@/components/new-shares/shortTrade.vue";
	import discountedTransaction from "@/components/new-shares/discountedTransaction.vue";
	import applyPurchase from "@/components/new-shares/applyPurchase.vue";
	import newShareRaising from "@/components/new-shares/newShareRaising.vue";
	// import subscriptionBonds from "@/components/new-shares/subscriptionBonds.vue";
	// import newBondPlacement from "@/components/new-shares/newBondPlacement.vue";
	import blockTrade from "@/components/new-shares/blockTrade.vue";
	import vipScramble from "@/components/new-shares/vipScramble.vue";
	export default {
		components: {
			CustomHeader,
			shortTrade,
			discountedTransaction,
			applyPurchase,
			newShareRaising,
			// subscriptionBonds,
			// newBondPlacement,
			blockTrade,
			vipScramble,

		},
		data() {
			return {
				current: this.current,
				list: [{
						name: '청약 신청'
					}, {
						name: '청약 내역'
					},
					// {
					// 	name: '新债申购',
					// },
					// {
					// 	name: "新债配售",
					// },
					{
						name: '기관 거래 우선가',
					}, {
						name: 'VIP 우대'
					},
				],
				newShares_list: [],
				newShares_list2: [],

			};
		},

		onLoad(item) {
			this.newShares()
			this.newShares2()
			this.current = Number(item.index);
		},
		methods: {
			// 跳转到大宗订单列表页面
			handleOderList() {
				uni.navigateTo({
					url: `/pages/index/components/newShares/blockTradeSell`
				});
			},
			//구독기록
			handleBuyLog() {
				// 短打交易  大宗交易 折价交易 新股申购 
				const urls = ['shortTradeLog', 'blockTransactions/blockTransactions', 'discountedTransactionLog',
					'applyPurchase/applyPurchase'
				];
				uni.navigateTo({
					url: `/pages/index/components/newShares/${urls[this.current]}`,
				});
			},
			//우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},
			select(item) {
				this.current = item;
			},
			//新股申购
			async newShares() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 1,
				})
				this.newShares_list = list.data.data
			},
			async newShares2() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 2,
				})
				this.newShares_list2 = list.data.data
				// console.log(list.data.data, '구독 예정');
			},
		},

	}
</script>

<style lang="scss">
	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>