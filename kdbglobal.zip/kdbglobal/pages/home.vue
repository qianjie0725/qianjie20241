<!-- 主页 -->
<template>
	<view>
		<view class="header_wrapper">
			<Header :title="$lang.HOME"></Header>
		</view>
		<ButtonGroup :btns="$util.BTNS_CONFIG_HOME"></ButtonGroup>
		<GoodsList ref="goods"></GoodsList>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
			}
		},
		onShow() {
			this.startTimer();
			if (this.$refs.goods) {
			this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			handleIPO(){
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.$refs.goods.getList();
				}, 3000);
			},
			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
		},
	}
</script>