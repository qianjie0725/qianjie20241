<template>
	<view>
		<view class="info flex flex-b" style="padding:0">
			<view class="flex-1">
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">기업순위</view>
					<view class="t" style="color:#333333;font-weight: 700;">코스닥
						{{top1.marketcap_rank}}위
					</view>
				</view>
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">주식수</view>
					<view class="t num-font" style="color:#333333;font-weight: 700;">
						{{top1.sharesout.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}주
					</view>
				</view>
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">산업군</view>
					<view class="t" style="color:#333333;font-weight: 700;">{{top1.sector}}</view>
				</view>
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">52주 최고</view>
					<view class="red num-font" style="font-weight: 700;">
						{{top1.year_high.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
			</view>
			<view class="flex-1">
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">평가금액</view>
					<view class="t num-font" style="color:#333333;font-weight: 700;">
						{{top1.marketcap.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}억
					</view>
				</view>
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">외국인비중</view>
					<view class="t" style="color:#333333;font-weight: 700;">
						{{top1.foreigners_pie.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}%
					</view>
				</view>
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">세부산업군</view>
					<view class="t" style="color:#333333;font-weight: 700;">{{top1.industry}}</view>
				</view>
				<view style="background-color: #F6F8FC;margin:10px;border-radius: 10px;padding:6px;text-align: center;">
					<view style="color:#333333;">52주 최저</view>
					<view class="blue num-font" style="font-weight: 700;">
						{{top1.year_low.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
			</view>
		</view>
		<view class="about">
			<view class="flex flex-b">
				<view class="t">기업개요</view>
				<view class="t1" style="color:#2E67F6" @click="showFullCompany()">{{txt_show==true?'간략히':'더보기'}}
					<image src="/static/arrow_down.png" mode="aspectFit" style="width: 30rpx;height: 30rpx;"
						:style="{transform:`rotate(${txt_show==true?0:180}deg)` }"></image>
				</view>
			</view>

			<view class="txt" :class="txt_show?'show':''" style="white-space:pre-wrap;">
				{{top2.description}}
			</view>
		</view>
		<view class="xs">
			<view class="flex flex-b tb">
				<view style="font-size: 17px;font-weight: 700;color: #333;">판매량</view>
				<view class="flex-1 t-r t" style="color:#666666;" v-if="info_two_ac==0&&top3">기준
					{{top3[0].report_year_month}}
				</view>
				<view class="flex-1 t-r t" style="color:#666666;" v-if="info_two_ac==1&&top33">기준
					{{top33[0].report_year_month}}
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-around;margin:10px 60px;">
				<view style="line-height: 24px;text-align: center;border-radius: 10px;padding:6px 20px;"
					:style="{backgroundColor:info_two_ac==0?'#2E67F6':'#F6F8FC',color:info_two_ac==0?'#FFFFFF':'#666666'}"
					@click="qh_info_two(0)">분기매출</view>

				<view
					style="background-color:#F6F8FC;line-height: 24px;text-align: center;border-radius: 10px;padding:6px 20px;"
					:style="{backgroundColor:info_two_ac==1?'#2E67F6':'#F6F8FC',color:info_two_ac==1?'#FFFFFF':'#666666'}"
					@click="qh_info_two(1)">연간매출</view>
			</view>


			<view class="nums" style="background-color: transparent;" v-if="info_two_ac==0&&top3">
				<view class="t" style="color:#666666;">전분기대비</view>
				<view class="flex flex-b">
					<view class="item" style="background-color: #F6F8FC;">
						<view class="t1">최근 매출액</view>
						<view class="t2" :class="top3[0].fields[29].value/100000000>0?'':'die'">
							{{number_geshi(top3[0].fields[29].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top3[0].fields[42].value*1>0?'':'die'">
							{{(top3[0].fields[42].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item" style="background-color: #F6F8FC;">
						<view class="t1">최근 영업이익</view>
						<view class="t2" :class="top3[0].fields[32].value/100000000>0?'':'die'">
							{{number_geshi(top3[0].fields[32].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top3[0].fields[81].value*1>0?'':'die'">
							{{(top3[0].fields[81].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item" style="background-color: #F6F8FC;">
						<view class="t1">최근 순이익</view>
						<view class="t2" :class="top3[0].fields[36].value/100000000>0?'':'die'">
							{{number_geshi(top3[0].fields[36].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top3[0].fields[83].value*1>0?'':'die'">
							{{(top3[0].fields[83].value).toFixed(2)}}%
						</view>
					</view>
				</view>
			</view>
			<view class="nums" style="background-color: transparent;" v-if="info_two_ac==1&&top33">
				<view class="t" style="color:#666666;">전분기대비</view>
				<view class="flex flex-b">
					<view class="item" style="background-color: #F6F8FC;">
						<view class="t1">최근 매출액</view>
						<view class="t2" :class="top33[0].fields[29].value/100000000>0?'':'die'">
							{{number_geshi(top33[0].fields[29].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top33[0].fields[43].value*1>0?'':'die'">
							{{(top33[0].fields[43].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item" style="background-color: #F6F8FC;">
						<view class="t1">최근 영업이익</view>
						<view class="t2" :class="top33[0].fields[32].value/100000000>0?'':'die'">
							{{number_geshi(top33[0].fields[32].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top33[0].fields[82].value*1>0?'':'die'">
							{{(top33[0].fields[82].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item" style="background-color: #F6F8FC;">
						<view class="t1">최근 순이익</view>
						<view class="t2" :class="top33[0].fields[36].value/100000000>0?'':'die'">
							{{number_geshi(top33[0].fields[36].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top33[0].fields[84].value*1>0?'':'die'">
							{{(top33[0].fields[84].value).toFixed(2)}}%
						</view>
					</view>
				</view>
			</view>
			<view class="chart-box">
				<view
					style="display: flex;align-items: center;justify-content: space-around;margin:10px 20px;margin-bottom: 20px;">
					<view style="line-height: 24px;text-align: center;border-radius: 10px;padding:6px 20px;"
						:style="{backgroundColor:zhexian_index==0?'#2E67F6':'#F6F8FC',color:zhexian_index==0?'#FFFFFF':'#666666'}"
						@click="zhexian_act(0)">매출액</view>

					<view
						style="background-color:#F6F8FC;line-height: 24px;text-align: center;border-radius: 10px;padding:6px 20px;"
						:style="{backgroundColor:zhexian_index==1?'#2E67F6':'#F6F8FC',color:zhexian_index==1?'#FFFFFF':'#666666'}"
						@click="zhexian_act(1)">영업이익</view>
					<view
						style="background-color:#F6F8FC;line-height: 24px;text-align: center;border-radius: 10px;padding:6px 20px;"
						:style="{backgroundColor:zhexian_index==2?'#2E67F6':'#F6F8FC',color:zhexian_index==2?'#FFFFFF':'#666666'}"
						@click="zhexian_act(2)">순이익</view>
				</view>

				<view id="main" class="chart">
					<!-- 折线图 -->
					<canvas canvas-id="zhexian" id="zhexian" class="charts" />
				</view>
			</view>
			<view>
				<view>
					<view class="flex flex-b top">
						<view class="t">투자자별 매매동향</view>
						<view class="t1" style="font-size: 13px;">기준 {{top4['net_volume'].dt}}</view>
					</view>

					<view style="font-size: 15px; font-weight: 500;text-align:  center;">순매수량</view>
					<view style="display: flex;align-items: center;margin:10px 4px;">
						<view
							style="flex:33%; background-color: #F6F8FC;border-radius: 10px;padding:10px;text-align: center;margin:6px;line-height: 2;">
							<view style="color:#666666;">개인</view>
							<view :style="{color:top4['net_volume'].net_vol_individual>0?'#FF533B':'#14CF76'}">
								{{number_geshi1(top4['net_volume'].net_vol_individual)}}
							</view>
						</view>
						<view
							style="flex:33%; background-color: #F6F8FC;border-radius: 10px;padding:10px;text-align: center;margin:6px;line-height: 2;">
							<view style="color:#666666;">기관</view>
							<view :style="{color:top4['net_volume'].net_vol_institutional>0?'#FF533B':'#14CF76'}">
								{{number_geshi1(top4['net_volume'].net_vol_institutional)}}
							</view>
						</view>
						<view
							style="flex:33%; background-color: #F6F8FC;border-radius: 10px;padding:10px;text-align: center;margin:6px;line-height: 2;">
							<view style="color:#666666;">외인</view>
							<view :style="{color:top4['net_volume'].net_vol_foreigner>0?'#FF533B':'#14CF76'}">
								{{number_geshi1(top4['net_volume'].net_vol_foreigner)}}
							</view>
						</view>
					</view>

					<view style="font-size: 15px; font-weight: 500;text-align:  center;">누적순매수량</view>
					<view style="display: flex;align-items: center;margin:10px 4px;">
						<view
							style="flex:33%; background-color: #F6F8FC;border-radius: 10px;padding:10px;text-align: center;margin:6px;line-height: 2;">
							<view style="color:#666666;">개인</view>
							<view :style="{color:top4['cum_volume'].cum_vol_individual>0?'#FF533B':'#14CF76'}">
								{{number_geshi1(top4['cum_volume'].cum_vol_individual)}}
							</view>
						</view>
						<view
							style="flex:33%; background-color: #F6F8FC;border-radius: 10px;padding:10px;text-align: center;margin:6px;line-height: 2;">
							<view style="color:#666666;">기관</view>
							<view :style="{color:top4['cum_volume'].cum_vol_institutional>0?'#FF533B':'#14CF76'}">
								{{number_geshi1(top4['cum_volume'].cum_vol_institutional)}}
							</view>
						</view>
						<view
							style="flex:33%; background-color: #F6F8FC;border-radius: 10px;padding:10px;text-align: center;margin:6px;line-height: 2;">
							<view style="color:#666666;">외인</view>
							<view :style="{color:top4['cum_volume'].cum_vol_foreigner>0?'#FF533B':'#14CF76'}">
								{{number_geshi1(top4['cum_volume'].cum_vol_foreigner)}}
							</view>
						</view>
					</view>


					<!-- <view class="pdd">
						<view>누적순매수량</view>
						<view class="flex flex-b last">
							<view>개인<span
									:class="top4['cum_volume'].cum_vol_individual>0?'':'die'">{{number_geshi1(top4['cum_volume'].cum_vol_individual)}}</span>
							</view>
							<view>기관<span
									:class="top4['cum_volume'].cum_vol_institutional>0?'':'die'">{{number_geshi1(top4['cum_volume'].cum_vol_institutional)}}</span>
							</view>
							<view>외인<span
									:class="top4['cum_volume'].cum_vol_foreigner>0?'':'die'">{{number_geshi1(top4['cum_volume'].cum_vol_foreigner)}}</span>
							</view>
						</view>
					</view> -->
				</view>
				<view class="list"
					style="background-color: #F6F8FC;border-radius: 10px;margin:10px;padding-top: 0;border-top-left-radius: 10px;border-top-right-radius: 10px;">
					<view class="flex flex-b titles"
						style="margin:0;border-top-left-radius: 10px;border-top-right-radius: 10px;color:#2E67F6;background-color: #E9EFFF;">
						<view style="flex:30%;text-align: center;">날짜</view>
						<view style="flex:25%;text-align: center;">개인</view>
						<view style="flex:25%;text-align: right;">기관</view>
						<view style="flex:20%;text-align: center;">외인</view>
					</view>
					<view class="flex flex-b item" v-for="(item,index) in top5">
						<view style="flex:30%;">{{item.dt}}</view>
						<view style="flex:25%;text-align: right;"
							:style="{color:item.net_vol_individual>0?'#FF533B':'#14CF76'}">
							{{number_geshi1(item.net_vol_individual)}}
						</view>
						<view style="flex:25%;text-align: right;"
							:style="{color:item.net_vol_institutional>0?'#FF533B':'#14CF76'}">
							{{number_geshi1(item.net_vol_institutional)}}
						</view>
						<view style="flex:20%;text-align: right;"
							:style="{color:item.net_vol_foreigner>0?'#FF533B':'#14CF76'}">
							{{number_geshi1(item.net_vol_foreigner)}}
						</view>
					</view>
				</view>

				<view class="list mborder">
					<!-- <view class="flex flex-b tb">
						<view class="flex flex-b flex-1 tabs">
							<view class="active">자산비율</view>
							<view class="">매출구성</view>
						</view>
						<view class="flex-1"></view>
					</view> -->
					<view class="flex flex-b">
						<canvas canvas-id="huan1" id="huan1" class="charts" />
					</view>
				</view>
			</view>
			<view>
				<view class="top">
					<view class="t" style="margin-bottom: 16px;">공매도 거래량</view>
					<view style="border:1px solid #E8EAF3; border-radius: 10px;line-height: 2;padding:10px;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="t2" >공매도 거래량</view>
							<view class="t4">{{top7[0].dt}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="t3" style="font-size: 16px;font-weight: 700;color:#14CF76;">
								{{top7[0].short_volume}}주
							</view>
							<view class="t4">{{top7[0].short_volume_weight}}%</view>
						</view>
						<view class="t2" style="color:#666666;">전체 거래량 대비</view>
					</view>
					<view
						style="border:1px solid #E8EAF3; border-radius: 10px;line-height: 2;padding:10px;margin-top: 10px;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="t2">공매도 잔고</view>
							<view class="t4">{{top7[1].dt}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="t3" style="font-size: 16px;font-weight: 700;color:#14CF76;">
								{{top7[1].short_volume}}주
							</view>
							<view class="t4">{{top7[1].short_volume_weight}}%</view>
						</view>
						<view class="t2" style="color:#666666;">시가총액 대비</view>
					</view>
				</view>
			</view>

			<view class="flex flex-b top" style="padding:10px 16px;">
				<view class="t">업종 내 비교</view>
				<view class="t1">자동차부품 {{top8.count}} 개중</view>
			</view>

			<view class="list"
				style="background-color: #F6F8FC;border-radius: 10px;margin:10px;padding-top: 0;border-top-left-radius: 10px;border-top-right-radius: 10px;">
				<view class="flex flex-b titles"
					style="margin:0;border-top-left-radius: 10px;border-top-right-radius: 10px;color:#2E67F6;background-color: #E9EFFF;">
					<view style="flex:30%;text-align: center;"></view>
					<view style="flex:25%;text-align: center;">현 종목</view>
					<view style="flex:25%;text-align: center;">업종평균</view>
					<view style="flex:20%;text-align: center;">업종내순위</view>
				</view>

				<view style="margin:0;display: flex;align-items: center;padding:6px;">
					<view style="flex:25%;">평가금액</view>
					<view style="flex:25%;text-align: right;" :style="{color:top8.marketcap>0?'#FF533B':'#14CF76'}">
						{{top8.marketcap}}억</view>
					<view style="flex:30%;text-align: right;" :style="{color:top8.marketcap_avg>0?'#FF533B':'#14CF76'}">
						{{top8.marketcap_avg}} 억</view>
					<view style="flex:20%;text-align: right;">{{top8.marketcap_rank}}위</view>
				</view>

				<view style="margin:0;display: flex;align-items: center;padding:6px;">
					<view style="flex:25%;">순이익증가율</view>
					<view style="flex:25%;text-align: right;"
						:style="{color:top8.net_income_growth>0?'#FF533B':'#14CF76'}">{{top8.net_income_growth}}%</view>
					<view style="flex:30%;text-align: right;"
						:style="{color:top8.net_income_growth_avg>0?'#FF533B':'#14CF76'}">
						{{top8.net_income_growth_avg}}%</view>
					<view style="flex:20%;text-align: right;">{{top8.net_income_growth_rank}}위</view>
				</view>

				<view style="margin:0;display: flex;align-items: center;padding:6px;">
					<view style="flex:25%;">부채비율</view>
					<view style="flex:25%;text-align: right;" :style="{color:top8.debt_ratio>0?'#FF533B':'#14CF76'}">
						{{top8.debt_ratio}}%</view>
					<view style="flex:30%;text-align: right;"
						:style="{color:top8.debt_ratio_avg>0?'#FF533B':'#14CF76'}">{{top8.debt_ratio_avg}}%</view>
					<view style="flex:20%;text-align: right;">{{top8.debt_ratio_rank}}위</view>
				</view>

				<view style="margin:0;display: flex;align-items: center;padding:6px;">
					<view style="flex:25%;">PER</view>
					<view style="flex:25%;text-align: right;" :style="{color:top8.per>0?'#FF533B':'#14CF76'}">
						{{top8.per}}배</view>
					<view style="flex:30%;text-align: right;" :style="{color:top8.per_avg>0?'#FF533B':'#14CF76'}">
						{{top8.per_avg}}배</view>
					<view style="flex:20%;text-align: right;">{{top8.per_rank}}위</view>
				</view>

				<view style="margin:0;display: flex;align-items: center;padding:6px;">
					<view style="flex:25%;">PBR</view>
					<view style="flex:25%;text-align: right;" :style="{color:top8.pbr>0?'#FF533B':'#14CF76'}">
						{{top8.pbr}}배</view>
					<view style="flex:30%;text-align: right;" :style="{color:top8.pbr_avg>0?'#FF533B':'#14CF76'}">
						{{top8.pbr_avg}}배</view>
					<view style="flex:20%;text-align: right;">{{top8.pbr_rank}}위</view>
				</view>
				<view style="margin:0;display: flex;align-items: center;padding:6px;">
					<view style="flex:25%;">ROE</view>
					<view style="flex:25%;text-align: right;" :style="{color:top8.roe>0?'#FF533B':'#14CF76'}">
						{{top8.roe}}%</view>
					<view style="flex:30%;text-align: right;" :style="{color:top8.roe_avg>0?'#FF533B':'#14CF76'}">
						{{top8.roe_avg}}%</view>
					<view style="flex:20%;text-align: right;">{{top8.roe_rank}}위</view>
				</view>
			</view>
		</view>
	</view>

</template>

<script>
	import zhexian from '@/utils/zhexian.js';
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name: 'InfoTwo',
		components: {
			zhexian
		},
		props: ['code', 'productDetails'],
		data() {

			return {
				cWidth: 750,
				cHeight: 500,
				top1: {
					sharesout: 0,
					year_high: 0,
					marketcap: 0,
					foreigners_pie: 0,
					year_low: 0
				},
				top2: [],
				top3: "",
				top33: "",
				top4: "",
				top5: "",
				top7: "",
				top8: '',
				txt_show: true,
				info_two_ac: 0,
				zhexian_index: 0,
				zhexian_index_i: 29
			}
		},

		methods: {
			// 公司信息，简信及完整切换
			showFullCompany() {
				this.txt_show = !this.txt_show;
			},

			qh_info_two(index) {
				this.info_two_ac = index;
				if (index == 0) {
					this.info_two()
				} else {
					this.info_two1()
				}
			},
			number_geshi1(price) {
				var fuhao = "";
				if (price * 1 > 0) {
					fuhao = "+";
				}
				var price = fuhao + price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

				return price;
			},
			number_geshi(prices, index) {
				var prices = (prices * 1).toFixed(index);
				if (prices > 0) {
					prices = "+" + prices;
				}
				return prices;
			},

			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "ring",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					series: data.series,
					animation: true,
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					fontSize: 13,
					fontColor: "#666666",
					dataLabel: true,
					dataPointShape: true,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					enableScroll: false,
					enableMarkLine: false,
					legend: {
						show: true,
						position: "right",
						lineHeight: 25,
						float: "left",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						hiddenColor: "#CECECE",
						itemGap: 10
					},
					// title: {
					//   name: "2,515억",
					//   fontSize: 15,
					//   color: "#666666",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					// subtitle: {
					//   name: "자산총계",
					//   fontSize: 25,
					//   color: "#7cb5ec",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					extra: {
						ring: {
							ringWidth: 30,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF",
							centerColor: "#FFFFFF",
							customRadius: 0,
							linearType: "none"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: true,
							legendShape: "auto",
							splitLine: true,
							horizentalLine: false,
							xAxisLabel: false,
							yAxisLabel: false,
							labelBgColor: "#FFFFFF",
							labelBgOpacity: 0.7,
							labelFontColor: "#666666"
						}
					}
				});
			},
			async info_two() {
				uni.showLoading({
					mask: true
				})
				let list = await this.$http.post('api/product/info_two', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})

				this.top1 = list.data.data[0].top1
				this.top2 = list.data.data[0].top2
				this.top3 = list.data.data[0].top3
				this.top4 = list.data.data[0].top4
				this.top5 = list.data.data[0].top5
				this.top7 = list.data.data[0].top7
				this.top8 = list.data.data[0].top8

				this.zhexian()
				let res = {
					series: [{
						data: list.data.data[0].top6
					}]
				};
				this.drawCharts('huan1', res);
				uni.hideLoading()
			},
			zhexian_act(index) {
				this.zhexian_index = index;

				if (index == 0) {
					this.zhexian_index_i = 29
				} else if (index == 1) {
					this.zhexian_index_i = 32
				} else if (index == 2) {
					this.zhexian_index_i = 36
				}

				this.zhexian()
			},
			zhexian() {
				var zhexian_index_i = this.zhexian_index_i
				if (this.info_two_ac == 0) {
					var top = this.top3;
				} else {
					var top = this.top33;
				}
				let res = {
					categories: [top[3].report_year_month, top[2].report_year_month, top[1].report_year_month, top[0]
						.report_year_month
					],
					series: [{
						name: "",
						data: [top[3].fields[zhexian_index_i].value / 100000000, top[2].fields[zhexian_index_i]
							.value / 100000000, top[1].fields[zhexian_index_i].value / 100000000, top[0]
							.fields[zhexian_index_i].value / 100000000
						]
					}]
				};
				const ctx = uni.createCanvasContext("zhexian", this);
				uChartsInstance["zhexian"] = new uCharts(zhexian.Charts(ctx, res, this.cWidth, this.cHeight))

			},
			async info_two1() {
				let list = await this.$http.post('api/product/info_two1', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})
				this.top33 = list.data.data[0].top3
				this.zhexian_act(0)
			},
		},

		mounted() {
			this.info_two()
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(750);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);


			//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接

		},

		onLoad() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>
<style scoped>
	.charts {
		width: 750rpx;
		height: 500rpx;
	}
</style>
<style lang="scss">
	.info {
		padding: 0 16px 16px;

		uni-view {
			color: #666;
			line-height: 32px;
		}

		.t {
			color: #333;
		}

		.red {
			color: red;
		}

		.blue {
			color: #014b8d;
		}
	}

	.about {
		// border-top: 5px solid #f0f2f5;
		// border-bottom: 5px solid #f0f2f5;
		padding: 16px;

		.t {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			color: #999;
		}

		.txt {
			margin-top: 16px;
			color: #333;
			line-height: 26px;
		}

		.txt.show {
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
		}
	}

	.xs {
		padding: 16px 0;

		.tb {
			padding: 0 16px 10px;
		}

		.tabs {
			background: #f1f2f4;
			border-radius: 5px;
			height: 32px;
			padding: 0 5px;

			.t {
				font-size: 12px;
				color: #999;
			}

			.active {
				color: #014b8d;
				background: #fff;
				border-radius: 3px;
			}

			uni-view {
				color: #014b8d;
				height: 26px;
				line-height: 26px;
				text-align: center;
				-webkit-box-flex: 1;
				-webkit-flex: 1;
				flex: 1;
			}
		}

		.nums {
			background: #f0f3fa;
			border-radius: 10px;
			padding: 5px;
			margin: 0 5px;
			text-align: center;

			.t {
				padding: 10px 0;
			}

			.item {
				background: #fff;
				border-radius: 8px;
				padding: 16px 0;
				width: 32%;

				.t1 {
					color: #666666;
				}

				.t2 {
					font-size: 21px;
					font-family: Roboto;
					font-weight: 700;
					color: #ff3636;
					margin: 10px 0;
				}

				.t3 {
					font-size: 19px;
					font-family: Roboto;
					font-weight: 400;
					color: #ff3636;
				}

				.die {
					color: #14CF76;
				}
			}
		}

		.chart-box {
			padding: 16px 5px 10px;
			// border-top: 5px solid #f0f2f5;
			// border-bottom: 5px solid #f0f2f5;
			margin-top: 16px;
		}
	}

	.top {
		padding: 16px;

		.t {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			font-size: 12px;
			color: #999;
		}

		.item {
			background: #f1f2f4;
			border-radius: 10px;
			width: 42%;
			padding: 16px 10px;

			.t1 {
				font-size: 17px;
				font-weight: 700;
				color: #333;
			}

			.t2 {
				color: #999;
			}

			.t3 {
				font-size: 17px;
				font-weight: 700;
				color: #14CF76;
				margin-right: 5px;
			}

			.t4 {
				color: #333;
			}

			.mtb {
				margin: 16px 0;
			}
		}
	}

	.cot {
		border-top: 5px solid #f0f2f5;
		border-bottom: 5px solid #f0f2f5;

		.tb {
			padding: 16px 16px 0;
		}
	}

	.border {
		border-bottom: 1px solid #dcdee0;
	}

	.pdd {
		padding: 16px 10px;

		.t2 {
			color: #333;
			font-size: 17px;
		}
	}

	.last {
		padding: 16px 0 0;

		uni-view {
			color: #333;
		}

		.die {
			color: #14CF76;
		}

		span {
			font-family: Roboto;
			font-weight: 700;
			color: #f72121;
		}
	}

	.list {
		// border-top: 5px solid #f0f2f5;
		// border-bottom: 5px solid #f0f2f5;
		padding: 16px 0;

		.tb {
			padding: 0 16px 16px;
		}

		.tabs {
			background: #f1f2f4;
			border-radius: 5px;
			height: 32px;
			padding: 0 5px;

			.active {
				color: #014b8d;
				background: #fff;
				border-radius: 3px;
			}
		}

		.mb20 {
			margin-bottom: 10px;
		}

		.titles {
			padding: 10px;
			background: #f0f2f5;
		}

		.item {
			padding: 10px;

			.time {
				color: #333;
			}

			.red.die {
				color: #14CF76;
			}

			.red {
				font-family: Roboto;
				font-weight: 700;
				color: #f72121;
			}
		}
	}

	.title {
		background: #f0f2f5;
		padding: 10px;
	}

	.item {
		padding: 10px;

		.red {
			font-family: Roboto;
			font-weight: 700;
			color: #f72121;
		}

		uni-view {
			color: #333;
		}

		.red.die {
			color: #14CF76;
		}
	}
</style>