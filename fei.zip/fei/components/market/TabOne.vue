<template>
	<view>
		<!-- <view class="flex padding-top-20 padding-bottom-10">
			<view class="margin-left-20 bold">국내종목</view>
		</view>
		<view style="padding:10px 40px;display: flex;align-items: center;justify-content: space-around;">
			<view v-for="(item,index) in top11" class="text-center color-white radius10" 
				:class="current1==index?'current1-a':'current1'" style="padding: 5px 10px;flex:30%;margin: 0 10px;" @click='qiehuan(index)'>
				{{item}}
			</view>
		</view>
		<view style="border-radius: 10px;background: #fff;margin: 10px;padding: 10px;">
			<view style="display: flex;align-items:center;">
				<block v-for="(item,index) in top1" :key="index">
					<view
						style="flex:33%;margin:6px;padding:10px;background-color: #F6F8FC;border:2px solid rgba(0, 0, 0, 0);border-radius: 10px;"
						:style="klineindex==index?`border-color:${item.rate>0?'#FF533B':'#14CF76'}`:'border-color:rgba(0, 0, 0, 0)' "
						@click='qiehuan111(index)'>
						<view style="text-align: center;">{{top111[index]}}</view>
						<view class="t num-font" :class="item.rate>0?'red':'green'" style="text-align: center;">
							{{item.close}}</view>
						<view class="t1 " :class="item.rate>0?'red':'green'" style="text-align: center;">
							{{(item.rate)}}%</view>
					</view>
				</block>
			</view>

			<view style="margin: 10px;">
				<view class="chart" id="chart-type-k-line" style="width: 100%;height: 300rpx;">
				</view>
			</view>
		</view>

		<view class="flex padding-top-10 padding-bottom-10">
			<view class="margin-left-20 bold">국내종목</view>
		</view>
		<view style="border-radius: 10px;background: #fff;margin: 10px;">


			<view class="flex flex-b padding-10">
				<view v-for="(item,index) in article" v-if="index<=1" @click="open(item.url)" style="width: 49%;">
					<image :src="item.pic"
						style="width: 100%;height: 117px;border-radius: 8px;box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;">
					</image>
					<view class="margin-top-10 show2">{{item.title}}</view>
					<view style="color:#949494">{{item.created_at}}</view>
				</view>
			</view>
			<view v-for="(item,index) in article" v-if="index>1" class="padding-10" @click="open(item.url)">
				<view class="padding-10" :style="index%2==0?'background-color: #fcf7ed;':''">
					<view class="t show1" style="font-weight: 500;">{{item.title}}</view>
					<view style="color:#949494">{{item.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-c more"
				@click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=3'});"
				style="width: 60%;margin-left: 20%;border-radius: 20px;color: #2E67F6;">
				주요뉴스 더보기
				<image src="/static/arrow_down.png" mode="aspectFit" style="width: 30rpx;height: 30rpx;transform:rotate(270deg)"></image>
			</view>
			<view style="height: 20px;"></view>
		</view> -->

		<view class="flex padding-top-10 padding-bottom-10">
			<view class="margin-left-20 bold">인기종목</view>
		</view>
		<view style="border-radius: 10px;background: #fff;margin: 10px;">

			<view class="flex padding-10">
				<view v-for="(item,index) in top22" class="text-center color-white radius10 flex-1"
					style="padding: 5px 0px;margin-right: 5px;" :class="current2==index?'current1-a':'current1'"
					@click='qiehuan2(index)'>
					{{item}}
				</view>
			</view>

			<view class="lists">
				<view class="item flex flex-b" v-for="(item,index) in top2"
					@click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
					<view class="flex flex-3">
						<view class="t">{{index+1}}</view>
						<view>
							<u-image :src="item.logo" width="30" height="30" shape="circle"></u-image>
						</view>
						<view style="margin-left: 20px;">
							<view class="name">{{item.ko_name}}</view>
							<span style="font-weight: 700;font-size: 13px;"
								:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</span>
							<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
								:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">
								{{(item.returns*1).toFixed(2)}}%</span>
						</view>
					</view>
					<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
						<!-- <u-icon name="photo" ></u-icon> -->
						<u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
						<u-image src="/static/icon/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
					</view>
				</view>
			</view>
			<view class="flex flex-c more"
				@click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});"
				style="width: 60%;margin-left: 20%;border-radius: 20px;color: #2E67F6;">
				인기종목 더보기
				<image src="/static/arrow_down.png" mode="aspectFit"
					style="width: 30rpx;height: 30rpx;transform:rotate(270deg)"></image>
				<!-- <view class="icon jtr"></view> -->
			</view>
			<view style="height: 20px;"></view>
		</view>

		<view class="flex padding-top-10 padding-bottom-10">
			<view class="margin-left-20 bold">국내종목</view>
		</view>
		<view style="border-radius: 10px;background: #fff;margin: 10px;">

			<view class="flex flex-b container1">
				<view class="item text-center" v-for="(item,index) in bottom"
					:class="item.avg_returns*1>0?'yinying-red':'yinying-blue'">
					<view class="margin-top-20 font-size-14">{{item.name}}</view>
					<view :class="item.avg_returns*1>0?'red':'green'" class="margin-bottom-20" style="font-size: 20px;">
						{{item.avg_returns>0?'+':''}}{{item.avg_returns}}
					</view>
				</view>
			</view>


			<view style="height: 20px;"></view>
		</view>

	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {
			return {
				// timer: null,
				tablist: [{
					name: '시장요약'
				}, {
					name: '인기종목'
				}, {
					name: '시장지표'
				}, {
					name: '시장이슈'
				}],
				top11: ["국내", "해외", "가상화폐"],
				top22: ["상승률", "하락률", "신고가", "거래량", '거래대금'],
				top111: {
					17470: "코스피 200",
					255: "코스피",
					141: "코스닥",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				current: 0,
				top1: [],
				kline: [],
				kLineChart: [],
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				top2: [],
				top3: [],
				bottom: [],
				klineindex: 141
			}
		},
		created() {
			this.top_one();
			this.top_two();
			this.top_three();
		},
		mounted() {
			console.log('child mounted', this.timer);
			// this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			// this.clearTimer();
		},

		methods: {
			// onSetTimeout() {
			// 	this.timer = setInterval(() => {
			// 		console.log("setInterval");
			// 		this.top_one();
			// 		this.top_two();
			// 		this.top_three();
			// 	}, 3000);
			// },
			// clearTimer() {
			// 	// clearTime
			// 	if (this.timer) {
			// 		clearInterval(this.timer);
			// 		this.timer = null;
			// 		console.log('clearTimer', this.timer);
			// 	}
			// },
			open(url) {
				window.open(url)
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.top_two()
					this.top_three()
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			qiehuan33(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan3(current) {
				this.current3 = current;
				this.top_three()
			},
			qiehuan2(current) {
				this.current2 = current;
				this.top_two()
			},
			qiehuan(current1) {
				this.current1 = current1;
				this.top_one()
			},
			qiehuan111(index) {
				this.klineindex = index;
				this.top_one()
			},
			async top_one() {
				let list = await this.$http.post('api/goods/top1', {
					current1: this.current1,
					stockid: this.klineindex
				})
				this.top1 = list.data.data.top1
				this.kline = list.data.data.kline
				this.article = list.data.data.article
				this.bottom = list.data.data.bottom
			},

			async top_two() {
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			async top_three() {
				let list = await this.$http.post('api/goods/top3', {
					current: this.current3,
					current33: this.current33
				})
				this.top3 = list.data.data
			},

			// //定时器
			// startTimer() {
			// 	const storedTimerId = uni.getStorageSync('timerId');
			// 	if (storedTimerId) {
			// 		clearInterval(storedTimerId);
			// 	}
			// 	this.timerId = setInterval(() => {
			// 		this.top_one()
			// 		this.top_two()
			// 		this.top_three()
			// 		// this.dataUpdate()
			// 	}, 5000);
			// 	uni.setStorageSync('timerId', this.timerId);
			// },
		},


	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 60px 0 70px;
	}

	view,
	text {
		box-sizing: border-box;
	}

	.current1-a {
		background-color: #9ca5ff;
		color: #fff;
	}

	.current1 {
		background-color: #fff;
		color: #666666;
	}

	.yinying-red {
		box-shadow: #ffcfd7 0px 1px 6px 0px;
	}

	.yinying-blue {
		box-shadow: #d1e0ff 0px 1px 6px 0px;
	}

	.container {
		display: flex;
		align-items: center;
		/* 垂直居中 */
		justify-content: center;
		/* 水平居中 */
	}

	.left-element {
		/* 左边元素的样式，可以指定宽度和高度 */
		width: 50px;
		/* 例如 */
		height: 50px;
		/* 例如 */
		display: flex;
		align-items: center;
		/* 内部元素垂直居中 */
		justify-content: center;
		/* 内部元素水平居中 */
	}

	.right-text {
		/* 右边文本的样式，可以指定宽度和行高 */
		width: auto;
		/* 自动宽度 */
		text-align: center;
		/* 文本水平居中 */
		line-height: normal;
		/* 根据需要设置行高 */
	}

	.container1 {
		display: flex;
		flex-wrap: wrap;
		max-width: 100%;

		/* 或者设置具体的宽度 */
		.item {
			flex: 0 0 calc(33.333% - 20px);
			/* 假设容器宽度能均匀容纳3个元素，并且留有一定间隙 */
			margin: 10px;
			/* 元素之间的间隙 */
			box-sizing: border-box;
			/* 确保元素宽度包含内边距和边框 */
		}
	}



	.charts {
		width: 100%;
		height: 200px;
		margin: 10px;

	}




	.more {
		padding: 10px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}



	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}
</style>