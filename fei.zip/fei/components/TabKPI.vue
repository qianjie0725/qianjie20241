<template>
	<view style="border-radius: 10px;background: #fff;margin:10px -10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 2.6px;">
		<!-- <view style="position: relative;" >
			<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #2E67F6;position: absolute;top: 10px;"></view>
		</view> -->
		<u-tabs :list="list1" style="margin: 10px 10px;"
			activeStyle="color:#fff;font-weight: 700;background:#9ca5ff;padding:5px 10px;border-radius:6px"
			lineColor="#f3f4f8" @change="change" :current="current">
		</u-tabs>

		<view class="list" style="padding:4px 6px;">
			<view class="flex flex-b titles">
				<view class="flex-2">종목명</view>
				<view class="flex-1 t-r" v-if="current==0">현재 지수</view>
				<view class="flex-1 t-r" v-else>현재가</view>
				<view class="flex-1 t-r">등락률</view>
			</view>
			<block v-for="(item,index) in list" :key="index">
				<view class="item flex flex-b" style="padding:10px 4px">
					<view style="margin-right: 10px;">
						<u-image :src="item.logo" width="30" height="30" shape="circle"></u-image>
					</view>
					<view class="t flex-2" style="font-size: 14px;font-weight: 500;">

						{{item.ko_name}}
					</view>
					<view class="t1 flex-1 t-r num-font" :class="item.returns>0?'':'die'">
						{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view class="t1 flex-1 t-r" :class="item.returns>0?'':'die'">{{(item.returns*1).toFixed(2)}}%</view>
				</view>
			</block>
		</view>
		<view class="flex flex-c more" @click="linkKPI()"
			style="width: 60%;margin-left: 20%;border-radius: 20px;color: #2E67F6;padding-bottom: 20px;">
			더 보려면 클릭하세요
			<!-- <view class="icon jtr"></view> -->
			<image src="/static/arrow_down.png" mode="aspectFit"
				style="width: 30rpx;height: 30rpx;transform:rotate(270deg)"></image>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TabKPI',
		data() {
			return {
				show: false,
				list1: [{
					name: '지수',
				}, {
					name: '환율',
				}, {
					name: '원자재'
				}, {
					name: '가상화폐'
				}],
				list: [],
				current: 0,
			}
		},

		created() {
			this.lists()
		},

		methods: {
			
		},
	}
</script>

<style>
</style>