<template>
	<!-- 大宗交易 -->
	<view style="margin:10px">
		<!-- 产品-->
		<template v-if="business.length>0">
			<block v-for="(item,index) in business" :key="index">
				<view
					style="border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 1px;margin:20px;padding:10px;background-color: #FFFFFF;">
					<view style="display: flex;align-items: center;">
						<view style="flex:20%;">
							<template v-if="!item.logo || item.logo==''">
								<view
									style="width: 40px;height: 40px;background-color:#2d2c62;text-align: center;line-height: 40px;color: #FFFFFF;border-radius: 20%;font-size: 18px;">
									{{item && item.goods.name? item.goods.name.slice(0,1):''}}
								</view>
							</template>
							<template v-else>
								<image v-if="item.logo" :src="getlogo()" mode="aspectFit"
									style="width: 40px;height: 40px;border-radius: 20%;"></image>
							</template>
						</view>
						<view style="flex:60%;font-size: 16px;">
							{{item.goods.name}}
							<view class="area" v-if="item.goods.locate=='깊은'">
								<view class="deep">{{item.goods.locate}}</view>
								<view class="deep-number">{{item.goods.code}}</view>
							</view>
							<view class="area" v-if="item.goods.locate=='북쪽'">
								<view class="north">{{item.goods.locate}}</view>
								<view class="north-number">{{item.goods.code}}</view>
							</view>
							<view class="area" v-if="item.goods.locate=='상하이'">
								<view class="shanghai">{{item.goods.locate}}</view>
								<view class="shanghai-number">{{item.goods.code}}</view>
							</view>
						</view>
						<view
							style="margin-left: auto; background-color: #2E67F6;color: #FFF;padding:6px 16px;border-radius: 20px;"
							@click="detail(item)">
							신청
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 14px;">
							{{$util.formatNumber(item.goods.rate,2)}}%
						</view>
						<view style="font-size: 16px;color:#FF533B;">
							{{$util.formatNumber(item.price)}}원
						</view>
					</view>
				</view>
			</block>
		</template>

		<u-popup :show="show" @close="close" mode="bottom" :closeable='closeable' :round="30">
			<view v-if="detailId" class="largeAmount" style="margin: 10px 20px;">
				<view class="business">
					청약 신청 내역
				</view>
				<view style="display: flex;align-items: center;justify-content:space-between;line-height: 2;">
					<view class="price">매입 가격</view>
					<view class="purchase-price">{{$util.formatNumber(detailId.price)}}</view>
				</view>
				<view class="purchase-text" style="line-height: 2;">
					<u-input type="number" placeholder="매입 수량을 입력하세요." v-model="value1"></u-input>
					<view class="hand">확인</view>
				</view>

				<!-- <template v-if="actions.length>1">
					<view class="price" style="padding: 10px 0;">레버리지</view>
					<u-grid :border="false" col="5">
						<u-grid-item v-for="(item,index) in actions">
							<view style="width: 90%;" :class="ganggan==item.name?'actity':'noactity'"
								@click="selected(item)">
								{{item.name}}
							</view>
						</u-grid-item>
					</u-grid>
				</template> -->


				<!-- <view class="price">레버리지</view>
				<view class="available" @click="ganggan_show=true">
					<u-input type="number" style="pointer-events: none;" :disabled="true" placeholder=""
						v-model="ganggan" inputAlign='right'>
					</u-input>
				</view> -->

				<view style="display: flex;align-items: center;justify-content:space-between;">
					<view class="price">거래 비밀번호</view>
					<view class="purchase-price">{{$util.formatNumber(detailId.price*this.value1/ganggan)}}</view>
				</view>

				<!-- <view class="amount">매입 가격 <text>{{detailId.price*this.value1/ganggan|addZero}} </text> </view> -->
				<view class="available">
					<u-input type="password" placeholder="비밀키를 입력해주세요" v-model="value2"></u-input>
				</view>
				<view class="fund" style="text-align: right;">
					사용 가능 잔액 <text>{{$util.formatNumber(availableFunds.money)}}</text>
				</view>
				<view class="purchase" style="background-color: #2E67F6;border-radius: 32px;"
					@click="bulkPurchase(detailId.id)">신청</view>
			</view>
		</u-popup>
		<!-- <u-action-sheet :show="ganggan_show" :actions="actions" title="레버리지를 선택하세요" @close="ganggan_show = false"
			@select="Select">
		</u-action-sheet> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				closeable: true,
				business: [],
				detailed: '',
				value1: '',
				value2: '',
				value3: '',
				availableFunds: '',
				detailId: '',
				ganggan: 1,
				// ganggan_show: false,
				actions: [],
			}
		},

		created() {
			this.largeAmount()
			this.available()
		},
		methods: {
			selected(item) {
				this.ganggan = item.index;

			},
			close() {
				this.show = false
				// console.log('close');
			},
			detail(item) {
				this.show = true
				this.bulkDetails(item)
				// console.log(this.bulkDetails, '987654');
			},
			blockTransactions() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			//列表
			async largeAmount() {
				let list = await this.$http.get('api/goods-bigbill/list', {})
				if (list.data.code == 0) {
					console.log(list);
					this.business = list.data.data.filter(item => item.gid && item.gid > 0);
				}
			},
			//세부
			async bulkDetails(item) {
				let list = await this.$http.get('api/goods-bigbill/detail', {
					id: item.id
				})
				this.detailed = list.data.data.goods
				this.detailId = list.data.data
			},

			//点击购买
			async bulkPurchase(id) {
				if (this.value1 == '') {
					uni.$u.toast('구매 수량을 입력해주세요.');
					return false;
				}
				if (this.value2 == '') {
					uni.$u.toast('펀드 비밀번호를 입력해주세요');
					return false;
				}
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					ganggan: this.ganggan
					// password: this.value3,
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.value3 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
						});
					}, 1000)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			//사용 가능한 자금
			async available() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.availableFunds = list.data.data
				this.actions = [{
					name: '1',
					index: 1
				}];
				if (list.data.data.ganggan) {
					this.actions.push(...list.data.data.ganggan);
				}
			},
		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(0)
			}
		},

	}
</script>
<style lang="scss">
	.actity {
		background-color: #2E67F6;
		color: #FFFFFF;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
		border-radius: 10px;
	}

	.noactity {
		background-color: #F6F8FC;
		color: #666666;
		// border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
		border-radius: 10px;
	}

	.corporation {
		font-size: 30rpx;
		font-weight: 600;
		color: #333;

	}

	.price {
		color: #f85252;
		font-size: 28rpx;
	}

	.detailed {
		background-color: rgb(72, 156, 229);
		color: #fff;
		border-radius: 40rpx;
		padding: 6rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 45%;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 45%;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 40rpx;
			// color: #333;
			// border-bottom: 1rpx solid #e0e0e0;
			// padding-bottom: 30rpx;
			color: #333;
			border-bottom: 1px solid #e0e0e0;
			height: 45px;
			line-height: 45px;
			//background-color: #4f61f5;
			// border-top-left-radius: 10px;
			// border-top-right-radius: 10px;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 5px 0 0 6px;
		}

		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;
			padding: 0 9px;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.available {
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;
			padding: 0 9px;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.purchase {
			background-color: #4f61f5;
			margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;

		}
	}
</style>