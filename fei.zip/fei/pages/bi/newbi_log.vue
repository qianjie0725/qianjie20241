<!-- 申购 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">{{$t('index.Subscription_record')}}</view>
			<view class=""></view>
		</view>

		<view class="" v-for="(item,index) in list" :key="index">
			<view style="margin: 30rpx; word-wrap:break-word;">
				<view class="display">
					<view class="">
						<view class="did-not">
							{{item.bi.name}}/{{item.bi.legal_name}} <text>{{item.message}}</text>
							<!-- 		<text v-if="item.status==0">未中签</text>
							<text v-if="item.status==1">申购中</text>
							<text v-if="item.status==2">申购中签</text>
							<text v-if="item.status==3">已
구독하다金额</text>
							<text v-if="item.status==4">中签弃奖</text>
							<text v-if="item.status==5">已上市</text> -->
						</view>
				
					</view>
					<view class="did-not">{{$t('index.price')}}<text>{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
					</view>
				</view>
				<u-divider></u-divider>
				<view class="display quantity" v-if="item.status>=2">
					<view class="display">
						<view class="">{{$t('index.Quantity')}}</view>
						<view class="red-mark">{{item.apply_amount}}</view>
					</view>
					<view class="display">
						<view class="">{{$t('index.amount')}}</view>
						<view class="red-mark">{{item.apply_num_amount}}</view>
					</view>
				</view>
				<view class="quantity">
					<view class="">{{$t('index.time')}}</view>
					<view class="">{{item.created_at}}</view>
				</view>
				<view class="quantity">
					<view class="">{{$t('index.order_NO.')}}</view>
					<view class="">{{item.order_sn}}</view>
				</view>
			</view>
			<view style=" height: 4rpx;width: 100%;background: #f5f5f5;"></view>
		</view>

		<view class="finished-text">{{$t('index.nothing_more')}}</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: '',
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/bi/newbi_log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	// 没有更多
	.finished-text {
		color: #969799;
		font-size: 28rpx;
		margin: 30rpx auto;
		text-align: center;
		padding: 30rpx 0;
	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;
		color: #666;
		display: flex;
		// justify-content: space-between;
		margin: 8rpx 0;

		view {
			margin-right: 30rpx;
		}

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>