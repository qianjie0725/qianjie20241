<template>
	<view class="page">
		<view
			style="background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));height: 200px;">

		</view>
		<view class="flex padding-10" style="gap: 10px;margin-top: -170px;">
			<view class="flex-1  text-center" :class="curTab==index?'top-a':'top'" v-for="(item,index) in tablist"
				:key="index" @click="changeTab(index)">
				{{item}}
			</view>
		</view>
		<!-- <u-tabs :list="tablist" lineColor="#014bab"  activeStyle="color:#014bab;font-size:18px;font-weight: 700;"  inactiveStyle="font-size:18px;font-weight: 700;" @change="change" :current="current"></u-tabs> -->
		<TabOne v-if="curTab==0"></TabOne>
		<TabTwo v-if="curTab==1"></TabTwo>
		<TabThree v-if="curTab==2"></TabThree>
		<TabFour v-if="curTab==3"></TabFour>
	</view>
</template>

<script>
	// import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	import TabFour from '@/components/market/TabFour.vue'
	export default {
		components: {
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				tablist: ['인기종목', '전체요약', '시장지표', '시장이슈'],
				curTab: 1
			}
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 1;
			}
		},
		onShow() {
			// console.log('onShow', this.$refs.tab0);
			// if (this.$refs.tab0) {
			// 	this.$refs.tab0.onSetTimeout();
			// }
			this.changeTab(this.curTab);
		},
		// onReady() {
		// 	console.log('onReady', this.$refs.tab0);
		// },
		// onHide() {
		// 	console.log('onHide', this.$refs.tab0);
		// 	if (this.$refs.tab0) {
		// 		this.$refs.tab0.clearTimer();
		// 	}
		// },
		// deactivated() {
		// 	console.log('deactivated', this.$refs.tab0);
		// 	if (this.$refs.tab0) {
		// 		this.$refs.tab0.clearTimer();
		// 	}
		// },

		methods: {
			changeTab(val) {
				console.log(val)
				// if (this.$refs.tab0) {
				// 	this.$refs.tab0.clearTimer();
				// }
				this.curTab = val;
				// 	if (this.curTab == 0) {
				// 		if (this.$refs.tab0) {
				// 			this.$refs.tab0.onSetTimeout();
				// 		}
				// 	}
				// },
			},
		}
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	page {
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}

	.top-a {
		color: #2E67F6;
		height: 25px;
		line-height: 25px;
		font-weight: 700;
	}

	.top-a::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 3px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		text-align: center;
		margin-left: 20%;
	}

	.top {
		color: #333333;
		height: 25px;
		line-height: 25px;
		margin-top: -4px;
	}
</style>