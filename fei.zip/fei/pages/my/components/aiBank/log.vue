<template>
	<view>
		<view class="college-bg" style="background: linear-gradient(to bottom, #919bff, rgba(189, 193, 238, 0));">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">입출금 세부 내역</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<u-tabs lineColor="#fff" :list="list" @click="select" :activeStyle="{color: '#f85050',fontWeight: 'bold',}"
				:inactiveStyle="{color: '#666'}"></u-tabs>
			<view>
				<view v-for="(item,index) in fundDetails" :key="index">
					<view class="takeNotes">
						<view class="display">
							<view class="business">
								<view class="recharge">잔액</view>
								<view class="money">{{$util.formatNumber(item.money)}}원
								</view>
							</view>
							<view class="underReview_b" v-if="item.status==1">
								<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>재충전 성공
							</view>
						</view>
						<view class="" style="margin: 10rpx 0;">유형：
							<text v-if="item.type==1" style="color: #5AC725;">예치</text>
							<text v-if="item.type==2" style="color: #F9AE3D;">취하다</text>
						</view>
						<view class="order flex">
							<view class="flex-1">
								<view>거래전 잔액: </view>
								<!-- 								<view><text>{{item.before.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}원</text>
								</view> -->
							</view>
							<view class="flex-1">
								<view>신청 시간 :<text>{{item.created_at.slice(0,10)}}</text> </view>
								<view v-if="item.status!=0">감사 시간 :<text>{{item.updated_at.slice(0,10)}}</text> </view>
							</view>
						</view>

						<view class="underReview_c" v-if="item.status==2">
							<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>충전에 실패했습니다. 고객센터에 문의하세요.
						</view>
					</view>

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				status: 0,
				list: [{
					name: '보류 중'
				}, {
					name: '통과'
				}, {
					name: '기각'
				}],
				fundDetails: {}
			}
		},
		onShow() {
			this.log_list()
		},
		methods: {
			home() {
				uni.navigateBack()
			},
			select(res) {
				this.status = res.index;
				this.fundDetails = {};
				this.log_list();
			},
			async log_list() {
				let list = await this.$http.get('api/user/userAiBankLog', {
					status: this.status
				});
				this.fundDetails = list.data.data;
				console.log(this.fundDetails);
			},
		}
	}
</script>

<style lang="scss">
	.college-bg {

		padding: 20rpx;

		height: 80rpx;

		background-color: #4f61f5;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-between;
		border-bottom: 1rpx solid #e0e0e0;
		padding: 0 30rpx;

	}

	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			padding: 20rpx 0;
			border-bottom: 2rpx solid #eeeeee;
			font-size: 26rpx;


			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>