<template>
	<view style="background-color: F6F6F6;">
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="widthFix" @tap="home()" style="width:15px;"></image>
			<view class="college-text">원클릭 이동 서비스</view>
		</view>
		<view style="margin-top: -100px;background-color:transparent;" class="text-center">
			<view class="title" style="font-size: 16px;color: #666;">
				<span>전환 가능 금액</span>
			</view>
			<view class="money text-center color-white bold margin-top-10" style="color: #121212;font-size: 48rpx;">
				<span>{{$util.formatNumber(userInformation.money)}}</span>
			</view>
		</view>
		<view style="margin: 20px 10px;font-size: 32rpx;color: #919bff;" class="padding-20">
			데이 트레이딩 지갑 계좌
		</view>
		<view
			style="background: #fff;padding: 20rpx;box-shadow: rgba(0, 0, 0, 0.15) 0 0 3px;border-radius: 10px;margin: 20px;">
			<view style="margin: 10px 0;" class="bold">전환 금액</view>
			<u--input placeholder="입력 금액" v-model="money" style="height: 30px;"
				placeholder-style="font-size:12px"></u--input>

			<view style="display: flex;align-items: center;flex-wrap: wrap;padding:0 10px;margin-top: 20px;">
				<block v-for="(item,index) in tabs" :key="index">
					<view
						style="border-radius: 6px;flex:12%;margin:10px;padding:10px;line-height: 1.6;text-align: center;"
						:class="curTab==item? 'active':'unactive'" @click="changeTab(item)">
						{{item}}%
					</view>
				</block>
			</view>

			<view class="purchase" @click="transfer" style="background-color: #919bff;">
				확인
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money: '',
				userInformation: {},
				balance: 0,
				curTab: -1, // 选中项
				tabs: [10, 20, 30, 40, 50, 60, 70, 80], // 备选项
			}
		},
		onShow() {
			this.gaint_info()
		},
		methods: {
			// 切换选项
			changeTab(val) {
				this.curTab = val;
				this.money = val <= 0 ? '' : parseInt(this.balance * this.curTab * 0.01);
			},

			home() {
				uni.navigateBack()
			}, //用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.balance = result.data.data.money;
				this.userInformation = result.data.data;
				this.cardManagement = result.data.data.bank_card_info
			},
			async transfer() {
				if (this.money <= 0 || this.money == "") {
					this.$u.toast('금액을 입력해주세요.');
					return false;
				}
				const result = await this.$http.post('api/user/transfer', {
					money: this.money,
					type: 1
				});
				this.$u.toast(result.data.message);
				if (result.data.code == 0) {
					this.gaint_info();
					this.money = '';
					this.changeTab(0);
				}
			}
		}
	}
</script>

<style lang="scss">
	// 切换选择
	.active {
		background-color: #919bff;
		color: #FFF
	}

	.unactive {
		background-color: #F1F1F1;
		color: #333
	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 150px;
		// background-image: url("../../../../static/my/zijimima.png");
		background: linear-gradient(to bottom, #919bff59, rgba(189, 193, 238, 0));
		// background-repeat: no-repeat;
		// background-size: 100% 100%;
		display: flex;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {
			text-align: center;
			margin: 0 auto;
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 20rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-color: #14CF76;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}

	.with-bottom-line {
		color: #1d7ed2;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		/* 使横线宽度与父元素相同 */
		margin-top: 10px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
		margin-left: 20%;
	}
</style>