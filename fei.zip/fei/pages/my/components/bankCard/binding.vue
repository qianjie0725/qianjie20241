<!-- 绑定银行卡 -->
<template>
	<view>

		<view class="college-bg"
			style="background: linear-gradient(to bottom, rgb(60 99 190), rgba(189, 193, 238, 0));">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text" style="color: #FFFFFF;">개인 계좌 연동</view>
			<view class=""></view>
		</view>

		<view class="college-content" style="margin:20px;padding: 10px;">
			<view class="bank-name" style="margin-bottom: 20px;">
				<view class="">성명:</view> <text> {{cardManagement.realname}}</text>
			</view>
			<!-- <view class="xian"></view> -->
			<view class="bank-name" style="margin-bottom: 20px;">
				<view class="">은행명: </view><text> {{cardManagement.bank_name}}</text>
			</view>
			<!-- <view class="xian"></view> -->
			<view class="bank-name" style="margin-bottom: 20px;">
				<view class="">계좌번호: </view> <text> {{cardManagement.card_sn}}</text>
			</view>

		</view>

		<!-- 		<view class="college-content">
			<view class="bank-name">
				<view class="">계좌 개설 지점: </view> <text> {{cardManagement.card_sn}}</text>
			</view>
		</view> -->


		<view class="purchase" style="height: 30px;line-height: 30px;background-color: rgb(60 99 190);border-radius: 12px;margin:auto 30px;" @tap='renewal()'>
			확인
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				cardManagement: '',
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			renewal() {
				uni.navigateTo({
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.cardManagement = list.data.data.bank_card_info
			},
		},
		onLoad() {
			this.gaint_info()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx;
		height: 120rpx;
		background-color: #3779CD;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 30rpx 20rpx;
			// font-weight: 700;
			background-color: #f5f5f5;
			display: flex;
			font-size: 28rpx;
			margin-top: 10px;
			border: 2rpx solid #f4f4f4;
			border-radius: 10px;

			view {
				width: 30%;
			}

			text {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
		background-image: linear-gradient(to right, #3779CD, #3779CD);
		margin: 50rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;
		// font-weight: 600;
	}
</style>