<template>
	<view
		style="background: linear-gradient(to bottom, rgba(46, 103, 246, 1), rgba(46, 103, 246, 0.4));position: relative;overflow: hidden;height: 100vh;">
		<view class="logo1" style="padding: 70px 0;">
			<view class="border flex flex-c">
				<view class="icon logo"></view>
			</view>
		</view>
		<view
			style="position: absolute;top:260px;left:50%;transform:translateX(-50%);padding:10px 20px;background-color:rgba(255,255,255,0.15);border-radius: 12px;width: 80%;">
			<view style="display: flex;align-items: center;justify-content: space-around;">
				<view style="width: 80px;height: 2px;background-color: #ffffff70;"></view>
				<view class="text-center bold font-size-20 margin-top-10" style="margin-bottom: 10px;color:#FFF;">로그인</view>
				<view style="width: 80px;height: 2px;background-color: #ffffff70;"></view>
			</view>
			<view style="padding-top: 20px;">
				<view style="padding-left: 20px;font-weight: 500;font-size: 32rpx; line-height: 2;color:#FFF;">전화번호를 입력</view>
				<u--input placeholder="전화번호를 입력" prefixIcon="/static/new/phone.png" shape="circle"
					placeholderStyle="font-size: 14px;color: #999999;"
					prefixIconStyle="margin-left:10px;margin-right:10px;height:20px" v-model="value1"
					customStyle="background-color: #F6F9FF;height:32px;margin-bottom: 20px;" type="number"
					maxlength="11"></u--input>
				<view style="padding-left: 20px;font-weight: 500;font-size: 32rpx; line-height: 2;color:#FFF;">비밀번호를 입력</view>
				<u--input placeholder="비밀번호를 입력" prefixIcon="/static/new/mima.png" shape="circle"
					placeholderStyle="font-size: 14px;color: #999999"
					prefixIconStyle="color: #909399;margin-left:10px;margin-right:10px;height:20px" v-model="value2"
					customStyle="background-color: #F6F9FF;height:32px;margin-bottom: 30px;" type="password"></u--input>

				<view class="radius30 text-center"
					style="background-color: rgba(46, 103, 246, 0.8);height: 80rpx;color: #fff;padding: 6px 9px;line-height: 80rpx;border-radius: 100px;"
					@click="gain_login">
					로그인
				</view>
				<view class="margin-top-30 text-right flex justify-end" style="margin-right: 10%;">
					<view style="font-size: 16px;color: #2E67F6" @tap="register()">
						회원가입
					</view>

				</view>
			</view>
		</view>
	</view>
	<!-- 登录-->

</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				showPassword: true
			};
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//忘记密码
			forget() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/forgot/forgot'
				});
			},
			// 跳转到注册
			register() {
				uni.redirectTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/register/register'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					console.log(token)
					uni.setStorageSync('token', token);
					uni.$u.toast('성공적 로그인');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// //数据请求
			// async login_liufu() {
			// 	try {
			// 		uni.removeStorageSync('url');
			// 	} catch (e) {}
			// 	let list = await this.$http.get(
			// 		'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
			// 			// language: this.$i18n.locale
			// 		})
			// 	// 接口域名
			// 	console.log(list.data, '接口位置')
			// 	uni.setStorageSync('url', list.data);
			// },

		},

		async mounted() {
			// await this.login_liufu()
		}

	}
</script>

<style lang="scss">
	.logo1 {
		width: 100%;
		height: 100%;

		.icon.logo {
			width: 120px;
			height: 120px;
			background: url(/static/logo.png) no-repeat 50%/100%;
			border-radius: 100%;
		}
	}
</style>