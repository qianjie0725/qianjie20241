<!-- 客服 -->
<template>
	<view>
		<!-- 		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">客服</view>
			<view class=""></view>
		</view> -->

		<!-- <view class="college-content"> -->
		<!-- <web-view :fullscreen="full" class="webview" :style="webviewStyles" :webview-styles="webviewStyles"
				:src='list'></web-view> -->
		<!-- 	<web-view :style="webviewStyles" :webview-styles="webview" :fullscreen="full" :src='list'></web-view>
		</view> -->
		<template>
			<web-view :src="list"></web-view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: "",
				full: false,
				webviewStyles: {
					height: '91vh',
					width: "100%",
				},
				webview: {
					height: '91vh',
					width: "100%",
				},
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			async get_url() {
				let list = await this.$http.get('api/app/config', {})
				this.list = list.data.data[8].value
			},
		},
		mounted() {
			this.get_url()
		},
	}
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		background: #007AFF;
		// background: #ea3544;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	iframe {
		width: 600px !important;
	}

	.college-content {
		width: 100%;
		height: 100%;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>