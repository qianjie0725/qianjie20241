<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" style="background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));box-shadow: none;" @click="home()">
				<image src="/static/zuojiantou.png" mode="aspectFit" style="width: 40rpx;height: 40rpx;"></image>
				<view class="header-center flex-1" style="color:#121212;">IPO</view>
			</view>
		</view>

		<!-- <view style="background-color: #FFF;">
			<view style="display: flex;align-items: center;margin:10px 30px;padding:10px;">
				<view style="flex:48%;text-align: center;" @click="select(0)"
					:style="{color:current==0?'#2E67F6':'#666666'}">
					<text style="font-size: 18px;display: inline-block;"
						:style="{borderBottom:`2px solid ${current==0?'#2E67F6':'transparent'}` }">공모주 청약</text>
				</view>
				<view style="width: 1px;height: 20px;background-color: #E8EAF3;"></view>
				<view style="flex:48%;text-align: center;" @click="select(1)"
					:style="{color:current==1?'#2E67F6':'#666666'}">
					<text style="font-size: 18px;display: inline-block;"
						:style="{borderBottom:`2px solid ${current==1?'#2E67F6':'transparent'}` }">기관 청약</text>
				</view>
			</view>
		</view> -->

		<view style="display: flex;align-items: center;margin:20px; background-image: linear-gradient(to bottom, rgba(35,65,215,0.3),rgba(0,207,125,0.3));border-radius: 12px;">
			<view @tap="applyPurchase()" v-if="current==0"
				style="flex:48%;margin:10px;padding:20px;border-radius: 10px;text-align: center;">
				<image src="/static/ipo_left.png" mode="aspectFit" style="width: 80rpx;height: 80rpx;background-color: #434341;border-radius: 100%;"></image>
				<view class="margin-top-10">구매 내역</view>
			</view>
			<view @tap="luckyNumber()" v-if="current==0"
				style="flex:48%;margin:10px;padding:20px;border-radius: 10px;text-align: center;">
				<image src="/static/ipo_right.png" mode="aspectFit" style="width: 80rpx;height: 80rpx;"></image>
				<view class="margin-top-10">배정 수량</view>
			</view>

			<!-- <view
				style="width: 48%;;margin:10px;padding:20px;border-radius: 10px; background-image: linear-gradient(to bottom, rgba(35,65,215,0.3), rgba(35,65,215,0));text-align: center;"
				@click="$u.route('/pages/index/components/newShares/ration/ration');" v-if="current==1">
				<image src="/static/ipo_left.png" mode="aspectFit" style="width: 80rpx;height: 80rpx;"></image>
				<view class="margin-top-10">구매 내역</view>
			</view> -->
		</view>


		<!-- 新股申购 -->
		<template v-if="current == 0">
			<block v-for="(item,index) in newShares_list" :key="index">
				<view
					style="border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 1px;margin:20px;padding:10px;background-color: #FFFFFF;">
					<view style="display: flex;align-items: center;">
						<view style="flex:20%;">
							<template v-if="!item.logo || item.logo==''">
								<view
									style="width: 40px;height: 40px;background-color:#2d2c62;text-align: center;line-height: 40px;color: #FFFFFF;border-radius: 20%;font-size: 18px;">
									{{item && item.goods.name? item.goods.name.slice(0,1):''}}
								</view>
							</template>
							<template v-else>
								<image v-if="item.logo" :src="getlogo()" mode="aspectFit"
									style="width: 40px;height: 40px;border-radius: 20%;"></image>
							</template>
						</view>
						<view style="flex:60%;font-size: 16px;">
							{{item.goods.name}}
						</view>
						<view
							style="margin-left: auto; background-color: #2E67F6;color: #FFF;padding:6px 16px;border-radius: 20px;"
							@click="to_skip(item.id)">
							신청
						</view>
					</view>
					<view style="font-size: 16px;text-align: right;">
						{{$util.formatNumber(item.price)}}원
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
						<view style="text-align: right;">
							{{$util.formatNumber(item.shiying,2)}}%
						</view>
						<view style="text-align: right;">
							청약 날짜<text>{{item.shengou_date}}</text>
						</view>
					</view>
				</view>
			</block>
		</template>

		<!-- <template v-else>
			<block v-for="(item,index) in newShares_list2" :key="index">
				<view
					style="border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 1px;margin:20px;padding:10px;background-color: #FFFFFF;">
					<view style="display: flex;align-items: center;">
						<view style="flex:20%;">
							<template v-if="!item.logo || item.logo==''">
								<view
									style="width: 40px;height: 40px;background-color:#2d2c62;text-align: center;line-height: 40px;color: #FFFFFF;border-radius: 20%;font-size: 18px;">
									{{item && item.goods.name? item.goods.name.slice(0,1):''}}
								</view>
							</template>
							<template v-else>
								<image v-if="item.logo" :src="getlogo()" mode="aspectFit"
									style="width: 40px;height: 40px;border-radius: 20%;"></image>
							</template>
						</view>
						<view style="flex:60%;font-size: 16px;">
							{{item.goods.name}}
						</view>
						<view
							style="margin-left: auto; background-color: #2E67F6;color: #FFF;padding:6px 16px;border-radius: 20px;"
							@tap="purchase(item.id,item.peishou_price)">
							신청
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
						<view style="font-size: 16px;">
							{{item.peishou_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
						</view>
						<view style="text-align: right;">
							{{item.fa_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
						</view>
					</view>
					<view style="text-align: right;">
						청약 날짜<text>{{item.shengou_date}}</text>
					</view>
				</view>
			</block>
		</template> -->
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				current: 0, // 当前IPO类型
				list: [{
					name: '청약 신청'
				}, {
					name: '청약 내역'
				}, {
					name: '기관 거래 우선가',
				}, {
					name: 'VIP 우대'
				}, ],
				newShares_list: [],
				newShares_list2: [],
			};
		},
		onLoad(option) {
			this.newShares();
		},

		methods: {
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},
			//구독기록
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
				});
			},
			//우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			select(item) {
				this.current = item;
				if (this.current == 0) {
					this.newShares();
				} else {
					this.newShares2();
				}
			},
			to_skip(id) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/nullElement/nullElement' +
						`?id=${id}`
				});
				// console.log(gid, fa_price, '携带');

			},
			//新股申购
			async newShares() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 1,
				})

				this.newShares_list = list.data.data
			},
			async newShares2() {
				let list = await this.$http.post('api/goods-scramble/calendar', {
					type: 2,
				})

				this.newShares_list2 = list.data.data
				// console.log(list.data.data, '구독 예정');
			},
		},

	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #F3F4F8;
	}

	.page {
		padding: 50px 0 0;
	}

	.header {
		height: 60px;
		background: #4f61f5;
		box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .1);
		padding: 20px 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}
	}

	.top-a {
		background-image: url(/static/market/top1.png);
		background-repeat: no-repeat;
		background-position: center;
		background-size: 100px 33px;
		/* 不重复背景图片 */
		height: 33px;
		line-height: 28px;
		text-align: center;
		color: #fff;
		margin: 5px;
	}

	.top {
		background-color: #fff;
		color: #000;
		height: 28px;
		line-height: 28px;
		width: 70px;
		text-align: center;
		border: 1px #b6b6b6 solid;
		margin: 5px;
	}

	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>