

<template>
	<view class="page">
		
		<view>
			<view class="flex  header">
				<view class="icon tz" @click="$u.route({type:'switchTab',url:'/pages/marketQuotations/marketQuotations'});"></view>
				<view style="width: 100%;margin-left: 15px;"  @click="$u.route({url:'/pages/searchFor/searchFor'});">
					<u-search placeholder="종목코드 검색" v-model="keyword" :showAction="false"></u-search>
				</view>
			</view>
		</view>
		<view class="banner flex">JPMSM</view>
		<view class="list flex flex-b">
			
			
			
			<view class="list-item"  @click="link(2,'/pages/index/components/fund/fund')">
				<view class="icon gd"></view>
				<view class="t">스마트 주문</view>
			</view>
			
			
			<view class="list-item" @click="link(3,'/pages/index/components/newShares/newShares?index=1')">
				<view class="icon hla"></view>
				<view class="t">공모주</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/marketQuotations/authentication')">
				<view class="icon sm"></view>
				<view class="t">본인 인증</view>
			</view>
			<view class="list-item" @click="silver(userinfo.money,userinfo.bank_card_info,userinfo.idno)">
				<view class="icon cza"></view>
				<view class="t">계좌 개설</view>
			</view>
			
			
			<view class="list-item" @click="link(2,$util.PAGE_URL.SERVICE)">
				<view class="icon kf"></view>
				<view class="t">고객센터</view>
			</view>
		</view>
		<view class="border">
			<view :class="gp_index==0?'tt':'tt1'" @click="qiehuan(0)">국내 주식</view>
			<view :class="gp_index==1?'tt':'tt1'" @click="qiehuan(1)">해외 주식</view>
		</view>
		<view class="box">
			<view class="top flex flex-b">
				<view class="flex-2">주식/코드</view>
				<view class="flex-1 t-r">등락률</view>
				<view class="flex-1 t-r">실시간</view>
			</view>
			<view class=" box-item flex flex-b" v-for="(item,index) in list" @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
				<view class="list-name flex-2">
					<view class="list-name-txt ">{{item.ko_name}}<span>{{item.code}}</span></view>
				</view>
				<view class="per flex flex-b flex-1 t-r " :class="item.returns>0?'bg-red':'bg-green'">
					<view class="icon" :class="item.returns>0?'up':'down'"></view>{{(1*item.returns).toFixed(2)}}%
				</view>
				<view class="flex-1 t-r num-font " :class="item.returns>0?'red':'green'" v-if="gp_index==0">{{numberToCurrency(item.close*1)}}</view>
				<view class="flex-1 t-r num-font " :class="item.returns>0?'red':'green'" v-if="gp_index==1">{{item.close}}</view>
			</view>
			
		</view><!----><!----><!---->
	
	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js'
	export default {
		
		data() {
			return {
				userinfo:[],
				show_money:true,
				page:1,
				list:[],
				gp_index:0,
				keyword:""
			}
		},
		
		methods: {
			qiehuan(index){
				this.gp_index=index
				this.good_list()
			},
			link(type,url){
				if(type==1){
					uni.switchTab({
						url:url
					})
				}else if(type==3){
					uni.reLaunch({
						url:url
					})
				}else{
					uni.navigateTo({
						url:url
					})
				}
			},
			// 银转证
			silver(money, bank_card_info, idno) {
				// if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: this.$util.PAGE_URL.SERVICE
					});
				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }
			
			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
			  if (!value) return '0'
			  // 将数值截取，保留两位小数
			  value = value.toFixed(2)
			  // 获取整数部分
			  const intPart = Math.trunc(value)
			  // 整数部分处理，增加,
			  const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
			  
			  return intPartFormat 
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {
				
				// this.list=[]
				let list = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index:this.gp_index
				})
				// if(this.page==1){
					this.list = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }
				
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
	
		
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		onLoad() {
			
		},
		async onShow() {
			this.page=1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			this.startTimer()
		},
		onReachBottom() {
			this.page=this.page+1;
			this.good_list()
		}

	}
</script>

<style lang="scss">
	view, uni-text {
	    box-sizing: border-box;
	}
	.page {
	    min-height: 100vh;
	    background-color: #fff;
	    padding: 54px 0 76px;
	}
	.header {
	    padding: 0 16px;
	    width: 100vw;
	    height: 54px;
	    line-height: 54px;
	    // background: #014b8d;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
		.title{
		    font-size: 17px;
		    font-weight: 700;
		    color: #fff;
		}
	}
	.banner {  
	    color: #ffffff;  
	    font-size: 65px; 
	}
	.header1 {
	    padding: 16px;
		
		.t1 {
		    color: #91a2b1;
		}
		.num {
		    margin-top: 10px;
			span {
			    font-size: 21px;
			    font-weight: 700;
			    color: #333;
			}
			.icon {
			    margin-left: 5px;
			}
		}
		.t2 {
		    margin-top: 10px;
			span {
			    font-size: 21px;
			    font-weight: 700;
			    color: #014b8d;
			}
		}
		
	}
	.list{
	    padding: 10px 0;
	    -webkit-flex-wrap: wrap;
	    flex-wrap: wrap;
		.list-item {
		    width: 20%;
		    margin: 10px 0;
		    -webkit-align-self: flex-start;
		    align-self: flex-start;
			.icon{
			    margin: 0 auto 10px;
			}
			.t {
			    color: #000;
			    text-align: center;
			}
		}
	}
	.banner {
	    padding: 0 10px;
	}
	.banner {
	    height: 108px;
	    background: url(/static/chuanggai/lunbo.png) no-repeat 50%/100%;
	    margin: 0 10px 10px;
	}
	.border{
	    border-bottom: 1px solid #ccc;
		.tt1 {
		    padding: 10px 16px;
		    font-size: 17px;
		    font-weight: 700;
		    color: #014b8d;
		    display: inline-block;
		    position: relative;
		}
		.tt {
		    padding: 10px 16px;
		    font-size: 17px;
		    font-weight: 700;
		    color: #014b8d;
		    display: inline-block;
		    position: relative;
		}
		.tt::after {
		    content: "";
		    width: 100%;
		    height: 3px;
		    background: #014b8d;
		    position: absolute;
		    bottom: 0;
		    left: 50%;
		    -webkit-transform: translateX(-50%);
		    transform: translateX(-50%);
		}
	}
	.box {
		
		.top{
			padding: 10px 16px;
			
			view{
				color: #91a2b1;
			}
		}
		.box-item {
		    padding: 10px 16px;
			.list-name-txt {
			    font-weight: 700;
			    color: #333;
				span{
				    background: linear-gradient(180deg,#eb9738,#f76938);;
				    border-radius: 5px;
				    padding: 2px 5px;
				    margin-left: 5px;
				    font-size: 13px;
				    font-weight: 400;
				    color: #fff;
				}
			}
			.per{
			    font-weight: 700;
			    border-radius: 10px;
			    padding: 5px;
				
			}
			
			.bg-red{
			    background: #f7e7e7;
			    color: #ff3636;
			}
			.bg-green {
			    background: #e7f1f9;
			    color: #014b8d;
			}
			.green{
			    font-family: Roboto;
			    font-weight: 700;
			    color: #014b8d;
			}
			.red{
			    font-family: Roboto;
			    font-weight: 700;
			    color: #ff3636;
			}
		}
	}
	.flex-2 {
	    -webkit-box-flex: 2;
	    -webkit-flex: 2;
	    flex: 2;
	}
	.flex-1 {
	    -webkit-box-flex: 1;
	    -webkit-flex: 1;
	    flex: 1;
	}
	.t-r {
	    text-align: right;
	}
	
	.num-font {
	    font-family: Roboto!important;
	}
	
	.flex.flex-b {
	    -webkit-box-pack: justify;
	    -webkit-justify-content: space-between;
	    justify-content: space-between;
	}
	.flex {
	    display: -webkit-box;
	    display: -webkit-flex;
	    display: flex;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    align-items: center;
	}
	
</style>