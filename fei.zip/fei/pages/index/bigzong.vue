<template>
	<view class="page">
		<view>
			<view class="header flex flex-b">
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">{{$t('index.bulk_transaction')}}</view><!---->
				<view class="icon ss" @click="$u.route({url:'/pages/searchFor/searchFor'});"></view>
			</view>
		</view>
		<view class="nav-box">
			<view class="nav-item active">{{$t('index.stock')}}</view>
			<view class="nav-item" @click="$u.route({url:'/pages/index/components/newShares/blockTransactions/blockTransactions'});">{{$t('index.Application_list')}}</view>
		</view>
		<view class="list">
			<view class="th flex flex-b">
				<view class="th-td flex-2">{{$t('index.nam')}}</view>
				<view class="th-td flex-1 t-c">{{$t('index.price')}}</view>
				<view class="th-td flex-1 t-r">{{$t('index.Details')}}</view>
			</view>
			<view class="th1 flex flex-b" v-if="business" v-for="(item,index) in business">
				<view class="flex-2">{{item.goods.name}}</view>
				<view class="flex-2 t-c red bold">{{item.price}}</view>
				<view class="flex-1 t-r border" @click="detail(item)">{{$t('index.buy')}}</view>
			</view>
			<view data-v-11de4fae="" class="nodata" v-if="!business">
				<view data-v-11de4fae="" class="no-img"></view>
				<view data-v-11de4fae="" class="txt">{{$t('index.no_data')}}</view>
			</view>
		</view>

		<u-popup :show="show" @close="close" :round="20" mode="bottom" :closeable='closeable'>
			<view class="largeAmount">
				<view class="business">
					{{$t('index.Shareholders_reduce_their_stake')}}
				</view>
				<view class="price">{{$t('index.price')}}</view>
				<view class="purchase-price">{{detailId.price}}</view>
				<view class="purchase-text">
					<u-input type="number" style="border: none;" :placeholder="$t('index.Enter_your_subscription_quantity')" v-model="value1"></u-input>
					<!-- <view class="hand">{{$t('index.share')}}</view> -->
				</view>
				<view class="amount">
					{{$t('index.purchase_price')}}<text>{{detailId.price*this.value1|addZero}} </text> </view>
				<view class="available">
					<u-input style="border: none;" type="password" :placeholder="$t('index.Please_enter_your_fund_password')" v-model="value2"></u-input>
				</view>

				<!-- <view class="available">
							<u-input type="password" placeholder="请输入주주들은 지분을 줄인다密码" v-model="value3"></u-input>
						</view> -->

				<view class="fund">
					{{$t('index.funds_available')}}<text>{{availableFunds.money}}</text>
				</view>
				<view class="purchase" @click="bulkPurchase(detailId.id)">{{$t('index.buy')}}</view>
			</view>
		</u-popup>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				closeable: true,
				business: "",
				detailed: '',
				value1: '',
				value2: '',
				value3: '',
				availableFunds: '',
				detailId: ''
			}
		},
		methods: {


			close() {
				this.show = false
				// console.log('close');
			},
			detail(item) {
				this.show = true
				this.bulkDetails(item)
				// console.log(this.bulkDetails, '987654');
			},
			blockTransactions() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			//列表
			async largeAmount() {
				let list = await this.$http.get('api/goods-bigbill/list', {})
				this.business = list.data.data
			},
			//세부
			async bulkDetails(item) {
				let list = await this.$http.get('api/goods-bigbill/detail', {
					id: item.id
				})
				this.detailed = list.data.data.goods
				this.detailId = list.data.data

			},

			//点击购买
			async bulkPurchase(id) {
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					// password: this.value3,
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.value3 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
						});
					}, 1000)
				} else {
					// if (list.data.code == 1) {
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/certificateBank/silver'
					// 		});
					// 	}, 1000)
					// }

					if (this.value1 == '') {
						this.show = false
						uni.$u.toast(this.$t('index.Please_enter_the_purchase_quantity'));
						setTimeout(() => {
							this.show = true
						}, 1000)
					} else if (this.value2 == '') {
						this.show = false
						uni.$u.toast(this.$t('index.qsrndzjmm'));
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
					// else if (this.value3 == '') {
					// 	this.show = false
					// 	uni.$u.toast('请填写주주들은 지분을 줄인다密码');
					// 	setTimeout(() => {
					// 		this.show = true
					// 	}, 1000)
					// } 
					else {
						this.show = false
						uni.$u.toast(list.data.message);
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
				}
			},
			//사용 가능한 자금
			async available() {
				let list = await this.$http.get('api/user/info', {})
				this.availableFunds = list.data.data
			},

		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},

		onShow() {
			this.available()
			this.largeAmount()
		}
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		padding: 50px 0 0;
	}

	.border {
		border-radius: 10px;
		background: #ffe6c5;
		text-align: center;
	}

	.header {
		height: 55px;
		background: #fff;
		box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .1);
		padding: 0 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}
	}

	.nav-box {
		height: 52px;
		background: #fff;
		border-radius: 0 0 19px 19px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.active {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.nav-item {
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 17px;
			color: #8e939b;
			position: relative;
		}
	}

	.nav-box .active:after {
		content: "";
		display: block;
		width: 18px;
		height: 3px;
		background-color: #eb3b3b;
		border-radius: 2px;
		position: absolute;
		bottom: -3px;
	}

	.list {
		background: #fff;
		border-radius: 19px 19px 0 0;
	}

	.th {
		padding: 11px 16px;
		background: #f8f8f8;
		font-size: 15px;
		color: #999;
	}

	.th1 {
		padding: 11px 16px;
		// background: #fff;
		font-size: 15px;
		color: #333;
	}

	.nodata {
		padding: 110px 0;

		.txt {
			color: #333;
			text-align: center;
		}
	}

	.no-img {
		width: 181px;
		height: 134px;
		background: url(/static/none.png) no-repeat 50%/100%;
		margin: 0 auto 22px;

	}

	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1rpx solid #e0e0e0;
			padding-bottom: 30rpx;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 30rpx 0;
		}

		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border: 1rpx solid #ffdcdc;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.available {
			border: 1rpx solid #ebebeb;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.purchase {
			background-image: linear-gradient(to right, #1a73e8, #014b8d);
			margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;

		}

	}
</style>