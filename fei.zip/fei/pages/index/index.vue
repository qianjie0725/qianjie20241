<template>
	<view style="background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));">
		<view style="padding:20px;height: 560rpx;">
			<view class="flex flex-b">

				<view class="flex-1 flex " style="color: #fff;font-size: 38rpx;">
					<view class="margin-right-10">
						<u-avatar size='30' :src="userinfo.avatar" default-url="/static/logo.png"
							shape="circle"></u-avatar>
					</view>
					<!-- <view class="font-size-18 bold" style="color: #FFFFFF;">
						{{userinfo.real_name}}
					</view> -->
				</view>

				<view class="flex-1 flex justify-end margin-right-10"
					@click="$u.route({url:'/pages/searchFor/searchFor'});">
					<image src="../../static/sousuo.png" mode="widthFix" style="width: 20px;"></image>
				</view>

			</view>

			<view style="border-radius: 23rpx;background-color: #ffffff;padding: 20px 10px;margin-top: 25px;">
				<view class="flex">
					<view class=" flex-column text-center flex flex-1"
						@click="link(3,'/pages/marketQuotations/marketQuotations')">
						<view class=" text-center flex">
							<image src="/static/btn0.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							시장정보
						</view>
					</view>

					<view class="flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newSharesIPO?index=0')">
						<view class=" flex-column text-center flex">
							<!-- <u-icon name="/static/home/top4.png" ></u-icon> -->
							<image src="/static/btn1.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							공모주
						</view>
					</view>


					<view class="flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newShares?index=3')">
						<!-- <u-icon name="/static/home/top2.png" style="width: 30px;height: 30px;"></u-icon> -->
						<image src="/static/btn2.png" style="width: 50px;height: 50px;"></image>
						<view class="margin-top-5 font-size-11">
							대량거래
						</view>
					</view>

					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/index/components/fund/fund')">
						<view class="flex-column text-center flex">
							<image src="/static/btn3.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							EA 거래
						</view>
					</view>
					<!-- <view class="flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newSharesIPO?index=0')">
						<view class=" flex-column text-center flex">
							<u-icon name="/static/home/top4.png" ></u-icon>
							<image src="/static/home/top4.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							IPO
						</view>
					</view> -->
				</view>

				<view class="margin-top-25  flex">
					<view class="flex-column text-center flex flex-1" @click="link(2,'/pages/index/rinei')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top5.png"></u-icon> -->
							<image src="/static/btn4.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							빠른 거래
						</view>
					</view>

					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/index/components/newShareRaising')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top7.png"></u-icon> -->
							<image src="/static/btn5.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							VIP 러쉬
						</view>
					</view>

					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/silver')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top6.png"></u-icon> -->
							<image src="/static/btn6.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							입금 전용
						</view>
					</view>

					<view class="flex-column text-center flex flex-1" @click="linkService()">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top8.png" ></u-icon> -->
							<image src="/static/btn7.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							고객센터
						</view>
					</view>
				</view>
			</view>

			<view class="font-size-18 color-black  margin-top-20">
				색인
			</view>

			<view
				style="border-radius: 10px;background: #fff;margin:10px -10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 2.6px;">
				<!-- <view style="position: relative;" >
					<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #2E67F6;position: absolute;top: 10px;"></view>
				</view> -->
				<u-tabs :list="list1" style="margin: 10px 10px;"
					activeStyle="color:#fff;font-weight: 700;background:#9ca5ff;padding:5px 10px;border-radius:6px"
					lineColor="#f3f4f8" @change="change" :current="current">
				</u-tabs>

				<view class="list" style="padding:4px 6px;">
					<view class="flex flex-b titles">
						<view class="flex-2">종목명</view>
						<view class="flex-1 t-r" v-if="current==0">현재 지수</view>
						<view class="flex-1 t-r" v-else>현재가</view>
						<view class="flex-1 t-r">등락률</view>
					</view>
					<block v-for="(item,index) in listKPI" :key="index">
						<view class="item flex flex-b" style="padding:10px 4px">
							<view style="margin-right: 10px;">
								<u-image :src="item.logo" width="30" height="30" shape="circle"></u-image>
							</view>
							<view class="t flex-2" style="font-size: 14px;font-weight: 500;">

								{{item.ko_name}}
							</view>
							<view class="t1 flex-1 t-r num-font" :class="item.returns>0?'':'die'">
								{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="t1 flex-1 t-r" :class="item.returns>0?'':'die'">
								{{(item.returns*1).toFixed(2)}}%
							</view>
						</view>
					</block>
				</view>
				<view class="flex flex-c more" @click="linkKPI()"
					style="width: 60%;margin-left: 20%;border-radius: 20px;color: #2E67F6;padding-bottom: 20px;">
					더 보려면 클릭하세요
					<!-- <view class="icon jtr"></view> -->
					<image src="/static/arrow_down.png" mode="aspectFit"
						style="width: 30rpx;height: 30rpx;transform:rotate(270deg)"></image>
				</view>
			</view>

			<TabOneSecond ref="flag1"></TabOneSecond>



			<!-- <view class="radius20 padding-20 color-white margin-top-10"
				style="background: linear-gradient(to left,#9e9eef, #6492FF);">
				<view class="flex flex-b">
					<view class="font-size-18">총자산</view>
					<view class="flex">
						<view class="radius10 font-size-14 margin-left-10 color-black"
							style="background-color:#7788fe;padding: 5px 10px;color:#FFFFFF"
							@click="$u.route({url:'/pages/my/components/certificateBank/prove'});">출금신청</view>
					</view>
				</view>
				<view class="font-size-25 margin-top-10 bold">
					₩{{$util.formatNumber(userinfo.totalZichan)}}
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between; margin-top: 20px;">
					<view>
						<view style="display: flex;align-items: center;">
							<image src="/static/new/home1.png" mode="widthFix"
								style="width:48rpx;height: 48rpx;background-color: rgba(255,255,255,0.55);border-radius: 6px;">
							</image>
							<view style="padding-left: 10px;">
								AI 계정
							</view>
						</view>
						<view style="font-size: 32rpx;font-weight: 700;color:#FFFFFF;line-height: 2.4;">
							{{`₩ `+$util.formatNumber(userinfo.aiMoney4)}}
						</view>
					</view>

					<view>
						<view style="display: flex;align-items: center;">
							<image src="/static/new/up1.png" mode="widthFix"
								style="width:48rpx;height: 48rpx;background-color: rgba(255,255,255,0.55);border-radius: 6px;">
							</image>
							<view style="padding-left: 10px;">
								운용 자금
							</view>
						</view>
						<view style="font-size: 32rpx;font-weight: 700;color:#FFFFFF;line-height: 2.4;">
							{{`₩ `+$util.formatNumber(userinfo.money)}}
						</view>
					</view>
				</view>
			</view> -->



			<view class="font-size-18 color-black">
				종목
			</view>

			<view
				style="border-radius: 12px;padding: 10pxbackground-color: #FFFFFF;margin:10px -10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 2.6px;">
				<view class="padding-10 flex" v-for="(item,index) in list"
					@click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});"
					style="border-bottom: 1px solid #f1f1f1;">
					<template v-if="!item.logo || item.logo==''">
						<view
							style="width: 30px;height: 30px;background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;;border-radius:10px;">
							{{item.ko_name.slice(0,1)}}
						</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" style="width: 40px;height: 40px;border-radius: 10px">
						</image>
					</template>

					<!-- <u--image :src="item.logo" shape="circle" width="30px" height="30px"></u--image> -->
					<view style="border-radius: 3px;padding: 3px 8px;" class="margin-left-10">
						<view class="font-size-15">
							{{item.ko_name}}
						</view>
						<view style="color: #999999;">
							{{item.code}}
						</view>
					</view>
					<view style="margin-left:auto;">
						<view class="text-center" style="gap: 20px">
							<view :class="item.returns>0?'red bold':'green bold'">
								<image :src="item.returns>0?'/static/new/up.png':'/static/new/down.png'" mode="widthFix"
									style="width: 15px;height: 15px;"></image>
								{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%

							</view>
							<view style="border-radius: 3px;padding: 3px 8px;color: #000;font-size: 18px;">
								{{numberToCurrency(item.close*1)}}
							</view>
						</view>

					</view>
				</view>
			</view>
		</view>

		<!-- 每次由登入跳转进入时，显示该弹层，关闭后，不再显示。 -->

		<template v-if="isShow && ipoInfo">
			<view class="mask" @click="handleClose()">

				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view style="position:absolute;right:15px;top:15px" @click="handleClose()">
						<image src="/static/close_light.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
					</view>
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;padding: 20px 0;">
						<view style="font-size: 48rpx;font-weight: 700;color: #F2F2F2;">
							축하합니다
						</view>

						<!-- <view>
							<image src="/static/dialog_icon.png" mode="aspectFit" style="$util.setImageSize(480,320)">
							</image>
						</view> -->
						<template v-if="userinfo.real_name">
							<view
								style="text-align: center;font-size: 36rpx;color:#121212;padding-bottom: 16px;line-height: 2.4;">
								{{userinfo.real_name}}
							</view>
						</template>
						<view
							style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
							<view style="font-size: 40rpx;font-weight: 700;color: #FFFFFF;padding:4px 40px;">
								{{ipoInfo.name}}
							</view>
							<view style="font-size: 28rpx;font-weight: 700;color: #f1f1f1;padding:4px 40px;">
								{{ipoInfo.code}}
							</view>

							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;color: #f7f7f7">
								공모주청약 당첨되었습니다
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view style="color: #f7f7f7;">배치 수량</view>
								<text style="font-weight: 700;color:#121212;font-size: 16px;">
									{{$util.formatNumber(ipoInfo.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view style="color: #f7f7f7;">일시금</view>
								<text
									style="font-weight: 700;color:#121212;font-size: 16px;">{{$util.formatNumber(ipoInfo.total)}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1.5;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="linkIPOSuccessLog()">바로보기</view>
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js';
	import TabOneSecond from '@/components/TabOneSecond.vue';
	export default {
		components: {
			TabOneSecond
		},
		data() {
			return {
				isShow: false, // 是否显示ad层,
				ipoInfo: null, // 
				userinfo: {},
				show_money: true,
				// page: 1,
				list: [],
				// gp_index: 0,
				keyword: "",
				business: "",

				show: false,
				list1: [{
					name: '지수',
				}, {
					name: '환율',
				}, {
					name: '원자재'
				}, {
					name: '가상화폐'
				}],
				listKPI: [],
				current: 0,
			}
		},
		onLoad() {
			this.ipoSuccess()
		},
		async onShow() {
			// this.page = 1;
			this.is_token()
			// this.good_list()
			this.gaint_info()
			// this.free()
			// this.startTimer()
			this.lists();
			if (this.$refs.flag1) {
				this.$refs.flag1.onSetTimeout();
			}
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.good_list()
		// },
		onReady() {
			console.log('onReady', this.$refs.flag1);

		},
		onHide() {
			console.log('onHide', this.$refs.flag1);
			if (this.$refs.flag1) {
				this.$refs.flag1.clearTimer();
			}
		},
		deactivated() {
			console.log('deactivated', this.$refs.flag1);
			if (this.$refs.flag1) {
				this.$refs.flag1.clearTimer();
			}
		},
		methods: {
			// 跳转到指标
			linkKPI() {
				if (this.$refs.flag1) {
					this.$refs.flag1.clearTimer();
				}
				uni.reLaunch({
					url: `/pages/marketQuotations/marketQuotations?type=2`
				})
			},
			async lists() {
				this.list = [];
				const result = await this.$http.post('api/goods/zhibiao', {
					current: this.current,
				})
				console.log(result.data.data);
				const temp = Object.values(result.data.data);
				console.log(temp);
				this.listKPI = temp.length <= 5 ? temp : temp.slice(0, 3);
			},
			change(index) {
				console.log(index)
				this.current = index.index;
				this.lists()
			},

			linkService() {
				if (this.$refs.flag1) {
					this.$refs.flag1.clearTimer();
				}
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				})
			},

			tiaozhuan(type) {
				if (type == "scramble") {
					uni.navigateTo({
						url: '/pages/index/components/newShares/ration/ration'
					})
				} else {
					uni.navigateTo({
						url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
					})
				}
			},

			async placement() {
				let list = await this.$http.get('api/goodsscramble/userApplyLog1', {})
				this.peishou_order = list.data.data
				console.log(777, list.data.data)
				// console.log(list.data.data[0], '抢筹');
			},
			// 关闭中签提醒
			handleClose() {
				this.isShow = false;
				uni.setStorageSync('show', 1);
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
				})
			},

			qiehuan(index) {
				if (this.$refs.flag1) {
					this.$refs.flag1.clearTimer();
				}
				this.gp_index = index
				this.good_list()
			},
			link(type, url) {
				if (this.$refs.flag1) {
					this.$refs.flag1.clearTimer();
				}
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			// 银转证
			silver(money, bank_card_info, idno) {
				// if (bank_card_info && idno !== null) {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				})
				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }

			},

			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			// //定时器
			// startTimer() {
			// 	const storedTimerId = uni.getStorageSync('timerId');
			// 	if (storedTimerId) {
			// 		clearInterval(storedTimerId);
			// 	}
			// 	this.timerId = setInterval(() => {
			// 		this.good_list()
			// 		this.free()
			// 	}, 3000);
			// 	uni.setStorageSync('timerId', this.timerId);
			// 	// 在这里立即执行一次请求
			// },
			// async good_list() {

			// 	// this.list=[]
			// 	let list = await this.$http.get('api/goods/list', {
			// 		page: this.page,
			// 		gp_index: this.gp_index
			// 	})
			// 	// if(this.page==1){
			// 	this.list = list.data.data
			// 	// }else{
			// 	// 	this.list = this.list.concat(list.data.data)
			// 	// }

			// },
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await await this.$http.post('api/goods-shengou/tanchuang', {});
				console.log(result);
				if (result.data.code == 0) {
					if (result.data.data.length > 0) {
						const temp = result.data.data[0];
						this.ipoInfo = {
							code: temp.goods.number_code,
							name: temp.goods.name,
							success: temp.success,
							total: temp.total,
						};
						this.isShow = true;
					}
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
			// async free() {
			// 	let list = await this.$http.get('api/user/collect_list', {})
			// 	this.business = list.data.data.list
			// },


		},
	}
</script>

<style lang="scss">
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		// background-image: url(/static/new/my_bg.png);
		// background-size: cover;
		// background-position: center;
		// background-repeat: no-repeat;
		background: linear-gradient(to top, #9e9eef, #6492FF);
		height: 40vh;
		width: 80vw;
	}
</style>