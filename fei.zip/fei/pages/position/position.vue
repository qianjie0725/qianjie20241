<template>
	<view class="page">
		<view class="home"
			style="padding: 10px 0;background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));">
			<view style="border-radius: 10px;margin: 10px;padding:10px;">
				<view class="flex padding-10">
					<view class="text-center" style="width: 40%;margin-left: 5%;" :class="Inv==0?'with-bottom-line':''"
						@click="qiehuan(0)">
						종목 보유 현황
					</view>
					<view class="text-center" style="width: 40%;margin-left: 5%;" :class="Inv==1?'with-bottom-line':''"
						@click="qiehuan(1)">
						매매 내역
					</view>
				</view>
				<!-- <view style="width: 100%;background-color: #E8EAF3;height: 1px;margin-top: 10px;"></view> -->
				<view
					style="border: 1px #d3d3d3 solid; padding: 10px;margin-top: 10px;border-radius: 10px;background-color: #fff;"
					v-for="(item,index) in storehouse" :key="index">
					<view class="flex flex-b ">
						<view class="flex gap10">
							<view style="width: 5px;background-color: #4f61f5;height: 35px;"></view>
							<view>{{item.goods_info.name}}</view>
							<view style="background-color: #c4d3f6;padding:8px 6px;color: #2E67F6;font-size: 12px;">
								{{item.goods_info.code}}</view>
						</view>

						<!-- <view style="padding:8px 10px;color: #666666;font-size: 12px;" v-if="Inv==0">
							{{item.order_buy.created_at}}</view>
						<view style="padding:8px 10px;color: #666666;ont-size: 12px;" v-if="Inv==1">
							{{item.order_sell.created_at}}</view> -->
					</view>
					<view style="width: 100%;background-color: #E8EAF3;height: 1px;margin-top: 10px;"></view>
					<view class="flex margin-top-10">
						<view class="flex-1">
							<view class="hui1">현재 가격</view>
							<view class="hui1" v-if="Inv==0">{{$util.formatNumber(item.goods_info.current_price)}}
							</view>
							<view class="hui1" v-if="Inv==1">{{$util.formatNumber(item.order_sell.price)}}</view>

						</view>
						<view class="flex-1 text-center">
							<view class="hui1">매수량</view>
							<view class="hui1">{{$util.formatNumber(item.order_buy.num)}}</view>

						</view>
						<view class="flex-1 text-right">
							<view class="hui1">체결가</view>
							<view class="hui1" v-if="Inv==0">{{$util.formatNumber(item.order_buy.price)}}</view>
							<view class="hui1" v-if="Inv==1">{{$util.formatNumber(item.order_buy.price)}}</view>

						</view>
					</view>
					<view class="flex margin-top-10">
						<view class="flex-1">
							<view class="hui1">시장 가치</view>
							<view class="hui1" v-if="Inv==0">{{$util.formatNumber(item.order_buy.amount)}}</view>
							<view class="hui1" v-if="Inv==1">{{$util.formatNumber(item.order_sell.amount)}}</view>

						</view>
						<view class="flex-1 text-center">
							<view class="hui1">총평가손익</view>
							<view v-if="Inv==0" :class="item.order_buy.yingkui>0?'red':'green'">
								{{$util.formatNumber(item.order_buy.yingkui)}}</view>
							<view v-if="Inv==1" :class="item.order_sell.yingkui>0?'red':'green'">
								{{$util.formatNumber(item.order_sell.yingkui)}}</view>

						</view>
						<view class="flex-1 text-right">
							<view class="hui1">수익률</view>
							<view v-if="Inv==0" :class="item.order_buy.yingkui>0?'red':'green'">
			{{$util.formatNumber((item.goods_info.current_price-item.order_buy.price)/item.order_buy.price/item.order_buy.double*100,2)}}%
							</view>
							<view v-if="Inv==1" :class="item.order_sell.yingkui>0?'red':'green'">
								{{$util.formatNumber(item.order_sell.yingkui/item.order_buy.amount/item.order_buy.double*100,2)}}%
							</view>

						</view>
					</view>
					<view style="width: 100%;background-color: #E8EAF3;height: 1px;margin-top: 10px;"></view>
					<view class="text-center padding-10 radius10 margin-top-10"
						style="background-color: #c4d3f6;color: #2E67F6;" @tap="sell(item)"
						v-if="Inv==0">
						보유중
					</view>
				</view>
			</view>

		</view>

		<u-picker :show="gp_show" :columns="gp_select" cancelText="취소" confirmText="확인" :closeOnClickOverlay="true"
			@close="gp_show=false" @cancel="gp_show=false" @confirm="gp_changes"></u-picker>




		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view
			style="position: fixed;left: 0;right: 0; width:100%;border-radius: 20px 20px 0 0;background-color: #fff;bottom: 0;z-index: 9999;padding-bottom: 30px;padding:20px;"
			v-if="item_show">
			<view class="padding-10 flex ">
				<view class="text-center justify-center width100 font-size-18 bold">세부</view>

				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목</view>
					<view class="flex-1" style="text-align: right;">{{info.goods_info.name}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매수 시간</view>
					<view class="flex-1" style="text-align: right;">{{info.order_buy.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;" v-if="Inv==1">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매도시간</view>
					<view class="flex-1" style="text-align: right;">{{info.order_sell.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">유동손익</view>
					<view class="flex-1" v-if="Inv==0" style="text-align: right;">
						{{$util.formatNumber(info.order_buy.float_yingkui)}}
					</view>
					<view class="flex-1" v-if="Inv==1" style="text-align: right;">
						{{$util.formatNumber(info.order_sell.float_yingkui)}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">레버리지</view>
					<view class="flex-1" style="text-align: right;">X{{info.order_buy.double}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총손익</view>
					<view class="flex-1" v-if="Inv==0" style="text-align: right;">
						{{$util.formatNumber(info.order_buy.yingkui)}}
					</view>
					<view class="flex-1" v-if="Inv==1" style="text-align: right;">
						{{$util.formatNumber(info.order_sell.yingkui)}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매입가</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.price)}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수량</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.num)}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수수료</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.buy_fee)}}
						<span v-if="Inv==1">/{{$util.formatNumber(info.order_sell.sell_fee)}}</span>
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총 매입가</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.amount)}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">코드</view>
					<view class="flex-1" style="text-align: right;">{{info.goods_info.number_code}}</view>
				</view>
			</view>

			<template v-if="Inv==0">
				<view style="display: flex;align-items: center;">
					<view
						style="background-color: #e82d28;flex:40%;margin:10px 20px;text-align: center;border-radius: 30px;"
						class="padding-10 radius10 color-white font-size-16"
						@tap="productDetails(info.goods_info.number_code)">매수</view>
					<view
						style="background-color: #2E67F6;flex:40%;margin:10px 20px;text-align: center;border-radius: 30px;"
						class="padding-10 radius10 color-white font-size-16" v-if="Inv==0" @tap="position(info.id)">매도
					</view>
				</view>
			</template>
		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' cancel-text="취소" confirm-text="포지션을 청산하다">

			<view class="flex-1 text-center bold font-size-18" v-if="Inv==0&&info.order_buy"
				:class="info.order_buy.float_yingkui>0?'red':'green'">
				{{info.order_buy.float_yingkui>0?'+'+$util.formatNumber(info.order_buy.float_yingkui):$util.formatNumber(info.order_buy.float_yingkui)}}

			</view>


		</u-modal>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				gp_select: [
					["국내", "해외"]
				],
				gp_index: 0,
				gp_show: false,

				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['종목 보유 현황', '매매 내역',
					// '보유수량', '매매내역'
				],
				show: false,
				title: '매도 주문',
				content: '매도 하시겠습니까?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				timerId: null,
				info: [],
				item_show: false
			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.shuaxin()
			uni.stopPullDownRefresh()
		},

		methods: {
			sell(item) {
				this.info = item
				this.item_show = true;
			},
			gp_changes(index) {
				console.log(index)
				this.gp_index = index.indexs[0]
				this.gp_show = false

				this.storehouse = ""

				this.shuaxin()
			},
			qiehuan(index) {
				this.Inv = index
				this.shuaxin()
			},
			shuaxin() {
				this.storehouse = ""
				uni.showLoading({
					mask: true
				})
				if (this.Inv == 1) {
					this.flat()
				} else {
					this.hold();
				}
			},
			// 平仓
			position(id) {
				this.item_show = false
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${code}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			// 银转证
			silver() {
				if (this.userInformation.bank_card_info && this.userInformation.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
					});
				} else if (this.userInformation.bank_card_info == null) {
					uni.$u.toast('은행 카드에 묶여 있지 않음');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInformation.idno == null) {
					uni.$u.toast('실명인증 불가');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			// 新股持仓
			async holdings(e) {
				let list = await this.$http.post('api/user/sg-order', {
					gp_index: this.gp_index
				})
				this.luckyNumber = list.data.data

			},

			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-all-apply-log', {
					gp_index: this.gp_index
				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},



			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');

			},
			//持仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					gp_index: this.gp_index
				})
				// this.storehouses = list.data.data
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');
				// setTimeout(() => {
				// 	this.marketQuotations()
				// }, 10000)
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "포지션을 마감 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.shuaxin()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('위치요청');
					this.shuaxin()
					this.gaint_info()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求

			},

			duihuan() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					// url: '/pages/my/components/duihuan/index'
					url: "/pages/my/components/certificateBank/prove"
				});
			}
		},

		onShow() {
			this.is_token()
			this.gaint_info()
			// this.flat()
			this.shuaxin()
			// this.startTimer()
		},

		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #fff;
	}

	.with-bottom-line {
		background-color: #2E67F6;
		padding: 10px;
		color: #fff;
		font-weight: 700;
		border-radius: 10px;
		text-align: center;
		height: 40px;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #2E67F6;
		/* 添加底部横线 */
		width: 20%;
		margin-left: 40%;
		/* 使横线宽度与父元素相同 */
		/* 可选：添加一些顶部外边距 */
		text-align: center;
	}

	.bglan {
		background-color: #EEF4FF;
	}

	.bgyellow {
		background-color: #F8F8F8;
	}


	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>