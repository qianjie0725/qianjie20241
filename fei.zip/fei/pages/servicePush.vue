<template>
	<view>
		<!-- <view class="access_bg" style="padding-top:0">
			<view @click="linkBack()">
				<CustomHeader title=""></CustomHeader>
			</view>
			<view style="text-align: center;margin-top: 15vh;">
				<image mode="aspectFit" src="/static/logo.png" :style="$util.setImageSize(240)">
				</image>
			</view>

			<view style="font-size: 28rpx;color:#FFFFFF;text-align: center;margin-top: 5vh;">
				{{$lang.TIP_LINK_SERVICE_SYSTEM}}
			</view>
		</view> -->
	</view>
</template>

<script>
	// import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		// components: {
		// 	CustomHeader,
		// },
		created() {
			this.getServiceURL()
		},
		methods: {
			// linkBack() {
			// 	console.log(111);
			// },

			async getServiceURL() {
				// setTimeout(() => {
				this.$util.linkService();
				// }, 2000)
			}
		}
	}
</script>