<template>
	<view class="page">
		<view class="home"
			style="padding: 30px 10px 10px 20px;background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));">
			<view class="flex flex-b">

				<view class="flex-1 flex " style="color: #000;font-size: 38rpx;">
					관심목록
				</view>
				<view class="flex-1 flex justify-end margin-right-10"
					@click="$u.route({url:'/pages/searchFor/searchFor'});">
					<image src="../../static/sousuo.png" mode="widthFix" style="width: 20px;"></image>
				</view>

			</view>



			<view class="box"
				style="margin-top: 30px;">
				
				<view class="  radius20 margin-top-10 background-white padding-20" v-for="(item,index) in business"
					@click="$u.route('/pages/marketQuotations/productDetails',{code:item.goods.number_code});">
					<view class="flex flex-b">
						<view class="list-name flex">
							<image :src="$BaseUrl+item.goods.logo" mode="widthFix" style="width: 40px;height: 40px;" class="radius20"></image>
							<view class="margin-left-10">
								<view class="list-name-txt ">{{item.goods.name}}</view>
								
								<view style="color: #999999;">{{item.goods.number_code}}</view>
							</view>
						</view>
						<view class="margin-left-10">
							<image src="/static/new/qx.png" mode="widthFix" style="width: 20px;" class="radius20" @click.stop="handleClickDelProduct(item.goods.gid)"></image>
						</view>
										
						<view class="per flex-1 t-r" :class="item.goods.rate>0?'red':'green'">
						<image :src="item.goods.rate>0?'/static/new/up.png':'/static/new/down.png'" mode="widthFix" style="width: 15px;"></image>
							{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
						</view>
						<view class="flex justify-end" style="margin-left: 10px;" :class="item.goods.rate>0?'red':'green'">
						</view>
					</view>
					
					<view class="margin-top-20 flex">
						<view class="flex-1 font-size-18 bold ">
							₩{{item.goods.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
						</view>
						<view>
							<image :src="item.goods.rate>0?'/static/hong.png':'/static/lv.png'" mode="widthFix" style="width: 80px;" class="radius20"></image>
						</view>
					</view>
				</view>

			</view>
		</view>
	</view>

</template>

<script>
	export default {
		components: {},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: '',
				updata: true,
				exchange: '',
				timerId: null
			}
		},
		methods: {

			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//产品세부
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			//跳转行情
			marketQuotations() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/marketQuotations'
				});
			},


			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: gid,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = false
					this.updata = true
					this.free()
					// this.$router.go(0)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			async market() {
				let list = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 10,
				})
				//上证指数
				this.exchange = list.data.data.zhishu
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			//版本更新
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(list.data.data, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('선택적 요청');
					this.free();
					this.market()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},

		},

		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			this.free()
			this.market()
			this.is_token()
			this.startTimer()
		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #f3f4f8;
	}

	.home {
		height: 600rpx;
		margin-left: -10px;
	}

	.header {
		height: 50px;
		background: #014b8d;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			width: 9px;
			height: 16px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}
	}

	.top {
		height: 55px;
		border-bottom: 1px solid #e5e8f6;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
	}

	.box .top {
		padding: 10px;

		view {
			color: #91a2b1;
		}

	}

	.box .box-item {
		padding: 10px;

		.list-name-txt {
			font-weight: 700;
			color: #333;

			span {
				background: #f0f3fa;
				border-radius: 5px;
				padding: 2px 5px;
				margin-left: 5px;
				font-size: 12px;
				font-weight: 400;
				color: #333;
			}
		}

		.per {
			font-weight: 700;
			border-radius: 10px;
			padding: 5px;
		}

		.per.bg-red {
			background-color: #ff3636;
			color: #fff;
			border-radius: 5px;
			text-align: center;
			padding: 3px 0px;
		}

		.red {
			font-weight: 700;
			color: #ff3636;

		}

		.per.bg-green {
			background-color: #014b8d;
			color: #fff;
			border-radius: 5px;
			text-align: center;
			padding: 3px 0px;
		}

		.green {
			font-weight: 700;
			color: #014b8d;

		}
	}
</style>