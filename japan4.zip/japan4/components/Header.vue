<template>
	<header class="common_header">
		<view class="primary_header_left" @click="$u.route({url:$util.PAGE_URL.SEARCH});">
			<image mode="aspectFit" src="/static/search.png" :style="$util.calcImageSize(16)"></image>
		</view>
		<view class="primary_header_right flex">
			<image class="flex-1" mode="aspectFit" src="/static/service.png" :style="$util.calcImageSize(20)"
				@click="kefu" style="padding-left: 6px;"></image>
			<image class="flex-1" mode="aspectFit" src="/static/notification.png" :style="$util.calcImageSize(20)"
				@click="$u.route({url:$util.PAGE_URL.NOTIFICATION});" style="padding-left: 6px;"></image>
			<image class="flex-1" mode="aspectFit" src="/static/sign_out.png" :style="$util.calcImageSize(20)" @click="handleSignOut()"
				style="padding-left: 6px;"></image>
		</view>
	</header>
</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
			async kefu() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('正常終了');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>