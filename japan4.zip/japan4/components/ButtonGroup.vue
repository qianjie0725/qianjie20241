<template>
	<view class="btns">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.calcImageSize(40)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns'],
		data() {
			return {};
		},

		methods: {
			actionEvent(url, index) {
				if (url.includes('pages')) {
					if(url=="/pages/stock/bookmark"){
						uni.switchTab({
							url:url
						})
					}else{
						uni.navigateTo({
							url: url
						})
					}
					
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>