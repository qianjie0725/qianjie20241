<template>
	<view class="common_block" style="margin-top: 20px;">
		<TabsSecond :tabs="$util.tabsMarketIndex" @action="handleChangeTab"></TabsSecond>
		<view style="padding:6px 10px;display: flex;align-items: center;" :style="{color:$util.THEME.TIP}">
			<view style="flex:50%;">종목명</view>
			<view v-if="current==0" style="flex:30%;text-align: right;padding-right: 16px;">현재 지수</view>
			<view v-else style="flex:30%;text-align: right;padding-right: 16px;">현재가</view>
			<view style="flex:20%;text-align: right;padding-right: 16px;">등락률</view>
		</view>

		<view style="overflow-y: scroll;height: 72vh;">
			<block v-for="(item,index) in list" :key="index">
				<view style="display: flex;align-items: center;padding: 0 10px;">
					<view style="flex:50%;">
						<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(24)"
							style="border-radius: 100%;"></image>
						<text style="font-size: 14px;font-weight: 500;padding-left: 10px;"
							:style="{color:$util.THEME.TEXT}">
							{{item.ko_name}}
						</text>
					</view>
					<view style="flex:30%;text-align: right;padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.returns>0)">
						{{$util.formatNumber(item.close)}}
					</view>
					<view style="flex:20%;text-align: right;padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.returns>0)">
						{{(item.returns*1).toFixed(2)}}%
					</view>
				</view>
			</block>
			<view style="text-align: center;color: #999;">인기종목은 총 100위까지 순위만 제공합니다. </view>
		</view>
	</view>
</template>

<script>
	import TabsSecond from '@/components/TabsSecond.vue';
	export default {
		name: 'TabThree',
		components: {
			TabsSecond
		},
		props: {},
		data() {
			return {
				list: [],
				current: 0,
			}
		},
		mounted() {
			this.getList()
		},
		methods: {
			handleChangeTab(val) {
				this.current = val;
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.GOODS_ZHIBIAO, {
					current: this.current
				});
				this.list = result.data.data;
				uni.hideLoading();
			},
		},
	}
</script>

<style lang="scss">
	.list {
		padding: 0 0 10px;

		.titles {
			padding: 10px;

			uni-view {
				color: #91a2b1;
			}
		}

		.item {
			padding: 10px;

			.t {
				font-size: 16px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				color: #ff3636;
				font-weight: 600;
			}

			.t1.die {
				color: #014b8d;
				font-weight: 600;
			}

			.num {
				color: #999;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #3c1f20;

			span {
				background: #f9e80e;
			}
		}
	}
</style>