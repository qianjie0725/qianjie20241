<template>
	<view style="padding:0 10px 6px 10px;">
		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.code)" class="line"
				style="padding: 6px 0;margin:0 10px;display: flex;align-items: center;">
				
				<view style="display: inline-block;flex:50%;padding-left: 6px;" :style="{color:$util.THEME.TEXT}">
					<view>{{item.name}}</view>
					<view style="color:#626262;">{{item.code}}</view>
				</view>
				
				<view style="display: inline-block;flex:25%;text-align: right;font-weight: 700;">
					<text style="display: inline-block;text-align: right;padding:4px;"
						:style="$util.calcStyleRiseFall(item.returns>0)">{{item.close}}
					</text>
					<view style="display: inline-block;padding:4px;"
						:style="$util.calcStyleRiseFall(item.returns>0,true)">
						{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
		},
		methods: {
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {

				// this.list=[]
				let list = await this.$http.post('api/goods/top2', {
					current: 0,
					limit:50
				})
				// if(this.page==1){
				this.list = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
		}
	}
</script>