<!-- 用于纵向导航，如：个人中心 -->
<template>
	<view style="padding: 6px;">
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block" style="display: flex;align-items: center;padding-left: 20px;margin:10px;margin-bottom: 20px;height: 60px;"
				@click="actionEvent(item,index)">
				<view style="flex: 12%;">
					<image style="width: 32px; height: 32px;" mode="aspectFit" :src="`/static/${item.icon}.png`">
					</image>
				</view>
				<text style="flex: 70%;font-weight: 700;font-size: 15px;"
					:style="{color:$util.THEME.TEXT}">{{item.name}}</text>
				<view style="flex: 12%;">
					<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: ['list'],
		data() {
			return {};
		},
		methods: {
			actionEvent(item, index) {
				if (item.mode) {
					uni.navigateTo({
						url: item.url,
					})
				} else {
					this.$emit('action', item);
				}
			},
		}
	}
</script>

<style>

</style>