<!-- 绑定银行卡 -->
<template>
	<view >
		<view class="header_wrapper">
			<CustomHeader title="口座登録" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:3vh;">
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<view style="width: 80px;display: inline-block;">銀行名:</view>
				
				<u--input v-model="value" type="text" :placeholder="$lang.REAL_NAME" :clearable='true'></u--input>
			</view>
			
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<view style="width: 80px;display: inline-block;">支店名:</view>
				
				<u--input v-model="value1" type="text" :placeholder="$lang.BANK_NAME" :clearable='true'></u--input>
				
			</view>

			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<view style="width: 80px;display: inline-block;">支店番号:</view>
				<u--input v-model="value2" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></u--input>
				
			</view>
			
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<view style="width: 80px;display: inline-block;">口座番号:</view>
				<u--input v-model="value3" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></u--input>
				
			</view>
			
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<view style="width: 80px;display: inline-block;">口座種類:</view>
				<u--input v-model="value4" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></u--input>
				
			</view>
			
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<view style="width: 80px;display: inline-block;">口座名義:</view>
				<u--input v-model="value5" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></u--input>
				
				
			</view>

			<template>
				<view class="common_btn btn_primary" style="width:80%;margin-top: 20px;" @click="replaceBank()">確認</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				info: {},
				isRenewal:false,
				value: '',
				value1: '',
				value2: '',
				value3: '',
				value4: '',
				value5: '',
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			renewal() {
				this.isRenewal=true;
			},
			// 换绑银行卡
			async replaceBank() {
				let list = await this.$http.post(this.$http.API_URL.USER_BIND_CARD, {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					bank_name: this.value,
					bank_sub_name: this.value1,
					// bank_sub_name: this.value3,
					zd_number: this.value2,
					qy_type: this.value3,
					realname: this.value4,
					card_sn: this.value5,
					
				})
				if (list.data.code == 0) {
					uni.$u.toast('銀行カード情報が正常に送信されました。');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				this.info = result.data.data.bank_card_info
				this.value=this.info.bank_name
				this.value1=this.info.bank_sub_name
				this.value2=this.info.zd_number
				this.value3=this.info.qy_type
				this.value4=this.info.realname
				this.value5=this.info.card_sn
				
			},
		},
	}
</script>