<template>
	<view >
		<view class="header_wrapper" style="margin-bottom: 20px;">
			<CustomHeader title="本人認証" @action="$u.route({type:'navigateBack'});"></CustomHeader>
		</view>
		<view class="common_block"
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;margin-top:5vh;">
			<view class="common_input_wrapper" style="width: 80%;">
				<image mode="aspectFit" src="/static/user.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value1" type="text" placeholder="名前を入力してください"></input>
			</view>
			<!-- <view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/card1.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value2" type="text" placeholder="ID番号を入力してください"></input>
			</view> -->
			<template v-if="userinfo.is_check!=0">
				<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding: 20px;">
					<view :style="{color:$util.THEME.PRIMARY}">身分証明の表面</view>
					<image :style="$util.calcImageSize(160)"
						:src="formData.obverseUrl?formData.obverseUrl:`/static/card_f.png`" @click="obverse_btn" style="margin-bottom: 20px;margin-top: 10px;"></image>
						
					<view :style="{color:$util.THEME.PRIMARY}">身分証明の裏面</view>
					<image :style="$util.calcImageSize(160)" style="margin-top: 10px;"
						:src="formData.reverseUrl?formData.reverseUrl:`/static/card_b.png`" @click="reverse_btn"></image>
			
					<view class="common_btn btn_primary" style="width: 50%;margin-top:40px ;" @click="gain_aouonym()">今すぐ認証します</view>
				</view>
			</template>
		</view>

		
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import Blob from 'blob';
	import md5 from 'js-md5'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onLoad() {},
		mounted() {
			this.userInfo()
		},
		methods: {
			obverse_btn() {
				if (this.obverseUrl) {

					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast('フロントをクリックして追加');
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast('裏をクリックして追加しました。');
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB

						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},

			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],

				});
			},
			// 删除
			del_btn(name) {
				this.$emit('del', {
					name
				});
			},

			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: "送信中です。 しばらくお待ちください....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.HOME
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
				}
			},
			async userInfo() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.value1 = list.data.data.real_name
				this.value2 = list.data.data.idno
				this.userinfo = list.data.data
				this.formData.obverseUrl = list.data.data.front_image
				this.formData.reverseUrl = list.data.data.back_image
				// console.log(list.data.data, '1111111111111');
				uni.hideLoading();
			},

			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "アップロード中"
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()


				let mdd = md5("XPFXMedS" + Request + str_url + time)

				uni.uploadFile({
					url: this.$BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
					filePath: tempFilePath,
					name: 'file',

					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data)
						if (type == 1) {
							this.formData.obverseUrl = data[0].url;
						} else {
							this.formData.reverseUrl = data[0].url;

						}

					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});
			},
			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				console.log(222, e)
				var that = this;
				if (e.name == "obverse") {
					this.upimg(1, e.tempFilePath)

				} else if (e.name == "reverse") {
					this.upimg(2, e.tempFilePath)

				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
	};
</script>