<!-- 银转证  存款 -->
<template>
	<view >
		<view class="header_wrapper" style="margin-bottom: 20px;">
			<CustomHeader :title="$lang.DEPOSIT" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(userInfo.money)}}
			</view>
			<view style="padding:20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
			<view class="common_btn btn_primary" style="width: 80%;margin:auto;height: 40px;line-height: 40px;" @click="handleCustomer()">
				{{$lang.TIP_LINK_SERVICE}}
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				userInfo: {},
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			async handleCustomer() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
				
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>