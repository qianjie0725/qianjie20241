<template>
	<!-- 大宗交易 -->
	<view>
		<view class="white-background">
			<view class="notes">
				<view class="purchase" @tap="blockTransactions()">
					<image src="/static/shengou.png" mode=""></image>
					<view class="">
						Lịch sử giao dịch
					</view>
				</view>
			</view>
		</view>
		<view style="background-color: #442f84;" class="padding-10 margin-10 radius10" v-for="(item,index) in business"
			:key="index">
			<view class="flex gap10">
				<view
					style="background-color: #2c4f9f;width: 40px;height: 40px;color: #fff;text-align: center;line-height: 40px;border-radius: 5px;">
					{{item.goods.name.charAt(0)}}
				</view>
				<view>
					<view style="color: #fff;">{{item.goods.name}}</view>
					<view class="hui font-size-12">{{item.goods.code}}</view>
				</view>
			</view>
			<view class="flex flex-b color-white">
				<view>Giá đặt lệnh</view>
				<view>{{toThousandFilter(item.price)}}</view>
			</view>
			<view @click="detail(item)" class="text-center padding-5 margin-top-10 radius10"
				style="background-image: linear-gradient(to right, #FFB044, #FF2D30);">
				Chi tiết
			</view>
		</view>


		<u-popup :show="show" @close="close" :round="20" mode="bottom" :closeable='closeable'>
			<view class="largeAmount">
				<view class="business">
					Đặt lệnh
				</view>
				<view class="price">Giá đặt lệnh</view>
				<view class="purchase-price">{{toThousandFilter(detailId.price)}}</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="" v-model="value1"></u-input>
					<view class="hand">Khối lượng</view>
				</view>

				<!-- <view class="amount" style="margin-bottom: 20rpx;">1 Lô chẵn = 100 Cổ phiếu </view> -->

				<view class="amount"> Số tiền yêu cầu mua
					<text>{{toThousandFilter(detailId.price*this.value1/curLever)}}
					</text>
				</view>

				<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>1">
					<view style="font-size: 14px;margin-top: 10px;">
						Margin
					</view>

					<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
						<block v-for="(item,index) in leverList" :key="index">
							<view
								style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="{color:curLever==item? '#121212' :'#999',backgroundColor:curLever==item?'#ebdbff'
												:'#F1F1F1'}" @click="chgangeLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template>

				<!-- 
				<view class="available"   v-if="detailId.gg_moren>0" >
					<u-input type="number" :disabled="true" placeholder="" v-model="ganggan" inputAlign='right'>
					</u-input>
				</view>
				<view class="available"  @tap.stop="ganggan_show=true" v-if="detailId.gg_moren==0">										
					<u-input type="number" :disabled="true" placeholder="" v-model="ganggan" inputAlign='right'>
					</u-input>
				</view> -->


				<!-- <view class="available">
					<u-input type="password" placeholder="请输入资金密码" v-model="value2"></u-input>
				</view> -->
				<view class="fund margin-top-15">
					Sức mua <text>{{toThousandFilter(availableFunds.money)}}</text>
				</view>
				<view>
					<view class="purchase "
						style="background-color:#ff5136 ;width: 85%;margin: 20px;height: 30px;line-height: 30px; border-radius: 5px;text-align: center;padding: 0px 5px;"
						@click="bulkPurchase(detailId.id)">Đặt lệnh</view>
				</view>
			</view>

		</u-popup>

		<!-- <u-action-sheet :show="ganggan_show" :actions="actions" title="Margin (Đòn bẩy)" @close="ganggan_show = false"
			@select="Select">
		</u-action-sheet> -->

	</view>
</template>

<script>
	export default {
		data() {
			return {
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前杠杆值
				// actions: [{
				// 		name: '1',
				// 		index: 1
				// 	}
				// ],
				show: false,
				closeable: true,
				business: "",
				detailed: '',
				value1: '',
				value2: '',
				availableFunds: '',
				detailId: '',
				// ganggan:2,
				// ganggan_show:false
			}
		},
		computed: {
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / this.curLever;
			}
		},
		methods: {
			// 选择杠杆
			chgangeLever(val) {
				this.curLever = val;
			},

			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// Select(e) {
			// 	console.log(e);
			// 	this.ganggan = e.index
			// 	// this.columns = this.detailedData.ganggan
			// 	// console.log(this.title, '99999');
			// },
			close() {
				this.show = false
				// console.log('close');
			},
			detail(item) {
				this.show = true
				this.bulkDetails(item)
				// console.log(this.bulkDetails, '987654');
			},
			blockTransactions() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			//列表
			async largeAmount() {
				let list = await this.$http.get('api/goods-bigbill/list', {})
				this.business = list.data.data
				// console.log(list.data.data, '大宗交易');
			},
			//详情
			async bulkDetails(item) {
				let list = await this.$http.get('api/goods-bigbill/detail', {
					id: item.id
				})
				this.detailed = list.data.data.goods
				this.detailId = list.data.data
				console.log(list.data);
				if (this.detailId.gg_moren && this.detailId.gg_moren > 0) {
					this.curLever = this.detailId.gg_moren;
				}
				// if (this.detailId.gg_moren > 0) {
				// 	this.ganggan = this.detailId.gg_moren
				// } else {
				// 	this.ganggan = 1
				// }

				// console.log(this.detailed, '大宗交易');
			},
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
				// this.actions = list.data.data.ganggan
				console.log(list.data.data.ganggan);
				// 处理杠杆，后端数据返回不一致。
				const temp = list.data.data.ganggan || [];
				if (!temp || temp.length <= 0) return false;
				// ganggan: [{name: "", index: ""}] 
				// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
				if (temp[0].index && temp[0].index * 1 > 0) {
					this.leverList = temp.map(item => item.index * 1);
					console.log('array object:', this.leverList);
					return false;
				}
				// ganggan: "2,3,4,5,6,7,8,9,10"
				if (typeof(temp) === 'string') {
					this.leverList = temp.split(',').map(item => item * 1);
					console.log('string:', this.leverList);
					return false;
				}
				// if (typeof(temp) == 'array') {
				// 	this.leverList = temp.filter(item => item * 1);
				// }
			},
			//点击购买
			async bulkPurchase(id) {
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					ganggan: this.curLever, // 杠杆
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
						});
					}, 1000)
				} else {
					// if (list.data.code == 1) {
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/certificateBank/silver'
					// 		});
					// 	}, 1000)
					// }

					if (this.value1 == '') {
						this.show = false
						uni.$u.toast('Vui lòng nhập số lượng');
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
					// else if (this.value2 == '') {
					// 	this.show = false
					// 	uni.$u.toast('请填写资金密码');
					// 	setTimeout(() => {
					// 		this.show = true
					// 	}, 1000)
					// } 
					else {
						this.show = false
						uni.$u.toast(list.data.message);
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
				}
			},
			//可用资金
			async available() {
				let list = await this.$http.get('api/user/info', {})
				this.availableFunds = list.data.data
			},

		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		mounted() {
			this.largeAmount()
			this.available()
			this.userInfo()
			// this.bulkDetails()
		},
		onShow() {
			this.bulkDetails()
			this.available()

		}
	}
</script>

<style lang="scss">
	/deep/.uni-input-placeholder {
		font-size: 28rpx !important;
	}

	.white-background {
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;
		color: #fff;

		.notes {
			text-align: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;

			.purchase {
				font-size: 28rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}

		}

		.take-notes {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;
			font-size: 28rpx;


		}
	}

	.science {
		margin: 30rpx;
		padding-bottom: 30rpx;
		border-bottom: 0.037037rem solid #e0e0e0;

		.corporation {
			font-size: 30rpx;
			font-weight: 600;
			color: #333;

		}

		.price {
			color: #121327;
			font-size: 28rpx;
			margin-left: 100rpx;
		}

		.detailed {
			background-image: linear-gradient(to right, #FFB044, #FF2D30);
			color: #fff;
			border-radius: 40rpx;
			padding: 6rpx 40rpx;
			font-size: 26rpx
		}

		.find {
			width: 45%;

			view:nth-child(2) {
				color: #121327;
			}
		}

		.ration {
			width: 45%;

			view:nth-child(2) {
				color: #121327;
			}
		}
	}

	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1rpx solid #e0e0e0;
			padding-bottom: 30rpx;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 30rpx 0;
		}

		.purchase-price {
			color: #4bae4f;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border: 1rpx solid #4bae4f;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #4bae4f;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;

			text {
				color: #4bae4f;
				margin-left: 20rpx;
			}
		}

		.available {
			border: 1rpx solid #ebebeb;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}


	}
</style>