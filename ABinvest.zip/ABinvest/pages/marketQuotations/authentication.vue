<template>
	<view style="background-color: #fff;">
		<view class="college-bg">
			<image src="../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">
				Danh tính
			</view>
			<view class=""></view>
		</view>

		<!-- 姓名 -->
		<view class="identity-card" >
			<view class="choice">Họ và Tên</view>
			<u-input placeholder="Vui lòng nhập Họ và Tên" v-model="value1"></u-input>
			<view class="choice">Số CCCD/CMND / Hộ chiếu</view>
			<u-input placeholder="Vui lòng nhập số Căn cước công dân" v-model="value2"></u-input>
		</view>
		<view
			style="border-radius: 10px;background: #fff;padding: 20px">
			<view v-if="userinfo.is_check!=1">
		
				<view class="bold">Tải lên mặt trước Căn cước công dân</view>
				<view style="background-color: #F6F9FF;border-radius: 10px;margin-top: 10px;padding: 30px;">
					<image :src="formData.obverseUrl?formData.obverseUrl:'/static/purchase/zheng.png'"
						style="margin-left: 5%;margin-top: 20px;width: 80%;margin-left: 10%;" mode="widthFix"
						@click="obverse_btn"></image>
				</view>
		
		
				<view class="bold">Tải lên mặt sau Căn cước công dân</view>
				<view style="background-color: #F6F9FF;border-radius: 10px;margin-top: 10px;padding: 30px;">
					<image :src="formData.reverseUrl?formData.reverseUrl:'/static/purchase/fan.png'"
						style="margin-left: 5%;margin-top: 20px;width: 80%;margin-left: 10%;" mode="widthFix"
						@click="reverse_btn"></image>
				</view>
				
			</view>
				
		</view>
		<!-- 身份证 -->
		<view class="">
			<view class="certification-content" >
				<view class="bottom-content">
					<view class="" v-if="this.value1||this.value2!=''">
						<view class="submit" v-if="userinfo.is_check!=1" @click="gain_aouonym()">Gửi</view>
						<view class="submit" v-if="userinfo.is_check==1">Xác minh</view>
					</view>


					<view class="upload" style="margin-top: 30px;">Lưu ý khi tải căn cước công dân</view>
					<view class="notes-documents" style="margin-top: 30px;">
						<view class="careful" >
							<view>
								<image src="../../static/purchase/biaozhun01.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="checkmark-circle-fill" color="#4db872"></u-icon>
								Tiêu chuẩn
							</view>
						</view>
						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun02.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
								Mất khung
							</view>
						</view>

						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun03.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
								Ảnh mờ
							</view>
						</view>

						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun04.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
								Chói sáng
							</view>
						</view>
					</view>

					<view class="ask">Điều kiện tải lên</view>
					<view class="requirement">1.Nội dung ảnh chụp chân thật, rõ nét, không được chỉnh sửa.</view>
					<view class="requirement">2.Số CCCD và tên rõ ràng, hỗ trợ JPG/JPEG/PNG。</view>
					<view class="requirement">3.CMND hoặc CCCD phải còn hạn ít nhất 6 tháng và không bị mờ số . Có thể sử dụng hình ảnh CMND hoặc CCCD để tải lên .</view>
					<view class="requirement">4.Đảm bảo đường truyền tốt.</view>
				</view>
			</view>
		</view>
	</view>
</template>


<script>
	
	import md5 from 'js-md5'
	export default {
		
		data() {
			return {
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},

		methods: {
			obverse_btn() {
				if (this.obverseUrl) {
			
					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
	
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: this.sourceType,
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB
			
						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},
			home() {
				uni.navigateBack()
			},
			// 认证
			async gain_aouonym() {
				
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})
			
				if (list.data.code == 0) {
			
			
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index'
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
			
				}
				
				
			},
			async userInfo() {
				let userinfo = await this.$http.get('api/user/fastInfo', {})
				this.value1 = userinfo.data.data.real_name
				this.value2 = userinfo.data.data.idno
				this.userinfo = userinfo.data.data
				this.formData.obverseUrl = userinfo.data.data.front_image
				this.formData.reverseUrl = userinfo.data.data.back_image
				// console.log(userinfo.data.data, '1111111111111');
				uni.hideLoading();
			},


			// 插件上传身份证
			// 上传
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi..."
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()
			
			
				let mdd = md5("XPFXMedS" + Request + str_url + time)
			
				uni.uploadFile({
					url: this.$http.BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
					filePath: tempFilePath,
					name: 'file',
			
					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data)
						if (type == 1) {
							this.formData.obverseUrl = data[0].url;
						} else {
							this.formData.reverseUrl = data[0].url;
			
						}
			
					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});
			},
			sfz_chagne(e) {
				var that = this;
				if (e.name == "obverse") {
					this.upimg(1, e.tempFilePath)

				} else if (e.name == "reverse") {
					this.upimg(2, e.tempFilePath)

				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
		mounted() {
			this.userInfo()
		}
	};
</script>

<style lang="scss">
	/deep/.u-input {
		background: #f5f5f5;
		font-size: 28rpx;
	}

	/deep/ .uni-input-input {
		font-size: 30rpx;
	}
	page{
		background-color: #fff;
	}
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 150rpx;
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}



	.identity-card {
		margin: -50rpx auto 0;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;


		.choice {
			color: #000;
			font-weight: 600;
			margin: 30rpx 0 10rpx;
			font-size: 28rpx;
		}

		input {
			background: #f5f5f5;
			padding: 20rpx;
			border-radius: 10rpx;
		}
	}

	.certification-content {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;



		.bottom-content {
			margin-top: 30rpx;
			background: #f9f9f9;
			width: 100%;
			height: 100%;

			.submit {
				text-align: center;
						background-image: linear-gradient(to right, #FFB044, #FF2D30);
				color: #fdfdfd;
				padding: 20rpx 0;
				width: 92%;
				border-radius: 20rpx;
				margin: 30rpx;
			}

			.upload {
				margin: 30rpx;
				font-weight: 600;
				// font-size: 30rpx;
				font-size: 28rpx;
			}

			.ask {
				margin: 10rpx 30rpx;
				font-size: 28rpx;
			}

			.requirement {
				margin: 10rpx 30rpx;
				color: #8b8b8b;
				font-size: 28rpx;
			}

			.notes-documents {
				display: flex;
				justify-content: space-around;
				align-items: center;
				text-align: center;

				.careful {
					// width: 80%;
					height: 200rpx;

					image {
						width: 150rpx;
						height: 120rpx;
					}

					.standard {
						display: flex;
						justify-content: center;
						align-items: center;
						font-size: 28rpx;
						color: #8b8b8b;

						.u-icon {
							margin-right: 10rpx;
						}
					}
				}
			}
		}
	}
</style>