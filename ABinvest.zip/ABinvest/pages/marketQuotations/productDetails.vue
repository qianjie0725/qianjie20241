<template>
	<view v-if="updata">
		<!-- 头部 -->
		<view class="college-bg">
			<view class="account">
				<image src="../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">
					<view class="">
						<image src="../../static/zuoshijiantou.png" mode=""></image>
					</view>
					<view class="product">
						<view class="">{{productDetails.name}}</view>
						<view class="code">{{productDetails.exchange}}</view>
					</view>
					<view class="">
						<image src="../../static/youshijiantou.png" mode=""></image>
					</view>
				</view>
				<view class=""></view>
			</view>

		</view>
		<view class="padding-20 margin-10 radius10" style="background-color: #442f84;">
			<view class="flex flex-b" v-if="productDetails">
				<view class="flex gap10">
					<view style="background-color: #3c655f;color: #fff;width: 20px;height: 20px;"
						class="padding-10 text-center">{{productDetails.name.charAt(0)}}</view>
					<view>
						<view class="flex">
							<view class="font-size-18 color-white bold margin-right-5">{{productDetails.name}}</view>
							<image src="/static/zhang.png" mode="widthFix" style="width: 40rpx;height: 40rpx;"
								v-if="productDetails.rate>0"></image>
							<image src="/static/die.png" mode="widthFix" style="width: 40rpx;height: 40rpx;"
								v-if="productDetails.rate<=0"></image>
						</view>

						<view class="hui font-size-12">{{productDetails.exchange}}</view>
					</view>

				</view>
				<view class="function" @click="handleClickDelProduct(productDetails.gid)">
					<image
						:src="productDetails.is_collected ==1?'/static/stock_unfollow.png':'/static/stock_follow.png'"
						mode="widthFix" style="width: 20px;height: 20px;"></image>
				</view>
			</view>
			<view class="flex flex-b bold margin-top-10"
				:style="productDetails.rate<=0?'color:#FE0101':'color:#1cdd49'">
				<view>{{toThousandFilter(today.current_price)}}</view>
				<!-- <view>{{toThousandFilter(today.rate_num)}}</view> -->
				<view>{{productDetails.rate}}%</view>
			</view>
		</view>
		<!-- <view class="padding-20 margin-10 radius10" style="background-color: #442f84;">
			<view class="flex flex-b color-white font-size-14">
				<view class="hui">Mở cửa</view>
				<view>{{toThousandFilter(today.open)}}</view>
			</view>
			<view class="flex flex-b color-white font-size-14">
				<view class="hui">Mức cao nhất</view>
				<view>{{toThousandFilter(today.high)}}</view>
			</view>
			<view class="flex flex-b color-white font-size-14">
				<view class="hui">Tổng KL</view>
				<view>{{toThousandFilter(today.volume)}}</view>
			</view>
			<view class="flex flex-b color-white font-size-14">
				<view class="hui">Tham chiếu </view>
				<view>{{toThousandFilter(today.close)}}</view>
			</view>
		</view> -->

		<!-- <u-tabs lineColor="#121327" :list="list1" @click="time_click" :activeStyle="{color: '#121327',}"></u-tabs> -->
		<!-- K线 -->
		<view class="padding-10 margin-10 radius10" style="background-color: #442f84;">
			<view class="KLineDiagram" id="chart-type-k-line"></view>

			<view class="flex color-white font-size-12 gap10">
				<view class="flex-1">
					<view class="flex flex-b text-center">
						<view class="flex-1"> </view>
						<view class="flex-1">Mua</view>
						<view class="flex-1">KL</view>
					</view>
					<view class="flex flex-b text-center" v-for="(item,index) in sell" :key="index" v-if="index<3">
						<view class="flex-1">Mua {{index+1}} </view>
						<view class="flex-1" style="color: aqua;font-weight: 700;">{{toThousandFilter(item.price)}}
						</view>
						<view class="flex-1">{{toThousandFilter(item.num)}}</view>
					</view>
				</view>

				<view class="flex-1">
					<view class="flex flex-b text-center">
						<view class="flex-1"> </view>
						<view class="flex-1">Bán</view>
						<view class="flex-1">KL</view>
					</view>
					<view class="flex flex-b text-center" v-for="(item,index) in buy" :key="index" v-if="index<3">
						<view class="flex-1">Bán {{index+1}} </view>
						<view class="flex-1" style="color: #f33431;font-weight: 700;">{{toThousandFilter(item.price)}}
						</view>
						<view class="flex-1">{{toThousandFilter(item.num)}}</view>
					</view>
				</view>
			</view>

		</view>
		<view style="height: 60px;"></view>
		<view v-show="today.current_price>0" @tap="purchase(productDetails)" class="purchase">
			Mua
		</view>
	</view>
</template>

<script>
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts';
	// import KLineDiagram from "../../components/kLine/KLineDiagram/KLineDiagram.vue";
	// import { init } from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'

	export default {
		components: {


		},
		data() {
			return {
				list1: [
					// {
					// 	name: ' Theo thời gian'
					// },
					// 
					{
						name: 'Ngày'
					}
				],
				updata: true,
				productDetails: '',
				today: {
					open: 0,
					volume: 0,
					high: 0
				},
				yesterday: {
					low: 0,
					close: 0
				},
				buy: "",
				sell: "",
				divide: '',
				sky: '',
				circumference: '',
				moon: '',
				onePoint: '',
				halfhour: '',
				timerId: null,
				option: {},
				kLineChart: null,
				time_index: 1
			};

		},
		mounted: function() {

			// chart.createTechnicalIndicator('MA', false, { id: 'candle_pane' })
			// chart.createTechnicalIndicator('VOL', false, { height: 120, dragEnabled: false })
			// chart.createTechnicalIndicator('MACD', false, { height: 120, dragEnabled: false })


		},
		methods: {
			time_click(i) {
				console.log(i.index);
				this.time_index = i.index;
				this.product()
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			socket() {
				var that = this;
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});

				uni.connectSocket({
					url: this.$http.WsUrl,
					success(res) {
						console.log("连接成功");
					},
					fail() {
						console.log("连接失败");
					}
				});
				console.log("codes", this.productDetails.code)
				uni.onSocketOpen(function(res) {
					console.log('WebSocket连接已打开！');
					uni.sendSocketMessage({
						data: that.productDetails.name
					});

				});
				uni.onSocketMessage(function(res) {
					// console.log('收到服务器内容：' + );
					var arr = JSON.parse(res.data);
					// console.log('收到服务器内容：' + arr);


					if (that.productDetails.name == arr[0]) {
						console.log('收到服务器内容：' + arr);
						// console.log('goods：' + arr[53]);
						that.today.current_price = arr[41]
						that.today.rate = arr[52]
					}




				});
				uni.onSocketError(function(res) {
					console.log('WebSocket连接打开失败，请检查！');
					uni.showToast({
						icon: 'none',
						title: 'Mạng chậm'
					})
				});
			},
			setStyleOptions() {
				if (this.time_index == 1) {
					var type = "candle_solid"
				} else {
					var type = "area"
				}
				// area
				// candle_solid
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$theme.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb919'
							}, {
								offset: 1,
								color: this.$theme.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#ffbfb9',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#ffbfb9',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#ffbfb9'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);

			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				})
			},
			// 买入
			purchase(productDetails) {
				console.log(productDetails);

				uni.navigateTo({
					url: '/pages/marketQuotations/purchase?gid=' + productDetails.gid
				});
			},
			// 产品详情
			async product() {
				let list = await this.$http.get('api/product/info', {
					gid: this.option.gid,
					time_index: this.time_index
				})
				this.productDetails = list.data.data[0]
				// console.log("k线数据",list.data.data[2]);
				if (!this.kLineChart) {
					this.kLineChart = init('chart-type-k-line');
					// this.kLineChart=chart;
					// this.kLineInit(); // 初始化Kline
				}
				this.setStyleOptions()
				this.kLineChart.clearData()

				this.kLineChart.applyNewData(list.data.data[2])

				// 今开
				this.today = list.data.data[1].today
				this.yesterday = list.data.data[1].yesterday
				// 买卖档
				this.buy = list.data.data[3].buy_sell[1]
				this.sell = list.data.data[3].buy_sell[0]
				this.socket()
			},
			//定时器

			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = !this.updata
					this.updata = true
					//按键样式判断
					this.productDetails.is_collected = this.productDetails.is_collected == 1 ? 0 : 1
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},

		},

		onLoad(option) {
			this.item = {
				gid: option.gid || '',
			}
			this.option = option;
			// option.gid=1791
			this.product()



		},

	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
				display: flex;
				align-items: center;

				image {
					width: 20rpx;
					height: 20rpx;
				}

				.product {
					margin: 0 30rpx;

					.code {
						font-size: 24rpx;
					}
				}

			}
		}


		.college-content {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 20rpx;
			color: #fff;


			.figure {
				view:nth-child(1) {
					font-size: 50rpx;
					font-weight: 700;
				}

				view:nth-child(2) {
					margin: 20rpx 0;
				}
			}

			.function {
				text-align: center;
				font-size: 26rpx;
				width: 120rpx;

				image {
					height: 50rpx;
					width: 50rpx;
				}
			}
		}
	}

	.openToday {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;
		padding: 10rpx 30rpx;
		background: #fff;
		font-size: 24rpx;

		.amount {
			// width: 32%;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			flex-wrap: wrap;
			align-items: center;
			margin: 10rpx 0;
			text-align: left;
			width: 33%;


			view:nth-child(1) {
				// width: 34%;
				text-align: left;
			}

			view:nth-child(2) {
				// width: 70%;
				text-align: end;
			}

			text {
				color: #333;
				font-weight: 600;
				font-size: 26rpx;

			}
		}
	}

	// k线
	/deep/.uni-scroll-view-content {
		display: flex;
		justify-content: space-around;
		align-items: center;
	}

	.kLine {
		margin: 20rpx 0 0;
		background: #fff;
	}

	.KLineDiagram {
		background: #442f84;
		height: 600rpx;
		color: #fff;
	}


	.purchase {
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		position: fixed;
		bottom: 20px;
		width: 90%;
		margin-left: 5%;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		z-index: 999;
	}
</style>