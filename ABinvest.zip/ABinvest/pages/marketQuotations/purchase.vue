<!-- 下单 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">
				{{productDetails.name}}
				<view class="" style="font-size: 24rpx;">{{toThousandFilter(productDetails.current_price)}}</view>
			</view>
			<view class=""></view>
		</view>
		<view class="padding-20 margin-10 radius10" style="background-color: #442f84;">
			<view class="flex flex-b" v-if="productDetails">
				<view class="flex gap10">
					<view style="background-color: #3c655f;color: #fff;width: 20px;height: 20px;" class="padding-10 text-center">{{productDetails.name.charAt(0)}}</view>
					<view>
						<view class="flex">
							<view class="font-size-18 color-white bold margin-right-5">{{productDetails.name}}</view>
							
						</view>
						
						<view class="hui font-size-12">{{productDetails.exchange}}</view>
					</view>
					
				</view>
				<view  class="function">
					<view style="color: #fff;">{{toThousandFilter(productDetails.current_price)}}</view>
					<view style="color: #ffb044;text-align: right;">
					<image src="/static/zhang.png" mode="widthFix" style="width: 40rpx;height: 40rpx;margin-right: 5px;" v-if="productDetails.rate>0"></image>
					<image src="/static/die.png" mode="widthFix" style="width: 40rpx;height: 40rpx;margin-right: 5px;" v-if="productDetails.rate<=0"></image>
					{{productDetails.rate}}%</view>
				</view>
			</view>
			
			
		</view>
		<view class="padding-10">
			<view style="position: relative; height: 40px; padding: 0px 20px; color: transparent; width: max-content;">Khối lượng
				<view
					style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; background-image: linear-gradient(90deg, rgb(255, 176, 68), rgb(255, 45, 48)); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Khối lượng</view>
			</view>
			<view class="flex-wrap flex gap10">
				
				<view :class="quantity==item?'xuanzhong':'noxuanzhong'" class="text-center padding-10 radius10" style="flex: 1 0 25%;" v-for="(item,index) in money_list" @click="quantity=item">{{item .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				
			</view>
			<input class="padding-10 margin-top-10" placeholder="Vui lòng nhập" type="number" style="border: 1px solid #E8EAF3;color: #fff;" v-model="quantity">
		</view>
		
	

		<!-- <view class="hand">1Lô chẵn=100Cổ phiếu</view> -->
		<view class="quantity-content">
			<view class="quantity">
				<view class="">Sức mua</view>
			</view>
			<view class="">
				{{toThousandFilter(list.money)}} VND
			</view>
		</view>

		<view class="quantity-content" @click="show=true">
			<view class="quantity">
				<view class="">Margin ( Đòn bẩy )</view>
			</view>
			<view class="">
				{{ganggan}}
			</view>
		</view>
		<!-- 二选一 -->
		<!-- 	<view class="radio">
			<view :class="[flag===0?rise:fall]" @click="chooseEmer(0)">买涨</view>
			<view :class="[flag===1?rise:fall]" @click="chooseEmer(1)">买跌</view>
		</view> -->
		<!-- 杠杆倍数 -->
		<!-- <view class="quantity-content">
				<view class="quantity">
				<image src="../../static/purchase/ganggan.png" mode=""></image>
				<view class="">选择杠杆倍数</view>
			</view> -->

		<!-- <view class="select" @click="show = true">
				<view class="times">{{title}}</view>
				<image src="../../static/purchase/xiabiao.png" mode=""></image>
			</view> -->
		<!-- 下拉菜单上面这个 -->
		<!-- 	<view class="select">
				<view class="times">{{title}}</view>
				<image src="../../static/purchase/xiabiao.png" mode=""></image>
			</view> -->
		<!-- </view> -->
		<!-- 下拉菜单 -->


		<u-action-sheet :show="show" :actions="actions" title="Margin (Đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>


		<view class="quantity-content">
			<view class="quantity">
				<view class="">Số tiền thanh toán</view>
			</view>
			<view class="">
				{{toThousandFilter(productDetails.current_price*this.quantity/this.ganggan)}} VND
			</view>

		</view>

		<view v-if="list.is_check!=1" @tap="authentication()" class="purchase">
			Vui lòng xác minh danh tính
		</view>
		<view v-if="list.is_check==1" class="purchase" @click="show_buy=true">
			Mua
		</view>

		<u-modal :show="show_buy" :content="getcontent()" confirm-text="Xác nhận" cancel-text="Huỷ bỏ" @confirm="placeOrder" :showCancelButton="true"
			@cancel="show_buy=false"></u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				actions: [{
						name: '1',
						index: 1
					}
				],
				show_buy: false,
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				// columns: [
				// 	["1", "5", "10", "20"]
				// ],
				list: '',
				quantity: 10000,
				productDetails: "",
				ganggan: 1,
				money_list:[10000,20000,30000,50000,80000,100000],
				option:""
			};
		},
		methods: {
			getcontent() {
				var total = (this.productDetails.current_price * this.quantity / this.title).toFixed(2)
				// return 'Mua vào ' + this.productDetails.name + ',' + this.quantity + 'lô chẵn,Số tiền thanh toán' + total + ",Xác nhận mua";
				return 'Xác nhận mua ' + this.productDetails.name + " " + this.quantity + ' Cổ phiếu' + "\n" +'Vui lòng thanh toán  ' + this.toThousandFilter(total) +'Để xác nhận hoàn tất giao dịch';
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.productDetails.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			//购买
			async placeOrder(productDetails) {
				this.show_buy=false
				console.log(this.ganggan);

				// return
				let list = await this.$http.post('api/product/purchase', {
					num: this.quantity,
					gid: this.productDetails.gid,
					price: this.productDetails.current_price,
					ganggan: this.ganggan
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: "Đang khớp lệnh, vui lòng chờ trong giây lát ...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/position/position',
						});
						uni.hideLoading();
					}, 2000)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
				this.actions=list.data.data.ganggan
			},
			// 产品详情
			async product() {
				let list = await this.$http.get('api/product/info', {
					gid: this.option.gid,
					time_index:this.time_index
				})
				this.productDetails = list.data.data[0]
	
				this.socket()
			},
			socket(){
				var that=this;
				uni.onSocketClose(function (res) {
				  console.log('WebSocket 已关闭！');
				});
				
				uni.connectSocket({
					url: this.$http.WsUrl,
					success(res) {
						console.log("连接成功");
					},
					fail() {
						console.log("连接失败");
					}
				});
				console.log("codes",this.productDetails.code)
				uni.onSocketOpen(function (res) {
					console.log('WebSocket连接已打开！');
					uni.sendSocketMessage({
				        data: that.productDetails.name
					});
				  
				});
				uni.onSocketMessage(function (res) {
					// console.log('收到服务器内容：' + );
					var arr=JSON.parse(res.data);
					// console.log('收到服务器内容：' + arr);
				
						
					if(that.productDetails.name==arr[0]){
						console.log('收到服务器内容：' + arr);
						// console.log('goods：' + arr[53]);
						that.today.current_price=arr[41]
						that.today.rate=arr[52]
					}
						
					
						
					
				});
				uni.onSocketError(function (res) {
				  console.log('WebSocket连接打开失败，请检查！');
				  uni.showToast({
				  	icon:'none',
					title:'Mạng chậm'
				  })
				});
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			if(option){
				this.option=option
			}
			this.product()
			// const item = JSON.parse(decodeURIComponent(option.item));
			// this.objData = item;
			// this.columns = [item.ganggan]

		}
	}
</script>

<style lang="scss">
	.xuanzhong{
		background-image: linear-gradient(90deg, rgb(187, 68, 255), rgb(100, 88, 255));
	}
	.noxuanzhong{
		background: #483f74;
	}
	.college-bg {
		padding: 20px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.quantity-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 30rpx;
		font-size: 28rpx;
		color: #fff;
		//数量
		.quantity {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-right: 20rpx;
			}
		}

		/deep/.input-placeholder {
			font-size: 28rpx;
		}

		.quantity-input {
			background-color: #f5f5f5;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;
			padding: 10rpx 20rpx;
			display: flex;
			font-size: 28rpx;
		}

		//杠杆倍数
		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;
			background-color: #f5f5f5;
			width: 50%;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;



			.times {}

			image {
				height: 20rpx;
				width: 20rpx;

			}
		}

	}

	// 二选一
	.hand {
		text-align: right;
		margin: 10rpx 30rpx;
		font-size: 26rpx;
		color: #999;
	}

	.radio {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10rpx 30rpx;


		view {
			width: 48%;
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			border-radius: 10rpx;
			border: 2rpx solid #e0e0e0;
		}

		.rise {
					background-image: linear-gradient(to right, #FFB044, #FF2D30);
			color: #fff;
		}

		.fall {
			color: #000;
		}
	}

	//买入
	.purchase {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 28rpx;
	}
</style>