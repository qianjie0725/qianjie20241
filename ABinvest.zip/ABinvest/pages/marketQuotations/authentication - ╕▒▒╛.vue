<template>
	<view>
		<view class="college-bg">
			<image src="../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">
				XÁC MINH DANH TÍNH
			</view>
			<view class=""></view>
		</view>

		<!-- 姓名 -->
		<view class="identity-card">
			<view class="choice">Họ và Tên</view>
			<u-input placeholder="Vui lòng nhập Họ và Tên" v-model="value1"></u-input>
			<view class="choice">CCCD</view>
			<u-input placeholder="Vui lòng nhập số Căn cước công dân" v-model="value2"></u-input>
		</view>
		<!-- 身份证 -->
		<view class="">
			<view class="certification-content">
				<view class="content" v-if="list.is_check<=0||list.is_check==2">
					<Rboy-upload-sfz :obverse-url="formData.obverseUrl" :reverse-url="formData.reverseUrl"
						@selectChange="sfz_chagne" @del="del_btn"></Rboy-upload-sfz>
				</view>
				


				<view class="bottom-content">
					<view class="" v-if="this.value1||this.value2!=''">
						<view class="submit" v-if="list.is_check!=1" @click="gain_aouonym()">Gửi</view>
						<view class="submit" v-if="list.is_check==1">Xác minh</view>
					</view>


					<view class="upload">Lưu ý khi tải lên Căn cước công dân</view>
					<view class="notes-documents">
						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun01.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="checkmark-circle-fill" color="#4db872"></u-icon>
								Tiêu chuẩn
							</view>
						</view>
						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun02.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
								Mất khung
							</view>
						</view>

						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun03.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
								Ảnh mờ
							</view>
						</view>

						<view class="careful">
							<view>
								<image src="../../static/purchase/biaozhun04.png" mode=""></image>
							</view>
							<view class="standard">
								<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
								Chói sáng
							</view>
						</view>
					</view>

					<view class="ask">Điều kiện tải lên</view>
					<view class="requirement">1.Nội dung ảnh chụp chân thật, rõ nét, không được chỉnh sửa.</view>
					<view class="requirement">2.Số CCCD và tên rõ ràng, hỗ trợ JPG/JPEG/PNG。</view>
					<view class="requirement">3.CMND hoặc CCCD phải còn hạn ít nhất 6 tháng và không bị mờ số . Có thể sử dụng hình ảnh CMND hoặc CCCD để tải lên .</view>
					<view class="requirement">4.Đảm bảo đường truyền tốt.</view>
				</view>
			</view>
		</view>
	</view>
</template>


<script>
	import RboyUploadSfz from '@/components/Rboy-upload-sfz/Rboy-upload-sfz.vue';
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import Blob from 'blob';

	export default {
		components: {
			RboyUploadSfz
		},
		data() {
			return {
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				//
				value1: '',
				value2: '',
				list: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onLoad() {
			//倒计时
			// uni.showLoading({
			// 	title: '正在检测真人身份证中....',
			// });
			// this.timer = setInterval(() => {
			// 	// 判断如秒数大于0继续执行，反之则清除定时器
			// 	if (this.second > 0) {
			// 		uni.showToast({
			// 			title: `${this.second}秒后`,
			// 			icon: 'loading',
			// 			duration: this.second * 1000,
			// 			//显示透明蒙层，防止触摸穿透
			// 			mask: true
			// 		})
			// 		this.second--
			// 	} else {
			// 		clearInterval(this.timer)
			// 	}
			// }, 1000)
		},
		methods: {
			home() {
				uni.navigateBack()
			},
			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})

				// console.log(111111, '已点击提交，请稍等');
				if (list.data.code == 0) {
					// uni.showToast({
					// 	title: `${this.second}秒后`,
					// 	icon: 'loading',
					// 	duration: this.second * 1000,
					// });
					// uni.$u.toast(list.data.message);
					// this.timer = setInterval(() => {
					// 	// 判断如秒数大于0继续执行，反之则清除定时器
					// 	if (this.second > 0) {
					// 		uni.showToast({
					// 			title: `${this.second}秒后`,
					// 			icon: 'loading',
					// 			duration: this.second * 1000,
					// 			//显示透明蒙层，防止触摸穿透
					// 			mask: true
					// 		})
					// 		this.second--
					// 	} else {
					// 		clearInterval(this.timer)
					// 	}
					// }, 1000)

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index'
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
					// if (this.real_name == '') {
					// 	uni.$u.toast('姓名不能为空');
					// 	console.log(this.real_name);
					// } else if (this.idno == '') {
					// 	uni.$u.toast('身份证号不能为空');
					// } else if (this.front_image == '') {
					// 	uni.$u.toast('身份证正面不能为空');
					// } else if (this.back_image == '') {
					// 	uni.$u.toast('两次密身份证反面不能为空码不一致');
					// }
				}
			},
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.value1 = list.data.data.real_name
				this.value2 = list.data.data.idno
				this.list = list.data.data
				this.formData.obverseUrl = list.data.data.front_image
				this.formData.reverseUrl = list.data.data.back_image
				// console.log(list.data.data, '1111111111111');
				uni.hideLoading();
			},


			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				if (e.name == "obverse") {
					if (typeof e.tempFilePath === 'object' && e.tempFilePath instanceof Blob) {
						console.log(e.tempFilePath, '111111');
						const reader = new FileReader();
						reader.onloadend = () => {
							// 将Blob对象转换为base64
							this.formData.obverseUrl = reader.result;
							console.log(this.formData.obverseUrl, 'da');
						};
						reader.onerror = (error) => {
							console.error(error);
						};
						reader.readAsDataURL(e.tempFilePath);
					} else {
						uni.getImageInfo({
							src: e.tempFilePath,
							success: (path) => {
								pathToBase64(path.path).then(base64 => {
									this.formData.obverseUrl = base64;
									console.log(this.formData.obverseUrl, 'xiao');
								}).catch(error => {
									console.error(error);
								});
							}
						});
					}
				} else if (e.name == "reverse") {
					if (typeof e.tempFilePath === 'object' && e.tempFilePath instanceof Blob) {
						const reader = new FileReader();
						reader.onloadend = () => {
							// 将Blob对象转换为base64
							this.formData.reverseUrl = reader.result;
						};
						reader.onerror = (error) => {
							console.error(error);
						};
						reader.readAsDataURL(e.tempFilePath);
					} else {
						uni.getImageInfo({
							src: e.tempFilePath,
							success: (path) => {
								pathToBase64(path.path).then(base64 => {
									this.formData.reverseUrl = base64;
								}).catch(error => {
									console.error(error);
								});
							}
						});
					}
				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
		mounted() {
			this.userInfo()
		}
	};
</script>

<style lang="scss">
	/deep/.u-input {
		background: #f5f5f5;
		font-size: 28rpx;
	}

	/deep/ .uni-input-input {
		font-size: 30rpx;
	}
	page{
		background-color: #fff;
	}
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 140rpx;
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}



	.identity-card {
		margin: -50rpx auto 0;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;


		.choice {
			color: #000;
			font-weight: 600;
			margin: 30rpx 0 10rpx;
			font-size: 28rpx;
		}

		input {
			background: #f5f5f5;
			padding: 20rpx;
			border-radius: 10rpx;
		}
	}

	.certification-content {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;



		.bottom-content {
			margin-top: 30rpx;
			background: #f9f9f9;
			width: 100%;
			height: 100%;

			.submit {
				text-align: center;
						background-image: linear-gradient(to right, #FFB044, #FF2D30);
				color: #fdfdfd;
				padding: 20rpx 0;
				width: 92%;
				border-radius: 20rpx;
				margin: 30rpx;
			}

			.upload {
				margin: 30rpx;
				font-weight: 600;
				// font-size: 30rpx;
				font-size: 28rpx;
			}

			.ask {
				margin: 10rpx 30rpx;
				font-size: 28rpx;
			}

			.requirement {
				margin: 10rpx 30rpx;
				color: #8b8b8b;
				font-size: 28rpx;
			}

			.notes-documents {
				display: flex;
				justify-content: space-around;
				align-items: center;
				text-align: center;

				.careful {
					// width: 80%;
					height: 200rpx;

					image {
						width: 150rpx;
						height: 120rpx;
					}

					.standard {
						display: flex;
						justify-content: center;
						align-items: center;
						font-size: 28rpx;
						color: #8b8b8b;

						.u-icon {
							margin-right: 10rpx;
						}
					}
				}
			}
		}
	}
</style>