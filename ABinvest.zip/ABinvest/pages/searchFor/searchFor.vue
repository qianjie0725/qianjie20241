<template>
	<view>
		<view class="head-background">
			<view class="header-bar">
				<view class="header-img" @tap="home()">
					<image src="../../static/zuojiantou.png" mode=""></image>
				</view>
				<view class="search">Tìm kiếm</view>
			</view>
			<view class="jump-search">
				<image src="../../static/sousuo.png" mode=""></image>
				<view class="function">
					<input type="text" class="code" placeholder='Nhập tên cổ phiếu/ mã' v-model="value">
					<view class="button" @click="searchButton()">Tìm kiếm</view>
				</view>

			</view>
		</view>
		<view class="padding-20 margin-10 radius10 flex flex-b" v-for="(item,index) in searchList" :key="index" @tap="detailed(item.name)" style="background-color: #442f84;">
			<view class="flex">
				<view class="color-white bold">{{item.name}}</view>
			</view>
			<view class="flex gap20">
				<view :style="item.rate>=0?'color:#16a038':'color:red'">{{toThousandFilter(item.current_price)}} </view>
				<view :style="item.rate>=0?'color:#16a038':'color:red'">{{item.rate}}%</view>
			</view>
		</view>
		

	</view>
</template>

<script>
	export default {
		data() {
			return {
				searchList: '',
				value: '',
				pager: {
					page: 1,
					limit: 20
				}
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		methods: {
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			//搜索
			async searchButton() {
				if (this.value == '') {
					uni.$u.toast('Không được để trống trong tìm kiếm');
					// let list = await this.$http.post('api/product/list', {
					// 	key: this.value,
					// 	page: this.pager.page,
					// 	limit: this.pager.limit,
					// })
					// console.log(this.pager.page, '=== >this.pager.page');
					// if (this.pager.page > 1) {
					// 	this.searchList = [...this.searchList, ...list.data.data]
					// } else {
					// 	this.searchList = ''
					// 	this.searchList = list.data.data
					// }
					// if (list.data.data.length < this.pager.limit) {
					// 	this.status = 'nomore'
					// }
					// // console.log(this.searchList);
					// uni.$u.toast('正在加载中...');
				} else {
					// console.log(1111);
					// uni.$u.toast('搜索中,请稍等...');
					uni.showLoading({
						title: "Đang tải...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.value,
						page: 1,
						limit: 9999999,
					})
					this.searchList = list.data.data
					uni.hideLoading();
					uni.showLoading({
						title: "Đang tải...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					// uni.$u.toast('正在加载中...');
					setTimeout(() => {
						uni.hideLoading();
					}, 2000)
					// uni.$u.toast('加载完成');
				}

			},
			mounted() {
				// this.searchButton()
			},
			onShow() {
				// this.searchButton()
			}
		}
	}
</script>

<style lang="scss">
	.head-background {
		width: 100%;
		height: 240rpx;
		background-size: 100%;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;

		.header-bar {
			margin-top: 20rpx;
			padding: 20rpx;
			display: flex;
			text-align: center;

			.header-img {
				image {
					width: 20rpx;
					height: 40rpx;
				}
			}

			.search {
				width: 97%;
				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.jump-search {
			margin: 0 30rpx;
			height: 70rpx;
			border-radius: 40rpx;
			background: hsla(0, 0%, 100%, .2);
			display: -webkit-box;
			display: -ms-flexbox;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			padding: 0 30rpx;

			.code {
				margin: 0 20rpx;
				color: #fff;
				font-size: 26rpx;
			}

			/deep/.uni-input-placeholder {
				color: #fff;
			}

			image {
				width: 40rpx;
				height: 40rpx;
				margin-top: 10rpx;
			}

			.function {
				display: flex;
				align-items: center;
				justify-content: space-between;
				width: 100%;
			}

			input {
				width: 70%;
			}

			.button {
				background: #fff;
				border-radius: 30rpx;
				padding: 6rpx 30rpx;
				color: #121327;
				width: 45%;
				text-align: center;
			}
		}
	}

</style>