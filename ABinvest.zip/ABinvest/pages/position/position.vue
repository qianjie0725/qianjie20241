<template>
	<view>
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 80rpx;color: #fff;">

			<image src="/static/chuanggai/applogo.png" mode="widthFix" style="width: 130px;height: 70px;"></image>
			<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>
		<view class="padding-10 margin-10 radius10" style="background-color: #231d42;">
			<view class="flex flex-b">
				<view style="color: #cbcbcf;">Tổng tài sản (VND)</view>
				<view style="color: #ffb044;">
					{{toThousandFilter(userInformation.totalZichan*1+userInformation.holdYingli*1)}}
				</view>
			</view>

			<view class="flex flex-b margin-top-10">
				<view style="color: #cbcbcf;">Tổng lãi lỗ</view>
				<view :class="userInformation.holdYingli>0?'color-green':'color-red'">
					{{toThousandFilter(userInformation.holdYingli)}}
				</view>
			</view>

			<view class="flex flex-b margin-top-10">
				<view style="color: #cbcbcf;">Tổng giá trị thị trường</view>
				<view style="color: #fff;">{{toThousandFilter(userInformation.frozen)}}</view>
			</view>

			<view class="flex flex-b margin-top-10">
				<view style="color: #cbcbcf;">Sức mua</view>
				<view style="color: #fff;">{{toThousandFilter(userInformation.money)}}</view>
			</view>

		</view>


		<view class="tab flex align-center padding-5 margin-10"
			style="border: 2px #ffb044 solid;border-radius: 30px;text-align: center;color:#fff;">
			<view class="flex-1" :class="1 === tabs_index ? 'active' : ''" @click="changeTabs(1)">Danh mục mua</view>

			<view class="flex-1" :class="2 === tabs_index ? 'active' : ''" @click="changeTabs(2)">Danh mục bán</view>
		</view>

		<!-- list -->
		<view class="list">

			<view class="_title flex align-center justify-between text-center gap10" style="color: #ffb044;">
				<view class="flex-1">Mã CK</view>
				<view class="flex-1">Margin</view>
				<view class="flex-2">Giá TT/Giá mua</view>
				<view class="flex-2">Khối lượng</view>
				<view class="flex-2">Lãi / lỗ</view>
			</view>
			<!-- v-for -->
			<view class="_item flex align-center justify-between gap10" @click="detail( item.id)"
				v-for="(item,index) in storehouse" style="color: #fff;">
				<!-- 代码 -->
				<view class="flex-1">
					<span class="font-size-13" style="color: #fff;">{{item.goods_info.name}}</span>
					<!-- <span class="font-size-12">{{jiequ(item.goods_info.ct_name)}}</span> -->
				</view>
				<view class="flex-1">
					<span class="font-size-12" style="color: #fff;">{{item.order_buy.double}}</span>
				</view>
				<!-- 单价：现价/成本 -->
				<view class="flex flex-column felx-1" v-if="item.status==1">
					<span class="font-size-13"
						style="color: #ffb044;">{{toThousandFilter(item.goods_info.current_price)}}</span>
					<span class="font-size-12" style="color: #fff;">{{ toThousandFilter(item.order_buy.price) }}</span>
				</view>


				<view class="flex flex-column flex-2" v-if="item.status==2">
					<span class="font-size-13">{{toThousandFilter(item.order_sell.price)}}</span>
					<span class="font-size-13" style="color: #fff;">{{ toThousandFilter(item.order_buy.price) }}</span>
				</view>



				<!-- 总量/可用 -->
				<view class="flex flex-column flex-2">
					<span class="font-size-13">{{ toThousandFilter(item.order_buy.num )}}</span>
					<span class="font-size-13" style="color: #fff;">{{toThousandFilter(item.order_buy.num) }}</span>
				</view>
				<!-- 盈亏数量/占比 -->
				<view class="flex flex-column flex-2" v-if="item.status==1">
					<span class="font-size-13 "
						:class="item.order_buy.float_yingkui>0?'color-green':'color-red'">{{toThousandFilter(item.order_buy.float_yingkui)}}
					</span>

					<span class="font-size-12 "
						:class="item.order_buy.float_yingkui>0?'color-green':'color-red'">{{(item.order_buy.float_yingkui/item.order_buy.num / item.order_buy.price*100).toFixed(2)}}%</span>
				</view>
				<view class="flex flex-column flex-2" v-if="item.status==2">
					<span class="font-size-13 "
						:class="item.order_sell.yingkui>0?'color-green':'color-red'">{{toThousandFilter(item.order_sell.yingkui)}}
					</span>

					<span class="font-size-12 "
						:class="item.order_sell.yingkui>0?'color-green':'color-red'">{{(item.order_sell.yingkui/item.order_buy.num / item.order_buy.price*100).toFixed(2)}}%</span>
				</view>
			</view>

		</view>
	</view>
</template>

<script>
	import getStatusBarHeightAndNavbarHeight from '@/utils/getStatusBarHeightAndNavbarHeight.js';
	export default {
		data() {
			return {
				statusBar: getStatusBarHeightAndNavbarHeight.statusBar,
				tab: [{
						type: 1,
						title: 'Sổ lệnh' // 持仓
					},
					// {
					// 	type: 2,
					// 	title: 'Thị trường' // 市场
					// },
					// {
					// 	type: 3,
					// 	title: 'Không bắt buộc' // 自选
					// }
				],
				storehouse: '', // 我的持仓
				tab_index: 0,
				tabs_index: 1,
				// 
				list_title: [
					'Mã CK', // 代码
					'Margin', // 杠杆
					'Giá TT/Giá mua vào', // 当前价格/成本
					'Khối lượng', // 总计/可用
					'Lãi / lỗ' // 盈亏
				],
				userInformation: '',
				page:1
			};
		},
		onShow() {
			this.gaint_info()
			this.getOrder()
		},
		//下拉刷新
		onPullDownRefresh() {
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
				uni.stopPullDownRefresh()
			}, 1000);
			this.page=1
			this.storehouse=[]
			this.getOrder()
		},
		onReachBottom() {
			uni.showLoading({
				
			})
			this.page=this.page+1;
			this.getOrder()
		},
		methods: {
			jiequ(str) {
				if (str.indexOf(",") != -1) { //如果字符转包含了*符号
					console.log(str.split(",")[0]) //则取*号之前的
					return str.split(",")[0];
					console.log("*号之后的" + str.split("*")[1]) //则取*号之后的
				} else {
					console.log("不好意思，当前字符串没有该字符")
				}
			},
			getOrder() {
				uni.showLoading();
				this.$http.get('api/user/order', {
					status: this.tabs_index,
					page:this.page
				}).then(res => {
					uni.hideLoading();
					if(this.storehouse.length>0){
						console.log("add order")
						if(res.data.data.length>0){
							this.storehouse.push(...res.data.data)
						}
					}else{
						this.storehouse= res.data.data
					}
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			changeTab(item, index) {
				this.tab_index = index
			},
			changeTabs(index) {
				this.tabs_index = index
				this.page=1;
				this.storehouse=[]
				this.getOrder()
			},
			detail(id) {
				uni.$u.route('/pages/position/detail', {
					id
				});
			},
		}
	}
</script>

<style lang="less" scoped>
	@import url("@/common/css/rc.css");

	page {
		color: #353539;
		font-family: ArialMT;
	}

	.color-green {
		color: #12f6b8 !important;
	}

	.color-red {
		color: #FF2D30 !important;
	}

	.tab {
		.active {
			color: #000;
			background-image: linear-gradient(to right, #FFB044, #FF2D30);
			font-weight: bold;
			display: flex;
			justify-content: center;
			padding: 5px;
			border-radius: 30px;
		}

	}

	.info {
		background: linear-gradient(to top, #e4edea, #F5FFFB);
		border-radius: 40rpx;
		padding: 24rpx;
		box-shadow: 0px 3px 0px 0px #C3EDDD;

		.up {
			.amount {
				color: #353539;
				font-size: 30rpx;
			}

			span {
				color: #717175;
			}
		}

		.down {
			margin-top: 48rpx;

			.title {
				color: #717175;
				font-size: 24rpx;
				margin-bottom: 15rpx;
			}

			.amount {
				font-size: 28rpx;
			}
		}
	}

	.subject {
		padding: 24rpx;
	}

	.placeholder {
		height: 30rpx;
		background: #F8F8F8;
	}

	.list {
		padding: 24rpx;

		& ._title {
			font-size: 24rpx;
			font-family: ArialMT;
			color: #27275D;
			padding: 24rpx 0;
			border-bottom: 1px solid #C2C2C4;

			view:nth-child(1) {
				width: 80rpx;
			}

			view:nth-child(2) {
				width: 220rpx;
			}

			view:nth-child(3) {
				width: 170rpx;
			}

			view:nth-child(4) {
				width: 180rpx;
			}
		}

		& ._item {
			padding: 24rpx;
			border-bottom: 1px solid #EAEAEB;

			view:nth-child(1) {
				width: 80rpx;

				span:last-child {
					color: #717175;
					margin-top: 16rpx;
				}
			}

			view:nth-child(2) {
				width: 220rpx;
				text-align: center;

				span:last-child {
					color: #717175;
					margin-top: 16rpx;
				}
			}

			view:nth-child(3) {
				width: 170rpx;
				text-align: center;

				span:last-child {
					color: #717175;
					margin-top: 16rpx;
				}
			}

			view:nth-child(4) {
				width: 180rpx;
				text-align: end;

				span:last-child {
					margin-top: 16rpx;
				}
			}
		}
	}

	.list1 {
		& ._title {
			font-size: 24rpx;
			font-family: ArialMT;
			color: #27275D;
			padding: 24rpx 0;
			border-bottom: 1px solid #C2C2C4;

			view:nth-child(1) {
				width: 80rpx;
			}

			view:nth-child(2) {
				width: 220rpx;
			}

			view:nth-child(3) {
				width: 170rpx;
			}

			view:nth-child(4) {
				width: 180rpx;
			}
		}

		& ._item {
			padding: 24rpx;
			border-bottom: 1px solid #EAEAEB;

			view:nth-child(1) {
				width: 80rpx;

				span:last-child {
					color: #717175;
					margin-top: 16rpx;
				}
			}

			view:nth-child(2) {
				width: 220rpx;
				text-align: center;

				span:last-child {
					color: #717175;
					margin-top: 16rpx;
				}
			}

			view:nth-child(3) {
				width: 170rpx;
				text-align: center;

				span:last-child {
					color: #717175;
					margin-top: 16rpx;
				}
			}

			view:nth-child(4) {
				width: 180rpx;
				text-align: end;

				span:last-child {
					margin-top: 16rpx;
				}
			}
		}
	}
</style>