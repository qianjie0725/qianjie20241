<template>
	<view>
		<header class="common_header">
			<view class="custom_header_left" @click="linkBack()">
				<view class="arrow rotate_225"></view>
			</view>
			<text class="custom_header_center" style="color:#fff;">Chi tiết giao dịch</text>
			<view class="custom_header_right"></view>
		</header>
		<!-- info -->
		<view class="info" id="info">
			<view class="up flex align-center justify-between" v-if="info.status==1">
				<view class="">
					<view class="flex align-center">
						<view class="font-size-20 bold margin-right-30 color-white">{{info.goods_info.name}}</view>
						<view class="font-size-20 bold " :class="info.goods_info.rate>=0?'color-green':'color-red'">
							{{toThousandFilter(info.goods_info.current_price)}}
						</view>
					</view>
					<view class="create-at font-size-12 margin-top-10">{{info.created_at}}</view>
				</view>
				<view class="">
					<u-image :showLoading="true" src="@/static/position-detail/jiantou.png" width="25px" height="12px"
						bgColor="#eee" v-if="info.goods_info.rate>0">
					</u-image>
				</view>
			</view>

			<view class="up flex align-center justify-between" v-if="info.status==2">
				<view class="">
					<view class="flex align-center">
						<view class="font-size-20 bold margin-right-30" style="color: #fff;">{{info.goods_info.name}}</view>
						<view class="font-size-20 bold "
							:class="info.order_buy.float_yingkui>=0?'color-green':'color-red'">
							{{toThousandFilter(info.order_buy.price)}}
						</view>
					</view>
					<view class="create-at font-size-12 margin-top-10">{{info.created_at}}</view>
				</view>
				<view class="">
					<u-image :showLoading="true" src="@/static/position-detail/jiantou.png" width="25px" height="12px"
						bgColor="#eee" v-if="info.order_buy.float_yingkui>0">
					</u-image>
				</view>
			</view>

			<view class="down flex align-center justify-between">
				<view class="left flex flex-column">
					<view class="flex align-center margin-bottom-10">
						<u-image :showLoading="true" src="@/static/position/base@2x.png" width="14px" height="14px"
							bgColor="#eee">
						</u-image>
						<span class="margin-left-5">Giá trị thị trường</span>
					</view>
					<view class="amount bold margin-left-20" v-if="info.status==1" style="color: #fff;">
						{{toThousandFilter(info.order_buy.num * info.goods_info.current_price)}}
					</view>

					<view class="amount bold margin-left-20" style="color: #fff;" v-else>
						{{toThousandFilter(info.order_buy.num * info.order_buy.price)}}
					</view>
				</view>
				<view class="right flex flex-column align-end">
					<view class="flex align-center margin-bottom-10">
						<u-image :showLoading="true" src="@/static/position/index@2x.png" width="15px" height="15px"
							bgColor="#eee">
						</u-image>
						<span class="margin-left-5">Lãi / lỗ</span>
					</view>
					<view class="amount bold" :class="info.order_buy.float_yingkui>0?'color-green':'color-red'"
						v-if="info.status==1">{{toThousandFilter(info.order_buy.float_yingkui)}}</view>

					<view class="amount bold" :class="info.order_sells[0].yingkui>0?'color-green':'color-red'"
						v-if="info.status==2">{{toThousandFilter(info.order_sells[0].yingkui)}}</view>
				</view>
			</view>
		</view>
		<!-- tab -->
		<view class="tab flex align-center" id="tab">
			<view class="item margin-right-10" @click="changeTab(index)" :class="index === tab_index ? 'active' : ''"
				v-for="item,index in tab">{{item.title}}</view>
		</view>
		<!-- order -->
		<view class="list" style="background-color: transparent;">
			<swiper @change="change" :duration='300' :current="tab_index" id="swiper" style="height: 60vh;">
				<swiper-item>
					<!-- <scroll-view scroll-y style="height: 100%;" @scrolltolower='scrolltolower()'> -->
					<view class="order-item margin-bottom-10">
						<view class="row flex align-end justify-between">
							<!-- 买价 -->
							<view class="flex flex-column">
								<span class="title">Giá mua vào</span>
								<span class="amount">{{ toThousandFilter(info.order_buy.price) }}</span>
							</view>
							<!-- 数量 -->
							<view class="flex flex-column">
								<span class="title">Khối lượng</span>
								<span class="amount">{{ toThousandFilter(info.order_buy.num) }}</span>
							</view>
							<!-- 本金 -->
							<view class="flex flex-column">
								<span class="title">Tổng vốn </span>
								<span class="amount">{{ toThousandFilter(info.order_buy.amount) }}</span>
							</view>
						</view>
						<view class="row flex align-end justify-between">
							<!-- 盈亏% -->
							<view class="flex flex-column">
								<span class="title">Lãi lỗ %</span>
								<span class="amount "
									:class="info.order_buy.float_yingkui>0?'color-green':'color-red'">{{(info.order_buy.float_yingkui/info.order_buy.num / info.order_buy.price*100).toFixed(2)}}%</span>
							</view>
							<!-- 盈亏额  -->
							<view class="flex flex-column">
								<span class="title">Lãi lỗ</span>
								<span class="amount "
									:class="info.order_buy.float_yingkui>0?'color-green':'color-red'">{{toThousandFilter(info.order_buy.float_yingkui)}}
								</span>
							</view>
							<!-- 市值  -->
							<view class="flex flex-column">
								<span class="title">Giá trị TT</span>
								<span
									class="amount">{{toThousandFilter(info.order_buy.num * info.goods_info.current_price)}}</span>
							</view>
						</view>
						<view class="row flex align-end justify-between">
							<!-- 手续费  -->
							<view class="flex flex-column">
								<span class="title">Phí giao dịch</span>
								<span class="amount">{{toThousandFilter(info.order_buy.buy_fee)}}</span>
							</view>
							<!-- 日期 -->
							<view class="flex flex-column">
								<span class="title">Thời gian</span>
								<span class="amount">{{info.order_buy.created_at}}</span>
							</view>
						</view>
						<view class="row flex align-end justify-between margin-top-20">
							<!-- <view style="color:#17A85B ;" @click="totab()">MUA </view>
								<template v-if="info.status==1">
									<view style="color:#EA393F ;" @click="position(info)">BÁN </view>
								</template> -->


							<u-button color='#17A85B' text="MUA" @click="totab()">MUA</u-button>
							<u-button color='#EA393F' text="BÁN" @click="position(info)"
								v-if="info.status==1">BÁN</u-button>
						</view>
					</view>
					<view class="loadmore">
						<u-loadmore loadmoreText="Đã hết" loadingText="đang tải..." nomoreText="không còn nữa"
							:status="loadmore_status" loadingIcon='semicircle' />
					</view>
					<!-- </scroll-view> -->
				</swiper-item>
				<swiper-item>
					<!-- <scroll-view scroll-y style="height: 100%;" @scrolltolower='scrolltolower()'> -->
					<view class="record-item margin-bottom-10" v-for="item in info.order_sells" style="background-color: transparent;">
						<view class="row flex align-end justify-between">
							<!-- 买价 -->
							<view class="flex flex-column">
								<span class="title">Giá bán</span>
								<span class="amount">{{toThousandFilter(item.price)}}</span>
							</view>
							<!-- 数量 -->
							<view class="flex flex-column">
								<span class="title">KL</span>
								<span class="amount">{{toThousandFilter(item.num)}}</span>
							</view>
							<!-- 支出 -->
							<view class="flex flex-column">
								<span class="title">Lãi/lỗ</span>
								<span class="amount">{{toThousandFilter(item.interest)}}</span>
							</view>
						</view>

						<view class="row flex align-end justify-between">
							<!-- 手续费  -->
							<view class="flex flex-column">
								<span class="title">Phí xử lý</span>
								<span class="amount">{{toThousandFilter(item.sell_fee)}}</span>
							</view>
							<!-- 日期 -->
							<view class="flex flex-column">
								<span class="title">Thời gian</span>
								<span class="amount">{{item.created_at}}</span>
							</view>
						</view>
					</view>
					<view class="loadmore">
						<u-loadmore loadmoreText="Tải thêm" loadingText="đang tải..." nomoreText="không còn nữa"
							:status="loadmore_status" loadingIcon='semicircle' />
					</view>
					<!-- </scroll-view> -->
				</swiper-item>
			</swiper>

		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" cancel-text="Huỷ bỏ" confirm-text="Xác nhận"
			@confirm="confirm(confirmation)" :showCancelButton='showCancelButton' :content='content'>
			<!-- <view class="quantity-input">
				<input class="" placeholder="Vui lòng nhập" type="number" v-model="quantity">
				<view class="">Lô chẵn</view>
			</view> -->
			<!-- <input class="" placeholder="Vui lòng nhập" type="number" v-model="quantity"> -->
		</u-modal>
	</view>

</template>

<script>
	import getStatusBarHeightAndNavbarHeight from '@/utils/getStatusBarHeightAndNavbarHeight.js';
	export default {
		data() {
			return {
				quantity: "",
				show: false,
				title: 'Nhắc nhở',
				content: 'Bạn xác nhận bán ra?',
				showCancelButton: true,
				tab: [{
						type: 1,
						title: 'Lịch sử mua'
					},
					{
						type: 2,
						title: 'Lịch sử bán'
					}
				],
				tab_index: 0,
				loadmore_status: 'loadmore',
				id: 0,
				info: {
					goods_info: {
						name: "",
						num: 0
					},
					order_buy: {
						num: 0
					}
				}
				// infoHeight: 0,
				// tabHeight: 0,
			};
		},
		watch: {
			// swiper与上面选项卡联动
			tab_index(newval) {
				this.tab_index = newval;
			},
		},
		onLoad(opt) {
			this.id = opt.id
		},
		onShow() {
			this.getorder()
		},
		mounted() {

			// this.setSwiperHeight();
		},
		methods: {
			linkBack() {
				uni.navigateBack({
					delta: 1,
				})
			},

			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			// 平仓功能
			async closingFunction(confirmation) {

				if (this.quantity * 1 < 1) {
					// uni.showToast({
					// 	title: "Bán tối thiểu 1 cổ phiếu",
					// 	icon: "none"
					// })
					// return;
				}
				uni.showLoading({
					title: "Đang bán ra, vui lòng chờ trong giây lát...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// quantity: this.quantity
					quantity: this.info.order_buy.num * 1
					// price: item.price
				})

				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.updata = false
					this.updata = true
					// this.hold()
					// this.flat()
					this.getorder();
					uni.$u.toast(list.data.message);
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			position(item) {
				if (item.status === 1) {
					this.show = true;
					this.confirmation = item.id
				} else {

				}
			},
			totab() {
				uni.navigateTo({
					url: "/pages/marketQuotations/productDetails?gid=" + this.info.goods_info.name
				})
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			async getorder() {
				let list = await this.$http.get('api/user/orderinfo', {
					id: this.id
				})
				this.info = list.data.data
			},
			// 触底操作
			scrolltolower() {
				// 根据tab 请求不同的数据
				// const type = this.tab_index;
				// console.log(type);


				// this.loadmore_status = 'loading';
				// // 节流
				// // uni.$u.throttle(this.getdata, 2000);
				// // 防抖
				// uni.$u.debounce(this.getdata, 1000)
			},
			getdata() {
				console.log('getdata');
				// this.loadmore_status = 'loading';
				setTimeout(() => {
					this.loadmore_status = 'nomore';
				}, 2000)
			},
			// 设置Swiper高度
			setSwiperHeight() {
				this.$nextTick(() => {
					const query = uni.createSelectorQuery().in(this);
					query.select('#info').boundingClientRect(data => {
						this.info_height = data.height
					}).exec();
					query.select('#tab').boundingClientRect(data => {
						this.tab_height = data.height
					}).exec();
					const swiper = document.getElementById('swiper');
					swiper.style.height =
						(getStatusBarHeightAndNavbarHeight.windowHeight -
							getStatusBarHeightAndNavbarHeight.customBar -
							this.info_height -
							this.tab_height) + 'px';

				});
			},
			changeTab(i) {
				this.tab_index = i;
				console.log(this.tab[i]);
			},
			change(e) {
				const {
					current
				} = e.detail;
				this.tab_index = current;
			},
		}
	}
</script>

<style lang="less" scoped>
	.arrow {
		display: inline-block;
		border: 2px solid #FFFFFF;
		border-left: 0;
		border-bottom: 0;
		width: 20rpx;
		height: 20rpx;
	}

	.rotate_225 {
		transform: rotate(225deg);
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;
		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
	}

	.custom_header_left {
		flex: 10%;
	}

	.custom_header_left>image {
		width: 24px;
		height: 24px;
	}

	.custom_header_center {
		display: block;
		color: #333333;
		font-size: 38rpx;
		padding: 0 10px;
		flex: 80%;
		text-align: center;
		font-weight: 800;
	}

	.custom_header_right {
		flex: 10%;
	}


	page {
		font-family: Arial;
	}


	.color-green {
		color: #17A75B !important;
	}

	.color-red {
		color: #E9393F !important;
	}

	.quantity-input {
		border: 2rpx solid #e0e0e0;
		border-radius: 10rpx;
		padding: 10rpx 20rpx;
		display: flex;
		font-size: 28rpx;
	}

	.info {

		.up {
			padding: 24rpx;

			.create-at {
				color: #dbdbdc;
			}
		}

		.down {
			padding: 24rpx;

			.amount {
				color: #353539;
				font-size: 30rpx;
			}

			span {
				color: #dbdbdc;
			}
		}
	}

	.tab {
		padding: 24rpx;

		.item {
			padding: 12rpx 24rpx;
			color: #dbdbdc;
			font-weight: bold;
			transition: all .3s ease-in;
		}

		.active {

			color: #27285E;
			background: #F0EEFF;
			border-radius: 30rpx 30rpx 30rpx 0;
		}
	}

	.list {
		.order-item {
			padding: 24rpx;

			.row {
				margin-bottom: 30rpx;

				.title {
					width: 180rpx;
					font-size: 24rpx;
					color: #dbdbdc;
					margin-bottom: 17rpx;
				}

				.amount {
					width: 200rpx;
					word-wrap: break-word;
					color: #fff;
					font-size: 26rpx;
				}

				button {
					width: 48.5%;
					margin: none;
					border-radius: 10rpx;
				}
			}

			.row:last-child {
				margin-bottom: 0;
			}
		}

		.record-item {
			background: #fff;
			padding: 24rpx;

			.row {
				margin-bottom: 30rpx;

				.title {
					width: 180rpx;
					font-size: 24rpx;
					color: #dbdbdc;
					margin-bottom: 17rpx;
				}

				.amount {
					width: 200rpx;
					word-wrap: break-word;
					color: #fff;
					font-size: 26rpx;
				}

				.create-at {
					color: #dbdbdc;
					font-size: 26rpx;
				}
			}

			.row:last-child {
				margin-bottom: 0;
			}
		}

		.loadmore {
			padding: 30rpx;
		}
	}
</style>