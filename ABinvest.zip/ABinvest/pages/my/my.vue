<template>
	<view>
		<view class="flex flex-b padding-20 padding-top-20">

			<image src="/static/chuanggai/applogo.png" mode="widthFix" style="width: 100px;height: 50px;"></image>
			<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;" @click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>

		<view>
			<view
				style="display: flex;align-items: center;justify-content: center; flex: 1 1 auto;
			margin: auto;border-radius: 100px; color: rgb(20, 16, 43);font-size: 15px; line-height: 1.3;
			text-align: center;background-image: linear-gradient(90deg, rgb(255, 176, 68), rgb(255, 45, 48));width: 132px;height: 132px;padding: 0px;">
				<u-avatar size='120' :src="userInfo.avatar" shape="circle"
					default-url="/static/chuanggai/logo.png"></u-avatar>
			</view>


			<view style="display: flex;align-items: center;justify-content: center; padding:20rpx;"
				@click="handleLink()">
				<view style="font-size: 36rpx;text-align: left;color:#FFFFFF;padding-right: 30rpx;">
					{{userInfo.real_name}}
				</view>
				<view class="arrow rotate_45" style="border-color: #CBCBCF;"></view>
			</view>

			<view style="display: flex;align-items: center;justify-content: center; padding:20rpx;">
				<view style="font-size: 32rpx;text-align: left;color:#CBCBCF;padding-right: 30rpx;">
					ID: {{userInfo.p_mobile}}
				</view>

				<view class="attestation">
					<view class="certification-icon display" v-if="userInfo.is_check==-1">
						<image src="../../static/renzheng.png" mode=""></image>
						<view class="" @tap="notCertified()">Chưa xác minh</view>
						<image class="you" src="../../static/jiantou.png" mode=""></image>
					</view>
					<!-- 未审核 -->
					<view class="certification-icon display" v-if="userInfo.is_check==0">
						<image src="../../static/renzheng.png" mode=""></image>
						<view class="" @tap="notCertified()">Chưa xác minh</view>
						<image class="you" src="../../static/jiantou.png" mode=""></image>
					</view>
					<view class="certification-icon display" v-if="userInfo.is_check==2">
						<image src="../../static/renzheng.png" mode=""></image>
						<view class="" @tap="notCertified()">Chưa được kiểm duyệt</view>
						<image class="you" src="../../static/jiantou.png" mode=""></image>
					</view>

					<!-- 这是认证成功的 -->
					<view class="certification-icon success" v-if="userInfo.is_check==1">
						<image src="../../static/renzheng2.png" mode=""></image>
						<view class=""> Đã xác minh</view>
					</view>
				</view>

			</view>
		</view>




		<view style="display: flex;align-items: center;justify-content: space-between;padding:20rpx 40rpx;"
			class="gap10">
			<view style="background-color: #3F3384;border-radius: 8rpx;height: 130px;" class="flex-1 padding-10"
				@click="silver(userInfo.money,userInfo.bank_card_info,userInfo.idno)">

				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_deposit.png" mode="aspectFit" style="width: 70px;height: 70px;"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFFFFF;margin-top: 40rpx;">
					Nạp tiền
				</view>
			</view>

			<view style="background-color: #3F3384;border-radius: 8rpx;height: 130px;" class="flex-1 padding-10"
				@tap="prove()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_withdraw.png" mode="aspectFit" style="width: 70px;height: 70px;"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFFFFF;margin-top: 40rpx;">
					Rút tiền
				</view>
			</view>

			<view style="background-color: #3F3384;border-radius: 8rpx;height: 130px;" class="flex-1 padding-10"
				@click="customer()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_service.png" mode="aspectFit" style="width: 70px;height: 70px;"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#FFFFFF;margin-top: 20rpx;">
				Dịch vụ CSKH
				</view>
			</view>
		</view>
		<view class="padding-20">
			<view style="position: relative; height: 40px; padding: 0px 20px; color: transparent; width: max-content;">
				Chức năng khác
				<view
					style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; background-image: linear-gradient(90deg, rgb(255, 176, 68), rgb(255, 45, 48)); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 4px; left: 0px; right: 0px; font-size: 20px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Chức năng khác</view>
			</view>

		</view>

		<view style="display: flex;flex-wrap: wrap;justify-content: space-between;margin: 10rpx 20rpx;">
			<block v-for="(item,index) in nav" :key="index">
				<view style="width: 50%;">
					<view
						style="display: flex;align-items: center;margin:10rpx;background-color: #3F3384;padding:20rpx 30rpx;border-radius: 8rpx;" class="gap10"
						@click="actionEvent(item,index)">
						<image mode="widthFix" :src="`/static/my/${item.icon}.png`" style="width:40px;height: 40px;" class="flex-1"></image>
						<text style="font-size: 28rpx;color: #FFFFFF;" class="flex-3">{{item.name}}</text>
					</view>
				</view>
			</block>
		</view>

	</view>
</template>

<script>
	import Profile from '@/components/Profile.vue';
	// import annular from "./components/annular/annular.vue"
	export default {
		components: {
			Profile
		},
		data() {
			return {
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInfo: '',
				is_check: '',
				cardManagement: '',
				item: '',
				nav: [
					{
							name: 'Đổi mật khẩu',
							url: '/pages/my/components/commonFunctions/changePassword',
							icon: 'signin_pwd',
							mode: 'link',
						}, {
							name: 'Mật khẩu giao dịch',
							url: '/pages/my/components/commonFunctions/fundPassword',
							icon: 'pay_pwd',
							mode: 'link',
						}, {
							name: 'Thẻ ngân hàng',
							url: '/pages/my/components/bankCard/binding',
							icon: 'bank_card',
							mode: 'link',
						}, {
							name: 'Lịch sử dòng tiền',
							url: '/pages/my/components/commonFunctions/capitalDetails?index=0',
							icon: 'capital_deatil',
							mode: 'link',
						},
						{
							name: 'Điều kiện & thỏa thuận',
							url: '/pages/my/components/other/aboutUs',
							icon: 'about',
							mode: 'link',
						},
						{
							name: 'Đăng xuất',
							url: '',
							icon: 'sign_out',
							mode: 'sign_out',
						}
				]
			}
		},
		
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Loading',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			actionEvent(item, index) {
				if (item.mode == 'sign_out') {
					// this.handleSignOut();
					uni.removeStorageSync("token")
					uni.navigateTo({
						url:"/pages/logon/logon/logon"
					})
					return false;
				}
				uni.navigateTo({
					url: item.url,
				})
			},
			
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			
			
			// 银转证
			silver(money, bank_card_info, idno) {
				if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/silver' + `?money=${money}`
					});
				} else if (bank_card_info == null) {
					uni.$u.toast('Vui lòng liên kết tài khoản ngân hàng');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (idno == null) {
					uni.$u.toast('Chưa xác thực danh tính');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			// 证转银
			prove() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove'
				});
			},
			
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			
			

			//实名认证
			notCertified() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					// url: '/pages/index/components/openAccount/openAccount'
					url: '/pages/marketQuotations/authentication'
				});
			},


			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInfo = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},

		},
		
		onShow() {
			this.gaint_info()
		},

	}
</script>

<style lang="scss">
	@import url("@/common/css/rc.css");

	.attestation {
		color: #fff;

		.success {
			display: flex;
			justify-content: center;
			align-items: center;
		}

		.certification-icon {
			padding: 4rpx 10rpx;
			background: #90bae7;
			border-radius: 40rpx;
			font-size: 28rpx;


			image {
				width: 30rpx;
				height: 30rpx;
				margin: 0;
			}

			view {
				margin: 0 10rpx;
			}

			.you {
				width: 20rpx;
				height: 20rpx;
			}
		}
	}



	//总资产
	.total-assets {
		box-shadow: 0 2rpx 2rpx 0 #e3e3e3;
		background: #fff;
		border-radius: 20rpx;
		margin: -100rpx 30rpx 0rpx;
		// display: flex;
		// justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
		padding: 30rpx;

		.account {
			// border: 20rpx solid #ea3544;
			border-radius: 30rpx;
			padding: 60rpx;
			margin: 30rpx;
			text-align: center;

			.assets-money {
				color: #ea3544;
				font-size: 46rpx;
				font-weight: 800;
			}

			.assets-text {
				color: #999;
				font-size: 28rpx;
			}
		}


		.fund {
			display: flex;
			flex-wrap: wrap;
			justify-content: space-around;
			align-items: center;
			margin: 30rpx 0;

			.hushen {
				width: 45%;
				font-size: 28rpx;
				display: flex;
				flex-direction: column;
				align-items: center;

				image {
					width: 30rpx;
					height: 30rpx;
					margin-right: 10rpx;
				}

				.money {
					color: #ea3544;
					font-size: 28rpx;
					margin-top: 20rpx;
					font-weight: bold;

				}
			}

		}

	}

	.press {
		// width: 100%;
		// box-shadow: 0rpx 2rpx 2rpx 2rpx #cfcfcf;
		margin: 30rpx 10rpx;
		padding: 10rpx 20rpx;
		border-radius: 10px;

		.bank-to-securities {
			padding: 24rpx 0;
			// width: 48%;
			// background: linear-gradient(to left, #4CA1AF, #C4E0E5);
			// background: linear-gradient(to left, #17A75B, #1fe67c);
			background: #0a9696;

			border-radius: 10rpx;
			color: #fff;
			flex-wrap: 800;
			font-size: 30rpx;
			text-align: center;
			margin: 30rpx 0;
			box-shadow: 0rpx 2rpx 2rpx 2rpx #e3e3e3;
		}

		.certificate-to-bank {
			padding: 24rpx 0;
			// width: 48%;
			// background: linear-gradient(to left, #17A75B, #1fe67c);
			// background: #E5CDAC;
			background: #a2c6b6;
			border-radius: 10rpx;
			color: #fff;
			flex-wrap: 800;
			font-size: 30rpx;
			text-align: center;
			margin: 30rpx 0;
			box-shadow: 0rpx 2rpx 2rpx 2rpx #e3e3e3;
		}
	}

	.tile {
		margin: 30rpx;
	}

	.common-use {
		display: flex;
		justify-content: space-around;
		align-items: center;
		text-align: center;
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		// border: 1rpx solid #cfcfcf;
		margin: 30rpx;
		padding: 40rpx 20rpx;
		font-size: 28rpx;

		image {
			width: 60rpx;
			height: 60rpx;

		}
	}

	.card {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 60rpx 30rpx;

		image {
			width: 20rpx;
			height: 20rpx;
			margin-left: 10rpx;
		}
	}

	//线
	.thread {
		height: 1rpx;
		width: 100%;
		background: #e0e0e0;
	}

	.ganh {
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		margin: 30rpx;
		font-size: 28rpx;

		.renew {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;

			.version-update {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}

			.renew-img {
				margin: 10rpx 10rpx 0 0;

				image {
					width: 40rpx;
					height: 40rpx;
				}


			}

			.right-side {
				image {
					width: 20rpx;
					height: 20rpx;
				}
			}

		}


	}
</style>