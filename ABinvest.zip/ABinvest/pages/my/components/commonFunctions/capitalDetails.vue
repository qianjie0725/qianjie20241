<!-- 资金明细 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Chi tiết dòng tiền</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<u-tabs lineColor="#fff" :current="current" :list="list1" @click="select"
				:activeStyle="{color: '#fff',fontWeight: 'bold',}" :inactiveStyle="{color: '#e9f2de'}"></u-tabs>
			<view v-if="current == 0">
				<template v-if="!fundDetails || fundDetails.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in fundDetails" :key="index">
						<view class="takeNotes" style="color: #fff;">
							<view class="display">
								<view class="business">

									<view class="recharge" style="color: #fff;">Số dư</view>
									<view class="money"> {{item.after}} đ</view>
								</view>
								<view class="underReview" v-if="item.status==0">
									<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xem xét
								</view>
								<view class="underReview_b" v-if="item.status==1">
									<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Nạp tiền thành
									công
								</view>
								<view class="underReview_c" v-if="item.status==2">
									<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
									khách hàng
								</view>
							</view>
							<view class="" style="margin: 10rpx 0;white-space: pre-wrap;">{{item.desc}}</view>
							<!-- <view class="order"> -->
							<view class=""> Số dư trước giao dịch:<text>{{toThousandFilter(item.before)}}</text> </view>

							<!-- </view> -->
							<view class=""> Thời gian:<text>{{item.created_at}}</text> </view>
						</view>
					</view>
				</template>
			</view>
			<view v-if="current == 1">
				<template v-if="!rechargeRecord || rechargeRecord.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in rechargeRecord" :key="index">
						<view class="takeNotes">
							<view class="display">
								<view class="business">
									<!-- <view class="corporate">{{item.desc_type}}</view> -->
									<view class="recharge" style="color: #fff;">Nạp tiền</view>
									<view class="money">{{item.money}} VND</view>
								</view>

								<view class="underReview" v-if="item.status==0">
									<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xem xét
								</view>
								<view class="underReview_b" v-if="item.status==1">
									<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Nạp tiền thành
									công
								</view>
								<view class="underReview_c" v-if="item.status==2">
									<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
									khách hàng
								</view>
							</view>
							<view class="order" style="color: #fff;">
								<view class=""> Mã giao dịch:<text>{{item.order_sn}}</text> </view>
								<view class=""> Thời gian:<text>{{item.created_at}}</text> </view>
							</view>
						</view>
					</view>
				</template>

			</view>
			<view v-if="current == 2">
				<template v-if="!withdrawalRecords || withdrawalRecords.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in withdrawalRecords" :key="index">
						<view class="takeNotes">
							<view class="display">
								<view class="business">
									<!-- <view class="corporate">{{item.desc_type}}</view> -->
									<view class="recharge" style="color: #fff;">Rút tiền</view>
									<view class="money">{{toThousandFilter(item.money)}} VND</view>
								</view>

								<view class="underReview" v-if="item.status==0">
									<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xử lý
								</view>
								<view class="underReview_b" v-if="item.status==1">
									<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Rút tiền thành
									công
								</view>
								<view class="underReview_c" v-if="item.status==2">
									<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
									khách hàng
								</view>
							</view>
							<view class="order" style="color: #fff;">
								<view class=""> Mã giao dịch:<text>{{item.order_sn}}</text> </view>
								<view class=""> Thời gian:<text>{{item.created_at}}</text> </view>
							</view>
						</view>
					</view>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current: 0,
				list1: [{
						name: 'Chi tiết'
					},
					{
						name: 'Lịch sử nạp tiền'
					},
					{
						name: 'Lịch sử rút tiền'
					},
				],
				fundDetails: [],
				rechargeRecord: [],
				withdrawalRecords: [],
			};
		},
		onLoad(item) {
			this.current = item.index || 0;
		},
		mounted() {
			this.fund()
			this.recharge()
			this.withdrawal()
		},
		methods: {
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/my'
				});
			},
			select(item) {
				// console.log(item);
				this.current = item.index;
				// console.log(this.current, '9989999999');
			},
			// 资金明细
			async fund() {
				let list = await this.$http.get('api/user/finance', {})
				this.fundDetails = list.data.data
				console.log(this.fundDetails);
			},
			//充值记录
			async recharge() {
				let list = await this.$http.get('api/user/recharge', {

				})
				this.rechargeRecord = list.data.data
			},
			//提现记录
			async withdrawal() {
				let list = await this.$http.get('api/user/withdraw', {

				})
				this.withdrawalRecords = list.data.data
			},

		},
		
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-between;
		border-bottom: 1rpx solid #e0e0e0;
		padding: 0 30rpx;

	}

	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			padding: 20rpx 0;
			border-bottom: 2rpx solid #eeeeee;
			font-size: 26rpx;


			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>