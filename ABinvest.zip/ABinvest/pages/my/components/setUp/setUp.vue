<template>
	<view>
		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Cài đặt</view>
			<view class=""></view>
		</view>

		<view class="head" @tap="sculpture()">
			<view class="sculpture">Ảnh đại diện</view>
			<!-- <image class="picture" src="../../../../static/logo.png" mode=""></image> -->
			<u-avatar size='50' :src="userInformation.avatar" shape="circle" default-url="/static/chuanggai/logo.png"></u-avatar>
		</view>
		<view class="head">
			<view class="sculpture">Số điện thoại</view>
			<view class="">{{userInformation.mobile}}</view>
		</view>
		
		<navigator class="head" url="/pages/my/components/commonFunctions/changePassword">
			<view class="sculpture">Đổi mật khẩu</view>
			<image class="withdraw"  src="/static/jiantou.png" mode=""></image>
		</navigator>
		<navigator class="head" url="/pages/my/components/commonFunctions/fundPassword">
			<view class="sculpture">Mật khẩu giao dịch </view>
			<image class="withdraw" src="/static/jiantou.png" mode=""></image>
		</navigator>
		<navigator class="head" url="/pages/my/components/commonFunctions/capitalDetails?index=0">
			<view class="sculpture">Lịch sử dòng tiền</view>
			<image class="withdraw" src="/static/jiantou.png" mode=""></image>
		</navigator>
		<navigator class="head" url="/pages/my/components/bankCard/renewal" v-if="cardManagement==null">
			<view class="sculpture">Thẻ ngân hàng</view>
			<image class="withdraw"  src="/static/jiantou.png" mode=""></image>
		</navigator>
		
		<navigator class="head" url="/pages/my/components/other/privacyAgreement" v-if="cardManagement==null">
			<view class="sculpture">Bảo mật</view>
			<image class="withdraw"  src="/static/jiantou.png" mode=""></image>
		</navigator>
		
		
		<view class="head" url="" v-if="cardManagement!=null"
		@tap="manage(cardManagement.bank_name,cardManagement.bank_sub_name,cardManagement.card_sn)">
			<view class="sculpture">Thẻ ngân hàng</view>
			<image class="withdraw"  src="/static/jiantou.png" mode=""></image>
		</view>
		
		<view class="head" @click="clear">
			<view class="sculpture">Đăng xuất</view>
			<!-- <image class="withdraw"  src="/static/my/tuichu.png" mode=""></image> -->
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInformation: "",
				cardManagement:""
			};
		},
		methods: {

			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			sculpture() {
				uni.navigateTo({
					url: '/pages/my/components/setUp/modifyAvatar'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.clearStorageSync();
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('Đăng xuất thành công');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},

		},

		onLoad(option) {
			this.gaint_info()
			this.userInformation = {
				mobile: option.mobile || '',
				avatar: option.avatar || ','
			}
			// console.log(option.avatar, '1111'); //打印出上个页面传递的参数。
		}
	}
</script>

<style lang="scss">
	
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;
		color: #fff;
		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	}

	.head {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx;
		color: #fff;
		border-bottom: 2rpx solid #e9e9e9;

		.picture {
			width: 120rpx;
			height: 120rpx;
			border-radius: 50%;
		}

		.withdraw {
			width: 40rpx;
			height: 40rpx
		}
	}
</style>
