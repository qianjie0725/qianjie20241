<!-- 证转银 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Rút tiền</view>
				<view class=""></view>
			</view>
			<view class="progress"> {{toThousandFilter(userInformation.money)}} ₫</view>
			<view class="vacancies">Số dư khả dụng hiện tại</view>
		</view>

		<view class="cash-withdrawal">
			<view class="withdrawal">Số tiền rút</view>
			<view class="money">
				<input placeholder="Xin mời nhập" v-model="value1"></input>
				<!-- <view class="" @click="whole((userInformation.money*1).toFixed(0))">
					Tất cả
				</view> -->
			</view>
		</view>
		<view class="cash-withdrawal">
			<view class="withdrawal">Mật khẩu rút tiền</view>
			<view class="money">
				<input placeholder="Xin mời nhập" type="password" v-model="value2"></input>
			</view>
		</view>
		<!-- <view class="cash-withdrawal">
			<view class="withdrawal">Nhập lại mật khẩu</view>
			<view class="money">
				<input placeholder="Xin mời nhập" type="text" v-model="value3"></input>
			</view>
		</view> -->
		<view class="purchase" @click="to_withdraw()">
			Rút tiền
		</view>

		<!-- <view class="point-out">
			<view>1、Lệnh hiện tại không thể rút tiền。</view>
			<view>2、Xin vui lòng rút tiền bằng tên thật và thẻ ngân hàng.。</view>
			<view>3、Thời gian rút tiền là 9:30 - 11:30 sáng, 1:00 - 3:00 chiều。</view>
			<view>4、Số tiền rút tối thiểu 100。</view>
			<view>
				5、<text>Rút tiền trong thời gian rút tiền thường là 2 giờ đến tài khoản, thời gian rút tiền bị ảnh hưởng bởi thời gian thanh toán giữa các ngân hàng, thời gian đến tài khoản của các ngân hàng khác nhau, muộn nhất T+1 đến tài khoản trước 24 giờ ngày hôm sau</text>
			</view>
		</view> -->



	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		methods: {
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			async to_withdraw() {
				uni.showLoading({
					title: "Xin chờ một chút....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				
			},

		},
		
		onLoad(option) {
			this.gaint_info()
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
				background-image: linear-gradient(#180d2b);

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #ffffff;
			font-size: 26rpx;
		}
	}

	.cash-withdrawal {
		border-radius: 30rpx 30rpx 0 0;
		margin-top: -30rpx;
		background: #180d2b;
		padding: 30rpx;
		font-size: 28rpx;

		.withdrawal {
			color: #fff;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

			input {
				font-size: 28rpx;
			}

		}
	}

	.purchase {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

		text {
			color: #cb1a1e;
		}
	}
</style>