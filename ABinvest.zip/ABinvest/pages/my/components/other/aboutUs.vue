<!-- 关于我们 -->
<template>
	<view>
		<view class="college-bg" >
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text" style="color: #fff;">{{about.title}}Điều kiện & thỏa thuận
</view>
			<view class=""></view>
		</view>
		<view class="college-content" style="color: #fff;">
			<!-- <rich-text :nodes="about.content"></rich-text> -->
			<view class="" v-html="about.content"></view>

			<u-divider></u-divider>



		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				about: ''
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//关于我们
			async about_us() {
				let list = await this.$http.get('api/article/about-us', {
					// language: this.$i18n.locale
				})
				this.about = list.data.data
				// console.log(list.data.data, '关于我们');
			},
		},
		mounted() {
			this.about_us()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

	}
</style>
