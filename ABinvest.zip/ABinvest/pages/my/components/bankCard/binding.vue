<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Liên kết ngân hàng</view>
			<view class=""></view>
		</view>

		<view class="college-content" >
			<view class="bank-name" style="background-color: aliceblue;border-radius: 10px;">
				<view class="" >Họ tên :</view> <text> {{cardManagement.bank_name}}</text>
			</view>
			<!-- <view class="xian"></view> -->
			<view class="bank-name" style="background-color: aliceblue;border-radius: 10px;margin-top: 5px;">
				<view class="">Tên ngân hàng : </view><text> {{cardManagement.bank_sub_name}}</text>
			</view>
			<!-- <view class="xian"></view> -->
			<view class="bank-name" style="background-color: aliceblue;border-radius: 10px;margin-top: 5px;">
				<view class="">Số tài khoản : </view> <text> {{cardManagement.card_sn}}</text>
			</view>

		</view>

		<!-- 		<view class="college-content">
			<view class="bank-name">
				<view class="">银行卡号: </view> <text> {{cardManagement.card_sn}}</text>
			</view>
		</view> -->


		<view class="purchase" @tap='renewal()'>
			Nhấp để liên kết lại
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				cardManagement: '',
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			renewal() {
				uni.navigateTo({
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},
		},
		onLoad(option) {
			this.gaint_info();
			

		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;
		.bank-name {
			padding: 30rpx 20rpx;
			// font-weight: 700;
			display: flex;
			font-size: 28rpx;
			border-bottom: 2rpx solid #f4f4f4;
			view {
				width: 35%;
			}

			text {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 100rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;
		// font-weight: 600;
	}
</style>