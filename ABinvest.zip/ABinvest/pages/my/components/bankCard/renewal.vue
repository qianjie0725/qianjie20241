<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Liên kết thẻ ngân hàng</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<view class="bank-name" style="background-color: #fff;border-radius: 10px;">
				<view class="">Họ tên :</view> <input placeholder="Vui lòng nhập" v-model="value"> </input>
			</view>
			<!-- <view class="xian"></view> -->
			<view class="bank-name" style="background-color: #fff;border-radius: 10px;margin-top: 5px;">
				<view class="">Tên ngân hàng :</view> <input placeholder="Vui lòng nhập" v-model="value2"> </input>
			</view>
			<!-- <view class="xian"></view> -->
			<!-- <view class="bank-name">
				<view class="">Mở tài khoản: </view> <input placeholder="Vui lòng nhập" v-model="value3"> </input>
			</view> -->
			<view class="bank-name" style="background-color: #fff;border-radius: 10px;margin-top: 5px;">
				<view class="">Số tài khoản : </view> <input placeholder="Vui lòng nhập" v-model="value4"> </input>
			</view>
		</view>

		<!-- 		<view class="college-content">

		</view> -->


		<view class="purchase" @click="replaceBank()">
			Xác nhận liên kết
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {

				value: '',
				value2: '',
				value3: '',
				value4: ''

			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value,
					bank_sub_name: this.value2,
					card_sn: this.value4,
				})
				if (list.data.code == 0) {
					uni.$u.toast('Thông tin thẻ gửi thành công');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
		// mounted() {
		// 	this.replaceBank()
		// },
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 30rpx 20rpx;
			// font-weight: 700;
			display: flex;
			font-size: 28rpx;
			border-bottom: 2rpx solid #f4f4f4;

			view {
				width: 34%;
			}

			input {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 100rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		// font-weight: 600;
		font-size: 28rpx;
	}
</style>