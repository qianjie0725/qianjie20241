<!-- 下单 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">
				{{objData.goods.name}}
				<view class="" style="font-size: 24rpx;">{{toThousandFilter(objData.goods.current_price)}}</view>
			</view>
			<view class=""></view>
		</view>
		<view class="quantity-content" style="margin-top: 50rpx;">
			<view class="quantity">
				<image src="../../../../../static/purchase/shangshen.png" mode=""></image>
				<view class="">Khối lượng</view>
			</view>
			<view class="quantity-input">
				<input class="" placeholder="Vui lòng nhập" type="number" @input="number_input" v-model="quantity"></input>
				<view class="">Lô chẵn</view>
			</view>
		</view>

		<view class="hand">1 lô chẵn = 100 Cổ phiếu</view>
		<view class="quantity-content">
			<view class="quantity">
				<image src="../../../../../static/purchase/biaoqian.png" mode=""></image>
				<view class="">Sức mua</view>
			</view>
			<view class="">
				{{toThousandFilter(list.money)}} ₫
			</view>
		</view>
			
		<view class="quantity-content" @click="show=true">
			<view class="quantity">
				<image src="/static/purchase/biaoqian.png" mode=""></image>
				<view class="">Margin (Đòn bẩy) </view>
			</view>
			<view class="">
				{{ganggan}}
			</view>
		</view>
	
		<u-action-sheet :show="show" :actions="actions" title="Margin (Đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>

		<view class="quantity-content">
			<view class="quantity">
				<image src="../../../../../static/purchase/baozheng.png" mode=""></image>
				<view class="">Số tiền thanh toán</view>
			</view>

			<view class="">
				{{toThousandFilter(objData.goods.current_price*this.quantity/this.ganggan*100|addZero)}} đ
			</view>

		</view>

		<view v-if="list.is_check!=1" @tap="authentication()" class="purchase">
			Vui lòng xác minh danh tính
		</view>
		<view v-if="list.is_check==1" class="purchase" @click="show_buy=true">
			Mua vào
		</view>
			
		<u-modal :show="show_buy" :content="getcontent()" confirm-text="Xác nhận" cancel-text="Huỷ bỏ" @confirm="placeOrder" :showCancelButton="true"
			@cancel="show_buy=false"></u-modal>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				actions: [{
						name: '1',
						index: 1
					}],
				show_buy:false,
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '',
				detailedData: "",
				objData: '',
				ganggan:1
			};
		},
		methods: {
			number_input(e){
				this.$nextTick(() => {
				  this.quantity=parseInt(e.detail.value)
				})
				
				
			},
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			getcontent() {
				
				var total = this.toThousandFilter(this.objData.goods.current_price*this.quantity/this.ganggan*100)
				return 'Khớp hết ' + this.objData.goods.name + ', ' + this.quantity + ' lô chẵn, Số tiền ' + total + " VND, \n\tXác nhận mua";
			
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.objData.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//购买
			async placeOrder(objData) {
				this.show_buy=false
				uni.showLoading({
					
				})
				let list = await this.$http.post('api/product/buy_vip_scramble', {
					num: this.quantity * 100,
					id: this.objData.id,
					ganggan:this.ganggan
				})
				
				if (list.data.code == 0) {
					uni.showLoading({
						title: "Đang khớp lệnh, vui lòng chờ trong giây lát ...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/position/position',
						});
						uni.hideLoading();
					}, 1000)

				} else {
					uni.hideLoading()
					uni.$u.toast(list.data.message);
				}
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
				this.actions=list.data.data.ganggan
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			const item = JSON.parse(decodeURIComponent(option.item));
			this.objData = item;
			// console.log(this.objData, '========接着');
			this.columns = [item.ganggan]

			// console.log(item.ganggan, '111');
			// const productDetails = JSON.parse(decodeURIComponent(option.productDetails));
			// this.detailedData = productDetails
			// this.columns = [productDetails.ganggan]

		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 90rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.quantity-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 30rpx;
		font-size: 28rpx;

		//数量
		.quantity {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 28rpx;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-right: 20rpx;
			}
		}

		/deep/.input-placeholder {
			font-size: 28rpx;
		}

		.quantity-input {
			background-color: #f5f5f5;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;
			padding: 10rpx 20rpx;
			display: flex;
			font-size: 28rpx;
		}

		//杠杆倍数
		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;
			background-color: #f5f5f5;
			width: 50%;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;



			.times {}

			image {
				height: 20rpx;
				width: 20rpx;

			}
		}

	}

	// 二选一
	.hand {
		text-align: right;
		margin: 10rpx 30rpx;
		font-size: 26rpx;
		color: #999;
	}

	.radio {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10rpx 30rpx;


		view {
			width: 48%;
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			border-radius: 10rpx;
			border: 2rpx solid #e0e0e0;
		}

		.rise {
					background-image: linear-gradient(to right, #FFB044, #FF2D30);
			color: #fff;
		}

		.fall {
			color: #000;
		}
	}

	//买入
	.purchase {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 28rpx;
	}
</style>