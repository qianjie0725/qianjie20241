<!-- 中签记录 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Lịch sử đăng ký</view>
			<view class=""></view>
		</view>
		<view class="" v-for="(item,index) in list" :key="index">
			<view style="background-color: #442f84;font-size: 14px;" class="padding-10 margin-10">
				<view class="flex flex-b color-white ">
					<view>{{item.goods.name}}</view>
					<view style="color: #f6ab44;">{{item.message}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Giá mua</view>
					<view>{{toThousandFilter(item.price)}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Margin (Đòn bẩy)</view>
					<view>{{item.ganggan}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>KL mua</view>
					<view>{{toThousandFilter(item.apply_amount)}}</view>
				</view>
				
				<view class="flex flex-b color-white margin-top-10">
					<view>Số tiền trúng thầu</view>
					<view>{{toThousandFilter(item.success_num_amount/item.ganggan)}}</view>
				</view>
				
				<view class="flex flex-b color-white margin-top-10">
					<view>Vị thế</view>
					<view>{{toThousandFilter(item.success*1)}}</view>
				</view>
				
				<view class="flex flex-b color-white margin-top-10">
					<view>Mã giao dịch</view>
					<view>{{item.order_sn}}</view>
				</view>
			</view>
		<!-- 	<view style="margin: 30rpx; word-wrap:break-word;">
				
				<view class="display">
					<view v-if="item.status==2" class="subscription" @click="subscription(item)">
						Xác nhận
					</view>
				</view>

			</view> -->
		</view>






	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: '',
				item: ''
			};
		},
		methods: {
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//充值
			// silver(money) {
			// 	uni.navigateTo({
			// 		//保留当前页面，跳转到应用内的某个页面
			// 		url: '/pages/my/components/certificateBank/silver' + `?money=${money}`
			// 	});
			// },
			// 中签记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

			async subscription(item) {
				let list = await this.$http.get('api/goods-shengou/pay', {
					id: item.id
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.data.message);
					if (list.data.data.success == 0) {
						setTimeout(() => {
							uni.navigateTo({
								//保留当前页面，跳转到应用内的某个页面
								url: '/pages/my/components/certificateBank/silver'
							});
						}, 500)
					} else {
						uni.redirectTo({
							url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
						});
						this.$router.go(0)

					}
				} else {
					uni.$u.toast(list.data.data.message);
				}
			},

		},
		onLoad(option) {
			this.shengou()
			// this.gaint_info()
		}
		// mounted() {
		// 	// uni.showLoading({
		// 	// 	title: '加载中'
		// 	// });

		// },
	}
</script>

<style lang="scss">
.college-bg {
		padding: 40rpx;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}
</style>