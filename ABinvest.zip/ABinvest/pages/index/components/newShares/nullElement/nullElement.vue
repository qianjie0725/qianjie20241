<!-- 学院 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Chi tiết cổ phiếu mới</view>
			<view class=""></view>
		</view>
		<view class="company-name">
			<h4>{{detailed.name}}</h4>
		</view>
		<view style="border-bottom: 1rpx dashed #ccc;padding-bottom: 20rpx;">
			<view class="issue" style="color: #FFF;">
				<view class="" >
					<text>Giá phát hành</text> <text style="color: #FFF;">{{toThousandFilter(price.price)}}</text>
				</view>
				
				<view class="">
					<text>Tổng KL phát hành</text> <text
						style="color: #FFF;">{{toThousandFilter(price.fa_amount) }}</text>
				</view>
			</view>

			<!-- <view class="" >
				<u-steps current="0" activeColor="#000" >
					<u-steps-item title="Ngày mua" :desc="title1.shengou_date"></u-steps-item>
					<u-steps-item title="Ngày công bố" :desc="title2.gb_date"></u-steps-item>
					<u-steps-item title="Ngày đăng ký" :desc="title3.gb_date"></u-steps-item>
					<u-steps-item title="Đợi niêm yết" :desc="title4.online_date ? title4.online_date : 'Chưa công bố'"></u-steps-item>
					 
					<u-steps-item title="Ngày mua"></u-steps-item>
					<u-steps-item title="Ngày công bố"></u-steps-item>
					<u-steps-item title="Ngày đăng ký"></u-steps-item>
					<u-steps-item title="Đợi niêm yết"></u-steps-item>
				</u-steps>
			</view> -->

		</view>

		<view class="general" style="color: #FFF;">
			<h4>Tổng quát phát hành</h4>
			<view class="display">
				<view class="front">Tổng quỹ vốn</view>
				<view>{{toThousandFilter(price.fa_muji_zijin)}}</view>
			</view>
			<!-- 	<view class="display">
				<view class="front">中签率</view>
				<view>{{price.success}}</view>
			</view> -->
			<!-- <view class="display">
				<view class="front">Ngày công bố phiếu</view>
				<view>{{price.gb_date}}</view>
			</view>
			<view class="display">
				<view class="front">Ngày đăng ký</view>
				<view>{{price.rj_date}}</view>
			</view> -->
			<view class="display">
				<view class="front">Ngày niêm yết</view>
				<view v-if="price.shengou_date!=null">{{price.shengou_date}}</view>
				<view v-if="price.shengou_date==null">Chưa công bố</view>
			</view>
		</view>
		<!-- <view  class="purchases" @click="position(price.id)">
			Yêu cầu mua
		</view> -->


		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)" cancelText='Hủy bỏ'
			confirmText="Xác nhận" :showCancelButton='showCancelButton' :content='content'>
		</u-modal>


		<view class="purchase">
			<view class="apply">
				<h4>Khối lượng mua </h4>
			</view>
			<input placeholder="Vui lòng nhập khối lượng cần mua" type="number" v-model="value" style="color: #000;">
			
			<view class="apply">
				<h4> Margin  </h4>
			</view>
			<input type="number" :disabled="true" placeholder="" v-model="ganggan" style="color: #000;" @click="ganggan_show=true">
			</input>
			
			<view class="purchases" @click="purchase(price.id)">Mua</view>
		</view>
		
		<u-action-sheet :show="ganggan_show" :actions="actions" title="Margin (Đòn bẩy)" @close="ganggan_show = false" @select="Select">
		</u-action-sheet>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				actions: [{
						name: '2',
						index: 2
					}
				],
				ganggan:2,
				ganggan_show:false,
				value: "",
				detailed: "",
				price: '',
				title1: '',
				title2: '',
				title3: '',
				title4: '',
				show: false,
				title: 'Nhấn xác nhận để mua',
				content: '',
				showCancelButton: true,
			};
		},
		methods: {
			
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			//申购
			position(id) {
				this.show = true;
				this.confirmation = id
				// console.log(this.confirmation, '11111111111');
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.purchase(confirmation)
				this.show = false;
			},
			//跳转
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 点击申购
			async purchase(confirmation) {
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.value,
					id: confirmation,
					ganggan:this.ganggan
					// price: this.price
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: "Đang khớp lệnh, vui lòng chờ trong giây lát ...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
						});
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//
			async information() {
				let list = await this.$http.get('api/goods-shengou/detail', {
					id: this.id
				})
				// console.log(list.data.data);
				this.detailed = list.data.data.goods
				this.price = list.data.data
				this.title1 = list.data.data
				this.title2 = list.data.data
				this.title3 = list.data.data
				this.title4 = list.data.data
				// console.log(this.detailed, '详情');
			},
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
				// 应客户需求，改为固定杠杆1 /by 2024.06.06
				list.data.data.ganggan.splice(0, 1);
				// // console.log(list.data.data.ganggan);
				this.actions=list.data.data.ganggan;
				
			},
			
		},
		//传值过来接收
		onLoad(option) {
			this.id = option.id
			this.userInfo()
			// this.price = option.fa_price
		},
		// 进入页面就开始渲染
		mounted() {
			// uni.showLoading({
			// 	title: '加载中'
			// });
			this.information()
		},

	}
</script>

<style lang="scss">
	/deep/.u-input {
		background: #f5f5f5;
	}

	/deep/.u-modal__content__text {
		text-align: center;
	}
	page{
		background-color: #fff;
	}
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//深北沪
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//深
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #3b4fde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #3b4fde;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//北
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//沪
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束
	/deep/.u-text {
		flex-direction: column !important;
	}

	.college-bg {
		padding: 20px;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.company-name {
		margin-top: 20rpx;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;
		border-bottom: 1rpx dashed #ccc;
	}

	.issue {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx;
		font-size: 24rpx;

		view {
			width: 42%;
			display: flex;
			justify-content: space-between;
			align-items: center;

		}

		text {
			margin: 10rpx 0;
		}
	}

	.general {
		padding: 30rpx;
		font-size: 26rpx;

		h4 {
			font-size: 32rpx;
		}

		view {
			margin: 6rpx 0;
		}

		.front {
			color: #fff;
		}
	}

	.purchase {
		padding: 30rpx;
		font-size: 26rpx;
		border-radius: 30rpx 30rpx 0 0;
		color: #fff;

		h4 {
			font-size: 32rpx;
		}

		.apply {
			display: flex;
			justify-content: space-between;
			align-items: center;

			text {
				color: #121327;
				margin-left: 20rpx;
			}
		}

		input {
			background: #fff;
			display: block;
			margin: 30rpx 0;
			padding: 20rpx;
			border-radius: 10rpx;
			font-size: 28rpx;
			// color: #C0C4CC;

		}

		.purchases {
					background-image: linear-gradient(to right, #FFB044, #FF2D30);
			margin: 30rpx 0;
			border-radius: 10rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;
			font-size: 32rpx;
		}
	}

	.purchases {
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx 0;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 32rpx;
		margin: 30rpx;
	}
</style>