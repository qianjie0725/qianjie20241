<!-- 大宗交易记录 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Giao dịch thỏa thuận</view>
			<view class=""></view>
		</view>
		<view class="" v-for="(item,index) in list" :key="index">
			<view style="margin: 30rpx; word-wrap:break-word;color: #FFF;">
				<view class="display">
					<view class="">
						<view class="did-not">
							{{item.goods_info.name}}
							<text style="margin-right: 20rpx;">Đã mua</text>
							<block >X{{item.order_buy.double}}</block>
						</view>
				
					</view>
					<view class="display font-size-15" >
						<!-- <view class="" style="color: #FFF;">Chờ khớp lệnh</view> -->
						<view class="" style="color:#50a42e;" v-if="item.order_buy.admin_status==1">Đã khớp lệnh</view>
						<view class="" style="color:#f82672 ;" v-if="item.order_buy.admin_status==2">Hủy lệnh</view>
						<view class="" style="color: #FFF;" v-if="item.order_buy.admin_status==0">Chờ khớp lệnh</view>
					</view>
					
				</view>
				<u-divider></u-divider>
				<view class="" style="width: 100%;font-size: 14px;">
					<view class="display" >
						<view class="">Khối lượng đặt lệnh</view>
						<view class="red-mark" style="color: #FFF;width: 50%;justify-content: flex-end; display: flex;">{{toThousandFilter(item.order_buy.num)}}</view>
					</view>
					<view class="display">
						<view class="">Giá mua vào</view>
						<view class="red-mark" style="color: #dc353c;width: 50%;justify-content: flex-end; display: flex;">{{toThousandFilter(item.order_buy.price)}}</view>
						</view>
					<!-- <view class="display">
						<view class="">Giá TT-市场价</view>
						<view class="red-mark" style="color: #FFF;width: 50%;justify-content: flex-end; display: flex;">{{toThousandFilter(item.order_buy.amount)}}</view>
						</view> -->
					<view class="display">
						<view class="">Số tiền mua</view>
						<view class="red-mark" style="color: #FFF;width: 50%;justify-content: flex-end; display: flex;">{{toThousandFilter(item.order_buy.amount)}}</view>
						</view>
					<view class="display">
						<view class="">Thời gian mua vào</view>
						<view class="red-mark" style="color: #FFF;width: 50%;justify-content: flex-end; display: flex;">{{item.created_at}}</view>
						</view>
						
					</view>
				</view>
			
			<view style="height: 4rpx;width: 100%;background: #f5f5f5;"></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: '',
			};
		},
		methods: {
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async shengou(e) {
				let list = await this.$http.post('api/goods-bigbill/user-order-log', {
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//深北沪
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//深
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #3b4fde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #3b4fde;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//北
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//沪
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 40rpx ;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #121327;
		}
	}
</style>
