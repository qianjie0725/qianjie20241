<!-- 申购 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Đăng ký mua</view>
			<view class=""></view>
		</view>

		<view class="" v-for="(item,index) in list" :key="index">
			<view style="background-color: #442f84;font-size: 14px;" class="padding-10 margin-10">
				<view class="flex flex-b color-white ">
					<view>{{item.goods.name}}</view>
					<view style="color: #f6ab44;">{{item.message}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Giá mua</view>
					<view>{{toThousandFilter(item.price)}}</view>
				</view>
				
				
				<view class="flex flex-b color-white margin-top-10">
					<view>Margin (Đòn bẩy)</view>
					<view>{{item.ganggan}}</view>
				</view>
				
				<view class="flex flex-b color-white margin-top-10">
					<view>Khối lượng mua</view>
					<view>{{toThousandFilter(item.apply_amount)}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Số tiền mua</view>
					<view>{{toThousandFilter(item.apply_num_amount/item.ganggan) }}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Thời gian mua</view>
					<view>{{item.created_at}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Mã giao dịch</view>
					<view>{{item.order_sn}}</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: '',
			};
		},
		methods: {
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	

	.college-bg {
		padding: 40rpx;
		height: 80rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

</style>