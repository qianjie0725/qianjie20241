<template>
	<view>
		<!-- 头部选项卡 -->
		<view class="college-bg">
			<view class="flex">
				<!-- <image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image> -->
				<u-icon name="arrow-left" color="#fff" size="20" @tap="home()" class="icon"></u-icon>
				<view class="text-center bold flex justify-center"  style="width: 88%;">
					{{list[current].name}}
				</view>
			</view>

		</view>

		<!-- 内容 -->
		<view class="margin-top-20">
			<!-- <view v-if="current == 2">
				<zhaijuan :newShares_list2='newShares_list2' ></zhaijuan>
			</view> -->
			
			
			<view v-if="current == 2">
				<applyPurchase :newShares_list='newShares_list' ></applyPurchase>
			</view>
			
			<!-- <view v-if="current == 3">
				<newShareRaising></newShareRaising>
			</view> -->
			
			<view v-if="current == 1">
				<blockTrade></blockTrade>
			</view>
			
			<!-- <view v-if="current == 3">
				<newBondPlacement></newBondPlacement>
			</view> -->
			
			
			<view v-if="current == 0">
				<vipScramble></vipScramble>
			</view>
			
			<!-- <view v-if="current == 3">
				<subscriptionBonds></subscriptionBonds>
			</view> -->
		</view>
	</view>

	</view>
</template>

<script>
	import zhaijuan from "../../../../components/new-shares/zhaijuan.vue";
	import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import newShareRaising from "../../../../components/new-shares/newShareRaising.vue";
	// import subscriptionBonds from "../../../../components/new-shares/subscriptionBonds.vue";
	// import newBondPlacement from "../../../../components/new-shares/newBondPlacement.vue";
	import blockTrade from "../../../../components/new-shares/blockTrade.vue";
	import vipScramble from "../../../../components/new-shares/vipScramble.vue";
	export default {
		components: {
			zhaijuan,
			applyPurchase,
			newShareRaising,
			// subscriptionBonds,
			// newBondPlacement,
			blockTrade,
			vipScramble,

		},
		data() {
			return {
				current: 0,
				list: [
					{
						name: 'Giao dịch'
					},
					
					// {
					// 	name: 'Phân phối'
					// },
					// {
					// 	name: '新债申购',
					// },
					// {
					// 	name: "新债配售",
					// },
					{
						name: 'Quyền mua',
					},
					// {
					// 	name: 'Trái phiếu'
					// }, 
					{
						name: "OTC",
					},
				],
				newShares_list: "",
				newShares_list2: "",

			};
		},
		onLoad(option) {
			if(option.index){
				this.current=option.index
				// this.newShares()
				if(this.current==2){
					this.newShares()
				}
				// this.newShares2()
			}
		},
		
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			select(item) {
				this.current = item.index;
			},
			//新股申购
			async newShares() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 1,
				})
				this.newShares_list = list.data.data
			},
			async newShares2() {
				let list = await this.$http.post('api/goods-shengou/zhaijuan', {
					type: 2,
				})
				this.newShares_list2 = list.data.data
				// console.log(list.data.data, '待申购');
			},
		},

	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}


	.college-bg {
		padding: 40rpx;
		color: #cbcbcf;
		
	}
</style>