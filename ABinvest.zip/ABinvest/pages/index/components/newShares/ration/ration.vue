<!-- 配售记录 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Hồ sơ đặt hàng</view>
			<view class=""></view>
		</view>
		<view class="" v-for="(item,index) in placingRecords" :key="index">
			<view style="margin: 30rpx;">
				<view class="display">
					<view class="">
						<view class="did-not">
							{{item.goods.name}} <text>Đặt hàng thành công</text>
						</view>
						<view class="area" v-if="item.goods.locate=='深'">
							<view class="deep">{{item.goods.locate}}</view>
							<view class="deep-number">{{item.goods.code}}</view>
						</view>
						<view class="area" v-if="item.goods.locate=='北'">
							<view class="north">{{item.goods.locate}}</view>
							<view class="north-number">{{item.goods.code}}</view>
						</view>
						<view class="area" v-if="item.goods.locate=='沪'">
							<view class="shanghai">{{item.goods.locate}}</view>
							<view class="shanghai-number">{{item.goods.code}}</view>
						</view>
					</view>
					<view class="did-not">
						Giá cả <text>{{item.price}}</text>
					</view>
				</view>
				<u-divider></u-divider>
				<view class="display quantity">
					<view class="display">
						<view class="">Khối lượng</view>
						<view class="red-mark">{{item.apply_amount}}</view>
					</view>
					<view class="display">
						<view class="">Số tiền yêu cầu mua</view>
						<view class="red-mark">{{item.total}}</view>
					</view>
				</view>
				<view class="quantity">
					<view class="displays">
						<view class="">Thời gian mua hàng</view>
						<view class="order_sn">{{item.created_at}}</view>
					</view>
					<view class="displays">
						<view class="">Yêu cầu mua số</view>
						<view class="order_sn">{{item.order_sn}}</view>
					</view>

				</view>
			</view>
			<view style="height: 4rpx;width: 100%;background: #f5f5f5;"></view>
		</view>

		<view class="finished-text">
			Đã hết
		</view>





	</view>
</template>

<script>
	export default {
		data() {
			return {
				placingRecords: '',
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async placement() {
				let list = await this.$http.get('api/goodsscramble/userApplyLog', {})
				this.placingRecords = list.data.data
				// console.log(list.data.data[0], '抢筹');
			},
		},
		mounted() {
			this.placement()
		},
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//深北沪
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//深
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #3b4fde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #3b4fde;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//北
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//沪
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束
	// 没有更多
	.finished-text {
		color: #969799;
		font-size: 28rpx;
		margin: 30rpx auto;
		text-align: center;
		padding: 30rpx 0;
	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 28rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.displays {
			display: flex;
			// justify-content: space-between;
			align-items: center;
			margin: 20rpx 0;
		}

		.red-mark {
			color: #121327;
		}

		.order_sn {
			font-size: 28rpx;
			color: #b3b3b3;
			margin-left: 30rpx;
		}
	}
</style>
