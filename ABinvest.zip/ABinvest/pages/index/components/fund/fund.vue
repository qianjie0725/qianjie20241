<template>
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">ETF</view>
				<view class=""></view>
			</view>
		</view>

		<view class="flex align-center padding-5 margin-10"  style="border: 2px #ffb044 solid;border-radius: 30px;text-align: center;color:#fff;">
			<view class="flex-1" :class="0 === current ? 'active' : ''" @click="sectionChange(0)">Vốn</view>
				
			<view class="flex-1" :class="1 === current ? 'active' : ''" @click="sectionChange(1)">Đơn hàng</view>
		</view>
		
		<view style="margin-top: 10rpx;"></view>
		
		<view v-if="current==0">
			<!-- <view class="tile">Vốn tối ưu</view> -->
			<!-- <view class="boxk">Vốn tối ưu, thu nhập tốt hơn</view> -->
			<view class="stock-fund" v-for="(item,index) in list">
				<view class="information">
					<view class="help">
						<image src="/static/chuanggai/new-logo.png" mode=""></image>
						<view class="">{{item.name}}</view>
					</view>
					<!-- <view class="detailed">
						<view class="">详情</view>
						<image src="../../../../static/jiantou.png" mode=""></image>
					</view> -->
				</view>
				<view class="increase">
					<view class="help">
						<image src="../../../../static/jijin/zhang.png" mode=""></image>
						<view class=""> {{item.syl}}
							<!-- <text style="font-size: 24rpx;"> %</text> -->
						</view>
					</view>
					<view class="detailed" style="color: #000;">
						<view class="">{{item.zhouqi}} ngày</view>
					</view>
				</view>
				<view class="last">
					<view class="help">
						{{item.gz==1?'Nhận lãi hàng ngày':'Nhận lãi từ thứ hai đến thứ sáu'}}
					</view>
					<view class="detailed">
						{{toThousandFilter(item.min_price)}}
					</view>
				</view>
				<view class="wrap" style="margin-top: 20rpx;">
					<u-row justify="space-between" gutter="20">
						<!-- <u-col span="5.8">
							<u-button type="primary" :plain="true" @click="jieshao(index)">Gợi ý</u-button>
						</u-col> -->
						<u-col span="12">
							<u-button color="#ffb044" @click="buy(index)">Mua</u-button>
						</u-col>
					</u-row>
				</view>
			</view>
		</view>
		
		<view v-if="current==1">
			<view style="background-color: #442f84;font-size: 14px;" class="padding-10 margin-10" v-for="(item,index) in order_list">
				<view class="flex flex-b color-white ">
					<view>{{item.goodname}}</view>
					<view style="color: #f6ab44;">{{item.zhouqi+' ngày'}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Số tiền mua</view>
					<view style="color: #f6ab44;">{{toThousandFilter(item.price)}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Chu kì</view>
					<view style="color: #f6ab44;">{{item.zhouqi+' ngày'}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Thời gian đến hạn</view>
					<view style="color: #f6ab44;">{{item.endtime}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>ID giao dịch</view>
					<view style="color: #f6ab44;">{{item.ordersn}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Margin (Đòn bẩy)</view>
					<view style="color: #f6ab44;">{{item.ganggan}}</view>
				</view>
				<view class="flex flex-b color-white margin-top-10">
					<view>Lợi nhuận hiện tại</view>
					<view style="color: #f6ab44;">{{item.shouyi}}</view>
				</view>
				
				<view @click="sell(item.id)" v-if="item.status==1" class="text-center padding-5 margin-top-10 radius10" style="background-image: linear-gradient(to right, #FFB044, #FF2D30);">Bán</view>
			</view>
		
		</view>
		
		<u-modal :show="xiangqing_show" title="Chi tiết lợi nhuận"   :closeOnClickOverlay="true" :showConfirmButton="false" @close="xiangqing_show=false" @confirm="confirm"  @cancel="xiangqing_show=false" >
			<view class="slot-content" style="position: relative;width: 100%;">
				
				<view v-for="(item,index) in xq_list" >
					<u-cell :title="item.created_at" :value="'+'+item.shouyi" ></u-cell>
				</view>
			</view>
		
		</u-modal>
		
		<u-modal :show="show_js" :title="title" :content='content' :closeOnClickOverlay="true"
			:showConfirmButton="false" @close="show_js=false">
			<view class="slot-content">
				<rich-text :nodes="content"></rich-text>
			</view>
		</u-modal>


		<u-modal :show="show_buy" title="Mua" confirmText="Mua" cancelText="Huỷ bỏ" @confirm="confirm" :showCancelButton="true" @cancel="show_buy=false" >
			<view >

				<u-row justify="between" gutter="20">
					<u-col span="12" style="align-items: center;">
						<view>{{jijin_name}}</view>
					</u-col>
				</u-row>
				<u-row justify="between" gutter="50" style="margin-top: 20rpx;"  >
					<u-col span="12" style="align-items: center;">
						<u--form labelPosition="left" ref="uForm">
							<u-form-item label="Số tiền"  borderBottom >
								<u--input  border="none" :placeholder="toThousandFilter(goods_buy.min_price)" v-model="price"></u--input>
							</u-form-item>
							
							<!-- <u-form-item label="Bội số (đòn bẩy)"  borderBottom @click="show=true"> -->	
							<u-form-item label="Margin"  borderBottom >
								<u--input  border="none" disabled="" inputAlign='right' v-model="ganggan" ></u--input>
							</u-form-item>
							
						</u--form>
					</u-col>
				</u-row>
			</view>
			
			
		</u-modal>
		<u-action-sheet :show="show" :actions="actions" title="Bội số (đòn bẩy)" @close="show = false" @select="Select">
		</u-action-sheet>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ganggan:10,
				show:false,
				actions: [{
						name: '1',
						index: 1
					}
				],
				top_list: [{
						name: 'Vốn'
					},
					{
						name: 'Đơn hàng'
					}
				],
				current: 0,
				top_hg: 80,
				show_js: false,
				title: "",
				content: "",
				show_buy:false,
				list:[],
				jijin_name:'',
				goods_buy:[],
				price:'',
				order_list:[],
				xiangqing_show:false,
				xq_list:[]
			};
		},
		onShow() {
			this.getlist()
			this.userInfo()
		},
		methods: {
			async sell(id){
				uni.showModal({
					content:"Bạn có chắc chắn muốn bán không?",
					cancelText:"Hủy bỏ",
					confirmText:"Bán",
					success: (res) => {
						if(res.confirm) {  
							this._sell(id)
						} else {  
							console.log('cancel') //点击取消之后执行的代码
						}  
					} 
					
				})
				
			},
			async _sell(id){
				var list = await this.$http.get('api/jijin/sell',{
					id:id,
				})
				uni.hideLoading()
				if(list.data.code==1){
					
					uni.$u.toast(list.data.message);
				}else{
					uni.$u.toast(list.data.message);
					this.getlist()
				}
			},
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				if(list.data.code==1){
					uni.reLaunch({
						url:"/pages/logon/logon/logon"
					})
				}
				this.actions=list.data.data.ganggan
			},
			async xiangqing(id){
				
				var list = await this.$http.post('api/jijin/info',{
					id:id,
					
				})
				
				console.log(list)
				this.xq_list=list.data
				this.xiangqing_show=true
			},
			buy(index){
				this.jijin_name=this.list[index].name
				this.show_buy=true
				this.goods_buy=this.list[index]
			},
			jieshao(index){
				console.log(index);
				this.content=this.list[index].content
				this.show_js=true
			},
			confirm() {
				console.log(this.goods_buy);
				var price =this.price
				this.show_buy=false
				uni.showLoading({
					
				})
				if(!price||price==''){
					console.log(price);
					// uni.showToast({
					// 	icon:'none',
					// 	title:'请输入金额'
					// })
					uni.$u.toast('Vui lòng nhập số tiền');
				}
				
				
				this.buy_goods(price)
			},
			async buy_goods(price){
				
				var list = await this.$http.get('api/jijin/buy',{
					id:this.goods_buy.id,
					price:price,
					ganggan:this.ganggan
				})
				uni.hideLoading()
				if(list.data.code==1){
					this.show_buy=false
					uni.$u.toast(list.data.message);
				}else{
					uni.$u.toast("Giao dịch thành công ");
					this.getlist()
				}
				
			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("基金列表",list);
				this.list=list.data.jj_list
				this.order_list=list.data.order
			},
			sectionChange(index) {
				console.log(index)
				this.current = index;
				this.getlist
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			fundDetails() {
				uni.navigateTo({
					url: '/pages/index/components/fund/fundDetails'
				});
			}
			
		}
	}
</script>


<style lang="scss">

	.active {
		color: #000;
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		font-weight: bold;
		display: flex;
		justify-content: center;
		padding: 5px;
		border-radius: 30px;
	}
	
	.u-modal uni-view .u-modal__content{
		flex-direction: column !important;
	}
	.u-subsection--button {
		height: 90rpx;
	}
	.slot-content{
		flex-direction: column !important;
	}
	.u-subsection__bar .u-subsection--button__bar {
		height: 39px;
	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {
				// width: 97%;
				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}
	}

	.tile {
		color: #333;
		font-size: 32rpx;
		font-weight: 500;
		margin: 10rpx 20rpx;
		font-weight: 700;
	}

	.boxk {
		color: rgb(153, 153, 153);
		margin: 0px 20rpx;
		font-size: 24rpx;
	}

	.stock-fund {
		margin: 20rpx 20rpx;
		background-color: rgb(255, 255, 255);
		padding: 40rpx 20rpx;
		border-radius: 10rpx;
		color: #fff;
	}

	.information {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.help {
			display: flex;
			justify-content: space-between;
			align-items: center;
			color: #000;
			view {
				font-weight: bold;
			}

			image {
				width: 30rpx;
				height: 30rpx;
				margin-right: 10rpx;
			}
		}

		.detailed {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 15rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}
	}

	.increase {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx 0;

		.help {
			display: flex;
			justify-content: space-between;
			align-items: center;

			view {
				font-weight: bold;
				color: #09a592;
				font-size: 36rpx;
			}

			image {
				width: 36rpx;
				height: 36rpx;
				margin-right: 10rpx;
			}
		}

		.detailed {
			image {
				width: 15rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}
	}

	.last {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.help {
			color: #999999;
			font-size: 24rpx;
		}

		.detailed {
			color: #999999;
			font-size: 24rpx;
		}
	}
	uni-modal .uni-modal__title {
		font-size: 14px !important;
	}
</style>