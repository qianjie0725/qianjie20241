<template>
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">
					<view class="">汇添富基金有色50ETF</view>
					<view class="subheading">SZ159652</view>
				</view>
				<!-- 占位 -->
				<view class=""></view>
			</view>
		</view>

		<view class="net-worth">
			<view class="netValueOfFund">
				<view class="">0.964</view>
				<text>基金净值</text>
			</view>
			<view class="fallingAndRisingValue">
				<view class="">-0.01</view>
				<text>跌涨值</text>
			</view>
			<view class="decreaseAndIncrease">
				<view class="">-0.52%</view>
				<text>跌涨幅</text>
			</view>
		</view>

		<view class="risk">
			<view class="fx"> 中低风险 </view>
			<view class="mixed-type"> 混合型 </view>
		</view>
		<view class="thread"></view>
		<view class="assessment">
			<view class="value">实时估值</view>
			<view class="">0.964</view>
			<view class="">0.963</view>
			<view class="">0.962</view>
		</view>
		<view class="thread"></view>
		<view class="select">

			<u-tabs lineColor="#ee0a24" :list="list1" @click="Kline"></u-tabs>
			<view v-if="current == 0">
				<areaMap></areaMap>
			</view>
			<view v-if="current == 1">
				<kLine></kLine>
			</view>

		</view>
		<view class="fundMarket">
			<view class="inv-h-w">
				<block v-for="(item,index) in items" :key="index">
					<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="Inv=index">{{item}}</view>
				</block>
				<!--<view :class="['inv-h',Inv==1?'inv-h-se':'']" @click="Inv=1">我是选项卡二</view>-->
			</view>
			<view class="" v-show="Inv == 0">
				<view class="tab">
					<view>阶段日期</view>
					<view>涨幅</view>
					<view>同类平均</view>
					<view>同类排行</view>
				</view>
				<view class="">
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45514722</view>
						<view>498300</view>
					</view>
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45522</view>
						<view>498300</view>
					</view>
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45514ds722</view>
						<view>4900</view>
					</view>
				</view>
			</view>
			<view class="" v-show="Inv == 1">
				<view class="tab">
					<view>公告日期</view>
					<view>截止日期</view>
					<view>持有股票市值(元)</view>
					<view>持有股票数量(股) </view>
				</view>
				<view class="">
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45514722</view>
						<view>498300</view>
					</view>
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45522</view>
						<view>498300</view>
					</view>
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45514ds722</view>
						<view>4900</view>
					</view>
				</view>
			</view>
			<view class="" v-show="Inv == 2">
				<view class="tab">
					<view> 可分配收益(元) </view>
					<view> 收益分配金额(元) </view>
					<view> 红利再投资到账日 </view>
					<view> 份额基准年度 </view>
				</view>
				<view class="">
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45514722</view>
						<view>498300</view>
					</view>
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45522</view>
						<view>498300</view>
					</view>
					<view class="numerical-value">
						<view>20221228</view>
						<view class="green">20221226</view>
						<view class="red">45514ds722</view>
						<view>4900</view>
					</view>
				</view>

			</view>
			<view class="" v-show="Inv == 3">
				<view class="tab">
					<view> 基金代码 </view>
					<view> 交易日期 </view>
					<view> 复权因子 </view>
				</view>
				<view class="numerical-value">
					<view>159682.SZ</view>
					<view class="green">20221226</view>
					<view class="red">1</view>
				</view>
				<view class="numerical-value">
					<view>159682.SZ</view>
					<view class="green">20221226</view>
					<view class="red">1</view>

				</view>
				<view class="numerical-value">
					<view>159682.SZ</view>
					<view class="green">20221226</view>
					<view class="red">1</view>
				</view>
			</view>
		</view>

		<view class="thread"></view>
		<view class="scale">
			<view class="fund">基金规模</view>

			<view class="quantity">
				<view class="fund-code">
					<view>159682.SZ</view>
					<view>基金代码</view>
				</view>

				<view class="fund-code">
					<view>20230228</view>
					<view>交易(变动)日期</view>
				</view>

				<view class="fund-code">
					<view>209330.767</view>
					<view>基金份额(万)</view>
				</view>
			</view>
			<view class="fund-code">基金经理</view>
		</view>
		<view class="thread"></view>
		<view class="">
			<view class="transaction-rules">
				<view class="rule">交易规则</view>
				<view class="sell-out"> 买入、卖出规则
					<image src="../../../../static/jiantou.png" mode=""></image>
				</view>
			</view>
			<view class="">
				<u-steps current="2" dot>
					<u-steps-item title="买入" desc="今日15点前"></u-steps-item>
					<u-steps-item title="确定份额" desc="星期一"></u-steps-item>
					<u-steps-item title="查看盈亏" desc="净值更新后"></u-steps-item>
				</u-steps>
			</view>

			<view class="oddNumbered-days">
				单日累计购买上限1,000,000元
			</view>
		</view>


		<view class="occupy"></view>
		<view class="purchase">
			购买
		</view>




	</view>
</template>
<script>
	import areaMap from "../../../../components/areaMap/areaMap.vue";
	import kLine from "../../../../components/kLine/kLine.vue";
	export default {
		components: {
			areaMap,
			kLine
		},
		data() {
			return {
				Inv: 0,
				items: ['基金行情', '基金持仓', '基金分红', '复权因子'],

				current: 0,
				list1: [{
						name: '分时'
					},
					{
						name: '日线'
					}

				],
			}
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			Kline(item) {
				// console.log(item);
				this.current = item.index;
			},
			changeTab(Inv) {
				that.navIdx = Inv;
			},
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 80rpx 30rpx 0;
		height: 120rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {
				// width: 97%;
				color: #fff;
				font-weight: 600;
				font-size: 38rpx;

				.subheading {
					font-size: 26rpx;
					margin-top: 10rpx;
				}
			}
		}
	}

	.net-worth {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx;

		.netValueOfFund {
			view {
				font-weight: bold;
				color: rgb(236, 21, 39);
				font-size: 60rpx;
			}

			text {
				color: #999;
				font-size: 24rpx;
				margin-top: 10rpx;
			}
		}

		.fallingAndRisingValue {
			view {
				font-weight: bold;
				color: rgb(51, 51, 51);
				font-size: 30rpx;
			}

			text {
				color: #999;
				font-size: 24rpx;
				margin-top: 10rpx;
			}
		}

		.decreaseAndIncrease {
			view {
				font-weight: bold;
				color: rgb(236, 21, 39);
				font-size: 30rpx;
			}

			text {
				color: #999;
				font-size: 24rpx;
				margin-top: 10rpx;
			}
		}
	}

	.risk {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		margin: 30rpx;

		.fx {
			padding: 2rpx 10rpx;
			background: #d5e8ff;
			color: #1941d5;
			margin-right: 20rpx;
			border-radius: 10rpx;
		}

		.mixed-type {
			padding: 2rpx 10rpx;
			background: #f2f2f5;
			color: #999;
			border-radius: 10rpx;
		}
	}

	.thread {
		background: #e0e0e0;
		height: 1rpx;
	}

	.assessment {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx;
		color: #178802;

		.value {
			color: #000;
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		height: 100upx;
		display: flex;
	}

	.inv-h {
		font-size: 32upx;
		flex: 1;
		text-align: center;
		color: #666666;
		height: 100upx;
		line-height: 100upx;
		position: relative;
	}

	.inv-h-se {
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #ea6248;
	}

	.inv-h-se:after {
		content: '';
		position: absolute;
		bottom: -2rpx;
		top: auto;
		left: 42%;
		height: 6rpx;
		width: 44rpx;
		background-color: #ea6248;
	}

	.fundMarket {
		text-align: center;

		.tab {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 10rpx 30rpx;
			font-size: 26rpx;
			color: #999;

			view {
				width: 24%;
			}
		}

		.numerical-value {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 10rpx 30rpx;
			font-size: 26rpx;
			color: #000;

			view {
				width: 24%;
			}

			.green {
				color: #178802;
			}

			.red {
				color: #ec1527;
			}
		}
	}

	.scale {
		margin: 30rpx;

		.fund {
			font-size: 38rpx;
			color: rgb(51, 51, 51);
			font-weight: bold;
			margin-bottom: 0.1rem;
			padding-top: 0.1rem;
		}

		.quantity {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 20rpx 0;

			.fund-code {
				view:nth-child(1) {
					width: 100%;
					margin: 10rpx 0;
					font-size: 28rpx;
					font-weight: 700;
				}

				view:nth-child(2) {
					margin: 10rpx 0;
					font-size: 24rpx;
					color: #999;
				}
			}

		}
	}

	.transaction-rules {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 0 30rpx 30rpx;

		.sell-out {
			display: flex;
			// justify-items: flex-start;
			align-items: center;

			image {
				width: 10rpx;
				height: 20rpx;
				margin-left: 10rpx;
			}
		}
	}

	.oddNumbered-days {
		background-color: rgb(255, 229, 229);
		color: rgb(255, 62, 62);
		margin: 20rpx 30rpx;
		text-indent: 6px;
		padding: 2rpx 10rpx;
	}

	.occupy {
		padding: 20rpx;
		margin: 100rpx 0;
	}

	.purchase {
		width: 100%;
		text-align: center;
		background-color: rgb(238, 133, 50);
		color: rgb(255, 255, 255);
		position: fixed;
		bottom: 0px;
		padding: 30rpx 0;

	}
</style>
