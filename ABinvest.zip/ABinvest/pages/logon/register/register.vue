<template>
	<view>
		<view class="head-background">
			<view class="head-image" @tap="home()">
				<!-- <image class="" src="../../../static/zuojiantou.png" mode=""></image> -->
			</view>
		</view>
		<view class="logo">
			<image src="../../../static/chuanggai/logo.png" mode=""></image>
		</view>

		<view class="erty">

			<view class="input-field">
				<!-- <image src="../../../static/denglu/gengren.png" mode=""></image> -->
				<u-input type="text" placeholder='Họ và tên' v-model="nick_name">
				</u-input>
			</view>

			<view class="input-field">
				<!-- <image src="../../../static/denglu/gengren.png" mode=""></image> -->
				<u-input type="text" placeholder='Nhập địa chỉ Email' v-model="userMail">
				</u-input>
			</view>

			<view class="input-field">
				<!-- <image src="../../../static/denglu/gengren.png" mode=""></image> -->
				<u-input type="text" placeholder='Nhập mã Email' v-model="code">
				</u-input>
				<!-- <view
					style="width: 2px; text-align: center;background-color: #000;height: 30px;"
					@click="getCode"></view> -->
				<view
					style="width: 80px;color:#242424; text-align: center;padding: 6rpx;border-radius: 6rpx;background-color: rgba(0,0,0,0.05);"
					@click="getCode">{{getCodeLabel}}</view>
			</view>

			<view class="input-field">
				<!-- <image src="../../../static/denglu/gengren.png" mode=""></image> -->
				<u-input type="text" placeholder='Nhập số điện thoại' maxlength="10" v-model="value1">
				</u-input>
			</view>
			<view class="input-field">
				<!-- <image src="../../../static/denglu/suo.png" mode=""></image> -->
				<u-input type="text" placeholder='Nhập mật khẩu' v-model="value2" password></u-input>
			</view>
			<view class="input-field">
				<!-- <image src="../../../static/denglu/suo.png" mode=""></image> -->
				<u-input type="text" placeholder='Xác nhận lại mật khẩu ' v-model="value3" password></u-input>
			</view>
			<view class="input-field">
				<!-- <image src="../../../static/denglu/suo.png" mode=""></image> -->
				<u-input type="text" placeholder='Nhập mật khẩu giao dịch' v-model="payPassword" password></u-input>
			</view>
			<view class="input-field">
				<!-- <image src="../../../static/denglu/suo.png" mode=""></image> -->
				<u-input type="text" placeholder='Xác nhận lại mật khẩu giao dịch' v-model="payPasswordVerify"
					password></u-input>
			</view>

			<view class="input-field">
				<!-- <image src="../../../static/denglu/suo.png" mode=""></image> -->
				<u-input type="text" placeholder='Mã giới thiệu' v-model="value4"></u-input>
			</view>
		</view>


		<view style="display: flex;justify-content: space-between;">
			<view class="jump-registration" style="display: flex;">
				<u-checkbox-group v-model="checkboxValue1" placement="column">
					<u-checkbox activeColor="#ffb044" label="" name="Đọc và đồng ý" size='16' labelSize='12'>
					</u-checkbox>
				</u-checkbox-group>

				<text style="font-size: 22rpx;text-align: left;" @tap="agree()">
					Đọc và đồng ý với các điều khoản dịch vụ
				</text>
			</view>

			<view class="jump-registration" @tap="signIn()" style="font-size: 22rpx;">
				Đăng nhập
			</view>
		</view>

		<view class="signIn" @click="gain_register()">ĐĂNG KÝ</view>
		<view style="height: 100rpx;"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				userMail: '', // 邮箱
				code: '', // 验证码
				getCodeLabel: 'Nhận mã', // 获取验证码，以及倒计时
				timer: null, // 验证码倒计时	
				count: 180, // 从180倒计时

				payPassword: '', // 交易密码
				payPasswordVerify: '', // 二次输入交易密码				
				value1: '',
				value2: '',
				value3: '',
				value4: '',
				checkboxValue1: [],
			};
		},

		mounted() {
			console.log('child mounted', this.timer);
			this.login_liufu();
		},
		onHide() {
			this.clearTimer();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},

		methods: {
			// 校验邮箱
			checkEmail(val) {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				console.log(emailPattern.test(val));
				return emailPattern.test(val)
			},
			// 获取验证码
			async getCode() {
				// 邮箱验证不通过
				if (!this.checkEmail(this.userMail)) {
					uni.$u.toast('vui lòng nhập email của bạn');
					return false;
				}

				if (typeof(this.getCodeLabel) === 'number') return false;

				uni.showLoading({
					title: 'Lấy mã xác minh'
				})
				const result = await this.$http.post(`api/app/sendSmsCode`, {
					mobile: this.userMail,
				});
				console.log('result:', result);
				uni.hideLoading();
				if (result.data.code == 0) {
					uni.$u.toast('mã xác minh đã gửi');
					this.onSetTimeout();
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					if (this.count <= 180 && this.count > 0) {
						this.getCodeLabel = this.count;
						this.count--;
					} else {
						this.clearTimer(); // 倒计时结束
						this.getCodeLabel = 'Nhận mã';
						this.count = 180;
					}
					console.log(this.getCodeLabel);
				}, 1000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//注册
			async gain_register() {
				// 检测 设置交易密码与二次交易密码
				if (this.payPassword == '') {
					uni.$u.toast('Vui lòng nhập mật khẩu giao dịch');
					return false;
				}
				if (this.payPasswordVerify == '') {
					uni.$u.toast('Vui lòng nhập lại mật khẩu giao dịch');
					return false;
				}
				if (this.payPassword != this.payPasswordVerify) {
					uni.$u.toast('Mật khẩu giao dịch được nhập hai lần không nhất quán.');
					return false;
				}

				if (this.nick_name == '') {
					uni.$u.toast('Tên viết liền không dấu');
					return false;
				}

				if (this.userMail == '' || !this.checkEmail(this.userMail)) {
					uni.$u.toast('địa chỉ email');
					return false;
				}

				if (this.value1 == '') {
					uni.$u.toast('Xin mời điền số điện thoại');
				} else if (this.value2 == '') {
					uni.$u.toast('Xin mời điền mật khẩu');
				} else if (this.value3 == '') {
					uni.$u.toast('Xin mời điền mật khẩu');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('Hai lần mật khẩu không phù hợp');
				} else if (this.checkboxValue1.length == 0) {
					uni.$u.toast('Vui lòng đọc thỏa thuận sau khi đánh dấu');
				} else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1, // 手机号
						password: this.value2,
						confirmpass: this.value3,
						invite: this.value4,
						code: this.code,
						email: this.userMail,
						nick_name: this.nick_name,
						pay_pass: this.payPassword, // 支付密码
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('Đăng ký thành công');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/logon/logon/logon'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
	}
</script>

<style lang="scss">
	.head-background {
		background-image: url('../../../static/chuanggai/denglubeijing.png');
		width: 100%;
		height: 370rpx;
		background-size: 100%;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;

		.head-image {
			width: 20rpx;
			height: 20rpx;
			margin: 30rpx;

			image {
				width: 20rpx;
				height: 20rpx;
			}
		}
	}

	.logo {

		text-align: center;
		margin: auto;
		border-radius: 50%;
		margin-top: -80rpx;

		image {
			width: 200rpx;
			height: 200rpx;
			border-radius: 50%;
		}
	}

	.erty {
		text-align: center;
		margin: 50rpx 20rpx 0;

		.input-field {
			display: flex;
			align-items: center;
			background: #f5f5f5;
			border-radius: 10rpx;
			margin: 20rpx 20rpx;
			padding: 20rpx;

			image {
				width: 30rpx;
				height: 30rpx;
			}

			input {
				width: 100%;
				margin-left: 30rpx;
				text-align: left;
				font-size: 32rpx;
			}
		}
	}

	.jump-registration {
		color: #ffb044;
		text-align: right;
		margin: 0 40rpx;
	}

	.signIn {
		margin: 100rpx 30rpx 30rpx;
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		border-radius: 10rpx;
		color: #fff;
		font-weight: 800;
		font-size: 32rpx;
		text-align: center;
		padding: 20rpx;
	}
</style>