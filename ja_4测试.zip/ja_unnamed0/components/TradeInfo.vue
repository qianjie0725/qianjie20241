<!-- 个人交易 交易信息 -->
<template>
	<view style="padding:0 10px;">
		<view
			style="display: flex;align-items: center;justify-content: space-between;padding:0 10px 10px 10px;border-bottom: 1px solid rgba(0,143,254,0.1);">
			<view style="font-size: 24px;font-weight: 700;" :style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(info.money,2)}}
			</view>
			<view class="common_btn btn_primary" style="width: 20%;padding:6rpx 12rpx;" @click="handleDeposit">
				{{$lang.DEPOSIT}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
			<view :style="{color:$util.THEME.LABEL}"> {{$lang.TOTAL_BUY_AMOUNT}} </view>
			<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;"> {{$util.formatNumber(info.frozen)}}
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
			<view :style="{color:$util.THEME.LABEL}"> {{$lang.VALUATION_GAIN_LOSS}} </view>
			<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;">
				{{$util.formatNumber(info.holdYingli,2)}}
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
			<view :style="{color:$util.THEME.LABEL}"> {{$lang.VALUATION_GAIN_LOSS_AMOUNT}} </view>
			<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;"> {{$util.formatNumber(info.guzhi)}}
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
			<view :style="{color:$util.THEME.LABEL}"> {{$lang.RATE_RESPONSE}} </view>
			<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;">
				{{$util.formatNumber(info.huibao,2)}}%
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
			<view :style="{color:$util.THEME.LABEL}"> {{$lang.AMOUNT_TOTAL}} </view>
			<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;">
				{{$util.formatNumber(info.totalZichan,2)}}
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
			<view :style="{color:$util.THEME.LABEL}"> {{$lang.TOTAL_GAIN}} </view>
			<view :style="$util.calcStyleRiseFall(info.totalYingli>0)" style="font-size: 32rpx;">
				{{$util.formatNumber(info.totalYingli,2)}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		data() {
			return {
				info: {},
			};
		},
		mounted() {
			this.getUserInfo()
		},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})

				if (result.data.code == 0) {
					this.info = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>