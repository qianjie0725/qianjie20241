<template>
	<view style="padding: 40rpx;text-align: center;">
		<image :src="`/static/empty_${img}.png`" mode="aspectFit" :style="$util.setImageSize(400)"></image>
		<view style="font-size: 32rpx;" :style="{color:color}">データなし</view>
	</view>
</template>

<script>
	export default {
		name: "EmptyData",
		props: {
			color: {
				type: String,
				default: '#333333',
			},
			// 空数据时，显示的图片
			img: {
				type: String,
				default: 'data'
			},
		},
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>