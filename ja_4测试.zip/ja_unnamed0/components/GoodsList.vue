<template>
	<view style="padding:0 10px 6px 10px;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="padding:10px;border-bottom: 1px solid #F1F1F1;" @click="link(item.code)">
					<view style="font-size: 32rpx;color: #121212;">{{item.name}}</view>

					<view style="display: flex;align-items: center;margin-top: 20rpx;">
						<view style="font-size: 24rpx;color: #333333;flex:1 0 10%">{{item.code}}</view>
						<view
							style="font-size: 28rpx;color: #333333;flex:1 0 60%;text-align:right;padding-right: 30rpx;">
							{{$util.formatNumber(item.close,2)}}
						</view>
						<view :style="$util.calcStyleRiseFall(item.returns>0)"
							style="margin-left: auto;padding-right: 10rpx;">
							{{($util.formatNumber(Math.abs(item.returns),2))}}%
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
			this.sockets()
		},
		onHide() {
			clearInterval(this.timer);
			uni.closeSocket({
				success: () => {},
			})
		},

		onUnload() {
			uni.$off('onSuccess');
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {},
			})
		},
		methods: {
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that = this;
				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data = JSON.parse(res.data);
					// console.log(data);

					this.list.forEach(item => {
						if (item.stock_id === data.pid) {
							item.close = data.last;
							let rate = data.pcp.replace("+", '')
							rate = rate.replace("%", '')

							item.returns = rate;

							// item.rate_num = data.pc;
						}
					});
					// console.log(data.pid);
					// that.quotation[data.market].price=data.lastPrice
					// that.quotation[data.market].rate=data.rate
				});
			},
			link(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {
				let list = await this.$http.post('api/goods/top2', {
					current: 0,
					limit: 50
				})
				this.list = list.data.data
			},
		}
	}
</script>