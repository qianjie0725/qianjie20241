<template>
	<view class="btns">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.calcImageSize(40)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		data() {
			return {};
		},
		computed: {
			// 主页功能按钮组配置
			btns() {
				return [{
					name: 'EA',
					icon: 'top1',
					url: "/pages/trade/ea",
				}, {
					name: 'お気に入り',
					icon: 'top2',
					url: '/pages/stock/bookmark',
				}, {
					name: '大口・OTC',
					icon: 'top3',
					url: `/pages/trade/large`, // 大宗交易
				}, {
					name: 'IPO',
					icon: 'top4',
					url: `/pages/trade/ipo`, // ipo交易
				}, {
					name: '記録',
					icon: 'top8',
					url: `/pages/account/tradeLog`, // 账户交易记录
				}, {
					name: '出金',
					icon: 'top5',
					url: `/pages/account/withdraw`,
				}, {
					name: '入金',
					icon: 'top6',
					url: `/pages/account/deposit`,
				}, {
					name: '本人認証',
					icon: 'top7',
					url: `/pages/account/auth`, // 认证
				}];
			}
		},

		methods: {
			actionEvent(url, index) {
				if (url.includes('pages')) {
					if (url == "/pages/stock/bookmark") {
						uni.switchTab({
							url: url
						})
					} else {
						uni.navigateTo({
							url: url
						})
					}

				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>