<template>
	<view style="padding: 10px;background-color: #FFFFFF;margin:20rpx;min-height: 100vh;">
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
				<!-- <TradeStockItem :item="item" @action="handleDetail"></TradeStockItem> -->
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
					<view style="flex:80%;">
						<view style="padding-left: 10px;font-size: 28rpx;color:#121212;">
							{{item.goodname}}
						</view>
					</view>

					<template v-if="item.status==1">
						<view class="access_btn" @click="handleDetail(item.id)"
							style="padding:6rpx 24rpx;margin:0;font-size: 28rpx;line-height: 1.4;">
							売る
						</view>
					</template>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>購入金額</view>
					<view style="color:#121212;">{{$util.formatNumber(item.price,2)}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>サイクル</view>
					<view style="color:#121212;">{{item.fudu+` %`}} </view>
					<view>期間</view>
					<view style="color:#121212;">{{item.zhouqi+` Day`}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>取引ID</view>
					<view style="color:#121212;">{{item.ordersn}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>マージン</view>
					<view style="color:#121212;">{{item.ganggan}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>リターン</view>
					<view style="color:#121212;">{{item.fudul*1+` %`}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>開始時間</view>
					<view style="color:#121212;">{{item.cretime}} </view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color:#8f8f8f;">
					<view>終了時間</view>
					<view style="color:#121212;">{{item.endtime}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'EaOrder',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},

		methods: {
			async handleDetail(id) {
				const result = await uni.showModal({
					title: '',
					content: `本当に販売しますか？`,
					cancelText: 'キャンセル',
					confirmText: '確認する',
					confirmColor: this.$util.THEME.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.handleSell(id);
				}
			},
			async handleSell(id) {
				const result = await this.$http.post(`api/jijin/buy`, {
					id
				});
				if (result.code == 0) {
					// this.getData()
					uni.$u.toast(result.message);
				} else {
					uni.$u.toast(result.message);
				}
				this.getList();
			},

			async getList() {
				this.list = []; // 请求前清除数据。
				const result = await this.$http.get(`api/jijin/list`);
				const temp = !result || !result.order || result.order.length <= 0 ? [] : result.order;
				this.list = !temp || temp.length <= 0 ? [] : temp;
			}
		}
	}
</script>

<style>
</style>