<template>
	<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: center; line-height: 3;">
		<view style="background-color: #03b7f2;width: 10rpx;height: 10rpx;border-radius: 100%;margin-right: 30rpx;"></view>
		<view style="font-size: 30rpx;font-weight: 800;" :style="{color:color}">
			{{title}}
		</view>
		<view style="background-color: #03b7f2;width: 10rpx;height: 10rpx;border-radius: 100%;margin-left: 30rpx;"></view>
	</view>
</template>

<script>
	export default {
		name: 'TitleSecond',
		props: {
			title: {
				type: String,
				default: ''
			},
			color: {
				type: String,
				default: '#121212',
			}
		},
	}
</script>

<style>
</style>