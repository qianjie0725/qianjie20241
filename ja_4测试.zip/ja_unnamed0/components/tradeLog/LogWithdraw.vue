<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:0;font-size: 14px;border-bottom: 1px solid #CFCFCF;padding:16rpx">
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view style="margin-left: auto;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">出金</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money,2)}}
					</view>
				</view>


				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">注文 番号:</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">日時:</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">拒否理由:</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)" style="padding-right: 20rpx;"></image>
					</view>
					<view style="flex:97%;" :style="{color:item.color}">{{item.text}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<u-button text="キャンセル" type="error" @click="handleCancel(item.id)" v-if="item.status==0"></u-button>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			handleCancel(id) {
				uni.showModal({
					title: "本当に引き出しをキャンセルしますか?",
					cancelText: "キャンセル",
					confirmText: "確認",
					success: function(res) {
						if (res.confirm) {
							console.log(this);
							this.qx_post(id);
						} else if (res.cancel) {
							console.log('ユーザーはキャンセルをクリックします。');
						}
					}
				})
			},
			async qx_post(id) {
				uni.showLoading({
					title: '処理',
				})
				const result = await this.$http.post(this.$http.API_URL.APP_QX, {
					id: id
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_WITHDRAW, {})
				console.log(result.data.data);
				if (result.data.code == 0) {
					result.data.data.forEach((item, index) => {
						this.list.push({
							...item,
							...this.$util.TRADE_LOG_STATUS[item.status]
						})
					});
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>