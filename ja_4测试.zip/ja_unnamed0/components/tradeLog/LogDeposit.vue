<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:0;font-size: 14px;border-bottom: 1px solid #CFCFCF;padding:16rpx">
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view style="margin-left: auto;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">出金</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money,2)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">注文 番号:</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">日時：</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">拒否理由:</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)" style="padding-right: 20rpx;"></image>
					</view>
					<view style="flex:97%;" :style="{color:item.color}">{{item.text}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogDeposit",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_DEPOSIT, {})
				if (result.data.code == 0) {
					this.list = result.data.data
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>