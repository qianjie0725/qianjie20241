<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:0;font-size: 14px;border-bottom: 1px solid #CFCFCF;padding:16rpx">
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">残高</view>
					<view style="font-size: 18px;font-weight: 700;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(item.after,2)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">取引前の残高:</view>
					<view :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.before,2)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">入金：</view>
					<view :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.desc)}}円
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
					<view :style="{color:$util.THEME.LABEL}">日時:</view>
					<view :style="{color:$util.THEME.LABEL}">
						{{item.created_at}}
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FINANCE, {})
				if (result.data.code == 0) {
					this.list = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>