<template>
	<view style="display: flex;flex-wrap: wrap;justify-content: space-between;margin: 10rpx 20rpx;">
		<block v-for="(item,index) in list" :key="index">
			<view style="width: 49%;">
				<view
					style="display: flex;align-items: center;margin:10rpx;padding:20rpx 30rpx;border-radius: 8rpx;border: 1px solid #01B4D5;"
					@click="actionEvent(item,index)">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize (60)"></image>
					<text style="font-size: 28rpx;color:  #121212;padding-left: 20rpx;">{{item.name}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: {
			code: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {};
		},

		computed: {
			// 功能列表
			list() {
				const AUTH_LIST = ['確認済み[認証されていません]',
					'確認済み[レビュー中]', '確認済み[監査失敗]'
				];

				const temp = AUTH_LIST.map((item, index) => {
					return {
						name: item,
						url: `/pages/account/auth`,
						icon: 'authentication',
						code: index == 0 ? -1 : index == 1 ? 0 : 2,
						mode: 'link',
					}
				}).filter(item => item.code == this.code);
				console.log(temp);

				return [...temp, {
					name: 'ログインパスワードの変更',
					url: `/pages/account/pwd`,
					icon: 'signin_pwd',
					mode: 'link',
				}, {
					name: '決済パスワードの変更',
					url: `/pages/account/pwdPay`,
					icon: 'pay_pwd',
					mode: 'link',
				}, {
					name: '入出金口座連動',
					url: `/pages/account/bankCard`,
					icon: 'bank_card',
					mode: 'link',
				}, {
					name: '記録',
					url: `/pages/account/tradeLog`,
					icon: 'capital_deatil',
					mode: 'link',
				}, {
					name: 'サイン終了',
					url: '',
					icon: 'sign_out',
					mode: 'signout'
				}];
			}
		},
		methods: {
			actionEvent(item, index) {
				if (item.mode == 'signout') {
					this.handleSignOut();
				} else if (item.mode == 'link') {
					uni.navigateTo({
						url: item.url,
					})
				} else {
					this.$emit('action', item);
				}
			},
			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('正常終了');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>

<style>

</style>