<!-- 包含返回和标题的自定义Header -->
<template>
	<view class="common_header">
		<view class="custom_header_left" @click="actionEvent()">
			<view class="arrow rotate_225" :style="$util.calcImageSize(10)"></view>
		</view>
		<text class="custom_header_center">{{title}}</text>
		<view class="custom_header_right"></view>
	</view>
</template>

<script>
	export default {
		name: "CustomHeader",
		props: ["title"],
		data() {
			return {};
		},
		methods: {
			actionEvent() {
				uni.navigateBack({
					delta:1
				})
				this.$emit('action', '');
			}
		}
	}
</script>