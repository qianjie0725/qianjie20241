<template>
	<!-- <view style="width: 98%;padding: 0px 10px;margin-bottom: 10rpx;">
		<block v-for="(item,index) in tabs" :key="index">
			<view @click="handleChange(index)"
				style="display: inline-block; width:max-content;padding:8rpx 32rpx;margin:0 20rpx;text-align: center;font-size: 32rpx;border-radius: 12rpx;"
				:style="setStyle(acitve ==index)">
				{{item}}
			</view>
		</block>
	</view> -->
	<view style="display: flex;align-items: center;justify-content: space-between;">
		<block v-for="(item,index) in tabs" :key='index'>
			<view @click="handleChange(index)"
				style="padding: 4px 10px; width: 25%;text-align: center;border-radius: 2rpx;font-size: 28rpx;line-height: 1.8;"
				:style="setStyle(acitve ==index)">{{item}}</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "TabsFourth",
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 自定义颜色
			color: {
				type: String,
				default: '#333333',
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		methods: {
			// 样式设置
			setStyle(val) {
				return {
					color: val ? '#008FFE' : 'rgb(1, 180, 213)',
					backgroundColor: val ? 'rgba(0,143,254,0.1)' : '#FFFFFF',
					// border: `1px solid #008FFE`
				}

				// return {
				// 	backgroundColor: val ? this.$theme.PRIMARY : '#F1F1F1',
				// 	color: val ? '#FFF' : this.color,
				// }
			},
			handleChange(val) {
				console.log(val);
				this.current = val;
				this.$emit('action', this.current);
			},
		}
	}
</script>

<style>

</style>