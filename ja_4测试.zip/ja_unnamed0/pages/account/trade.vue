<template>
	<view :style="$util.setBGSize(`680rpx`)">
		<!-- <view class="header_wrapper" style="margin-bottom: 20px;"> -->
		<Header></Header>
		<!-- </view> -->

		<view
			style="margin: 30rpx;margin-top: 1vh;padding:40rpx 20rpx; background-color: rgba(255,255,255,0.85);border-radius: 16rpx;">
			<TradeInfo></TradeInfo>
		</view>



		<view class="common_page_fg">
			<view style="margin:16rpx;">
				<view
					style="display: flex;align-items: center;justify-content:space-between;font-size: 16px;padding: 10px;font-weight: 700;">
					<image mode="aspectFit" src="/static/refresh.png" :style="$util.calcImageSize(20)"
						@click="handleRefresh()">
						<view :style="{color:isHold? $util.THEME.PRIMARY:$util.THEME.TEXT}"
							@click="handleChangeList(0)">
							{{$lang.STOCK_HOLD_STATUS}}
						</view>
						<view :style="{color:!isHold? $util.THEME.PRIMARY:$util.THEME.TEXT}"
							@click="handleChangeList(1)">
							{{$lang.STOCK_SALES_HISTORY}}
						</view>
					</image>
				</view>

				<view style="display: flex;align-items: center;" :style="{color:$util.THEME.LABEL}">
					<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding:2px;height: 38px;">
						<view>株式</view>
						<view></view>
					</view>
					<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding: 2px;">
						<view> 評価損</view>
						<view> 収益率 </view>
					</view>
					<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding: 2px;">
						<view> 残高数量</view>
						<view> 評価額 </view>
					</view>
					<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding: 2px;">
						<view> 購入価格</view>
						<view> 現在価格 </view>
					</view>
				</view>

				<view>
					<block v-for="(item,index) in list" :key="index">
						<view @tap="handleShowModal(item)"
							style="display: flex;align-items: center;padding:10px 0;border-bottom: 1px solid #ccc;">
							<view style="flex:25%;">
								<view :style="{color:$util.THEME.LABEL}"> {{item.goods_info.name}}</view>
								<!-- <view :style="{color:$util.THEME.TEXT}"> {{item.goods_info.number_code}}</view> -->
							</view>
							<view style="flex:25%;text-align: right;">
								<template v-if="isHold">
									<view :style="$util.calcStyleRiseFall(item.order_buy.float_yingkui>0)">
										{{$util.formatNumber(item.order_buy.yingkui,2)}}
									</view>
									<view :style="{color:$util.THEME.TEXT}" class="margin-top-10">
										{{$util.formatNumber((item.order_buy.yingkui/item.order_buy.user_pay/item.order_buy.double*100),2)}}%
									</view>
								</template>
								<template v-else>
									<view :style="$util.calcStyleRiseFall(item.order_sell.yingkui>0)">
										{{$util.formatNumber(item.order_sell.yingkui,2)}}
									</view>
									<view :style="{color:$util.THEME.TEXT}" class="margin-top-10">
										{{$util.formatNumber((item.order_sell.yingkui/item.order_buy.user_pay/item.order_buy.double*100),2)}}%
									</view>
								</template>
							</view>
							<view style="flex:25%;text-align: right;" :style="{color:$util.THEME.TEXT}">
								<view> {{$util.formatNumber(item.order_buy.num)}}</view>
								<!-- <view>{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}</view> -->
								<template v-if="isHold">
									<view>
										{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num,2)}}
									</view>
								</template>
								<template v-else>
									<template v-if="item.order_sell">
										<view class="margin-top-10">
											{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num,2)}}
										</view>
									</template>
								</template>
							</view>
							<view style="flex:25%;text-align: right;">
								<view :style="{color:$util.THEME.TEXT}">{{$util.formatNumber(item.order_buy.price,2)}}
								</view>
								<view :style="{color:$util.THEME.TEXT}" class="margin-top-10">
									{{$util.formatNumber((isHold? item.goods_info.current_price:item.order_sell.price,2))}}
								</view>
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" :style="{backgroundColor:$util.THEME.PRIMARY}" style="margin: 0;">
						<text style="text-align: center;font-size: 16px;color:#FFF;">詳細</text>
						<image src="/static/close.png" :style="$util.calcImageSize(24)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.STOCK_NAME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.goods_info.name}}</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_DATETIME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.created_at}}</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.SELL_DATETIME}}</view>
							<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.CURRENT_PROFIT_LOSS}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.float_yingkui:info.order_sell.float_yingkui)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.LEVER}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.double}}</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.TOTAL_PROFIT_LOSS_AMOUNT}}
						</view>

						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui:info.order_sell.yingkui)}}
						</view>

						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_PRICE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_NUM}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.FEE_BUY_SELL}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:info.order_sell.sell_fee)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_TOTAL_AMOUNT}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.CODE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view
						style="border-radius: 0 0 20px 20px;display: flex;align-items: center;justify-content: space-around;padding-top: 20px;margin-bottom: 20px;"
						v-if="isHold">
						<view class="common_btn btn_primary" style="width: 40%;"
							@tap="handleStockDetail(info.goods_info.number_code,info.goods_info.id)">
							{{$lang.STOCK_DETAIL}}
						</view>
						<view class="common_btn btn_secondary" style="width: 40%;" @tap="handleSell(info.id)">
							{{$lang.STOCK_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	export default {
		components: {
			Header,
			TradeInfo,
		},
		data() {
			return {
				isHold: true, // 是否是持股状态，否则为销售历史
				list: [],
				isSelf: true, // 国内，false:海外
				info: {},
				isShow: false, // 买卖弹出
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.curPage = 1; // 从第一页重新开始
			this.list = []; // 清空所有翻页后内中数据
			this.handleRefresh()
			uni.stopPullDownRefresh()
		},
		//监听页面触底函数
		onReachBottom() {
			// 如果触底，并且当前页码<最大页码
			console.log(this.curPage, this.maxPage);
			if (!this.flag) {
				if (this.curPage < this.maxPage) {
					this.curPage++;
					console.log('page:', this.curPage);
					this.getList()
				}
				if (this.curPage >= this.maxPage) {
					return false;
				}
			}
		},
		onShow() {
			this.handleRefresh()
			this.sockets()
		},

		onUnload() {
			console.log('ポジションが終了しました');
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {},
			})
		},
		onHide() {
			console.log('ポジションが終了しました');
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {},
			})
		},
		methods: {
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that = this;
				// console.log(this.list.goods_info);

				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data = JSON.parse(res.data);
					// console.log(data);


					this.list.forEach(item => {
						if (item.goods_info.stock_id === data.pid) {
							// console.log(this.list);
							// console.log(data);
							let current_price = data.last.replace(",", '')
							item.goods_info.current_price = current_price;
							// let rate=data.pcp.replace("+",'')
							// rate=rate.replace("%",'')

							// item.returns = rate;

							// item.rate_num = data.pc;
						}
					});
				});
			},
			handleChangeList(val) {
				this.isHold = val == 0;
				this.handleRefresh();
			},
			handleChangeLocation(val) {
				this.isSelf = val == 0;
				this.handleRefresh();
			},

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			handleRefresh() {
				uni.showLoading({
					mask: true
				})
				this.curPage = 1; // 从第一页重新开始
				this.list = []; // 清空所有翻页后内中数据
				this.getList();
			},
			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.STOCK_SELL_TIP,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							console.log(_this);
							uni.hideLoading();
							_this.confirmSell(id);
						} else if (res.cancel) {
							console.log('ユーザーはキャンセルをクリックします。');
						}
					}
				})
			},
			// //定时器
			// startTimer() {
			// 	const storedTimerId = uni.getStorageSync('timerId');
			// 	if (storedTimerId) {
			// 		clearInterval(storedTimerId);
			// 	}
			// 	this.timerId = setInterval(() => {
			// 		console.log('위치요청');
			// 		this.handleRefresh()
			// 		this.gaint_info()
			// 	}, 8000);
			// 	uni.setStorageSync('timerId', this.timerId);
			// },
			// 平仓功能
			async confirmSell(id) {
				uni.showLoading({
					title: this.$lang.TIP_SELLING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.USER_SELL, {
					id
				})
				if (result.data.code == 0) {
					this.handleRefresh()
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				}
			},

			handleStockDetail(code, id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`
				});
			},

			async getList() {
				this.flag = true;
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`${this.$http.API_URL.USER_ORDER}`, {
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
					page: this.curPage
				})
				this.flag = false;
				if (result.data.code == 0) {
					// this.list.push(...result.data.data.data);
					this.list = result.data.data.data;
					this.maxPage = result.data.data.last_page; // 最大页码
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>