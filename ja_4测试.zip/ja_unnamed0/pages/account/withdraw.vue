<!-- 실시간 이체 -->
<template>
	<view :style="$util.setBGSize(`480rpx`)">
		<!-- <view class="header_wrapper" style="margin-bottom: 20px;"> -->
		<CustomHeader :title="$lang.WITHDRAW" ></CustomHeader>
		<!-- </view> -->
		<view class="common_page_fg">
			<!-- <view class="common_block" style="padding:20px"> -->
			<!-- <view style="text-align:center;font-size: 16px;" :style="{color:$util.THEME.TIP}"> 실시간이체 </view> -->
			<view style="font-size: 32px;font-weight: 700;text-align: center;margin-top: 10px;"
				:style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(userInfo.money,2)}}
			</view>

			<view style="text-align: center;margin-top: 10px;" :style="{color:$util.THEME.TIP}">
				{{$lang.TIP_AMOUNT_AVAIL}}
			</view>

			<view style="width: 86%;margin:60rpx auto;">
				<view class="common_input_wrapper" style="padding-right: 20rpx;padding-left: 40rpx;">
					<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"></input>
					<view @click="handleAllAmount(userInfo.money)" class="btn_small" style="margin-left: auto;">
						{{$lang.TIP_AMOUNT_ALL}}
					</view>
				</view>

				<view class="common_input_wrapper" style="padding-left: 40rpx;margin-top: 40rpx;">
					<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"></input>
				</view>

				<view class="common_btn btn_primary" style="margin:auto;margin-top: 40rpx;" @click="handleWithdraw()">
					{{$lang.WITHDRAW}}{{$lang.CONFIRM}}
				</view>
			</view>

			<view style="padding: 20px;" :style="{color:$util.THEME.TIP}">
				<block v-for="(item,index) in $util.TIP_WITHDRAW_CONDITION">
					<view style="padding-bottom: 6px;" :style="{color:index!==4?$util.THEME.LABEL:$util.THEME.TIP}">
						{{item}}
					</view>
				</block>
			</view>
			<!-- </view> -->
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleAllAmount(val) {
				this.amount = val
			},
			async handleWithdraw() {
				uni.showLoading({
					title: this.$lang.TIP_WITHDRAWING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.APP_WITHDRAW, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>