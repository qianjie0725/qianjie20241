<template>
	<view :style="$util.setBGSize(`100%`)">
		<CustomHeader title="ログインパスワードの変更" ></CustomHeader>
		<view class="common_page_fg">
			<view style="padding-top:3vh;margin:0 32rpx;">

				<TitleSecond :title="$lang.OLD_PWD" color="#121212"></TitleSecond>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
					</image>
					<input v-model="value" type="password" :placeholder="$lang.OLD_PWD"></input>
				</view>

				<TitleSecond :title="$lang.NEW_PWD" color="#121212"></TitleSecond>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
					</image>
					<input v-model="value2" type="password" :placeholder="$lang.NEW_PWD"></input>
				</view>

				<TitleSecond :title="$lang.NEW_PWD2" color="#121212"></TitleSecond>
				<view class="common_input_wrapper" style="margin-bottom: 60rpx;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
					</image>
					<input v-model="value3" type="password" :placeholder="$lang.NEW_PWD2"></input>
				</view>

				<view class="common_btn btn_primary" style="margin: auto;margin-top: 20px;" @click="changePassword">確認
				</view>

			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TitleSecond from '@/components/TitleSecond.vue';
	export default {
		components: {
			CustomHeader,
			TitleSecond,
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(this.$http.API_URL.SIGNIN_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('修正されました.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>