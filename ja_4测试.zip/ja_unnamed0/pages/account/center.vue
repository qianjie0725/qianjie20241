<template>
	<view :style="$util.setBGSize(`100%`)">
		<Header></Header>

		<view
			style="margin: 30rpx;margin-top: 3vh;padding:40rpx 20rpx; background-color: rgba(255,255,255,0.75);border-radius: 16rpx;">
			<Profile :info="userInfo"></Profile>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;margin: 30rpx;padding:20rpx; ">
			<view class="common_btn btn_secondary" style="width: 40%;" @click="linkDeposit()">
				{{$lang.DEPOSIT}}
			</view>
			<view class="common_btn btn_primary" style="width: 40%;" @click="linkWithDraw()">
				{{$lang.WITHDRAW}}</view>
		</view>

		<view class="common_page_fg">
			<NavList :code="userInfo.is_check"> </NavList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	export default {
		components: {
			Header,
			Profile,
			NavList,
		},
		data() {
			return {
				userInfo: {}, // 基本信息
			}
		},
		onShow() {
			this.gaint_info()
			this.is_token()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},
		methods: {
			linkDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				})
			},
			// 提款
			linkWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},

			//用户信息
			async gaint_info() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
					// language: this.$i18n.locale
				})
				this.userInfo = result.data.data;
				// this.cardManagement = result.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},


	}
</script>