<template>
	<view :style="$util.setBGSize(`100%`)">
		<!-- <view class="header_wrapper"> -->
		<CustomHeader :title="$lang.TRADE_LOG"></CustomHeader>
		<!-- </view> -->
		<view class="common_page_fg">
			<view style="margin:auto;width: 90%;">
				<TabsFourth :tabs="$util.BTNS_TRADE_LOG" @action="changeTab" :acitve="curTab"></TabsFourth>
				<view style="min-height: 66vh;margin-top: 10px;">
					<template v-if="curTab == 0">
						<LogTrade></LogTrade>
					</template>

					<template v-if="curTab == 1">
						<LogDeposit></LogDeposit>
					</template>

					<template v-if="curTab == 2">
						<LogWithdraw></LogWithdraw>
					</template>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TabsFourth from '@/components/TabsFourth.vue';
	import LogTrade from '@/components/tradeLog/LogTrade.vue';
	import LogDeposit from '@/components/tradeLog/LogDeposit.vue';
	import LogWithdraw from '@/components/tradeLog/LogWithdraw.vue';
	export default {
		components: {
			CustomHeader,
			TabsFourth,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				curTab: 0,
			};
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		methods: {
			changeTab(val) {
				clearInterval(this.timer);
				this.curTab = val;
			},
		},
	}
</script>