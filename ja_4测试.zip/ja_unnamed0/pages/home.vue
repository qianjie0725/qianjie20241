<!-- 主页 -->
<template>
	<view :style="$util.setBGSize(`680rpx`)">
		<Header></Header>

		<view
			style="margin: 30rpx;margin-top: 1vh;padding:40rpx 20rpx; background-color: rgba(255,255,255,0.85);border-radius: 16rpx;">
			<ButtonGroup></ButtonGroup>
		</view>
		<view class="common_page_fg">
			<view
				style="padding:4px 20px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
				<text style="font-size: 14px;font-weight: 700;"
					:style="{color:$util.THEME.TIP}">{{ $lang.STOCK_HOT}}</text>
				<!-- <view style="font-size: 14px;" @click="handleAllList()" :style="{color:$util.THEME.LABEL}">
					{{$lang.DETAIL}}
					<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
				</view> -->
			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
				webSocketTask: ""
			}
		},
		onShow() {
			this.startTimer();
			this.sockets()
			// if (this.$refs.free) {
			// 	this.$refs.free.getList();
			// 	this.$refs.goods.getList();
			// }
		},
		onHide() {
			clearInterval(this.timer);
			uni.closeSocket({
				success: () => {},
			})
		},

		onUnload() {
			uni.$off('onSuccess');
			clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {},
			})
		},
		methods: {

			handleAllList() {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_ALL}?type=0`,
				})
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					// this.$refs.goods.getList();
				}, 3000);
			},
			// 银转证
			async silver() {

				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value

				// window.open(this.list, '_blank');
				if (window.android) {
					window.android.callAndroid("open," + url)
					return;
				}
				if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
					.nativeExt) {
					window.webkit.messageHandlers.nativeExt.postMessage({
						msg: 'open,' + url
					})
					return;
				}

				var u = navigator.userAgent;
				var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
				if (isiOS) {
					window.location.href = url;
					return;
				}
				window.open(url)


			},
		},
	}
</script>