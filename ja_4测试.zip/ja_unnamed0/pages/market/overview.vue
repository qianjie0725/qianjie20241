<template>
	<view :style="$util.setBGSize(`680rpx`)">
		<Header></Header>


		<view class="common_page_fg">
			<TabOne v-if="current==0"></TabOne>
			<TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
			<TabFour v-if="current==3"></TabFour>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	import TabFour from '@/components/market/TabFour.vue'
	export default {
		components: {
			Header,
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				current: 0
			}
		},
		onShow() {},
		onLoad(op) {
			if (op.type) {
				this.current = Number(op.type);
			}
		},
		methods: {
			handleChange(val) {
				this.current = val;
			},
		},
	}
</script>