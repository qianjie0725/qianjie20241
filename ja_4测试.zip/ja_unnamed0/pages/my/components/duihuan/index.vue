<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<view class="college-text">환전</view>
			<view class=""></view>
		</view>
		
		
		<view class="duihuanForm">
			  <!-- <u-tabs :list="list2" @change="listChange" lineColor="#16a038" style="margin-bottom: 60rpx;"></u-tabs> -->
			<view class="input" @click="duihuan1_show=true">
				<u--input
				  disabled
				  disabledColor="#fff"
				  border="surround"
				  v-model="duihuan1"
				  suffixIcon="arrow-right"
				></u--input>
				
			</view>		
			<u-picker :show="duihuan1_show" :columns="duihuan_columns" cancelText="취소" confirmText="確認하다" @confirm="duihuan1_click" @cancel="duihuan1_show=false"></u-picker>
			
			<u-picker :show="duihuan2_show" :columns="duihuan_columns" cancelText="취소" confirmText="確認하다" @confirm="duihuan2_click" @cancel="duihuan1_show=false"></u-picker>
			
			
			<view class="prc" style="margin-left: 20rpx;margin-top: -20rpx;" v-if="duihuan1=='KRW'"><text>KRW:{{userInformation.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text></view>
			<view class="prc" style="margin-left: 20rpx;margin-top: -20rpx;" v-if="duihuan1=='USD'"><text>USD:{{userInformation.usd}}</text></view>
			
			<!-- <view class="prc" style="margin-left: 20rpx;margin-top: -20rpx;" v-if="duihuan1=='THB'"><text>THB:</text></view>
			<view class="prc" style="margin-left: 20rpx;margin-top: -20rpx;" v-if="duihuan1=='THB'"><text>THB:</text></view> -->
			
			
			  <view class="prc" style="margin-left: 20rpx;margin-top: 20rpx;">통화 교환</view>
			  
			  <view class="input" @click="duihuan2_show=true">
			  	<u--input
			  	  disabled
			  	  disabledColor="#fff"
			  	  border="surround"
			  	  v-model="duihuan2"
			  	  suffixIcon="arrow-right"
			  	></u--input>
			  	
			  </view>	
			  
			  <view class="input">
				    <u--input
				      placeholder="상환할 수량"
					  type="number"
				      border="surround"
				      v-model="value"
					  @input="amount_input"
				    ></u--input>
			  </view>
			    <view class="prc">{{duihuan2}}：+<text>{{dh_money}}</text> </view>
				100,000 KRW={{huilv}} USD
				
				<view class="purchase" @tap='renewal()'>
					완료
				</view>
		</view>


	</view>
</template>

<script>
	export default {
		data() {
			return {
				cardManagement: '',
				userInformation:{money:'',exchange:0,hkmoney:''},
				value:'',
				list2:[{name:this.$t('index.ghzls')},{name:this.$t('index.lszgh')}],
				type:1,
				duihuan1:'KRW',
				duihuan2:'USD',
				duihuan_columns:[
                    ['KRW', 'USD']
                ],
				duihuan1_show:false,
				duihuan2_show:false,
				dh_money:0,
				huilv:0
			};
		},
		methods: {
			amount_input(e){
				console.log(e);
				var that=this
				this.$http.post('api/StockApi/huilv', {
					duihuan1: this.duihuan1,
					duihuan2: this.duihuan2,
					amount: e
				}).then(res=>{
					console.log(res);
					that.dh_money=res.data.data	
				})
			},
			duihuan1_click(e){
				console.log(e);
				this.duihuan1=e.value[0]
				this.duihuan1_show=false
				this.dh_money="";
				this.value="";
			},
			duihuan2_click(e){
				console.log(e);
				this.duihuan2=e.value[0]
				this.duihuan2_show=false,
				this.dh_money="";
				this.value="";
			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			renewal() {
				
				this.$http.post('api/tool/rateChange', {
					duihuan1: this.duihuan1,
					duihuan2: this.duihuan2,
					num: this.value
				}).then(res=>{
					if(res.data.code==2){
						uni.$u.toast(res.data.message);
					}else{
						uni.$u.toast("상환 성공");
						setTimeout(()=>{
							uni.switchTab({
								url: this.$util.PAGE_URL.ACCOUNT_TRADE
							});
						},500)
					}
					
				})
			},
			huilv_get(){
				var that=this
				this.$http.post('api/StockApi/huilv', {
					duihuan1: this.duihuan1,
					duihuan2: this.duihuan2,
					amount: 100000
				}).then(res=>{
					console.log(res);
					that.huilv=res.data.data	
				})
			},
			listChange(e) {
				this.type = e.index + 1
			},
			
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
		},
		onShow() {
			this.gaint_info()
			this.huilv_get()
		},
		
	
	}
</script>

<style lang="scss" scoped>
	.prc{
		font-size: 28rpx;
		text{
			font-size: 26rpx;
			color: #999;
		}
	}
	.input{
		border: 1px solid #f5f5f5;
		border-radius: 6px;
		margin: 32rpx 6px;
	}
	page{
		background-color: #f5f5f5;
	}
	.duihuanForm{
		padding: 25rpx;
		background-color: #fff;
		margin: 50px 40rpx;
		border-radius: 6px;
	}
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		background-image: linear-gradient(to right,  #16a038, #16a038);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}


	.purchase {
		background-image: linear-gradient(to right,  #16a038, #16a038);
		margin: 60rpx 30rpx 5rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;
		// font-weight: 600;
	}
</style>