<!-- 新股申购 -->
<template>
	<view :style="$util.setBGSize(`680rpx`)">
		<CustomHeader :title="$lang.TRADE_IPO"></CustomHeader>

		<view class="common_page_fg">
			<view style="margin:auto;width: 90%;">
				<TabsFourth :tabs="tabs" @action="changeTab" :acitve="curTab"></TabsFourth>

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<template v-if="curTab==0">
						<block v-for="(item,index) in list" :key="index">
							<view style="border-bottom: 1px solid #e7e7e7;padding:20rpx 0;">
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;">
										{{item.goods.name}}
									</view>
									<view class="common_btn btn_primary"
										style="padding:6rpx 12rpx;margin-left: auto;font-size: 22rpx;"
										@click="handleApply(item.id)">
										申請
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">申請金額</view>
									<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price,2)}}</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">収益率</view>
									<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.shiying,2)}}
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">申請日</view>
									<view :style="{color:$util.THEME.TIP}">{{item.shengou_date}}</view>
								</view>
							</view>
						</block>
					</template>

					<template v-else-if="curTab==1">
						<block v-for="(item,index) in list" :key="index">
							<view style="border-bottom: 1px solid #e7e7e7;padding:20rpx 0;">
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;">
										{{item.goods.name}}
									</view>
									<template v-if="item.message && item.message.length>0">
										<view style="font-size: 28rpx;color:#ea3544;">{{item.message}}</view>
									</template>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">申請金額</view>
									<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price)}}</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">申請数量</view>
									<view>{{$util.formatNumber(item.apply_amount)}}</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">申請総額</view>
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.apply_num_amount,2)}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">購入時間</view>
									<view :style="{color:$util.THEME.TIP}">{{$util.formatDate(item.created_at)}}</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">取引コード</view>
									<view :style="{color:$util.THEME.TIP}">{{item.order_sn}}</view>
								</view>
							</view>
						</block>
					</template>
					<template v-else>
						<block v-for="(item,index) in list" :key="index">
							<view style="border-bottom: 1px solid #e7e7e7;padding:20rpx 0;">
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TEXT}" style="font-size: 32rpx;">
										{{item.goods.name}}
									</view>
									<template v-if="item.status==2">
										<view v-if="item.status==2" class="" @click="subscription(item)">購読する</view>
									</template>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">公募価格</view>
									<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price,2)}}</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">機関公募数量</view>
									<view>{{$util.formatNumber(item.apply_amount)}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">割り当て数量</view>
									<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.success)}}
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">公募額</view>
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.success_num_amount,2)}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">取引日</view>
									<view :style="{color:$util.THEME.TIP}">{{$util.formatDate(item.created_at)}}</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
									<view :style="{color:$util.THEME.TIP}">取引コード</view>
									<view :style="{color:$util.THEME.TIP}">{{item.order_sn}}</view>
								</view>
							</view>
						</block>
					</template>
				</template>
			</view>

			<!-- <view style="margin: 10px;">
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
					<view class="display approve">
						<view>
							<view class="corporation">{{item.goods.name}}</view>
							<view class="area" v-if="item.goods.locate=='깊은'">
								<view class="deep">{{item.goods.locate}}</view>
								<view class="deep-number">{{item.goods.code}}</view>
							</view>
							<view class="area" v-if="item.goods.locate=='북쪽'">
								<view class="north">{{item.goods.locate}}</view>
								<view class="north-number">{{item.goods.code}}</view>
							</view>
							<view class="area" v-if="item.goods.locate=='상하이'">
								<view class="shanghai">{{item.goods.locate}}</view>
								<view class="shanghai-number">{{item.goods.code}}</view>
							</view>
						</view>
						<view class="subscription-times">購読時間<text>{{item.shengou_date}}</text> </view>
					</view>

					<view class="display" style="margin-top: 10rpx;">
						<view class="display price">購読
							価格<text>{{$util.formatNumber(item.price,2)}}</text>
						</view>
						<view class="display price">
							株価収益率<text>{{$util.formatNumber(item.shiying,2)}}</text>
						</view>
					</view>
					<view class="display price">
						循環<text>{{$util.formatNumber(item.fa_amount,2)}}</text>
					</view>
				</view>
			</block>
		</view> -->
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TabsFourth from '@/components/TabsFourth.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			TabsFourth,
			EmptyData,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			};
		},

		computed: {
			tabs() {
				return ['市場', '取引記録', '当選履歴']
			},
		},

		onLoad(item) {},
		onShow() {
			this.getGoodsList();
		},

		methods: {
			changeTab(val) {
				this.curTab = val;
				this.list = [];
				if (this.curTab == 0) {
					this.getGoodsList();
				} else if (this.curTab == 1) {
					this.getApplyList();
				} else {
					this.getSuccessList();
				}
			},

			// IPO
			async handleApply(val) {
				const result = await uni.showModal({
					title: 'ヒント',
					content: '購読を確認するにはクリックしてください。',
					cancelText: 'キャンセル',
					confirmText: '確認する',
					cancelColor: this.$util.THEME.LABEL,
					confirmColor: this.$util.THEME.PRIMARY,
				});
				console.log('result:', result);
				if (result[1].confirm) {
					this.purchase(val);
				}
			},

			// 点击申购
			async purchase(val) {
				const result = await this.$http.post('api/goods-shengou/doOrder', {
					// num: this.value,
					id: val,
					// price: this.price
				})
				if (result.data.code == 0) {
					uni.showLoading({
						title: "購読が進行中です。 しばらくお待ちください....",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						// this.
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			// goods
			async getGoodsList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.TRADE_IPO_LIST, {
					type: 1, // 传参 1或2
				})
				uni.hideLoading();
				this.list = result.data.data;
			},

			// 申购记录
			async getApplyList() {
				const result = await this.$http.get(`api/goods-shengou/user-apply-log`);
				console.log(result);
				const temp = !result || result.data.code != 0 || !result.data.data ||
					result.data.data.length <= 0 ? [] : result.data.data;
				this.list = temp.length <= 0 ? [] : temp;
			},

			// 中签记录
			async getSuccessList() {
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				console.log(result);
				const temp = !result || result.data.code != 0 || !result.data.data ||
					result.data.data.length <= 0 ? [] : result.data.data;
				this.list = temp.length <= 0 ? [] : temp;
			},

		}
	}
</script>