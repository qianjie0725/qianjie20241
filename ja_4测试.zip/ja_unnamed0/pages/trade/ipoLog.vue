<!-- 申购 记录 -->
<template>
	<view :style="$util.setBGSize(`680rpx`)">
		<CustomHeader title="取引記録" ></CustomHeader>

		<view class="common_page_fg">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 1px solid #ccc;margin: 4px 20px;background-color: #FFF;">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
							<view>{{item.goods.name}}</view>
							<template v-if="item.message && item.message.length>0">
								<view style="font-size: 16px;color:#ea3544;">{{item.message}}</view>
							</template>
						</view>
						<view style="display: flex;align-items: center;padding-bottom: 6px;">
							<view style="flex:15%;" :style="{color:$util.THEME.TIP}">申請金額</view>
							<view :style="{color:$util.THEME.PRIMARY}"
								style="flex:35%;text-align: right;padding-right: 20px;">
								{{$util.formatNumber(item.price)}}
							</view>
							<view style="flex:15%;" :style="{color:$util.THEME.TIP}">申請数量</view>
							<view :style="{color:$util.THEME.PRIMARY}" style="flex:35%;text-align: right;">
								{{$util.formatNumber(item.apply_amount)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
							<view :style="{color:$util.THEME.TIP}">申請総額</view>
							<view style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">
								{{item.apply_num_amount}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
							:style="{color:$util.THEME.TIP}">
							<view>購入時間</view>
							<view>{{item.created_at}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
							:style="{color:$util.THEME.TIP}">
							<view>取引コード</view>
							<view>{{item.order_sn}}</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onLoad(option) {
			this.shengou();
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			// 新股申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
	}
</script>