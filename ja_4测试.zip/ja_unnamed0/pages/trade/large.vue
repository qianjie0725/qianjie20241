<!-- 大宗交易 -->
<template>
	<view :style="$util.setBGSize(`680rpx`)">
		<CustomHeader :title="$lang.TRADE_LARGE"></CustomHeader>
		<view class="common_page_fg">
			<view style="margin:auto;width: 90%;">
				<TabsFourth :tabs="tabs" @action="handleChangeTab" :acitve="curTab"></TabsFourth>

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<template v-if="curTab==0">
						<block v-for="(item,index) in list" :key="index">
							<view style="margin:40rpx 0;border-bottom: 1px solid #e7e7e7;padding-bottom: 20rpx;">
								<view style="display: flex;align-items: center;">
									<view style="font-size: 32rpx;color: #121212;">{{item.goods.name}}</view>
									<view class="common_btn btn_primary"
										style="padding:6rpx 12rpx;margin-left: auto;font-size: 22rpx;"
										@click="handleDetail(item)">
										{{$lang.STOCK_DETAIL}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.price,2)}}
									</view>
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.goods.rate_num*1,2)}}
									</view>
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.goods.rate,2)}}%
									</view>
								</view>
							</view>
						</block>
					</template>
					<template v-else>
						<block v-for="(item,index) in list" :key="index">
							<view style="margin:40rpx 0;border-bottom: 1px solid #e7e7e7;padding-bottom: 20rpx;">
								<view style="display: flex;align-items: center;">
									<view style="font-size: 32rpx;color: #121212;">{{item.goods.name}}</view>
									<view style="margin-left: auto;font-size: 28rpx;color:rgb(0, 143, 254)"> 購入完了
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view style="color: #8f8f8f;">購入価格</view>
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.price,2)}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view style="color: #8f8f8f;">枚数</view>
									<view>
										{{$util.formatNumber(item.num)}}
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view style="color: #8f8f8f;">買収金額</view>
									<view :style="{color:$util.THEME.PRIMARY}">
										{{$util.formatNumber(item.amount,2)}}
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
									<view style="color: #8f8f8f;">レバレッジ</view>
									<view> {{item.double}} </view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;color: #8f8f8f;">
									<view>購入時間</view>
									<view> {{item.created_at}} </view>
								</view>
							</view>
						</block>
					</template>
				</template>

			</view>

			<template v-if="isShow">
				<view class="common_mask">
					<view class="common_block common_popup" style="min-height:35vh;margin:auto">
						<view class="popup_header">購読申し込み詳細</view>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
							<text :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</text>
							<text :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(detail.price,2)}}</text>
						</view>
						<view class="common_input_wrapper" style="margin:30rpx 60rpx;">
							<image mode="aspectFit" src='/static/amount.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="amount" :placeholder="$lang.TIP_BUY_COUNT" type="number"></input>
						</view>

						<!-- <view class="common_input_wrapper">
						<image mode="aspectFit" src='/static/leverage.png' :style="$util.calcImageSize(20)"> </image>
						<block v-for="(item,index) in leverList" :key="index">
							<text @click="handleChgangeLever(index)" style="display: inline-block;padding:0 16px;"
								:style="{borderBottom:`2px solid ${index==current? $util.THEME.PRIMARY:'transparent'}`,color:index==current?$util.THEME.PRIMARY:$util.THEME.TEXT}">{{item.name}}</text>
						</block>
					</view> -->

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
							<view :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(buyAmount,2)}}</view>
						</view>

						<!-- <view class="common_input_wrapper">
						<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
						</image>
						<input v-model="password" :placeholder="$lang.TIP_BUY_PWD" type="password"></input>
					</view> -->

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
							<text :style="{color:$util.THEME.LABEL}">利用可能残高 </text>
							<text :style="{color:$util.THEME.PRIMARY}">{{availBal}}</text>
						</view>


						<view style="display: flex;justify-content: space-evenly;margin:20px 0;">
							<view class="common_btn btn_primary" style="width: 30%;" @click="handleConfirm">
								{{$lang.BUY}}
							</view>
							<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
								{{$lang.CANCEL}}
							</view>
						</view>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TabsFourth from '@/components/TabsFourth.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			TabsFourth,
			EmptyData,
		},
		data() {
			return {
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				password: '',
				availBal: 0,
				curTab: 0,
			}
		},
		onShow() {
			this.getList()
		},
		computed: {
			tabs() {
				return ["市場", "取引記録"];
			},
			// 计算购买总价
			buyAmount() {
				return this.detail.price * 1 * this.amount * 1;
			}
		},

		methods: {
			handleChangeTab(val) {
				this.curTab = val;
				this.list = []; // 每次切换，清空数组，否则会因网速延迟，页面无法及时更新。
				if (this.curTab == 0) {
					this.getList()
				} else {
					this.getLargeLog();
				}
			},

			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			handleDetail(val) {
				this.isShow = true;
				this.detail = val;
				// 只有打开弹层，才请求用户信息，获取可用余额
				this.available();
			},
			handleCancel() {
				this.isShow = false;
				this.amount = "";
				this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async buy() {
				const result = await this.$http.post(this.$http.API_URL.TRADE_LARGE_ORDER, {
					id: this.detail.id,
					num: this.amount,
					pay_pass: this.password,
					// ganggan: this.curLever.index,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					// uni.navigateTo({
					// 	url: this.$util.PAGE_URL.TRADE_LARGE_LOG
					// });
					this.handleChangeTab(1);
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_LIST, {})
				uni.hideLoading();
				this.list = result.data.data
			},
			async available() {
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.availBal = this.$util.formatNumber(result.data.data.money,2);
			},
			async getLargeLog(e) {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				let result = await this.$http.post('api/goods-bigbill/user-order-log');
				uni.hideLoading();
				this.list = result.data.data
			},
		},
	}
</script>