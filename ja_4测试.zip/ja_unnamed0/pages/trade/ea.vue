<template>
	<view :style="$util.setBGSize(`480rpx`)">
		<CustomHeader title="EA"></CustomHeader>
		<view class="common_page_fg">
			<view style="margin:auto;width: 90%;">
				<TabsFourth :tabs="tabsLabel" @action="changeTab" :acitve="curTab"></TabsFourth>
				<template v-if="curTab==0">
					<EaMarket></EaMarket>
				</template>
				<template v-else>
					<EaOrder></EaOrder>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TabsFourth from '@/components/TabsFourth.vue';
	import EaIntroduce from '@/components/trade/ea/EaIntroduce.vue';
	import EaMarket from '@/components/trade/ea/EaMarket.vue';
	import EaOrder from '@/components/trade/ea/EaOrder.vue';
	export default {
		components: {
			CustomHeader,
			TabsFourth,
			EaIntroduce,
			EaMarket,
			EaOrder,
		},
		data() {
			return {
				curTab: 0,
			}
		},
		computed: {
			tabsLabel() {
				return ['市場', '記録']
			}
		},

		onShow() {
			this.is_token()
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		methods: {
			changeTab(val) {
				console.log(val);
				this.curTab = val;
			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},
	}
</script>