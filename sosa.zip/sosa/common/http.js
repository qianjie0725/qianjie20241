import Vue from 'vue';
import {
	ACCOUNT_ACCESS
} from '@/common/paths.js';
import md5 from 'js-md5';

export const BASE_URL = `https://api.sosastock.top`;

const CODE = "Qwd3N5yp";

export default async function http(url, params = {}) {
	console.log('url:', url, 'params:', params);
	const token = uni.getStorageSync("token") || '';
	const headers = {
		"Content-Type": "application/x-www-form-urlencoded",
		// 处理携带token
		"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
		"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
	};
	const time = parseInt(new Date().getTime() / 1000);
	const str_url = `/api/${url}`.toLowerCase();
	const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

	try {
		if (!params.hide) {
			// 默认显示状态
			uni.showLoading({
				title: params.title || Vue.prototype.$lang.STATUS_REQUEST,
			})
		}
		const response = await uni.request({
			url: `${BASE_URL}/api/${url}?sign=${mdd}&t=${time}`,
			method: params.method || 'GET',
			data: params.data || {},
			header: headers
		});
		if (!params.hide) {
			uni.hideLoading();
		}
		// console.log('response:', response);
		let [err, res] = response;		
		if (res.statusCode == 200) {
			if (res.data.code === 999) {
				uni.clearStorageSync();
				uni.$u.toast(Vue.prototype.$lang.API_TOKEN_EXPIRES);
				uni.$u.sleep(1000).then(() => {
					uni.navigateTo({
						url: ACCOUNT_ACCESS
					});
				})
				return false;
			}
			return res.data;
		} else {
			uni.$u.toast(Vue.prototype.$lang.STATUS_HTTP_ERROR);
		}
	} catch (error) {
		// console.log(error);
		throw error;
	}
};

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
})


// const request = async (options = {}) => {
// 	console.log('options:', options);
// 	// 在这里可以对请求头进行一些设置
// 	const token = uni.getStorageSync("token") || '';
// 	options.header = {
// 		"Content-Type": "application/x-www-form-urlencoded",
// 		// 处理携带token
// 		"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
// 		"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
// 	}

// 	console.log(options.header);

// 	return new Promise((resolve, reject) => {
// 		let time = parseInt(new Date().getTime() / 1000)
// 		let str_url = ("/" + options.url).toLowerCase()
// 		let mdd = md5("XPFXMedS" + Request + str_url + time)
// 		// console.log(mdd+"=="+options.url+"=="+str_url+"=="+time);

// 		uni.request({
// 			// url: CONFIG.API_BASE_URL + "/api/" + options.url + "?sign=" + mdd + "&t=" + time,
// 			url: `${CONFIG.API_BASE_URL}/api/${options.url}?sign=${mdd}&t=${time}`,
// 			method: options.type || 'GET',
// 			data: options.data || {},
// 			header: options.header || {},
// 		}).then(data => {
// 			let [err, res] = data;
// 			if (err) {
// 				reject(err)
// 			} else {
// 				if (res.data.code === 999) {
// 					try {
// 						try {
// 							uni.clearStorageSync();
// 						} catch (e) {
// 							// error
// 						}
// 						uni.$u.toast("로그인 상태가 잘못되었습니다. 다시 로그인해 주세요.");
// 						setTimeout(() => {
// 							uni.navigateTo({
// 								url: CONFIG
// 									.PAGE_URL_ACCOUNT_ACCESS // '/pages/account/sigin'
// 							});
// 						}, 1000)

// 					} catch (e) {
// 						//TODO handle the exception
// 					}
// 				}
// 				resolve(res);
// 			}

// 		}).catch(error => {
// 			// console.log(error)
// 			reject(error)

// 		})
// 	});
// }

// const get = (url, data, options = {}) => {
// 	options.type = 'GET';
// 	options.data = data;
// 	options.url = url;
// 	return request(options)
// }

// const post = (url, data, options = {}) => {
// 	options.type = 'POST';
// 	options.data = data;
// 	options.url = url;
// 	return request(options)
// }


// export default {
// 	request,
// 	get,
// 	post,
// }