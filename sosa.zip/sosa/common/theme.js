/* change theme 挂在全局，方便后期做主题切换 */

// 主题，一些通用的颜色值 硬编码
export default {
	ACCESS_TEXT: '#FFFFFF', // 标题文字
	PRIMARY: '#9047FF', // 
	TITLE:'#666666', // 
	RISE: '#E82D28', // 股票涨
	FALL: '#9047FF',// 股票跌
	LABEL:'#A0A0A0', // 列表的标题
	

	STOCK_NAME: '#121212',
	FG: ' #AFAFAF',
	SECONDARY: '#FF8C00',
	
	// LABEL: '#F7F7F7',
	TEXT: '#555555', // D3D3D3
	TIP: '#333333',
	PLACEHOLDER: '#66666652', // 输入框占位符
};