<!-- 股票详情 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.PAGE_TITLE_STOCK_OVERVIEW"></CustomHeader>

		<view style="background-color: #fef9fe;padding-top: 1vh;padding-bottom: 20px;">
			<template v-if="stockInfo">
				<view class="stock_info_bg">
					<view style="display: flex;align-items: center;padding: 20px;padding-bottom: 0;">
						<view style="flex:18%">
							<template v-if="!stockInfo.logo || stockInfo.logo==''">
								<view :style="$util.setImageSize(80)"
									style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;border-radius: 100px;font-size: 18px;">
									{{stockInfo && stockInfo.name? stockInfo.name[0]:''}}
								</view>
							</template>
							<template v-else>
								<image v-if="stockInfo.logo" :src="getlogo()" mode="aspectFit"
									:style="$util.setImageSize(80)" style="border-radius: 100px;"></image>
							</template>
						</view>
						<view style="flex:72%">
							<view style="margin-bottom: 2px;">
								<text
									style="font-weight: 700;font-size: 32rpx;background-color: #FFF;padding:1px 6px;border-radius: 4px;">{{stockInfo.name}}</text>
							</view>
							<view style="color:#FFF;"> {{stockInfo.ct_name}} {{stockInfo.number_code}}</view>
						</view>
						<view style="flex:10%;text-align: right;" @click="handleUnFollow(stockInfo.gid)">
							<image :src="`/static/${stockInfo.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
								:style="$util.setImageSize(40)"></image>
						</view>
					</view>

					<view style="display: flex;align-items: center;padding: 10px 20px;padding-bottom: 0;"
						:style="$util.setStockRiseFall(stockInfo.rate>0)">
						<view style="flex:50%; font-size: 20px; font-weight: 700;">
							{{$util.formatNumber(stockInfo.current_price)}} {{$lang.CURRENCY_UNIT}}
						</view>
						<view style="flex:30%;text-align: right; font-size: 20px; font-weight: 700;">
							{{$util.formatNumber(stockInfo.rate_num)}}
						</view>
						<view style="flex:20%;text-align: right; font-size: 20px; font-weight: 700;">
							{{$util.formatNumber(stockInfo.rate)}}%
						</view>
					</view>

					<view style="padding: 10px 10px;padding-top: 4px;">
						<view style="background-color: #FFFFFF;padding:6px;border-radius: 6px;">
							<view
								style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;">
								<view
									style="flex:31%;margin:0 6px;background-color: #f9fcfe;padding:4px 6px;border-radius: 4px;">
									<view style="color:#e48a88;">
										{{$util.formatNumber(stockInfo.info.open)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view style="color:#999">{{$lang.STOCK_INFO_TITLES[0]}}</view>
								</view>
								<view
									style="flex:31%;margin:0 6px;background-color: #f9fcfe;padding:4px 6px;border-radius: 4px;">
									<view style="color:#e48a88;text-align: right;">
										{{$util.formatNumber(stockInfo.info.prev_close)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view style="color:#999;text-align: right;">{{$lang.STOCK_INFO_TITLES[1]}}</view>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;">
								<view
									style="flex:31%;margin:0 6px;background-color: #f9fcfe;padding:4px 6px;border-radius: 4px;">
									<view style="color:#666;">
										{{$util.formatNumber(stockInfo.info.high)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view style="color:#999;">{{$lang.STOCK_INFO_TITLES[2]}}</view>
								</view>
								<view
									style="flex:31%;margin:0 6px;background-color: #f9fcfe;padding:4px 6px;border-radius: 4px;">
									<view style="color:#666;text-align: right;">
										{{$util.formatNumber(stockInfo.info.low)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view style="color:#999;text-align: right;">{{$lang.STOCK_INFO_TITLES[3]}}</view>
								</view>
							</view>

							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view
									style="flex:31%;margin:0 6px;background-color: #f9fcfe;padding:4px 6px;border-radius: 4px;">
									<view style="color:#666;">
										{{$util.formatNumber(stockInfo.info.volume/10000)}}
									</view>
									<view style="color:#999;">{{$lang.STOCK_INFO_TITLES[4]}}</view>
								</view>
								<view
									style="flex:31%;margin:0 6px;background-color: #f9fcfe;padding:4px 6px;border-radius: 4px;">
									<view style="color:#666;text-align: right;">
										{{$util.formatNumber(stockInfo.info.volume_valued/10000)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<view style="color:#999;text-align: right;">{{$lang.STOCK_INFO_TITLES[5]}}</view>
								</view>
							</view>
						</view>
					</view>
				</view>

				<TabsPrimary :tabs="$lang.STOCK_OVERVIEW_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

				<view class="common_block" :style="{display:curTab==0?'block':'none' }">
					<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
						<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key="index">
							<view style="flex:25%;text-align: center;font-size: 32rpx;"
								:style="{color:curKLine==index? '#e48a88':'#666'}" @click="handleShowKLine(index)">
								{{item}}
							</view>
						</block>
					</view>
					<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
					</view>
				</view>

				<template v-if="curTab==0">
					<!-- <StockKline :code='code' :id='stockInfo.stock_id' :type="stockInfo.project_type_id" ref="stockLine"> -->
					</StockKline>
					<view class="common_btn btn_primary" style="margin: auto;margin-top:30px; width: 90%;"
						@click="purchase">{{$lang.BTN_BUY}}
					</view>
				</template>


				<template v-if="curTab==1">
					<InfoTwo :code='code' :id='stockInfo.stock_id'></InfoTwo>
				</template>

				<template v-if="curTab==2">
					<StockNews :code='code' :id='stockInfo.stock_id'></StockNews>
				</template>
			</template>
		</view>
	</view>
</template>

<script>
	import {
		BASE_URL
	} from '@/common/http.js';
	import {
		getStockInfo,
		getKLineData,
		updateFollow
	} from '@/common/api.js';
	import {
		STOCK_BUY
	} from '@/common/paths.js';

	import CustomHeader from '@/components/CustomHeader.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import InfoTwo from '@/components/info/InfoTwo.vue'
	import StockNews from '@/components/stock/StockNews.vue';
	// import StockKline from '@/components/stock/StockKline.vue';
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts';

	export default {
		components: {
			CustomHeader,
			TabsPrimary,
			InfoTwo,
			StockNews,
			// StockKline
		},
		data() {
			return {
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				stockInfo: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
				timer: null,
			};

		},
		onLoad(option) {
			this.code = option.code;
			this.product();
		},
		onShow() {
			console.log('stock onShow:', this.curTab)
			if (this.curTab == 0) {
				this.onSetTimeout()
			}
		},
		onHide() {
			this.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			getlogo() {
				return BASE_URL + this.stockInfo.logo
			},

			changeTab(val) {
				this.clearTimer();
				console.log('changeTab:', this.timer3);
				console.log('val:', val);
				this.curTab = val;
				if (this.curTab == 0) {
					this.onSetTimeout();
				}
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.genKLineData();
				}, 5000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleShowKLine(val) {
				this.curKLine = val;
				this.product();
			},

			kLineInit() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$theme.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb9'
							}, {
								offset: 1,
								color: this.$theme.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#888888',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#888888',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#888888'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
			},

			// 买入
			purchase() {
				uni.navigateTo({
					url: `${STOCK_BUY}?code=${this.code}`
				});
			},

			// 产品详情
			async product() {
				const result = await getStockInfo({
					code: this.code,
					time_index: this.curKLine
				});
				console.log(result);
				this.stockInfo = result.data[0];

				// 延时,等DOM渲染
				uni.$u.sleep(50).then(() => {
					if (!this.kLineChart) {
						this.kLineChart = init('chart-type-k-line');
						this.kLineInit(); // 初始化Kline
					}
					this.genKLineData(); // 获取并生成KLine数据				
				})
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await getKLineData({
					stock_id: this.stockInfo.stock_id,
					ac_time: this.curKLine,
					project_type_id: this.stockInfo.project_type_id,
					code: this.stockInfo.code
				})
				console.log('k data:', result);
				this.kLineChart.setStyles({
					"candle": {
						"type": this.curKLine == 0 ? "area" : "candle_solid",
					},
				});
				this.kLineChart.setPriceVolumePrecision(0, 0)
				this.kLineChart.applyNewData(result.data)
			},

			// 取关
			async handleUnFollow(id) {
				const result = await updateFollow({
					gid: id,
				})
				if (result.code == 0) {
					uni.$u.toast(result.message);
					//按键样式判断
					this.stockInfo.is_collected = this.stockInfo.is_collected == 1 ? 0 : 1
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>

<style lang="scss">
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #489ce5;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #489ce5;
			}
		}

		.list1 {
			background-color: #0332783b;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 32%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #999;
			}

			.t3 {
				font-size: 12px;
				color: #333;
				font-family: Roboto;
			}
		}
	}

	// .stock-chart {
	// 	background: #fff;

	// 	.chart-time {
	// 		background: #489ce51f;
	// 		// border: 1px solid #999;
	// 		border-radius: 5px;
	// 		display: -webkit-box;
	// 		display: -webkit-flex;
	// 		display: flex;
	// 		-webkit-box-pack: justify;
	// 		-webkit-justify-content: space-between;
	// 		justify-content: space-between;
	// 		-webkit-box-align: center;
	// 		-webkit-align-items: center;
	// 		align-items: center;
	// 		margin: 0 10px 10px;

	// 		.txt {
	// 			-webkit-box-flex: 1;
	// 			-webkit-flex: 1;
	// 			flex: 1;
	// 			text-align: center;
	// 			color: #999;
	// 			border-radius: 5px;
	// 			padding: 10px 0;
	// 		}

	// 		.active.txt {
	// 			color: #e48a88;
	// 			background-color: #fff;
	// 			// box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
	// 		}
	// 	}
	// }
</style>