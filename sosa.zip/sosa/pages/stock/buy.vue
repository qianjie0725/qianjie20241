<!-- 下单 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="stockInfo.name"></CustomHeader>

		<view class="withdraw_info">
			<view style="display: flex;padding:20px;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">{{$lang.WITHDRAW_AMOUNT}}</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`"
					@click="handleShowAmount" :style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;text-align: center;">
				{{showAmount?$util.formatNumber(userInfo.money)+$lang.CURRENCY_UNIT:hideAmount}}
			</view>
			<view style="color:#f5f5f5;margin-bottom: 10px;text-align: center;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		</view>

		<view class="common_block" style=";margin-top: 20px;padding:20px 10px;">
			<view class="flex padding-bottom-10">
				<view style="margin-left: 10px;" :style="{color:$theme.TEXT}">{{stockInfo.name}}</view>
				<view class="text-right flex-1 bold margin-right-20">
					<view :style="{color:$theme.TEXT}">
						{{$util.formatNumber(stockInfo.current_price)}}<text
							style="padding:0 4px">{{$lang.CURRENCY_UNIT}}</text>
					</view>
					<view :style="$util.setStockRiseFall(stockInfo.rate>0)">{{stockInfo.rate}}%</view>
				</view>
			</view>

			<view class="margin-top-20 bold" :style="{color:$theme.TEXT}">
				{{$lang.STOCK_BUY_QUANTITY}}
			</view>

			<view class="btns">
				<block v-for="(item,index) in quantityList" :key="index">
					<view class="item" style="flex:30%;margin:4px;" :class="curQuantity==item?'actity':'noactity'"
						@click="handleSelected(item)">{{item}}</view>
				</block>
			</view>

			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
				<view style="width: 20px;"></view>
				<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY" @input="handleInput"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;" :style="{color:$theme.TEXT}">
				<view >{{$lang.STOCK_BUY_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]</view>
				<view >
					{{$util.formatNumber(stockInfo.current_price*curQuantity/lever)}}
				</view>
			</view>
			<view style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;" :style="{color:$theme.TEXT}">
				<view >{{$lang.STOCK_BUY_FEE}}[{{$lang.CURRENCY_UNIT}}]</view>
				<view >
					{{$util.formatNumber(stockInfo.current_price*curQuantity/lever*fee)}}
				</view>
			</view>

			<view class="common_btn btn_primary access_btn" style="width: 100%;" @click="placeOrder()">
				{{$lang.BTN_BUY}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getAPPConfig,
		accountInfo,
		postStockBuy,
		getStockInfo
	} from '@/common/api';
	import {
		ACCOUNT_TRADE
	} from '@/common/paths';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				quantityList: [50, 100, 150, 200, 250, 300], // 预置数量
				curQuantity: 50, // 当前选中预置数量
				show: false,
				stockInfo: {},
				quantity: 50,
				lever: 1,
				userInfo: {},
				fee: 1, // 手续费
			};
		},
		created() {
			this.getUserInfo()
		},
		onLoad(option) {
			this.getStockDetail(option.code)
			this.getconfig()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleSelected(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},

			// 获取配置
			async getconfig() {
				const result = await getAPPConfig();
				if (result.code == 0) {
					const temp = result.data.reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());
					this.fee = temp.get('TransRate') || this.fee;
				}
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async getStockDetail(code) {
				const result = await getStockInfo({
					code: code,
				})
				this.stockInfo = result.data[0]
			},
			//购买
			placeOrder() {
				const _this = this;
				let money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} ,${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
					success: (res) => {
						if (res.confirm) {
							_this.buy()
						} else {}
					}
				})
			},
			async buy() {
				const result = await postStockBuy({
					num: this.quantity || 0,
					gid: this.stockInfo.gid,
					price: this.stockInfo.current_price,
					ganggan: this.lever,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_TRADE,
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
			//实名认证
			async getUserInfo() {
				const result = await accountInfo();
				this.userInfo = result.data
			},
		},
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		// background: url(../../static/anniu.png);
		background-size: 100% 100%;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 40rpx;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-box-pack: center;
		-ms-flex-pack: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: rgba(48, 131, 248, 0.35);
		color: #3c1f20;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #979898;
		border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>