<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.STOCK_ALL"></CustomHeader>
		<view style="padding-bottom: 20px;">
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			CustomHeader,
			GoodsList,
		},
		onShow() {
			if (this.$refs.goods) {
				this.$refs.goods.onSetTimeout();
			}
		},
		onHide() {
			console.log('onHide', this.$refs.goods);
			this.$refs.goods.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.$refs.goods);
			this.$refs.goods.clearTimer();
		},
	}
</script>