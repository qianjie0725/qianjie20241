<template>
	<view class="launch">

		<view style="position: fixed;bottom: 10vh;">
			<image src='/static/logo_name.png' :style="$util.setImageSize(600,150)" style="margin-bottom: 50px;">
			</image>

			<view>
				<u-line-progress :percentage="percentage" height="24" activeColor="#9047FF"></u-line-progress>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	export default {
		data() {
			return {
				percentage: 20, // 进度条初始值
			}
		},
		onLoad() {
			uni.$u.sleep(1500).then(() => {
				this.percentage = 120;
				//跳转到首页 缓一秒，否则看不到进度条加满效果
				uni.$u.sleep(1000).then(() => {
					uni.switchTab({
						url: HOME,
					})
				})
			})
		},
	}
</script>

<style>
</style>