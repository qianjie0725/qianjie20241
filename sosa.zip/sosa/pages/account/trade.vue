<template>
	<view :style="$util.setPageBG('bg_common')">
		<Header></Header>

		<view class="withdraw_info" style="height: 120px;position: relative;border-radius: 16px;">
			<view style="display: flex;padding:10px;margin-bottom: 10px;padding-right: 20px;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}[{{$lang.CURRENCY_UNIT}}]
				</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left:10px;">
				</image>
			</view>

			<view
				style="color:#FFFFFF;font-size: 48rpx;font-weight: 500;padding-right: 20px;padding-bottom: 10px;padding-left: 20px;">
				{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
			</view>

			<view class="btn_deposit" @click="handleDeposit()" style="background-color: #ebdcff;">
				<image src="/static/trade_deposit.png" mode="aspectFit" :style="$util.setImageSize(40)"></image>
				<view style="display: inline-block;padding-left: 10px;font-size: 32rpx;color:#a35bfe;">
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
			</view>
		</view>

		<!-- <view
			style="display: flex;align-items: center;justify-content:space-between;font-size: 16px;padding: 10px;font-weight: 700;">
			<view :style="{color:isHold? $theme.PRIMARY:$theme.TITLE}" @click="handleChangeList(0)">
				{{$lang.TRADE_TABS[0]}}
			</view>
			<view :style="{color:!isHold? $theme.PRIMARY:$theme.TITLE}" @click="handleChangeList(1)">
				{{$lang.TRADE_TABS[1]}}
			</view> -->
		<!-- <view>
				<u-radio-group v-model="radioLocation" placement="row" @change="groupChange">
					<u-radio :customStyle="{marginRight: '6px'}" v-for="(item, index) in locationList" :key="index"
						:label="item.name" :name="item.name" @change="handleChangeLocation(index)"
						:activeColor="$theme.PRIMARY" labelSize="11px"
						:labelColor="item.name==radioLocation?$theme.PRIMARY:$theme.TITLE">
					</u-radio>
				</u-radio-group>
			</view> -->
		<!-- </view> -->

		<view class="common_block" style="background-color: #a35bfe;border-radius: 8px;margin-top: 20px;">
			<view class="large_tab_wrapper">
				<view class="large_tab_item " :class="curTab==0?'large_tab_active_left':'large_tab_unactive_left'"
					@click="handleChangeTab(0)">{{$lang.TRADE_TABS[0]}}</view>
				<view class="large_tab_item " :class="curTab==1?'large_tab_active_rigt':'large_tab_unactive_rigt'"
					@click="handleChangeTab(1)">{{$lang.TRADE_TABS[1]}}
				</view>
			</view>

			<view style="background-color: #a35bfe;padding:10px;">


				<!-- <view class="common_block" style="padding:10px;margin-top: 20px;"> 
			<view
				style="background-color: #F0F1F3;display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding:10px 20px">
				<view style="flex:70%;">거래 내역</view>
				<image mode="aspectFit" src="/static/refresh.png" :style="$util.setImageSize(40)"
					@click="handleRefresh()"></image>
				<view style="display: inline-block;padding-left: 6px;">새로고침</view>
			</view> -->

				<view style="background-color: #FFFFFF;border-radius: 4px;margin-top: 10px;padding:10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.TITLE}">
							{{$lang.TRADE_TOTAL_BUY_AMOUNT}}
						</view>
						<view style="text-align: right;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(userInfo.frozen)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view style="" :style="{color:$theme.TITLE}">
							{{$lang.TRADE_VALUATION_GAIN_LOSS}}
						</view>
						<view style="text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(userInfo.holdYingli)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.TITLE}">
							{{$lang.TRADE_VALUATION_GAIN_LOSS_AMOUNT}}
						</view>
						<view style="text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(userInfo.guzhi)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.TITLE}">
							{{$lang.TRADE_RATE_RESPONSE}}
						</view>
						<view style="text-align: right;padding-right: 4px;" :style="{color:$theme.TEXT}">
							{{userInfo.huibao}}%
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.TITLE}">
							{{$lang.ACCOUNT_AMOUNT_TOTAL}}
						</view>
						<view style="text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(userInfo.totalZichan)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.TITLE}">
							{{$lang.TRADE_TOTAL_GAIN}}
						</view>
						<view style="text-align: right;" :style="$util.setStockRiseFall(userInfo.totalYingli>0)">
							{{$util.formatNumber(userInfo.totalYingli)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
				</view>
			</view>
		</view>

		<view class="common_block" style="margin-top: 20px;padding:10px;margin-bottom: 20px;">
			<view style="overflow-y: scroll;min-height: 47vh;">
				<view style="display: flex;align-items: center;" :style="{color:$theme.TITLE}">
					<view
						style="flex:16%;margin:4px;height: 36px;line-height: 36px;text-align: center;background-color: #E8DCFF;padding:4px 0;border-radius: 6px;">
						<view>{{$lang.TRADE_LIST_THEAD[0]}}</view>
					</view>
					<view
						style="flex:30%;margin:4px;text-align: center;background-color: #E8DCFF;padding:4px 0;border-radius: 6px;">
						<view>{{$lang.TRADE_LIST_THEAD[1]}}</view>
						<view>{{$lang.TRADE_LIST_THEAD[2]}}</view>
					</view>
					<view
						style="flex:34%;margin:4px;text-align: center;background-color: #E8DCFF;padding:4px 0;border-radius: 6px;">
						<view>{{$lang.TRADE_LIST_THEAD[3]}}</view>
						<view>{{$lang.TRADE_LIST_THEAD[4]}}</view>
					</view>
					<view
						style="flex:20%;margin:4px;text-align: center;background-color: #E8DCFF;padding:4px 0;border-radius: 6px;">
						<view>{{$lang.TRADE_LIST_THEAD[5]}}</view>
						<view>{{$lang.TRADE_LIST_THEAD[6]}}</view>
					</view>
				</view>

				<template v-if="list && list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view class="flex flex-b margin-top-5" @tap="handleShowModal(item)" style="margin-bottom: 8px;"
							:style="{backgroundColor:index%2==0?'#ebe5f8':'#efefef'}">
							<view class="padding-5" :class="index%2==0?'bgyellow':'bglan'" style="width: 16%">
								<view :style="{color:$theme.TIP}"> {{item.goods_info.name}} </view>
							</view>
							<view class="padding-5 flex flex-b" :class="index%2==0?'bgyellow':'bglan'"
								style="width: 84%">
								<template v-if="isHold">
									<view class="flex-1"
										:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
										<view style="text-align: right;padding-right: 6px;">
											{{$util.formatNumber(item.order_buy.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
										</view>
										<view class="margin-top-10 " style="text-align: right;padding-right: 6px;">
											{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
										</view>
									</view>
								</template>
								<template v-else>
									<template v-if="item.order_sell">
										<view class="flex-1"
											:style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)"
											style="text-align: right;padding-right: 6px;">
											<view>
												{{$util.formatNumber(item.order_sell.yingkui*1)}}
											</view>
											<view class="margin-top-10 " style="text-align: right;padding-right: 6px;">
												{{$util.formatNumber((item.order_sell.yingkui*1/item.order_buy.user_pay*1/item.order_buy.double*100),2)}}%
											</view>
										</view>
									</template>
								</template>

								<view class="flex-1">
									<view style="text-align: right;padding-right:6px;" :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_buy.num)}}
									</view>
									<template v-if="isHold">
										<view class="margin-top-10 " style="text-align: right;"
											:style="{color:$theme.TEXT}">
											{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view class="margin-top-10" style="text-align: right;"
												:style="{color:$theme.TEXT}">
												{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
											</view>
										</template>
									</template>
								</view>

								<view class="flex-1">
									<view style="text-align: right;padding-right: 6px;" :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_buy.price)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<template v-if="isHold">
										<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
											:style="{color:$theme.RISE}">
											{{$util.formatNumber(item.goods_info.current_price)}}{{$lang.CURRENCY_UNIT}}
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
												:style="{color:$theme.RISE}">
												{{$util.formatNumber(item.order_sell.price)}}{{$lang.CURRENCY_UNIT}}
											</view>
										</template>
									</template>
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:$theme.ACCESS_TEXT}"
							style="text-align: center;font-size: 16px;">{{$lang.TRADE_MOADL_TITLE}}</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.goods_info.name}}</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.order_buy.created_at}}</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}</view>
							<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.order_buy.double}}</view>
					</view> -->

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}</view>
						<view style="flex: 30%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}</view>
						<view style="flex: 20%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="common_btn btn_primary" style="width: 40%;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_BUY}}
						</view>
						<view class="common_btn btn_secondary" style="width: 40%;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import {
		getTradeList,
		postStockSell,
		accountInfo
	} from '@/common/api.js';
	import {
		STOCK_OVERVIEW,
		ACCOUNT_DEPOSIT
	} from '@/common/paths.js';
	import Header from '@/components/Header.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			TradeInfo,
			EmptyData,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				curTab: 0, // 默认放在持仓列表，即左边

				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				isShow: false, // 买卖弹出
				curPage: 1, // 当前页码	
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},

		onLoad() {
			this.getUserInfo();
		},
		onShow() {
			this.getData();
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.curPage = 1; // 从第一页重新开始
			// this.list = []; // 清空所有翻页后内中数据
			this.getData();
			uni.stopPullDownRefresh();
		},

		// //监听页面触底函数
		// onReachBottom() {
		// 	// 如果触底，并且当前页码<最大页码
		// 	console.log(this.curPage, this.maxPage);
		// 	if (!this.flag) {
		// 		if (this.curPage < this.maxPage) {
		// 			this.curPage++;
		// 			console.log('page:', this.curPage);
		// 			this.getData()
		// 		}
		// 		if (this.curPage >= this.maxPage) {
		// 			return false;
		// 		}
		// 	}
		// },
		methods: {
			// tab切换
			handleChangeTab(val) {
				console.log(val)
				this.curTab = val;
				this.isHold = this.curTab != 1;
				// this.isHold = val == 1;
				// this.curPage = 1; // 从第一页重新开始
				// this.list = []; // 清空数据
				this.getData();
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},
			groupChange(n) {
				console.log('groupChange', n);
			},
			// handleChangeLocation(val) {
			// 	this.isSelf = val == 0;
			// 	this.getData();
			// },
			// handleChangeList(val) {
			// 	this.isHold = val == 0;
			// 	this.getData();
			// },

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.TRADE_MODAL_ALERT_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							_this.confirmSell(id);
						} else if (res.cancel) {}
					}
				})
			},

			async getUserInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},

			// 平仓功能
			async confirmSell(id) {
				const result = await postStockSell({
					id
				}, this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					this.getData()
					uni.$u.toast(result.message);
				} else {
					uni.$u.toast(result.message);
				}
			},

			handleStockDetail(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`
				});
			},

			async getData() {
				// this.flag = true;
				const result = await getTradeList({
					// page: this.curPage,
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
				});

				// this.flag = false;
				if (result.code == 0 && result.data) {
					// this.list.push(...result.data);
					this.list = result.data;
					// this.maxPage = result.data.last_page; // 最大页码
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>