<!-- 绑定银行卡 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.ACCOUNT_CARD_MANAGEMENT"></CustomHeader>

		<view style="background-color: #fef9fe;">
			<view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/bank_card_bnner.png" :style="$util.setImageSize(600,300)"></image>
			</view>

			<view class="common_block" style="margin: 20px;padding: 20px;">
				<view style="padding-left: 10px;" :style="{color:$theme.TEXT}">{{$lang.REAL_NAME}}</view>
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;padding-left: 10px;">
					<template v-if="isRenewal">						
						<input v-model="realname" type="text" :placeholder="$lang.TIP_REAL_NAME"
							:placeholder-style="$util.setPlaceholder()"></input>
					</template>
					<template v-else>
						<view style="display: inline-block;min-height: 40rpx;"> {{info.realname ||''}}
						</view>
					</template>
				</view>

				<view style="padding-left: 10px;" :style="{color:$theme.TEXT}">{{$lang.BANK_NAME}}</view>
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;padding-left: 10px;">
					<template v-if="isRenewal">
						<input v-model="bank_name" type="text" :placeholder="$lang.TIP_BANK_NAME"
							:placeholder-style="$util.setPlaceholder()"></input>
						<view @click="handleShowBankList()"
							style="width:80px;height: 23px;line-height: 23px; background-color:#c7ddff;text-align: center;margin-right: 3px;border-radius: 6px;">
							은행 선택</view>
						<!-- <template v-if="showBankList">
							<input v-model="value1" type="text" :placeholder="$lang.BANK_NAME"
								:placeholder-style="$util.setPlaceholder()" ></input>
						</template>
						<template v-else>
							<view @click="handleShowBankList()" style="width:80px;height: 23px;">은행 선택</view>
						</template> -->
						<u-picker :show="showBankList" :columns="bankList" @cancel="showBankList = false"
							@confirm="handleConfirmBank" :cancelText="$lang.BTN_CANCEL"
							:confirmText="$lang.BTN_CONFIRM"></u-picker>
					</template>
					<template v-else>
						<view style="display: inline-block;min-height: 40rpx;"> {{info.bank_name ||''}}
						</view>
					</template>
				</view>

				<view style="padding-left: 10px;" :style="{color:$theme.TEXT}">{{$lang.BANK_CARD}}</view>
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin-bottom: 30px;padding-left: 10px;">
					<template v-if="isRenewal">
						<input v-model="card_sn" type="text" :placeholder="$lang.TIP_BANK_CARD"
							:placeholder-style="$util.setPlaceholder()"></input>
					</template>
					<template v-else>
						<view style="display: inline-block;min-height: 40rpx;"> {{info.card_sn}}
						</view>
					</template>
				</view>
				<template v-if="isRenewal">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="common_btn btn_primary"
							style="border:1px solid transparent;width: 40%;display: inline-block;margin:10px;"
							@click="replaceBank()">
							{{$lang.BTN_CONFIRM}}
						</view>
						<view class="common_btn btn_secondary"
							style="width: 40%;display: inline-block;margin:10px;" @click="handleCancel()">
							{{$lang.BTN_CANCEL}}
						</view>
					</view>
				</template>
				<template v-else>
					<view class="common_btn btn_primary access_btn" style="width: 100%;" @click="renewal()">
						{{$lang.BTN_CHANGE_BANK_CARD}}
					</view>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_CENTER,
		ACCOUNT_AUTH
	} from '@/common/paths';
	import {
		accountInfo,
		bindBankCard
	} from '@/common/api.js';
	import {
		LIST_BANK
	} from '@/common/config.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				showBankList: false, // 是否显示银行备选列表
				info: {},
				isRenewal: false,
				realname: '', // 开户人
				bank_name: '', // 银行名称
				card_sn: '', // 卡号
			};
		},
		computed: {
			// 银行备选列表， u-picker中需要套一层数组
			bankList() {
				return [LIST_BANK];
			}
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleShowBankList() {
				this.showBankList = true;
			},
			handleConfirmBank(e) {
				console.log('e:', e);
				this.bank_name = e.value[0];
				this.showBankList = false;
			},
			renewal() {
				this.isRenewal = true;
			},
			handleCancel() {
				this.isRenewal = false;
				this.replaceBank();
			},
			// 换绑银行卡
			async replaceBank() {
				const result = await bindBankCard({
					realname: this.realname,
					bank_name: this.bank_name,
					card_sn: this.card_sn,
				})
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			//用户信息
			async gaint_info() {
				const result = await accountInfo();
				console.log(result);
				if (result.code == 0) {
					// 未有真实姓名，跳转到实名认证
					if (!result.data.real_name) {
						uni.navigateTo({
							url: ACCOUNT_AUTH,
						})
					}
					// 未有银行卡信息，自动切换到绑卡状态
					if (!result.data.bank_card_info) {
						this.isRenewal = true;
					} else {
						this.info = result.data.bank_card_info;
					}
				}
			},
		},
	}
</script>