<!-- 银转证  存款 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.PAGE_TITLE_DEPOSIT"></CustomHeader>

		<view class="withdraw_info">
			<view style="display: flex;padding:20px;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">{{$lang.WITHDRAW_AMOUNT}}</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;text-align: center;">
				{{showAmount?$util.formatNumber(userInfo.money)+$lang.CURRENCY_UNIT:hideAmount}}
			</view>
			<view style="color:#f5f5f5;margin-bottom: 10px;text-align: center;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		</view>

		<view
			style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;margin-top: 20px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$theme.TITLE}">
				{{$lang.PAGE_TITLE_DEPOSIT}}
			</view>
		</view>

		<view class="common_block" style="padding: 20px 10px;">
			<view style="margin-left: 10px;color:#AFAFAF;">{{$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT}}</view>
			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin:10px;">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view
				style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:10px;">
				<block v-for="(item,index) in amountList" :key="index">
					<view style="padding:10px;border-radius: 6px;"
						:style="{backgroundColor:curPos==index?$util.RGBConvertToRGBA('#A460FF',49):'#FFF',color:'#333' }"
						@click="quantity(item,index)">
						{{item}}
					</view>
				</block>
			</view>
			<view @click="to_recharge()" class="common_btn btn_primary access_btn" style="width: 100%;">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>

		<view style="padding: 10px;">
			<!-- <view style="font-size: 14px;font-weight: 700;text-align: center;" :style="{color:$theme.TITLE}">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view> -->
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="padding-bottom:6px;color: #999;">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import {
		accountInfo,
		postDeposit
	} from '@/common/api.js';
	import {
		DEPOSIT_AMOUNTS
	} from '@/common/config.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
			};
		},
		computed: {
			amountList() {
				return DEPOSIT_AMOUNTS;
			}
		},
		onLoad(option) {
			this.gaint_info()
			this.amount = this.amountList[0];
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				this.$util.linkCustomerService();
				
				// const result = await postDeposit({
				// 	money: this.amount,
				// 	type: 5,
				// 	image: this.is_url || '',
				// 	desc: this.value2 || '',
				// }, this.$lang.DEPOSIT_POST_TIP);

				// if (result.code == 0) {
				// 	uni.$u.toast(result.message);
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			url: SERVICE
				// 		});
				// 	}, 1000)
				// } else {
				// 	uni.$u.toast(result.message);
				// }
			},

			// //凭证
			// deletePic(event) {
			// 	this[`fileList${event.name}`].splice(event.index, 1)
			// },
			// // 新增图片
			// async afterRead(event) {
			// 	// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
			// 	let lists = [].concat(event.file)
			// 	let fileListLen = this[`fileList${event.name}`].length
			// 	lists.map((item) => {
			// 		this[`fileList${event.name}`].push({
			// 			...item,
			// 		})
			// 	})
			// 	for (let i = 0; i < lists.length; i++) {
			// 		const result = await this.uploadFilePromise(lists[i].url)
			// 		let item = this[`fileList${event.name}`][fileListLen]
			// 		this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
			// 			status: 'success',
			// 			message: '',
			// 			url: result
			// 		}))
			// 		fileListLen++
			// 	}
			// },
			//个人信息
			async gaint_info() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},

			// uploadFilePromise(url) {
			// 	// console.log(url)
			// 	pathToBase64(url).then(base64 => {
			// 			// 这就是转为base64格式的图片
			// 			this.is_url = base64
			// 			// console.log(base64)
			// 		})
			// 		.catch(error => {
			// 			console.error(error)
			// 		})
			// },
		},
	}
</script>