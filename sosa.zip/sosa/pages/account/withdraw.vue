<!-- 실시간 이체 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.PAGE_TITLE_WITHDRAW" ></CustomHeader>
		<view class="withdraw_info">
			<view style="display: flex;padding:20px;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">{{$lang.WITHDRAW_AMOUNT}}</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;text-align: center;">
				{{showAmount?$util.formatNumber(userInfo.money)+$lang.CURRENCY_UNIT:hideAmount}}
			</view>
			<view style="color:#f5f5f5;margin-bottom: 10px;text-align: center;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		</view>

		<view
			style="padding:10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;margin-top: 20px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$theme.TITLE}">
				{{ $lang.WITHDRAW_TITLE}}
			</view>
		</view>

		<view class="common_block" style="padding:20px;margin-top: 10px;margin-bottom: 20px;">
			<view style="padding-left: 10px;" :style="{color:$theme.TEXT}">{{$lang.WITHDRAW_WITH_AMOUNT}}</view>
			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;border-radius: 30px;padding-left: 30px;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;"></input>
				<!-- <view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view> -->
			</view>

			<view style="padding-left: 10px;" :style="{color:$theme.TEXT}">{{$lang.WITHDRAW_PAY_PWD}}</view>
			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin-bottom: 30px;border-radius: 30px;padding-left: 30px;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
					:placeholder-style="$util.setPlaceholder()" style="width: 100%;"></input>
			</view>
			<view class="common_btn btn_primary access_btn" style="width: 100%;" @click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>


		<view style="margin:10px; padding: 20px;" :style="{color:$theme.TITLE}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?'red':$theme.TITLE}">
					{{item}}
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		postWithdarw,
		accountInfo
	} from '@/common/api.js';
	import {
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				const result = await postWithdarw({
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				}, this.$lang.WITHDRAWING_POST_TIP)
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 500)
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>