<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.ACCOUNT_TRADE_LOG"></CustomHeader>

		<view style="padding: 10px 0;background-color: #fef9fe;">
			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(44)"></image>
				<view style="padding-left: 10px; font-size: 36rpx;" :style="{color:$theme.TITLE}">
					{{ $lang.ACCOUNT_TRADE_LOG}}
				</view>
			</view>

			<TabsPrimary :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsPrimary>

			<template v-if="curTab == 0">
				<LogTrade></LogTrade>
			</template>

			<template v-if="curTab == 1">
				<LogDeposit></LogDeposit>
			</template>

			<template v-if="curTab == 2">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			CustomHeader,
			TabsPrimary,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				curTab: 0,
			};
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>