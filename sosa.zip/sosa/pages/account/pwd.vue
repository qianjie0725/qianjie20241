<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.ACCOUNT_CHANGE_PWD" ></CustomHeader>

		<view style="background-color: #fef9fe;">
			<view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/change_pwd.png" :style="$util.setImageSize(600,300)"></image>
			</view>

			<view class="common_block" style="margin: 20px;padding: 20px;">
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(48)">
					</image>
					<input v-model="value" type="password" :placeholder="$lang.TIP_OLD_PWD"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>

				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(48)">
					</image>
					<input v-model="value2" type="password" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>

				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin-bottom: 30px;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(48)">
					</image>
					<input v-model="value3" type="password" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>
				<view class="common_btn btn_primary access_btn" style="width: 100%;" @click="changePassword">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_CENTER
	} from '@/common/paths';
	import {
		putSignInPwd
	} from '@/common/api.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			//修改登录密码
			async changePassword() {
				const result = await putSignInPwd({
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				});
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>