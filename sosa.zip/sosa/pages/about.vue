<!-- 关于我们 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="about.title" ></CustomHeader>
		<view class="common_block" style="margin-top: 10px;min-height: 80vh;">
			<view v-html="about.content"
				style="font-size: 14px;white-space: break-spaces;line-height: 1.3;padding:10px;"
				:style="{color:$theme.TEXT}"></view>
		</view>
	</view>
</template>

<script>
	import {
		getAboutInfo
	} from '@/common/api.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				about: {},
			};
		},
		created() {
			this.getAbout()
		},
		methods: {
			//关于我们
			async getAbout() {
				const result = await getAboutInfo();
				this.about = result.data
			},
		},
	}
</script>