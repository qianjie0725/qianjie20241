<template>
	<view :style="$util.setPageBG('bg_common')">
		<Header></Header>

		<view class="home_bnner"></view>

		<view style="margin-top: 1vh;">
			<ButtonGroup :btns="$util.homeBtns()"></ButtonGroup>
			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(44)"></image>
				<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$theme.TITLE}">
					{{ $lang.STOCK_ALL}}
				</view>
				<view style="font-size: 14px;margin-left: auto;" @click="handleAllList()" :style="{color:$theme.TITLE}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$util.setImageSize(20)"></view>
				</view>
			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>


		<template v-if="isShow && ipoInfo">
			<view class="mask" @click="handleClose()">

				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view style="position:absolute;right:15px;top:15px" @click="handleClose()">
						<image src="/static/close_light.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
					</view>
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;padding: 20px 0;">
						<view style="font-size: 48rpx;font-weight: 700;color: #F2F2F2;">
							축하합니다
						</view>

						<!-- <view>
							<image src="/static/dialog_icon.png" mode="aspectFit" style="$util.setImageSize(480,320)">
							</image>
						</view> -->
						<template v-if="userinfo.real_name">
							<view
								style="text-align: center;font-size: 36rpx;color:#121212;padding-bottom: 16px;line-height: 2.4;">
								{{userinfo.real_name}}
							</view>
						</template>
						<view
							style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
							<view style="font-size: 40rpx;font-weight: 700;color: #FFFFFF;padding:4px 40px;">
								{{ipoInfo.name}}
							</view>
							<view style="font-size: 28rpx;font-weight: 700;color: #f1f1f1;padding:4px 40px;">
								{{ipoInfo.code}}
							</view>

							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;color: #f7f7f7">
								공모주청약 당첨되었습니다
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view style="color: #f7f7f7;">배치 수량</view>
								<text style="font-weight: 700;color:#121212;font-size: 16px;">
									{{$util.formatNumber(ipoInfo.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view style="color: #f7f7f7;">일시금</view>
								<text
									style="font-weight: 700;color:#121212;font-size: 16px;">{{$util.formatNumber(ipoInfo.total)}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1.5;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="linkIPOSuccessLog()">바로보기</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		STOCK_ALL
	} from '@/common/paths.js';
	import {
		getIPOSuccessItem,
		accountInfo
	} from '@/common/api.js';
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			GoodsList,
		},
		data() {
			return {
				isShow: true, // 是否显示ad层,
				ipoInfo: null, // 
				userinfo: {},
				// timer: null,
			}
		},

		onLoad() {
			this.gaint_info()
			this.ipoSuccess()
			console.log('onLoad', this.$refs.goods);
		},

		onShow() {
			console.log('onShow', this.$refs.goods);
			if (this.$refs.goods) {
				this.$refs.goods.onSetTimeout();
			}
		},
		onReady() {
			console.log('onReady', this.$refs.goods);
		},
		onHide() {
			console.log('onHide', this.$refs.goods);
			this.$refs.goods.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.$refs.goods);
			this.$refs.goods.clearTimer();
		},
		methods: {
			// 跳转到全部股票
			handleAllList() {
				uni.navigateTo({
					url: STOCK_ALL
				})
			},
			handleClose() {
				this.isShow = false;
				uni.setStorageSync('show', 1);
			},
			async ipoSuccess() {
				const result = await getIPOSuccessItem();
				console.log(result);
				if (result && result.code == 0) {
					if (result.data.length > 0) {
						const temp = result.data[0];
						this.ipoInfo = {
							code: temp.goods.number_code,
							name: temp.goods.name,
							success: temp.success,
							total: temp.total,
						};
						this.isShow = true;
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
			handleClose() {
				this.isShow = false;
				uni.setStorageSync('show', 1);
			},
			async gaint_info() {
				let list = await accountInfo();
				console.log(list);
				this.userinfo = list.data
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: '/pages/trade/ipo',
				})
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/account/access'
						});
					}, 1000)
				} else {

				}
			},
		},

	}
</script>

<style lang="scss">
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		// background-image: url(/static/new/my_bg.png);
		// background-size: cover;
		// background-position: center;
		// background-repeat: no-repeat;
		background: linear-gradient(to top, #9e9eef, #6492FF);
		height: 40vh;
		width: 80vw;
	}
</style>