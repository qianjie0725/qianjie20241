<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.PAGE_TITLE_SEARCH"></CustomHeader>

		<view style="background-color: #fef9fe;padding:10px;">
			<view style="margin:20px;border:1px solid #C6C6C6;border-radius: 8px;">
				<u-search shape="square" :placeholder="$lang.TIP_SEARCH" v-model="keyword" :showAction="false"
					height="40px" :searchIconColor="$theme.PRIMARY" searchIconSize="30" bgColor="" @clear="keyword=''"
					:actionText="$lang.PAGE_TITLE_SEARCH" @search="searchButton" @custom="searchButton"></u-search>
			</view>

			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(44)"></image>
				<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$theme.TITLE}">
					{{$lang.SEARCH_HISTORY}}
				</view>
				<image mode="aspectFit" src="/static/delete.png" :style="$util.setImageSize(44)"
					style="margin-left: auto;" @click="clearKeywords()"></image>
			</view>

			<view style="display: flex;align-items: center;margin:0 10px;padding:10px;flex-wrap: wrap;">
				<template v-if="keywords.length>0">
					<block v-for="(item,index) in keywords" :key="index">
						<view style="padding:4px 10px;margin:4px;border-radius: 4px;" @click="selectedItem(item)"
							:style="{backgroundColor:$util.RGBConvertToRGBA('#666666',15)}">{{item}}</view>
					</block>
				</template>
			</view>


			<view class="common_block" style="">
				<template v-if="!list || list.length<=0">
					<view
						style="display: flex;align-items: center;flex-direction: column;justify-content: center;padding:30%;">
						<image mode="aspectFit" src="/static/search_result.png" :style="$util.setImageSize(600)">
						</image>
						<view class="font-size-20 text-center" :style="{color:$theme.TITLE}">{{$lang.EMPTY_DATA}}
						</view>
					</view>
				</template>

				<template v-else>
					<view style="display: flex;align-items: center;padding: 10px;border-bottom: 1px solid #A0A0A0;">
						<block v-for="(item,index) in $util.setStockListThead()" :key="index">
							<view style="font-size: 32rpx;"
								:style="{color:$theme.LABEL,flex:item.width,textAlign:item.align}">
								{{item.label}}
							</view>
						</block>
					</view>

					<block v-for="(item,index) in list">
						<view @click="handleStockInfo(item.code)"
							style="padding-top: 24rpx;margin-left:10px;display: flex;align-items: center;margin:0 10px;padding-bottom: 6px;">
							<view style="display: inline-block;flex:6%;">
								<template v-if="!item.logo || item.logo==''">
									<view :style="$util.setImageSize(80)"
										style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">
										{{item.name.slice(0,1)}}
									</view>
								</template>
								<template v-else>
									<image mode="aspectFit" :src="$util.setLogo(item.logo)"
										:style="$util.setImageSize(80)" style="border-radius: 100%;"></image>
								</template>
							</view>

							<view style="flex:44%;padding-left: 6px;font-size: 30rpx;"
								:style="{color:$theme.STOCK_NAME}">
								<view>{{item.name}}</view>
								<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{item.code}}</view>
							</view>
							<view
								style="flex: 25%;text-align: right;margin-right: 20px;font-size: 30rpx;font-weight: 700;"
								:style="$util.setStockRiseFall(item.rate>0)">
								{{$util.formatNumber(item.current_price)}}
							</view>

							<view style="flex:25%;text-align: right;margin-right: 6px;border-radius: 3px;"
								:style="$util.setStockRiseFall(item.rate>0,true)">
								<view style="padding:4px; font-size: 30rpx;font-weight: 700;">
									{{item.rate>0?'+':""}}{{(1*item.rate).toFixed(2)}}%
								</view>
							</view>
							<!-- <view style="flex:5%;">
								unfollow star
								<image mode="aspectFit" src="/static/star.png" :style="$util.setImageSize(36)"
									@click.stop="handleUnFollow(item.gid)"></image>
							</view> -->
						</view>
					</block>
				</template>
			</view>
		</view>
	</view>
</template>
<script>
	import {
		postSearchList,
		updateFollow
	} from '@/common/api.js';
	import {
		STOCK_OVERVIEW
	} from '@/common/paths.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				keyword: "", // 当前关键词
				keywords: [], // 搜索词条组
				list: [], // 搜索结果
				curPage: 1,
				limit: 20,

				// gp_select: [{
				// 	name: "국내",
				// }, {
				// 	name: "해외",
				// }],
				// gp_index: 0,
			};
		},
		onReachBottom() {
			// 只要最大条数20，条件永不成立。
			if (this.list.length > this.limit) {
				this.curPage++;
				this.searchButton();
			}
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
		},
		methods: {
			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`,
				})
			},
			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.searchButton()
			},

			//搜索
			async searchButton() {
				if (this.keyword == '' || this.keyword.length < 3) {
					uni.$u.toast(this.$lang.TIP_SEARCH);
					return false;
				}
				const result = await postSearchList({
					key: this.keyword,
					page: this.curPage,
					limit: this.limit,
					gp_index: 0
				})
				if (result.code == 0) {
					this.list = result.data;
					console.log('search result:', result.data)
					if (this.keywords.indexOf(this.keyword) < 0) {
						this.keywords.push(this.keyword);
						uni.setStorageSync("keywords", this.keywords)
					}
				}
			},
			// 取关
			async handleUnFollow(gid) {
				const result = await updateFollow({
					gid: gid,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.getList()
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>