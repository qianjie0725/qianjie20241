<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="개인 계좌 연동" @action="home()"></CustomHeader>

		<view
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:10vh;">
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/user.png" :style="$util.setImageSize(20)" style="padding:0 10px;">
				</image>
				<input v-model="value" type="text" :placeholder="$lang.REAL_NAME"></input>
			</view>
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/bank.png" :style="$util.setImageSize(20)" style="padding:0 10px;">
				</image>
				<input v-model="value2" type="text" :placeholder="$lang.BANK_NAME"></input>
			</view>
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/card1.png" :style="$util.setImageSize(20)"
					style="padding:0 10px;"></image>
				<input v-model="value4" type="text" :placeholder="$lang.BANK_CARD"></input>
			</view>
			<view class="common_btn" style="width:50%;margin-top: 20px;" @click="replaceBank">확인</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value: '',
				value2: '',
				value3: '',
				value4: ''
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value2,
					bank_sub_name: this.value3,
					card_sn: this.value4,
				})
				if (list.data.code == 0) {
					uni.$u.toast('은행 카드 정보가 성공적으로 제출되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
		// created() {
		// 	this.replaceBank()
		// },
	}
</script>