<!-- 申购 记录 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="전체내역" ></CustomHeader>
		<view class="common_block" style="padding:20px 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px solid #ccc;margin: 4px 20px;background-color: #FFF;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>{{item.goods.name}}</view>
						<!-- 		<text v-if="item.status==0">未中签</text>
								<text v-if="item.status==1">申购中</text>
								<text v-if="item.status==2">申购中签</text>
								<text v-if="item.status==3">已구독하다金额</text>
								<text v-if="item.status==4">中签弃奖</text>
								<text v-if="item.status==5">已上市</text> -->
						<view style="font-size: 16px;color:#ea3544;">{{item.message}}</view>
					</view>
					<view style="display: flex;align-items: center;padding-bottom: 6px;">
						<view style="flex:20%;" :style="{color:$theme.TITLE}">청약 금액</view>
						<view :style="{color:$theme.PRIMARY}"
							style="flex:30%;text-align: right;padding-right: 20px;">
							{{$util.formatNumber(item.price)}}<text style="padding:0 4px">원</text>
						</view>
						<view style="flex:20%;" :style="{color:$theme.TITLE}">청약 수량</view>
						<view :style="{color:$theme.PRIMARY}" style="flex:30%;text-align: right;">
							{{$util.formatNumber(item.apply_amount)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view :style="{color:$theme.TITLE}">청약 총금액</view>
						<view style="font-size: 16px;" :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.apply_num_amount)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.TITLE}">
						<view>매입 시간</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.TITLE}">
						<view>거래 코드</view>
						<view>{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onLoad(option) {
			this.shengou();
		},
		methods: {
			// 新股申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
	}
</script>