<!-- 折价交易 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.PAGE_TITLE_TRADE_DISCOUNT"></CustomHeader>
		<view style="background-color: #fef9fe;padding-bottom: 20px;">
			<view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/trade_large_bnner.png" :style="$util.setImageSize(600,300)"></image>
			</view>

			<view class="common_block" style="background-color: #a35bfe;border-radius: 8px;padding-bottom: 10px;">
				<view class="large_tab_wrapper">
					<view class="large_tab_item " :class="curTab==0?'large_tab_active_left':'large_tab_unactive_left'"
						@click="handleChangeTab(0)">{{$lang.TRADE_LARGE_TABS[0]}}</view>
					<view class="large_tab_item " :class="curTab==1?'large_tab_active_rigt':'large_tab_unactive_rigt'"
						@click="handleChangeTab(1)">{{$lang.TRADE_LARGE_TABS[1]}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
					<view style="display: flex;align-items: center;">
						<image src="/static/icon1.png" :style="$util.setImageSize(40)"></image>
						<text style="padding-left: 10px;color:#FFFFFF">{{$lang.TRADE_LARGE_TAB1_TITLES[0]}}</text>
					</view>
					<view style="display: flex;align-items: center;">
						<image src="/static/icon2.png" :style="$util.setImageSize(40)"></image>
						<text style="padding-left: 10px;color:#FFFFFF">{{$lang.TRADE_LARGE_TAB1_TITLES[1]}}</text>
					</view>
				</view>

				<template v-if="curTab==0">
					<TradeDiscountLog></TradeDiscountLog>
				</template>
				<template v-else>
					<view style="padding: 10px;">
						<EmptyData v-if="list.length<=0"></EmptyData>
						<block v-for="(item,index) in list" :key="index">
							<view
								style="margin-bottom: 20px;background-color: #FFFFFF;border-radius: 8px;padding: 10px;">
								<TradeStockItem :item="item" @action="handleDetail"></TradeStockItem>
							</view>
						</block>
					</view>
				</template>
			</view>
		</view>
		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" style="color:#FFFFFF">{{$lang.TRADE_LARGE_ORDER_TITLE}}</view>
					<view
						style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
						<text :style="{color:$theme.TIP}">{{$lang.TRADE_LARGE_BUY_AMOUNT}}</text>
						<text :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(detail.price)}}{{$lang.CURRENCY_UNIT}}</text>
					</view>
					<view class="common_input_wrapper"
						style="margin:20px;background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;padding-left: 20px;">
						<input v-model="amount" :placeholder="$lang.TRADE_LARGE_TIP_BUY_COUNT" type="number"
							style="width: 80%;" :placeholder-style="$util.setPlaceholder()"></input>
						<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
					</view>

					<template v-if="leverList.length>1">
						<view class="common_input_wrapper"
							style="margin:20px;background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
							<image mode="aspectFit" src='/static/leverage.png' :style="$util.setImageSize(36)"> </image>
							<block v-for="(item,index) in leverList" :key="index">
								<text @click="handleChgangeLever(index)" style="display: inline-block;padding:0 16px;"
									:style="{borderBottom:`2px solid ${index==current? $theme.PRIMARY:'transparent'}`,color:index==current?$theme.PRIMARY:$theme.TEXT}">{{item.name}}</text>
							</block>
						</view>
					</template>

					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_BUY_TOTAL_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(buyAmount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view class="common_input_wrapper"
						style="margin:20px;background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;padding-left: 20px;">
						<input v-model="password" :placeholder="$lang.TRADE_LARGE_TIP_BUY_PWD" type="password" :placeholder-style="$util.setPlaceholder()"></input>
					</view>

					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<text :style="{color:$theme.TITLE}">{{$lang.TIP_AMOUNT_AVAIL}}</text>
						<text :style="{color:$theme.PRIMARY}">
							{{availBal}} {{$lang.CURRENCY_UNIT}}</text>
					</view>

					<view style="display: flex;justify-content: space-evenly;margin:20px 0;transform: scaleY(0.75);">
						<view class="common_btn btn_primary" style="width: 30%;" @click="handleConfirm">
							{{$lang.BTN_BUY}}
						</view>
						<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.BTN_CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		getTradeDiscountList,
		getTradeDiscountDetail,
		postTradeDiscountBuy,
		userFastInfo,
	} from '@/common/api.js';

	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeDiscountLog from '@/components/trade/TradeDiscountLog.vue';
	import TradeStockItem from '@/components/trade/TradeStockItem.vue';

	export default {
		components: {
			CustomHeader,
			EmptyData,
			TradeDiscountLog,
			TradeStockItem,
		},
		data() {
			return {
				curTab: 1, // 默认放在产品列表，即右边
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		onShow() {
			this.getList()
			this.available()
		},
		computed: {
			// 当前选择杠杆值
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / Number(this.curLever.index);
			}
		},
		methods: {
			// tab切换
			handleChangeTab(val) {
				this.curTab = val;
				if (this.curTab == 1) {
					this.getList();
				}
			},

			handleChgangeLever(val) {
				this.current = val;
			},
			async handleDetail(id) {
				console.log('id:', id);
				this.isShow = true;
				const result = await getTradeDiscountDetail(id);
				console.log('result:', result);
				this.detail = result.data;
			},
			handleCancel() {
				this.isShow = false;
				this.amount = "";
				this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_PWD);
					return false;
				}
				return true;
			},
			async buy() {
				const result = await postTradeDiscountBuy({
					id: this.detail.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever.index,
				})
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.isShow=false;
					this.handleChangeTab(0);
				} else {
					this.isShow=false;
					uni.$u.toast(result.message);
				}
			},
			async getList() {
				const result = await getTradeDiscountList();
				if (result.code == 0 && result.data) {
					this.list = result.data.filter(item => item.gid && item.gid > 0);
				} else {
					uni.$u.toast(result.message);
				}
			},
			async available() {
				const result = await userFastInfo();
				this.availBal = this.$util.formatNumber(result.data.money);
				this.leverList = [{
					name: 1,
					index: 1
				}];
				if (result.data.ganggan) {
					this.leverList.push(...result.data.ganggan);
				}
			},
		},
	}
</script>