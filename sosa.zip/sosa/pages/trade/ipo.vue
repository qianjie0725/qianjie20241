<!-- 新股申购 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.PAGE_TITLE_TRADE_IPO"></CustomHeader>

		<view style="background-color: #fef9fe;padding-bottom: 20px;">
			<view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/trade_large_bnner.png" :style="$util.setImageSize(600,300)"></image>
			</view>

			<view class="common_block" style="background-color: #a35bfe;border-radius: 8px;">
				<view class="large_tab_wrapper">
					<view class="large_tab_item " :class="curTab==0?'large_tab_active_left':'large_tab_unactive_left'"
						@click="handleChangeTab(0)">{{$lang.TRADE_IPO_TABS[0]}}</view>
					<view class="large_tab_item " :class="curTab==1?'large_tab_active_rigt':'large_tab_unactive_rigt'"
						@click="handleChangeTab(1)">{{$lang.TRADE_IPO_TABS[1]}}
					</view>
				</view>

				<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
					<view style="display: flex;align-items: center;">
						<image src="/static/icon1.png" :style="$util.setImageSize(40)"></image>
						<text style="padding-left: 10px;color:#FFFFFF">{{$lang.TRADE_IPO_TAB1_TITLES[0]}}</text>
					</view>
					<view style="display: flex;align-items: center;" @click="handleBuySuccess()">
						<image src="/static/icon2.png" :style="$util.setImageSize(40)"></image>
						<text style="padding-left: 10px;color:#FFFFFF">{{$lang.TRADE_IPO_TAB1_TITLES[1]}}</text>
					</view>
				</view> -->

				<view class="common_block" style="padding:10px;margin-bottom: 20px;">
					<template v-if="curTab == 1">
						<TradeIPOLog></TradeIPOLog>
					</template>

					<template v-else>
						<EmptyData v-if="list.length<=0"></EmptyData>
						<block v-for="(item,index) in list" :key="index">
							<view :class="index==list.length-1?'':'line'" style="padding: 10px;">
								<TradeStockItem :item="item" @action="handleDetail"></TradeStockItem>
							</view>
						</block>
					</template>
				</view>

				<u-modal :show="show" :title="$lang.TRADE_IPO_MODAL_TITLE" @cancel="cancel" @confirm="confirm()"
					:showCancelButton='true' :content='$lang.TRADE_IPO_MODAL_CONTENT' :cancelText="$lang.BTN_CANCEL"
					:confirmText="$lang.BTN_CONFIRM">
				</u-modal>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getIPOList,
		postBuyIPO
	} from '@/common/api.js';
	import {
		TRADE_IPO_SUCCESS
	} from '@/common/paths.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeIPOLog from '@/components/trade/TradeIPOLog.vue';
	import TradeStockItem from '@/components/trade/TradeStockItem_t.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
			TradeIPOLog,
			TradeStockItem,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
				list: [],
				curId: '', // 当前选中数据的ID值
				show: false, // 购买前二次确认的弹层
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			// tab切换
			handleChangeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) {
					this.getList();
				}
			},

			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.curId = val;
				this.show = true;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase()
				this.show = false;
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				const result = await postBuyIPO({
					// num: this.value,
					id: this.curId,
					// price: this.price
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						this.handleChangeTab(1);
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			async getList() {
				const result = await getIPOList({
					type: this.curTab + 1, // 传参 1或2
				})
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},

			//우승기록 获胜记录
			handleBuySuccess() {
				uni.navigateTo({
					url: TRADE_IPO_SUCCESS
				});
			},
		}
	}
</script>