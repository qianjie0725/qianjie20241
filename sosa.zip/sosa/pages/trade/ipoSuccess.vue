<!-- 우승기록 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.TRADE_IPO_SUCCESS_TITLE"></CustomHeader>

		<view class="common_block" style="padding:20px 10px;margin-bottom: 20px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px solid #ccc;margin: 4px;background-color: #FFF;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view style="font-size: 36rpx;">{{item.goods.name}}</view>
						<view style="font-size: 16px;color:seagreen;">
							<template v-if="item.status==2">
								<view @click="subscription(item)">
									{{$lang.TRADE_IPO_SUCCESS_LOG_LABELS[0]}}
								</view>
							</template>
							<template v-else>
								<view>{{item.message}}</view>
							</template>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TADE_IPO_SUB_PRICE}}</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;">
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_SUCCESS_APPLY_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.apply_amount)}}
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_SUCCESS_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.success)}}
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_SUCCESS_NUM_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}" style="text-align: right;">
							{{$util.formatNumber(item.success_num_amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.TIP}">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_SUCCESS_ORDER_SN}}</view>
						<view>{{item.order_sn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.TIP}">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_SUCCESS_CT}}</view>
						<view>{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		getIPOSuccessList,
		postIPOPay
	} from '@/common/api.js';
	import {
		TRADE_IPO_SUCCESS
	} from '@/common/paths.js';
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		onLoad(option) {
			this.shengou()
		},
		methods: {
			// 우승기록
			async shengou(e) {
				const result = await getIPOSuccessList();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
			async subscription(item) {
				const result = await postIPOPay({
					id: item.id
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					if (result.data.success == 0) {
						setTimeout(() => {
							this.$util.linkCustomerService();
						}, 500)
					} else {
						uni.redirectTo({
							url: TRADE_IPO_SUCCESS,
						});
						this.$router.go(0)
					}
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>