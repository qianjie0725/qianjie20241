<template>
	<view style="padding-bottom: 20px;">
		<template v-if="stockInfo">
			<view class="common_block" style="padding: 10px;">
				<view style="margin:10px;background-color:#FFF;">
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[0]}}</view>
						<view style="flex:70%;text-align: right;">{{$lang.STOCK_BASE_INFO[1]}}<text
								style="padding:0 10px;"
								:style="{color:$theme.PRIMARY}">{{stockInfo.top1.marketcap_rank}}</text></view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[2]}}</view>
						<view style="flex:70%;text-align: right;"><text
								style="padding:0 10px;">{{$util.formatNumber(stockInfo.top1.marketcap)}}</text></view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[3]}}</view>
						<view style="flex:70%;text-align: right;"><text
								style="padding:0 10px;">{{$util.formatNumber(stockInfo.top1.sharesout)}}</text>{{$lang.QUANTITY_UNIT}}
						</view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[4]}}</view>
						<view style="flex:70%;text-align: right;"><text
								style="padding:0 10px;">{{$util.formatNumber(stockInfo.top1.foreigners_pie)}}</text>%
						</view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:20%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[5]}}</view>
						<view style="flex:30%;text-align: right;">{{stockInfo.top1.sector}}
						</view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[6]}}</view>
						<view style="flex:20%;text-align: right;">{{stockInfo.top1.industry}}</view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:20%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[7]}}</view>
						<view style="flex:30%;text-align: right;" :style="{color:'red'}">
							{{$util.formatNumber(stockInfo.top1.year_high)}}
						</view>
					</view>
					<view style="display:flex;align-items: center;padding:4px 0;">
						<view style="flex:20%;" :style="{color:$theme.TITLE}">{{$lang.STOCK_BASE_INFO[8]}}</view>
						<view style="flex:30%;text-align: right;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(stockInfo.top1.year_low)}}
						</view>
					</view>
				</view>
			</view>


			<view
				style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 10px;padding-left: 0;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$theme.TITLE}">
					{{$lang.STOCK_COMPANY}}
				</view>
				<view style="flex:10%;text-align: right;color:#999;" @click="changeCompanyInfo()">
					{{fullCompanyInfo? $lang.BRIEF:$lang.MORE }}
				</view>
			</view>

			<view class="about common_block" style="padding: 4px 10px;">
				<view class="txt" :class="fullCompanyInfo?'':'show'" style="white-space:pre-wrap;margin-top: 0;"
					:style="{color:$theme.TEXT}">
					{{stockInfo.top2.description}}
				</view>
			</view>

			<view style="margin-top:10px;display: flex;align-items: center;padding: 10px 20px;">
				<block v-for="(item,index) in $lang.STOCK_SALES_TABS" :key="index">
					<view style="flex:28%;text-align: center;font-size: 28rpx;font-weight: 700;"
						:style="$util.setTabThird(curSales==index)" @click="changeSalesTab(index)">{{item}}</view>
				</block>
				<view style="flex:44%;text-align: right;">
					{{stockInfo.top3[0].report_year_month}}
				</view>
			</view>

			<view class="common_block" style="padding: 10px 6px;">
				<template v-if="salesData.length>0">
					<view style="display: flex;align-items: center;">
						<block v-for="(item,index) in formatSalesData">
							<view class="common_block" style="flex:33%;margin: 6px;padding: 6px;text-align: center;">
								<view style="line-height: 1.8;" :style="{color:$theme.PRIMARY}">{{item.label}}</view>
								<view style="font-size: 28rpx;font-weight: 700;line-height: 1.8;"
									:class="item.rate>0? 'rise':'fall'">
									{{$util.formatNumber(item.amount)}}{{$lang.UNIT_BILION}}
								</view>
								<view style="font-size: 24rpx;line-height: 1.8;" :class="item.rate>0? 'rise':'fall'">
									{{$util.formatNumber(item.rate,2)}}%
								</view>
							</view>
						</block>
					</view>
				</template>
			</view>

			<view style="margin-top:10px;display: flex;align-items: center;padding: 10px 20px;">
				<block v-for="(item,index) in $lang.STOCK_SALES_KLINE_TABS" :key="index">
					<view style="flex:33%;text-align: center;font-size: 28rpx;font-weight: 700;"
						:style="$util.setTabThird(curSalesKline==index)" @click="changeSalesKlineTab(index)">{{item}}
					</view>
				</block>
			</view>
			<view class="common_block" style="padding: 10px 6px;">
				<view id="main" class="chart">
					<canvas canvas-id="zhexian" id="zhexian" class="charts" />
				</view>
			</view>

			<view
				style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 10px;padding-left: 0;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$theme.TITLE}">
					{{$lang.STOCK_TRADE_TREND_TITLE}}
				</view>
			</view>

			<view class="common_block" style="padding:10px;">
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view>{{$lang.STOCK_TRADE_TREND_BUY_AMOUNT[0]}}</view>
					<view style="flex:10%;text-align: right;" @click="txt_show=false" :style="{color:$theme.TIP}">
						{{stockInfo.top4['net_volume'].dt}}
					</view>
				</view>
				<view style="display: flex;align-items: center;margin:10px 0">
					<view style="flex:33%;text-align: center;border-right: 1px solid #999;line-height: 1.5;">
						<view>{{$lang.STOCK_TRADE_TREND_INFO_TITLE[0]}}</view>
						<view :class="stockInfo.top4['net_volume'].net_vol_individual>0?'rise':'fall'">
							{{$util.formatNumber(stockInfo.top4['net_volume'].net_vol_individual)}}
						</view>
					</view>
					<view style="flex:33%;text-align: center;border-right: 1px solid #999;line-height: 1.5;">
						<view>{{$lang.STOCK_TRADE_TREND_INFO_TITLE[1]}}</view>
						<view :class="stockInfo.top4['net_volume'].net_vol_institutional>0?'rise':'fall'">
							{{$util.formatNumber(stockInfo.top4['net_volume'].net_vol_institutional)}}
						</view>
					</view>
					<view style="flex:33%;text-align: center;line-height: 1.5;">
						<view>{{$lang.STOCK_TRADE_TREND_INFO_TITLE[2]}}</view>
						<view :class="stockInfo.top4['net_volume'].net_vol_foreigner>0?'rise':'fall'">
							{{$util.formatNumber(stockInfo.top4['net_volume'].net_vol_foreigner)}}
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view>{{$lang.STOCK_TRADE_TREND_BUY_AMOUNT[1]}}</view>
					<!-- <view style="flex:10%;text-align: right;" @click="txt_show=false"
						:style="{color:$theme.TIP}">기준 {{stockInfo.top4['net_volume'].dt}}</view> -->
				</view>
				<view style="display: flex;align-items: center;margin:10px 0">
					<view style="flex:33%;text-align: center;border-right: 1px solid #999;line-height: 1.5;">
						<view>{{$lang.STOCK_TRADE_TREND_INFO_TITLE[0]}}</view>
						<view :class="stockInfo.top4['cum_volume'].cum_vol_individual>0?'rise':'fall'">
							{{$util.formatNumber(stockInfo.top4['cum_volume'].cum_vol_individual)}}
						</view>
					</view>
					<view style="flex:33%;text-align: center;border-right: 1px solid #999;line-height: 1.5;">
						<view>{{$lang.STOCK_TRADE_TREND_INFO_TITLE[1]}}</view>
						<view :class="stockInfo.top4['cum_volume'].cum_vol_institutional>0?'rise':'fall'">
							{{$util.formatNumber(stockInfo.top4['cum_volume'].cum_vol_institutional)}}
						</view>
					</view>
					<view style="flex:33%;text-align: center;line-height: 1.5;">
						<view>{{$lang.STOCK_TRADE_TREND_INFO_TITLE[2]}}</view>
						<view :class="stockInfo.top4['cum_volume'].cum_vol_foreigner>0?'rise':'fall'">
							{{$util.formatNumber(stockInfo.top4['cum_volume'].cum_vol_foreigner)}}
						</view>
					</view>
				</view>

				<view style="background-color: #ebdcff;line-height: 2;padding: 0 10px;border-radius: 6px;">
					{{$lang.STOCK_TRADE_TREND_RECENT_TITLE}}
				</view>

				<template v-if="stockInfo.top5">
					<block v-for="(item,index) in stockInfo.top5" :key="index">
						<view :class="index==stockInfo.top5.length-1?'':'line'" style="padding: 10px;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>{{$lang.STOCK_TRADE_TREND_RECENT_LABELS[0]}}</view>
								<view>{{item.dt}}</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>{{$lang.STOCK_TRADE_TREND_RECENT_LABELS[1]}}</view>
								<view :class="item.net_vol_individual>0?'rise':'fall'">
									{{$util.formatNumber(item.net_vol_individual)}}
								</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>{{$lang.STOCK_TRADE_TREND_RECENT_LABELS[2]}}</view>
								<view :class="item.net_vol_institutional>0?'rise':'fall'">
									{{$util.formatNumber(item.net_vol_institutional)}}
								</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>{{$lang.STOCK_TRADE_TREND_RECENT_LABELS[2]}}</view>
								<view :class="item.net_vol_foreigner>0?'rise':'fall'">
									{{$util.formatNumber(item.net_vol_foreigner)}}
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>


			<view
				style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 10px;padding-left: 0;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$theme.TITLE}">
					{{$lang.STOCK_TRADE_TREND_PIE_TITLE}}
				</view>
			</view>
			<view class="common_block">
				<view class="list" style="background-color: #FFF;margin:0px;padding:0 10px;border:none">
					<view class="flex flex-b">
						<canvas canvas-id="huan1" id="huan1" class="charts" />
					</view>
				</view>
			</view>

			<view
				style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 10px;padding-left: 0;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$theme.TITLE}">
					{{$lang.STOCK_TRADE_SELL_EMPTY_TITLE}}
				</view>
			</view>

			<view class="common_block">
				<view style="display: flex;align-items: center;padding:10px;">
					<block v-for="(item,index) in $util.setSellEmptyData(stockInfo.top7)">
						<view class="common_block" style="flex:49%;margin: 6px;padding: 6px;">
							<view style="line-height: 1.8;font-size: 32rpx;font-weight: 700;">{{item.title}}</view>
							<view style="line-height: 1.5;">{{item.desc}}</view>
							<view style="font-size: 32rpx;font-weight: 700;line-height: 1.8;text-align: center;"
								:class="item.rate>0? 'rise':'fall'">
								{{$util.formatNumber(item.amount)}}{{$lang.QUANTITY_UNIT}}
							</view>
							<view style="font-size: 24rpx;line-height: 1.8;text-align: center;"
								:class="item.rate>0? 'rise':'fall'">
								{{$util.formatNumber(item.rate,2)}}%
							</view>
							<view style="line-height: 1.8;text-align: right;">{{item.dt}}</view>
						</view>
					</block>
				</view>
			</view>

			<view
				style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 10px;padding-left: 0;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(40)"></image>
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$theme.TITLE}">
					{{$lang.STOCK_INDUSTRY_TITLE}}
				</view>
				<view style="flex:10%;text-align: right;" @click="txt_show=false" :style="{color:$theme.TIP}">
					{{$lang.STOCK_INDUSTRY_DESC}}
					{{stockInfo.top8.count}} {{$lang.STOCK_INDUSTRY_DESC_SUFFIX}}
				</view>
			</view>
			<view class="common_block" style="padding: 10px;margin: 10px;">
				<view style="display: flex;align-items: center;flex-wrap: wrap;">
					<view class="common_block" style="flex:99%;margin: 6px;padding: 6px;">
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_LABELS[0]}}</view>
							<view>{{stockInfo.top8.marketcap_rank}}{{$lang.UNIT_POS}}</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.marketcap>0)">
								{{stockInfo.top8.marketcap}}{{$lang.UNIT_BILION}}
							</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.marketcap_avg>0)">
								{{stockInfo.top8.marketcap_avg}} {{$lang.UNIT_BILION}}
							</view>
						</view>
					</view>

					<view class="common_block" style="flex:99%;margin: 6px;padding: 6px;">
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_LABELS[1]}}</view>
							<view>{{stockInfo.top8.net_income_growth_rank}}{{$lang.UNIT_POS}}</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.net_income_growth>0)">
								{{stockInfo.top8.net_income_growth}}%
							</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.net_income_growth_avg>0)">
								{{stockInfo.top8.net_income_growth_avg}}%
							</view>
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;flex-wrap: wrap;">
					<view class="common_block" style="flex:99%;margin: 6px;padding: 6px;">
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_LABELS[2]}}</view>
							<view>{{stockInfo.top8.debt_ratio_rank}}{{$lang.UNIT_POS}}</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.debt_ratio>0)">
								{{stockInfo.top8.debt_ratio}}%
							</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.debt_ratio_avg>0)">
								{{stockInfo.top8.debt_ratio_avg}}%
							</view>
						</view>
					</view>
					<view class="common_block" style="flex:99%;margin: 6px;padding: 6px;">
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_LABELS[3]}}</view>
							<view>{{stockInfo.top8.per_rank}}{{$lang.UNIT_POS}}</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.per>0)">
								{{stockInfo.top8.per}}배
							</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.per_avg>0)">
								{{stockInfo.top8.per_avg}}배
							</view>
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;flex-wrap: wrap;">
					<view class="common_block" style="flex:99%;margin: 6px;padding: 6px;">						
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_LABELS[4]}}</view>
							<view>{{stockInfo.top8.pbr_rank}}{{$lang.UNIT_POS}}</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.pbr>0)">
								{{stockInfo.top8.pbr}}배
							</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.pbr_avg>0)">
								{{stockInfo.top8.pbr_avg}}배
							</view>
						</view>
					</view>
					<view class="common_block" style="flex:99%;margin: 6px;padding: 6px;">
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_LABELS[5]}}</view>
							<view>{{stockInfo.top8.roe_rank}}{{$lang.UNIT_POS}}</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.roe>0)">
								{{stockInfo.top8.roe}}%
							</view>
						</view>
						<view style="display: flex;align-items: center; justify-content: space-between;">
							<view>{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
							<view :style="$util.setStockRiseFall(stockInfo.top8.roe_avg>0)">
								{{stockInfo.top8.roe_avg}}%
							</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		getStockInfoMore,
		getStockInfoSales
	} from '@/common/api.js';
	import zhexian from '@/common/zhexian.js';
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name: 'InfoTwo',
		props: ['code', 'id'],
		data() {
			return {
				stockInfo: null, // 单股概况
				curSales: 0, // 销售额tab选中项
				salesData: [], // 销售额
				formatSalesData: [], // 格式化销售额
				curSalesKline: 0, // 当前显示Kline数据
				curSalesKlinePos: 29, // 当前显示Kline的销售额数组中，下标值。(29:销售额;32:盈利;36:净利)
				cWidth: 750,
				cHeight: 500,
				fullCompanyInfo: false,
			}
		},
		created() {
			this.getStockInfo();
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(750);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
			//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
		},

		onLoad() {},
		methods: {
			// 公司简介
			changeCompanyInfo() {
				this.fullCompanyInfo = !this.fullCompanyInfo;
			},

			// 季度年度 销售额切换
			changeSalesTab(val) {
				this.curSales = val;
				if (this.curSales == 0) {
					this.getStockInfo()
				} else {
					this.getStockInfoYear()
				}
			},

			// 销售额 Kline切换
			changeSalesKlineTab(val) {
				this.curSalesKline = val;
				this.curSalesKlinePos =
					this.curSalesKline == 1 ? 32 :
					this.curSalesKline == 2 ? 36 : 29;
				this.genKLine()
			},

			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "ring",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					series: data.series,
					animation: true,
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					fontSize: 13,
					fontColor: "#666666",
					dataLabel: true,
					dataPointShape: true,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					enableScroll: false,
					enableMarkLine: false,
					legend: {
						show: true,
						position: "right",
						lineHeight: 25,
						float: "left",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						hiddenColor: "#CECECE",
						itemGap: 10
					},
					// title: {
					//   name: "2,515억",
					//   fontSize: 15,
					//   color: "#666666",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					// subtitle: {
					//   name: "자산총계",
					//   fontSize: 25,
					//   color: "#7cb5ec",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					extra: {
						ring: {
							ringWidth: 30,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF",
							centerColor: "#FFFFFF",
							customRadius: 0,
							linearType: "none"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: true,
							legendShape: "auto",
							splitLine: true,
							horizentalLine: false,
							xAxisLabel: false,
							yAxisLabel: false,
							labelBgColor: "#FFFFFF",
							labelBgOpacity: 0.7,
							labelFontColor: "#666666"
						}
					}
				});
			},

			async getStockInfo() {
				const result = await getStockInfoMore({
					code: this.code,
					stock_id: this.id,
				});
				this.stockInfo = result.data[0];
				console.log('stockInfo:', this.stockInfo);
				this.salesData = this.stockInfo.top3; // 季度销售额
				this.formatSalesData = this.$util.setSalesData(this.salesData, this.curSales);
				this.genKLine(); // 处理并显示折线数据
				let res = {
					series: [{
						data: result.data[0].top6
					}]
				};
				this.drawCharts('huan1', res);
			},

			// 生成折线数据，并显示
			genKLine() {
				let res = {
					categories: this.salesData.map(item => item.report_year_month),
					series: [{
						name: "",
						data: this.salesData.map(item => item.fields[this.curSalesKlinePos].value / 100000000),
					}]
				};
				const ctx = uni.createCanvasContext("zhexian", this);
				uChartsInstance["zhexian"] = new uCharts(zhexian.Charts(ctx, res, this.cWidth, this.cHeight))
			},
			// 获取年度销售额
			async getStockInfoYear() {
				const result = await getStockInfoSales({
					code: this.code,
					stock_id: this.id
				})
				console.log('getStockInfoYear:', result);
				this.salesData = result.data[0].top3; // 年度销售额
				this.formatSalesData = this.$util.setSalesData(this.salesData, this.curSales);
				this.changeSalesKlineTab(0)
			},
		},
	}
</script>
<style scoped>
	.charts {
		width: 750rpx;
		height: 500rpx;
	}
</style>
<style lang="scss">
	.about {
		.txt {
			margin-top: 16px;
			color: #333;
			line-height: 26px;
		}

		.txt.show {
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
		}
	}
</style>