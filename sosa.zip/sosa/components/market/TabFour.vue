<template>
	<view class="common_block" style="margin-top: 20px;">
		<TabsSecond :tabs="$lang.MARKET_NEWS_TABS" @action="handleChangeTab"></TabsSecond>
		<view style="margin-top: 20px;padding: 0 10px;">
			<block v-for="(item,index) in list" :key="index">
				<view @click="open(item.url)" class="line"
					style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;">
					<template v-if="curTab==0">
						<view style="flex:60%;padding-right: 30px;padding-top: 10px;">
							<view>{{item.title}}</view>
							<view style="margin:6px;margin-top: 16px;"><text
									style="color:#FFFFFF;padding: 4px 10px;border-radius: 8px;"
									:style="{backgroundColor:$util.RGBConvertToRGBA('#663BF5',70),textAlign:curTab!=0?'right':''}">{{$util.formatDate(item.updated_at)}}</text>
							</view>
						</view>
						<image :src="item.pic" :style="$util.setImageSize(200,150)" mode="aspectFit" style="border-radius: 10px;"></image>
					</template>
					<template v-else>
						<view style="flex:100%">
							<view>{{item.title}}</view>
							<view style="margin:6px;margin-top: 16px;text-align: right;"><text
									style="color:#FFFFFF;padding: 4px 10px;border-radius: 8px;"
									:style="{backgroundColor:$util.RGBConvertToRGBA('#663BF5',70)}">{{$util.formatDate(item.updated_at)}}</text>
							</view>
						</view>
					</template>
				</view>
			</block>

			<view style="text-align: center;color: #999;margin-top: 20px;">{{$lang.MARKET_NEWS_TIP}} </view>
		</view>
	</view>
</template>

<script>
	import {
		getMarketNews
	} from '@/common/api.js';
	import TabsSecond from '@/components/TabsSecond.vue';
	export default {
		name: 'TabFour',
		components: {
			TabsSecond
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getList();
		},
		methods: {
			handleChangeTab(val) {
				this.curTab = val;
				this.getList();
			},
			open(url) {
				window.open(url)
			},
			async getList() {
				const result = await getMarketNews({
					current: this.curTab
				});
				this.list = result.data;
			},
		},
	}
</script>