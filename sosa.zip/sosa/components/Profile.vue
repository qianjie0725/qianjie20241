<!-- 用户基本信息 -->
<template>
	<view>
		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<view style="flex:20%;text-align: center;" @click="handleLink()">
				<image style="border-radius: 100px;border:3px solid #a35bfe;" mode="aspectFit"
					:src="info.avatar?info.avatar:'/static/avatar.png'" :style="$util.setImageSize(130)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 36rpx;text-align: left;color:#FFFFFF;">
					{{info.nick_name}}
				</view>
				<view style="font-size:26rpx;text-align: left;color:#3C1E20;">
					{{info.p_mobile}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_AVATAR
	} from '@/common/paths.js';
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入信息修改页面
			handleLink() {
				uni.navigateTo({
					url: ACCOUNT_AVATAR,
				})
			},
		}
	}
</script>

<style>

</style>