<template>
	<view class="empty">
		<image src="/static/search_result.png" mode="aspectFit" :style="$util.setImageSize(400)"></image>
		<view :style="{color:color}">{{$lang.EMPTY_DATA}}</view>
	</view>
</template>

<script>
	export default {
		name: "EmptyData",
		props: {
			color: {
				type: String,
				default: '#121212',
			}
		},
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>