<template>
	<view class="common_block" style="padding-bottom: 6px;border-top-left-radius: 10px;border-top-right-radius: 10px;">
		<view style="display: flex;align-items: center;padding: 10px;border-bottom: 1px solid #A0A0A0;">
			<block v-for="(item,index) in $util.setStockListThead()" :key="index">
				<view style="font-size: 32rpx;" :style="{color:$theme.LABEL,flex:item.width,textAlign:item.align}">
					{{item.label}}
				</view>
			</block>
		</view>

		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.code)"
				style="padding-top: 24rpx;margin-left:10px;display: flex;align-items: center;">
				<view style="flex:6%;">
					<template v-if="!item.logo || item.logo==''">
						<view :style="$util.setImageSize(80)"
							style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">
							{{item.ko_name.slice(0,1)}}
						</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" :style="$util.setImageSize(80)"
							style="border-radius: 100%;"></image>
					</template>
				</view>
				<view style="flex:44%;padding-left: 6px;font-size: 36rpx;" :style="{color:$theme.STOCK_NAME}">
					<view>{{item.ko_name}}</view>
					<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{item.code}}</view>
				</view>

				<view style="flex: 25%;text-align: right;margin-right: 20px;font-size: 30rpx;font-weight: 700;"
					:style="$util.setStockRiseFall(item.returns>0)">
					{{$util.formatNumber(item.close*1)}}
				</view>

				<view style="flex:25%;text-align: right;margin-right: 6px;border-radius: 3px;"
					:style="$util.setStockRiseFall(item.returns>0,true)">
					<view style="padding:4px; font-size: 30rpx;font-weight: 700;">
						{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import {
		getStockList
	} from '@/common/api.js';
	import {
		STOCK_OVERVIEW
	} from '@/common/paths.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				gpIndex: 0,
				curPage: 1, // 当前页码
				timer: null,
			};
		},
		// computed: {
		// 	best() {
		// 		console.log('best');
		// 		// 取最高三条数据为顶部块状展示
		// 		return this.list.sort((a, b) => b.rate - a.rate).slice(0, 3);
		// 	}
		// },
		created() {
			console.log('child created', this.timer);
			this.getData();
		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getData();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			// 点击查看股票详情
			handleDetail(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getData() {
				const result = await getStockList({
					page: this.curPage,
					gp_index: this.gpIndex
				});
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>