<template>
	<view class="common_header">
		<view style="flex: 30%;margin-right: 10px;text-align: center;padding: 6px;border-radius: 30px;"
			:style="{backgroundColor:$util.RGBConvertToRGBA('#9047FF',99)}">
			<image mode="aspectFit" src="/static/notification.png" :style="$util.setImageSize(40)"
				@click="handleNotifiy()" style="padding-right: 8rpx;"></image>
			<view style="display: inline-block;height: 20px;width: 1px;margin:0 6px;background-color: #FFF;"></view>
			<image mode="aspectFit" src="/static/header_service.png" :style="$util.setImageSize(40)"
				@click="handleService" style="padding:0  8rpx;"></image>
		</view>

		<view class="primary_header_search" @click="handleSearch()">
			<image mode="aspectFit" src="/static/search.png" :style="$util.setImageSize(30)"></image>
		</view>
		<Translate></Translate>
	</view>
</template>

<script>
	import {
		NOTIFICATION,
		SEARCH
	} from '@/common/paths.js';
	import Translate from '@/components/Translate.vue';
	export default {
		name: "Header",
		components: {
			Translate
		},
		data() {
			return {};
		},
		methods: {
			// 跳转到通知页面
			handleNotifiy() {
				uni.navigateTo({
					url: NOTIFICATION
				})
			},

			// 跳转到个人中心
			handleService() {
				console.log(0)
				this.$util.linkCustomerService();
			},
			// 跳转到查询页面
			handleSearch() {
				uni.navigateTo({
					url: SEARCH
				})
			}
		}
	}
</script>