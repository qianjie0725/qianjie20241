<template>
	<view>
		<view style="padding:20px;">
			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;padding-left: 20px;">

				<input v-model="amount" type="number" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
					:placeholder-style="$util.setPlaceholder()" maxlength="11" style="width: 90%;"></input>
				<view style="color:#999">{{$lang.CURRENCY_UNIT}}</view>
			</view>
		</view>
		<view class="common_btn btn_primary" @click="handleBuy()"
			style="border-radius: 20rpx;text-align: center;margin: 20px;">
			{{$lang.TRADE_DAY_BUY}}
		</view>

		<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#959393;">
			<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
			<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;">{{item}}</view>
			</block>
		</view>
		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' :content="$lang.TRADE_DAY_MODAL_CONTENT" :cancel-text="$lang.BTN_CANCEL"
			:confirm-text="$lang.BTN_CONFIRM">
		</u-modal>
	</view>
</template>

<script>
	import {
		postTradeDayBuy,
	} from '@/common/api.js';
	export default {
		name: 'TradeDayBuy',
		data() {
			return {
				amount: '',
				showBuyConfirm: false,
			}
		},
		methods: {
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast($lang.TRADE_DAY_TIP_INPUT_AMOUNT);
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await postTradeDayBuy({
					money: this.amount,
				},this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.amount = '';
					// 1 为驱动父事件，实现切换Tab效果
					this.$emit('action',1);
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>