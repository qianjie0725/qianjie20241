<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="display: flex;align-items: center;padding:10px;" :style="{color:$theme.TITLE}">
				<view style="flex: 40%;">{{$lang.TRADE_DAY_BUY_LOG[0]}}
				<!-- [{{$lang.CURRENCY_UNIT}}] -->
				</view>
				<view style="flex: 40%;text-align: right;padding-right: 20px;">
					{{$lang.TRADE_DAY_BUY_LOG[1]}}
					<!-- [{{$lang.CURRENCY_UNIT}}] -->
				</view>
				<view style="flex: 20%;">{{$lang.TRADE_DAY_BUY_LOG[2]}}</view>
			</view>
			<view>
				<EmptyData v-if="list && list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view :class="index==list.length-1?'':'line'"
						style="display: flex;align-items: center;margin-top:10px;padding: 0 6px 10px 6px;">
						<view style="flex: 40%;">
							{{$util.formatNumber(item.money)}}
						</view>
						<view style="flex: 40%;font-size: 16px;text-align: right;padding-right: 20px;"
							:style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.success)}}
						</view>
						<view style="flex: 20%;font-size: 13px;">{{item.zt}}</view>
					</view>
				</block>
			</view>
		</template>

	</view>
</template>

<script>
	import {
		getTradeDayOrderList,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getData();
		},
		methods: {
			// 申请列表
			async getData() {
				const result = await getTradeDayOrderList();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>
