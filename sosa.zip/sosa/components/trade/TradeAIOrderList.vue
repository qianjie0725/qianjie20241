<template>
	<view>
		<view class="common_block" style="margin-top: 20px;padding:10px;margin-bottom: 20px;">
			<view
				style="display: flex;align-items: center;justify-content: space-around;border-bottom: 1px solid #F1f1f1;margin-bottom: 10px;">
				<block v-for="(item,index) in $lang.TRADE_AI_ORDER_TABS" :key="index">
					<view style="padding:6px;margin:6px;border-radius: 6px;text-align: center;"
						:style="{color:index==curTab? '#121212':'#666',backgroundColor:curTab==index? '#ebdcff':''}"
						@click="changeTab(index)">{{item}}</view>
				</block>
			</view>


			<view style="overflow-y: scroll;min-height: 47vh;">
				<view style="display: flex;align-items: center;background-color: #E8DCFF;border-radius: 6px;"
					:style="{color:$theme.TITLE}">
					<view
						style="flex:16%;margin:4px;height: 40px;line-height: 40px;text-align: center;padding:4px 0;border-right: 1px solid #F1f1f1;">
						<view>{{$lang.TRADE_AI_LIST_THEAD[0]}}</view>
					</view>
					<view
						style="flex:34%;margin:4px;height: 40px;line-height: 20px;text-align: center;padding:4px 0;border-right: 1px solid #F1f1f1;">
						<view>{{$lang.TRADE_AI_LIST_THEAD[1]}}</view>
						<view>{{$lang.TRADE_AI_LIST_THEAD[2]}}</view>
					</view>
					<view
						style="flex:30%;margin:4px;height: 40px;line-height: 20px;text-align: center;padding:4px 0;border-right: 1px solid #F1f1f1;">
						<view>{{$lang.TRADE_AI_LIST_THEAD[3]}}</view>
						<view>{{$lang.TRADE_AI_LIST_THEAD[4]}}</view>
					</view>
					<view style="flex:20%;margin:4px;height: 40px;line-height:20px;text-align: center;padding:4px 0;">
						<view>{{$lang.TRADE_AI_LIST_THEAD[5]}}</view>
						<view>{{$lang.TRADE_AI_LIST_THEAD[6]}}</view>
					</view>
				</view>

				<template v-if="list && list.length<=0">
					<EmptyData></EmptyData>
				</template>

				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view class="flex flex-b margin-top-5" @tap="handleShowModal(item)" style="margin-bottom: 8px;"
							:class="index<list.length-1?'line':''">
							<view class="padding-5" style="width: 14%">
								<view :style="{color:$theme.TIP}"> {{item.goods_info.name}} </view>
							</view>
							<view class="flex flex-b" style="width: 86%;">
								<template v-if="isHold">
									<view style="flex:35%;"
										:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
										<view style="text-align: right;padding-right: 6px;">
											{{$util.formatNumber(item.order_buy.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
										</view>
										<view class="margin-top-10 " style="text-align: right;padding-right: 6px;">
											{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
										</view>
									</view>
								</template>
								<template v-else>
									<template v-if="item.order_sell">
										<view :style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)"
											style="text-align: right;padding-right: 6px;flex:35%;">
											<view>
												{{$util.formatNumber(item.order_sell.yingkui*1)}}
											</view>
											<view class="margin-top-10 " style="text-align: right;padding-right: 6px;">
												{{$util.formatNumber((item.order_sell.yingkui*1/item.order_buy.user_pay*1/item.order_buy.double*100),2)}}%
											</view>
										</view>
									</template>
								</template>

								<view style="flex:35%;">
									<view style="text-align: right;padding-right:6px;" :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_buy.num)}}
									</view>
									<template v-if="isHold">
										<view class="margin-top-10 " style="text-align: right;"
											:style="{color:$theme.TEXT}">
											{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view class="margin-top-10" style="text-align: right;"
												:style="{color:$theme.TEXT}">
												{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
											</view>
										</template>
									</template>
								</view>

								<view style="flex:30%;">
									<view style="text-align: right;padding-right: 6px;" :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_buy.price)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<template v-if="isHold">
										<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
											:style="{color:$theme.RISE}">
											{{$util.formatNumber(item.goods_info.current_price)}}{{$lang.CURRENCY_UNIT}}
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
												:style="{color:$theme.RISE}">
												{{$util.formatNumber(item.order_sell.price)}}{{$lang.CURRENCY_UNIT}}
											</view>
										</template>
									</template>
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:$theme.ACCESS_TEXT}"
							style="text-align: center;font-size: 16px;">{{$lang.TRADE_MOADL_TITLE}}</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.goods_info.name}}</view>
					</view>
					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.order_buy.created_at}}</view>
					</view> -->
					<!-- <template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}</view>
							<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template> -->
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">{{info.order_buy.double}}</view>
					</view> -->

					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view> -->
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}</view>
						<view style="flex: 30%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}</view>
						<view style="flex: 20%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}</view>
						<view style="flex: 70%;" :style="{color:$theme.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content:center;padding-top: 20px;"
						v-if="isHold">
						<!-- <view class="common_btn btn_primary" style="width: 40%;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view> -->
						<view class="common_btn btn_secondary" style="width: 40%;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		getTradeList,
		postStockSell,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeAIOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				isShow: false, // 买卖弹出
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.isHold = this.curTab != 1;
				this.getData()
			},
			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.TRADE_MODAL_ALERT_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							_this.confirmSell(id);
						} else if (res.cancel) {}
					}
				})
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await postStockSell({
					id
				}, this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					this.getData()
					uni.$u.toast(result.message);
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 申请列表
			async getData() {
				this.list = []; // 数据响应不及时，请求前，清空数据
				const result = await getTradeList({
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: 0,
					ai: 1,
				});
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>