<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view :class="index==list.length-1?'':'line'" style="margin-top:0;padding:10px 0;">
					<view style="display: flex;align-items: center;">
						<view style="flex:15%;" :style="{color:$theme.TITLE}">
							{{$lang.TRADE_DAY_BUY_AMOUNT}}
						</view>
						<view style="flex:35%;font-size: 16px;text-align: right;">
							{{$util.formatNumber(item.money)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;">
						<view style="flex:15%;" :style="{color:$theme.TITLE}">
							{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}
						</view>
						<view style="flex:35%;font-size: 16px;text-align: right;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.success)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;">
						<!-- <view style="flex:15%;" :style="{color:$theme.TITLE}">
							{{$lang.TRADE_DAY_BUY_PRICE}}
						</view> -->
						<!-- <view style="flex:35%;font-size: 16px;text-align: right;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view> -->
					</view>

					<view style="display: flex;align-items: center;" :style="{color:$theme.TITLE}">
						<view style="flex:30%;">{{$lang.TRADE_DAY_ORDER_SN}}</view>
						<view style="flex:70%;font-size: 12px;text-align: right;">{{item.ordersn}}
						</view>
					</view>
					<view style="display: flex;align-items: center;" :style="{color:$theme.TITLE}">
						<view style="flex:30%;">{{$lang.TRADE_DAY_CREATE_TIME}}</view>
						<view style="flex:70%;font-size: 12px;text-align: right;">
							{{item.created_at}}
						</view>
					</view>
					<view style="display: flex;align-items: center;" :style="{color:$theme.TITLE}">
						<!-- <view style="flex:30%;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view> -->
						<!-- <view style="flex:70%;font-size: 12px;text-align: right;">
							{{item.zt}}
						</view> -->
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import {
		getTradeDaySuccessList,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDaySuccessList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getData();
		},
		methods: {
			// 申请列表
			async getData() {
				const result = await getTradeDaySuccessList();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>