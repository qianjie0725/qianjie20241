// 底部导航组
const TABBAR = ['홈', '시장정보', '내 주식', '관심 목록', '내 계정'];
// 主页功能按钮组
const HOME_BTNS = ['집중매매', '블록딜', 'AI트레이딩', '공모주/IPO', '입금', '출금', '실명인증', '고객센터'];

// 账户管理相关 登入、注册
const ACCESS = {
	SIGN_IN: "로그인",
	SIGN_UP: "회원가입",
	SIMGN_OUT: "로그아웃",
	GO_TO_SIGN_IN: '로그인페이지',
	USER_NAME: '전화번호',
	ENTER_USER_NAME: '휴대폰 번호 입력',
	PASSWORD: '비밀번호',
	ENTER_PASSWORD: '비밀번호 입력',
	VERIFY_PASSWORD: '비밀번호 재입력',
	ENTER_VERIFY_PASSWORD: '비밀번호 재입력',
	INVITATION_CODE: '초대 코드',
	ENTER_INVITATION_CODE: '초대 코드 입력',
	TIP_PWD_NOEQUAL: '두 개의 비밀번호가 일치하지 않습니다',
	TIP_SUCCESS_SIGNIN: '로그인 완료',
	TIP_SUCCESS_REGISTER: '등록이 완료되었습니다. 로그인하세요.',
	TIP_SIGNIN_ING: '로그인 중',
	TIP_SIGNUP_ING: '등록 중',
	TIP_REMEMBER_PWD: '로그인 상태 유지',
	API_TOKEN_EXPIRES: '로그인 상태가 잘못되었습니다. 다시 로그인해 주세요.',
	TIP_SIGN_OUT_SUCCESS: '로그아웃 완료',
	TIP_AGREE: '동의 읽기',
	TIP_PRVITE_PACT: '개인 정보 보호 계약',
	TIP_CHECK_AGREE: '사용자 개인정보 보호 계약에 동의하려면 확인란을 선택하세요.',
};

// 变更登入密码、变更支付密码、变更账户信息
const ACCOUNT = {
	TIP_OLD_PWD: '이전 비밀번호를 입력해주세요',
	TIP_NEW_PWD: '새 비밀번호를 입력 해주세요',
	TIP_NEW_PWD_VERIFY: '새 비밀번호를 다시 입력 해주세요',
	// 个人信息修改页面
	PAGE_TITLE_AVATAR: '설정',
	AVATAR_TIP_NICK_NAME: '성함을 입력해주세요',
};

// 绑定银行卡
const BIND_BANK_CARD = {
	REAL_NAME: '성명',
	TIP_REAL_NAME: '성함을 입력해 주세요',
	BANK_NAME: '은행명',
	TIP_BANK_NAME: '연동 은행을 입력하시거나 선택하세요',
	BANK_CARD: '계좌번호',
	TIP_BANK_CARD: '계좌번호를 입력해 주세요',
	BTN_CHANGE_BANK_CARD: '확인',
};

// 提款页面
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: '출금',
	WITHDRAW_AMOUNT: 'MY 자산',
	WITHDRAW_TITLE: "출금",
	TIP_AMOUNT_AVAIL: '사용 가능 금액',
	WITHDRAW_WITH_AMOUNT: '출금금액',
	TIP_AMOUNT_WITHDRAW: '출금 금액 입력',
	WITHDRAW_PAY_PWD: '출금 비밀번호',
	TIP_WITHDRAW_PWD: '계정 로그인 비밀번호를 입력하세요',
	WITHDRAWING_POST_TIP: '처리....',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1.현재 보유주식 매도전에는 출금이 불가능합니다.`, `2.출금을 위해서는 실명인증 및 본인 계좌 확인 후 출금진행이 됩니다`,
		`3.출금 거래 가능 시간:평일 오전 09시~오후15시30분(주말.대체공휴일 출금 불가)`, `4.출금 신청 최소 금액은 10,000 단위 입니다`,
		`5.출금 도착 시간은 D+2입니다 `
	],
};

// 入金页面
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: '입금',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: '입금하실 금액을 입력하세요',
	DEPOSIT_TIP_LOW_AMOUNT: '최소 입금 금액 1,000,000원',
	DEPOSIT_POST_TIP: '처리....',
	DEPOSIT_TIP_TITLE: '친절한 팁',
	DEPOSIT_TIP_TEXT: ['주의: 매번 입금하실 때마다 고객센터로 연락하셔서 입금계좌 정보를 확인하시기 바랍니다 계좌 정보 오류로 인한 금전적 손실이 발생하지 않도록 해주시기 바랍니다!'
	],
};

// 个人中心页面
const ACCOUNT_CENTER = {
	// 个人中心 认证状态
	ACCOUNT_AUTH_STATUS: ['실명인증되지 않음', '확인됨[검토중]', '확인됨[감사 실패]'],
	ACCOUNT_CHANGE_PWD: '로그인 비밀번호 변경',
	ACCOUNT_CHANGE_PAY_PWD: '거래 비밀번호 변경',
	ACCOUNT_CARD_MANAGEMENT: '입출금 계좌 연동',
	ACCOUNT_TRADE_LOG: '계정 자산 내역',
	ACCOUNT_SERVICE: '고객센터',
	ACCOUNT_AMOUNT_TOTAL: '총자산',
	ACCOUNT_AMOUNT_AVAILABLE: '사용 가능금액',
};

// 实名认证页面
const AUTH = {
	PAGE_TITLE_AUTH: '실명 인증',
	AUTH_TIP_ID_CARD: '주민등록번호를 입력해주세요',
	AUTH_TIP_CARD_F: '전면을 클릭하여 추가',
	AUTH_TIP_CARD_B: '뒷면을 클릭해서 추가했어요',
	AUTH_ID_CARD: '주민등록번호',
	AUTH_CARD_F: '신분증 앞면 사진',
	AUTH_CARD_B: '신분증 뒷면 사진',
	AUTH_TIP_TEXT: '※본인이 아닐경우, 이용에 불이익을 받으실 수있습니다.',
};

// 交易记录页面
const TRADE_LOG = {
	TRADE_LOG_BTNS: ['거래 내역', '입금 내역', '출금 내역'],
	TRADE_LOG_TIP_MODAL_TITLE: '출금신청을 취소하시겠습니까?',
	TRADE_LOG_WITHDRAW_STATUS: ['심사중', '출금 성공', '출금 실패 고객센터로 문의주세요', '신청 취소'],
	LOG_TRADE_AMOUNT_AFTER: '현금 잔액',
	LOG_TRADE_AMOUNT_BEFORE: '거래전 잔액',
	LOG_TRADE_DW: '입금',
	LOG_TRADE_CREATE_TIME: '거래 시간',
	LOG_TRADE_DESC: '명세',
	LOG_TRADE_ORDER_SN: '주문 번호',
	LOG_TRADE_DW_DESC: '거부 이유',
	LOG_WITHDRAW_AMOUNT: '출금',
};

// 交易页面
const ACCOUNT_TRADE = {
	TRADE_TABS:['보유종목', '거래내역'],
	TRADE_TOTAL_BUY_AMOUNT: '총매입',
	TRADE_VALUATION_GAIN_LOSS: '평가손익',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: '평가금액',
	TRADE_RATE_RESPONSE: '수익률',
	TRADE_TOTAL_GAIN: '총수익',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['종목명', '평가손익', '수익률', '매입수량', '평가금액', '평균단가','매도가격'],
	TRADE_MOADL_TITLE: '세부정보',
	// 订单的label组
	TRADE_MODAL_LABELS: ['종목명', '매수 시간', '매도시간', '평가손익', '레버리지', '손익총액', '매수가격', '매수수량', '수수료', '총매입금액', '코드'],
	// 卖出弹出提示
	TRADE_MODAL_ALERT_TITLE: '매도 하시겠습니까?',
};

// AI交易
const TRADE_AI = {
	PAGE_TITLE_TRADE_AI: 'AI 거래',
	TRADE_AI_TABS: ['AI트레이딩', '거래내역'],
	TRADE_AI_AMOUNT: 'AI투자 금액',
	TRADE_AI_AMOUNT_TOTAL:'AI 총자산',
	TRADE_AI_TRANSFER: ['신청', '출금'],
	TRADE_AI_PROFIT: 'AI 수익',
	TRADE_AI_LOG: ['보류 중', '통과', '기각'],
	TRADE_AI_CYCLE_TITLE: '기간을 선택하세요',
	TRADE_AI_TRADE_VOL: '거래량',
	TRADE_AI_BALANCE: '균형',
	TRADE_AI_TYPE: '거래 유형',
	TRADE_AI_CYCLE_DAY: '주기',
	TRADE_AI_DEPOSIT_BTN:'입금',
	TRADE_AI_ORDER_TABS:['보유 종목', '거래 내역'],
	TRADE_AI_LIST_THEAD:['종목명', '평가손익', '수익률', '매입수량', '평가금액', '평균단가','매도가격'],
}

// 日内交易
const TRADE_DAY = {
	// PAGE_TITLE_TRADE_DAY: 'AI데이 트레이딩',
	TRADE_DAY_TABS: ['집중매매', '신청내역', '거래내역'],
	TRADE_DAY_BUY: '신청',
	TRADE_DAY_TIP: '힌트',
	TRADE_DAY_TIP_TEXT: ['집중매매종목 운영기간 중 종목명 공시 없음,종목 예상수익 달성 후 바로 매도 가능'],
	TRADE_DAY_BUY_LOG: ['투자금액', '참여금액', '통과/거부'],
	TRADE_DAY_BUY_AMOUNT: '투자금액',
	TRADE_DAY_SUCCESS_AMOUNT: '참여금액 ',
	TRADE_DAY_BUY_PRICE: '구매금액',
	TRADE_DAY_ORDER_SN: '주문 번호',
	TRADE_DAY_CREATE_TIME: '날짜 시간',
	TRADE_DAY_ORDER_STATUS: '주문 상태',
	TRADE_DAY_MODAL_CONTENT: '투자 금액 확인해주세요',
	TRADE_DAY_TIP_INPUT_AMOUNT: '투자금액을 입력하세요',
};

// 大宗交易
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: '블록딜',
	TRADE_LARGE_TABS: ['거래 내역', '종목 목록'],
	TRADE_LARGE_TAB1_TITLES: ['구매 내역', '할당 수량'],
	TRADE_LARGE_PRICE: '확정공모가',
	TRADE_LARGE_PRICE_DZ: '매수 가격',
	TRADE_LARGE_RATE: '종목 수익률',
	TEADE_LARGE_RATE_AMOUNT: '1주 평균수익',
	TRADE_LARGE_MIN_QTY: '최소 매입 수량',
	TRADE_LARGE_MAX_QTY: '최대 구매 금액',
	TRADE_LARGE_MIN_DAY: '최소 보유 일수',
	TRADE_LARGE_ITEM_LABELS: ['가격', '증가율'],
	TRADE_LARGE_ORDER_TITLE: '블록딜',
	TRADE_LARGE_BUY_AMOUNT: '매입 가격',
	TRADE_LARGE_TIP_BUY_COUNT: '매입 수량을 입력하세요',
	TRADE_LARGE_ORDER_AMOUNT: '매입금액',
	TRADE_LARGE_TIP_BUY_PWD: '거래 비밀번호 6자리 입력해주세요',
	TRADE_LARGE_LOG_FINISH: '신청완료',
	TRADE_LARGE_LOG_PRICE: '매수가격',
	TRADE_LARGE_LOG_NUM: '매수수량',
	TRADE_LARGE_LOG_AMOUNT: '매수금액',
	TRADE_LARGE_LOG_LEVER: '레버리지',
	TRADE_LARGE_LOG_CREATE_TIME: '매수시간',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: '총매입금액',
};

// IPO 交易
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO: '공모주/IPO',
	TRADE_IPO_TABS: ['종목 목록', '거래 내역'],
	TRADE_IPO_TAB1_TITLES: ['구매 내역', '할당 수량'],
	TRADE_IPO_MODAL_TITLE: '공모주 청약 신청',
	TRADE_IPO_MODAL_CONTENT: '신청 하시겠습니까?',
	TADE_IPO_SUB_PRICE: '구독 금액',
	TRADE_IPO_PE_RATE: '주가수익비율',
	TRADE_IPO_SUB_CT: '공모청약일',
	TRADE_IPO_SUB_RJ: '납입일',
	TRADE_IPO_SUB_GB: '배정공고일',
	TRADE_IPO_SUB_SS: '상장일',
	TRADE_IPO_POST_QTY: '순환',
	TRADE_IPO_RAISE_MONEY: '기금 모금',
	TRADE_IPO_LOG_LABELS: ['확정공모가', '구독가격', '주가수익비율', '순환'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO 청약 성공기록',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: '구독 수량',
	TRADE_IPO_SUCCESS_AMOUNT: '당첨 수량',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: '구독 금액',
	TRADE_IPO_SUCCESS_ORDER_SN: '주문 번호',
	TRADE_IPO_SUCCESS_CT: '날짜 시간',
}

// 单股详情页面
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: '재고 세부정보',
	// 股票最新数值
	STOCK_INFO_TITLES: ['시가', '전일종가', '고가', '저가', '거래량', '거래대금'],
	// 股票详情 一级TABS
	STOCK_OVERVIEW_TABS: ['차트', '종목분석', '뉴스'],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['분', '일', '주', '월'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: '수량',
	STOCK_BUY_TIP_QUANTITY: '수량을 입력해주세요',
	STOCK_BUY_AMOUNT: '결제 금액',
	STOCK_BUY_FEE: '수수료',
	STOCK_BUY_CONFIRM: '매수 확인',
	// 单股概览 概览信息
	STOCK_BASE_INFO: ['기업순위', '코스닥', '평가금액', '주식수', '외국인비중', '산업군', '세부산업군', '52주 최고', '52주 최저'],
	// 概览 
	STOCK_COMPANY: '기업개요',
	STOCK_SALES_TABS: ['분기매출', '연간매출'],
	// 销售额三块数据
	STOCK_SALES_TITLE: ['최근 매출액', '최근 영업이익', '최근 순이익'],
	// 销售额折线上方的三个选项
	STOCK_SALES_KLINE_TABS: ['매출액', '영업이익', '순이익'],
	// 投资者交易趋势
	STOCK_TRADE_TREND_TITLE: '투자자별 매매동향',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['순매수량', '누적순매수량'],
	STOCK_TRADE_TREND_INFO_TITLE: ['개인', '기관', '외인'],
	STOCK_TRADE_TREND_RECENT_TITLE: '최근 거래 동향',
	STOCK_TRADE_TREND_RECENT_LABELS: ['날짜', '개인', '기관', '외인'],
	// 饼图的title
	STOCK_TRADE_TREND_PIE_TITLE: '매매동향',
	STOCK_TRADE_SELL_EMPTY_TITLE: '공매도 거래량',
	// 卖空量两组数据的Title
	STOCK_TRADE_SELL_EMPTY_ITEM_TITLES: ['공매도 거래량', '공매도 잔고'],
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC: ['전체 거래량 대비', '시가총액 대비'],
	// 行业内比较
	STOCK_INDUSTRY_TITLE: '업종 내 비교',
	STOCK_INDUSTRY_DESC: '자동차부품',
	STOCK_INDUSTRY_DESC_SUFFIX: '개중',
	STOCK_INDUSTRY_DATA_TITLES: ['현 종목', '업종평균'],
	STOCK_INDUSTRY_DATA_LABELS: ['평가금액', '순이익증가율', '부채비율', 'PER', 'PBR', 'ROE'],
};

// 市场页面
const MARKET = {
	MARKET_TABS: ['전체요약', '인기종목', '시장지표', '시장이슈'],
	// 市场概况：
	MARKET_OVERVIEW_SELF_TITLE: '국내종목',
	//国内、国外、虚拟货币
	MARKET_OVERVIEW_SELF_TABS: ["국내", "해외", "가상화폐"],
	MARKET_MORE_HOT_TITLE: '인기종목 더보기',
	MARKET_NEWS_TITLE: '시장이슈',
	MARKET_OVERVIEW_THEAD: ["상승률", "하락률", "신고가", "거래량", '거래대금'],
	// 热门股票：
	MARKET_HOT_TABS: ['상승률', '하락률', '신고가', '거래량 상위/하위', '거래대금 상위/하위', '외국인 순매수', '기관 순매수', '신규상장', '공매도 비중'],
	// 热门股票过滤
	MARKET_HOT_FILTER: ['당일', '1주일', '1개월', '3개월', '6개월'],
	MARKET_HOT_THEAD: ['종목명', '현재가', '등락률', '현재 지수'],
	// 市场指标
	MARKET_INDEX_TABS: ['지수', '환율', '원자재', '가상화폐'],
	MARKET_NEWS_TABS: ['뉴스', '시장', '경제', '산업', '채권', '파생', '기업', '투자'],
	MARKET_NEWS_TIP: '인기종목은 총 100위까지 순위만 제공합니다. ',
};

export default {
	TRANSLATE_TITLE: '당신의 언어를 고르시 오',
	TABBAR,
	HOME_BTNS,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_AI,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...STOCK_INFO,
	...MARKET,
	STOCK_ALL: '종목',
	// 首页股票列表表头
	STOCK_THEAD: ['주식', '최신 가격', '등락률'],
	PAGE_TITLE_NOTIFICATION: '알림',
	PAGE_TITLE_SEARCH: '검색',
	TIP_SEARCH: '주식명/주식코드를 입력하세요',
	SEARCH_HISTORY: '검색기록',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: '무역',
	TIP_POST_SUCCESS: '성공적인 운영',
	ABOUT_US: '회사 소개',
	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: '억',
	UNIT_POS: '위',
	UNIT_DAY: '낮',
	MORE: '더많이',
	BRIEF: '간략히',
	EMPTY_NOTIFIY: '메시지 없음',
	EMPTY_DATA: '기록 없음',
	BTN_CONFIRM: '확인',
	BTN_CANCEL: '취소',
	BTN_SEND_SERVICE: '고객 서비스에 문의하세요',
	BTN_DETAIL: '세부',
	BTN_BUY: '매수',
	BTN_BUY_T: '청약',
	BTN_SELL: '매도',
	STATUS_LOADING: "로딩 중",
	STATUS_SUBMIT: '신청중',
	STATUS_REQUEST: '데이터 검색중',
	STATUS_HTTP_ERROR: '재시도 중',
	STATUS_UPLOAD: '업로드 중',
	TIP_LINK_SERVICE_SYSTEM: '고객센터에 들어가려고 합니다……',
}