<template>
	<view style="overflow-y: scroll;height: 66vh;padding:0 10px;">
		<view v-for="(item,index) in list" :key="index" @click="open(item.link)"
			style="display: flex;align-items: center;">
			<view style="flex:20%;">
				<image mode="aspectFit" :src="item.image" :style="$util.calcImageSize(80)"></image>
			</view>
			<view style="padding-left: 10px;flex:80%;">
				<view :style="{color:$util.THEME.TEXT}">{{item.title}}</view>
				<view :style="{color:$util.THEME.LABEL}" style="text-align: right;padding-right: 16px;">
					{{$util.formatDate(item.dt)}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "StockMarketNews",
		props: ['code', 'id'],
		data() {
			return {
				list: []
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			open(url) {
				window.open(url)
			},
			async getList() {
				const result = await this.$http.post(`api/product/news`, {
					code: this.code,
					stock_id: this.id
				})
				this.list = result.data.data[0];
			},
		},
	}
</script>