<template>
	<view class="btns_wrapper common_block">
		<view v-for="(item,index) in btns" :key="index" class="item" @click="actionEvent(item.url,index)"
			:style="{flex:col}">
			<view class="icon">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.calcImageSize(48)"></image>
			</view>
			<text class="btn_name">{{item.name}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns', 'col'],
		data() {
			return {};
		},

		methods: {
			actionEvent(url, index) {
				if (url.includes('pages')) {
					console.log(url,index)
					if (url.includes('marketQuotations/marketQuotations')) {
						uni.switchTab({
							url: url
						})
					} else {
						uni.navigateTo({
							url: url
						})
					}
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>