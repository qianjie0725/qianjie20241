<template>
	<view style="padding:10px 0;text-align: center;width: 100%;color:#ccc">{{$lang.ENPTY_DATA}}</view>
</template>

<script>
	export default {
		name: "EmptyData",
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>