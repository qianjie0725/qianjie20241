<template>
	<view class="common_block" style="padding: 0 6px 6px 0;">
		<view style="overflow-y: scroll;height: 14vh;">
			<view v-for="(item,index) in list" @click="$u.route('/pages/marketQuotations/productDetails',{code:item.goods.code});"
				style="padding-top: 6px;margin-left:10px;width: 96%;display: flex;line-height: 36px;border-bottom:1px solid #C0C0C0;">
				<view style="display: inline-block;flex:10%;"><u--image :src="$BaseUrl+item.goods.logo" shape="circle"
						width="30px" height="30px"></u--image></view>
				<view style="margin-left:10px;display: inline-block;flex:36%;" :style="{color:item.goods.rate>0?$util.THEME.SECONDARY:'#939292'}">
					{{item.goods.name}}
				</view>
				<text style="display: inline-block;flex:20%;margin:0 10px;"
					:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{$util.formatNumber(item.goods.current_price*1)}}
				</text>
				<view style="border-radius: 3px;font-weight: 700; display: inline-block;flex:29%;"
					:style="$util.calcStyleRiseFall(item.goods.rate>0)">
					<u-icon :name="`/static/${item.goods.rate>0?'up':'down'}.png`" size="12"
						style="display: inline-block;padding-right:10px;"></u-icon>
					{{item.goods.rate>0?'+':""}}{{(1*item.goods.rate).toFixed(2)}}%

				</view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
		</view>		
	</view>
</template>

<script>
 import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "Favorites",
		props:['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>

<style>

</style>