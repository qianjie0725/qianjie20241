<template>
	<view
		style="border-radius: 10px;background: #fff;margin: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
		<view style="position: relative;">
			<view
				style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #f9e80e;position: absolute;top: 10px;">
			</view>
		</view>
		<u-tabs :list="list1" style="margin: 10px 10px;"
			activeStyle="color:#3c1f20;font-weight: 700;background:#f9e80e;padding:5px 10px;border-radius:6px"
			lineColor="#f3f4f8" @change="change" :current="current">
		</u-tabs>

		<view style="padding: 0 10px;display: flex;align-items: center;">
			<view style="flex:50%;">종목명</view>
			<view v-if="current==0" style="flex:30%;text-align: right;padding-right: 16px;">현재 지수</view>
			<view v-else style="flex:30%;text-align: right;padding-right: 16px;">현재가</view>
			<view style="flex:20%;text-align: right;padding-right: 16px;">등락률</view>
		</view>

		<view style="overflow-y: scroll;height: 66vh;">
			<view v-for="(item,index) in list" style="display: flex;align-items: center;padding: 0 10px;">
				<view style="flex:50%;">
					<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(24)" style="border-radius: 100%;"></image>
					<text style="font-size: 14px;font-weight: 500;padding-left: 10px;"	:style="{color:$util.THEME.SECONDARY}">
						{{item.ko_name}}
					</text>
				</view>
				<view style="flex:30%;text-align: right;padding-right: 16px;" :style="$util.calcStyleRiseFall(item.returns>0)">
					{{$util.formatNumber(item.close)}}
				</view>
				<view style="flex:20%;text-align: right;padding-right: 16px;" :style="$util.calcStyleRiseFall(item.returns>0)">
					{{(item.returns*1).toFixed(2)}}%
				</view>
			</view>
			<view style="text-align: center;color: #999;" class="content-end-text">인기종목은 총 100위까지 순위만 제공합니다.
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TabThree',
		components: {},
		props: {},
		data() {

			return {
				show: false,
				list1: [{
					name: '지수',
				}, {
					name: '환율',
				}, {
					name: '원자재'
				}, {
					name: '가상화폐'
				}],

				list: [],
				current: 0,

			}
		},

		methods: {

			async lists() {
				uni.showLoading({

				})
				let list = await this.$http.post('api/goods/zhibiao', {
					current: this.current,
				})
				this.list = list.data.data
				uni.hideLoading()
			},
			qiehuan(index) {
				console.log(index)
				this.current1 = index;
				this.lists()
			},
			change(index) {
				console.log(index)
				this.current = index.index;
				this.current1 = 0;
				this.lists()
			},
			changes(index) {
				console.log(index)
				this.current = index.indexs[0];
				this.current1 = 0;
				this.show = false;
				this.$forceUpdate()
				this.lists()
			},
		},

		mounted() {

			this.lists()
		},

		onLoad() {},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	.list {
		padding: 0 0 10px;

		.titles {
			padding: 10px;

			uni-view {
				color: #91a2b1;
			}
		}

		.item {
			padding: 10px;

			.t {
				font-size: 16px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				color: #ff3636;
				font-weight: 600;
			}

			.t1.die {
				color: #014b8d;
				font-weight: 600;
			}

			.num {
				color: #999;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #3c1f20;

			span {
				background: #f9e80e;
			}
		}
	}
</style>