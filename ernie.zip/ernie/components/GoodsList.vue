<template>
	<view class="common_block" style="padding: 0 6px 6px 0;">
		<view style="min-height: 64vh;">
			<view v-for="(item,index) in list"
				@click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});"
				style="padding-top: 6px;margin-left:10px;display: flex;align-items: center;border-bottom:1px solid #C0C0C0;">
				<view style="display: inline-block;flex:6%;">
					<template v-if="!item.logo || item.logo==''">						
						<view :style="$util.calcImageSize(30)" style="background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;">{{item.ko_name.slice(0,1)}}</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(30)"></image>
					</template>					
				</view>
				<view style="display: inline-block;flex:40%;padding-left: 6px;"
					:style="{color:item.returns>0?$util.THEME.SECONDARY:'#939292'}">
					{{item.ko_name}}
				</view>
				<text style="display: inline-block;flex:20%;text-align: right;padding-right: 16px;font-size: 16px;"
					:style="$util.calcStyleRiseFall(item.returns>0)">{{$util.formatNumber(item.close*1)}}
				</text>
				<view
					style="border-radius: 3px;font-weight: 700; display: inline-block;flex:20%;text-align: right;padding-right: 16px;"
					:style="$util.calcStyleRiseFall(item.returns>0)">
					<image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
						:style="$util.calcImageSize(12)"></image>
					<view style="display: inline-block;">{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
					</view>
				</view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		props: ['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>