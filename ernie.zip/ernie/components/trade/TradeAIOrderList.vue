<template>
	<view>
		<view style="margin-top:0px;padding:10px;margin-bottom: 20px;">
			<view
				style="display: flex;align-items: center;justify-content: space-around;border-bottom: 1px solid #F1f1f1;margin-bottom: 10px;">
				<block v-for="(item,index) in ['보유 종목', '거래 내역']" :key="index">
					<view style="padding:6px;margin:6px;border-radius: 6px;text-align: center;"
						:style="{color:index==curTab? '#121212':'#666',backgroundColor:curTab==index? '#f9e80e':'#e5e5e5'}"
						@click="changeTab(index)">{{item}}</view>
				</block>
			</view>


			<view style="overflow-y: scroll;min-height: 47vh;">
				<view style="display: flex;align-items: center;background-color: #fffbdb;border-radius: 6px;"
					:style="{color:'#121212'}">
					<view
						style="flex:16%;margin:4px;height: 40px;line-height: 40px;text-align: center;padding:4px 0;border-right: 1px solid #F1f1f1;">
						<view>종목명</view>
					</view>
					<view
						style="flex:34%;margin:4px;height: 40px;line-height: 20px;text-align: center;padding:4px 0;border-right: 1px solid #F1f1f1;">
						<view>평가손익</view>
						<view>수익률</view>
					</view>
					<view
						style="flex:30%;margin:4px;height: 40px;line-height: 20px;text-align: center;padding:4px 0;border-right: 1px solid #F1f1f1;">
						<view>매입수량</view>
						<view>평가금액</view>
					</view>
					<view style="flex:20%;margin:4px;height: 40px;line-height:20px;text-align: center;padding:4px 0;">
						<view>평균단가</view>
						<view>매도가격</view>
					</view>
				</view>

				<template v-if="list && list.length<=0">
					<EmptyData></EmptyData>
				</template>

				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view class="flex flex-b margin-top-5" @tap="handleShowModal(item)" style="margin-bottom: 8px;"
							:class="index<list.length-1?'line':''">
							<view class="padding-5" style="width: 14%">
								<view :style="{color:'#999'}"> {{item.goods_info.name}} </view>
							</view>
							<view class="flex flex-b" style="width: 86%;">
								<template v-if="isHold">
									<view style="flex:35%;"
										:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
										<view style="text-align: right;padding-right: 6px;">
											{{$util.formatNumber(item.order_buy.yingkui*1)}}원
										</view>
										<view class="margin-top-10 " style="text-align: right;padding-right: 6px;">
											<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
											{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
										</view>
									</view>
								</template>
								<template v-else>
									<template v-if="item.order_sell">
										<view :style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)"
											style="text-align: right;padding-right: 6px;flex:35%;">
											<view>
												{{$util.formatNumber(item.order_sell.yingkui*1)}}
											</view>
											<view class="margin-top-10 " style="text-align: right;padding-right: 6px;">
												<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
												{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
											</view>
										</view>
									</template>
								</template>

								<view style="flex:35%;">
									<view style="text-align: right;padding-right:6px;" :style="{color:'#121212'}">
										{{$util.formatNumber(item.order_buy.num)}}
									</view>
									<template v-if="isHold">
										<view class="margin-top-10 " style="text-align: right;"
											:style="{color:'#121212'}">
											{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}원
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view class="margin-top-10" style="text-align: right;"
												:style="{color:'#121212'}">
												{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}원
											</view>
										</template>
									</template>
								</view>

								<view style="flex:30%;">
									<view style="text-align: right;padding-right: 6px;" :style="{color:'#121212'}">
										{{$util.formatNumber(item.order_buy.price)}}원
									</view>
									<template v-if="isHold">
										<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
											:style="{color:' 	red'}">
											{{$util.formatNumber(item.goods_info.current_price)}}원
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
												:style="{color:'red'}">
												{{$util.formatNumber(item.order_sell.price)}}원
											</view>
										</template>
									</template>
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:'#121212'}" style="text-align: center;font-size: 16px;">
							세부정보 </text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#666'}">종목명</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">{{info.goods_info.name}}</view>
					</view>
					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#666'}">평가손익</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">{{info.order_buy.created_at}}</view>
					</view> -->
					<!-- <template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:'#666'}">매도시간00</view>
							<view style="flex: 70%;" :style="{color:'#121212'}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template> -->
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#666'}">현재손익</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}원
						</view>
					</view>
					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#666'}">레버리지</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">{{info.order_buy.double}}</view>
					</view> -->

					<!-- <view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#999'}">손익총액
						</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}원
						</view>
					</view> -->
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#999'}"> 매입가</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#999'}">매수 수량</view>
						<view style="flex: 30%;" :style="{color:'#121212'}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:'#999'}">수수료</view>
						<view style="flex: 20%;" :style="{color:'#121212'}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#999'}">총매입금액</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">
							{{$util.formatNumber(info.order_buy.amount)}}원
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:'#999'}">코드</view>
						<view style="flex: 70%;" :style="{color:'#121212'}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content:center;padding-top: 20px;"
						v-if="isHold">
						<!-- <view class="common_btn btn_primary" style="width: 40%;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view> -->
						<view class="common_btn btn_secondary" style="width: 40%;" @tap="handleSell(info.id)">
							매도
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeAIOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				isShow: false, // 买卖弹出
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.isHold = this.curTab != 1;
				this.getData()
			},
			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: `매도 하시겠습니까?`,
					cancelText: '취소',
					confirmText: '확인',
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							_this.confirmSell(id);
						} else if (res.cancel) {}
					}
				})
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id
				});
				if (result.data.code == 0) {
					this.getData()
					uni.$u.toast(result.data.message);
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			// 申请列表
			async getData() {
				this.list = []; // 数据响应不及时，请求前，清空数据
				const result = await this.$http.get(`api/user/order`, {
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: 0,
					ai: 1,
				});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>