<template>
	<view>
		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/trade_ai.png" mode="aspectFit" style="width: 600rpx;height: 320rpx;"></image>
		</view> -->

		<view class="withdraw_info" style="height: 180px;position: relative;border-radius: 16px;margin-top: 20px;">
			<view style="display: flex;padding:10px;margin-bottom:0;padding-right: 20px;padding-bottom:10px;">
				<view style="padding-left: 10px;color:#121212;font-size: 32rpx;">
					사용 가능금액[원]
				</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: 10px;">
				</image>
			</view>

			<view style="color:#121212;font-size: 48rpx;font-weight: 500;padding-right: 20px;padding-left: 20px;">
				{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px 0 20px;">
				<view style="color:#121212;font-size: 26rpx;">
					AI투자 금액[원]
				</view>
				<view style="color:#121212;font-size: 32rpx;font-weight: 500;">
					{{showAmount?$util.formatNumber(userInfo.aiMoney):hideAmount}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px 0 20px;">
				<view style="color:#121212;font-size: 26rpx;">
					AI 수익[원]
				</view>
				<view style="color:#121212;font-size:32rpx;font-weight: 500;">
					{{showAmount?$util.formatNumber(userInfo.aiShouyi):hideAmount}}
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px 0 20px;">
				<view style="color:#121212;font-size: 28rpx;">
					AI 총자산[원]
				</view>
				<view style="color:#121212;font-size: 32rpx;font-weight: 500;">
					{{showAmount?$util.formatNumber(userInfo.aiZong):hideAmount}}
				</view>
			</view>

			<view class="btn_deposit" @click="linkDeposit()">
				<image src="/static/trade_deposit.png" mode="aspectFit" :style="$util.setImageSize(40)"></image>
				<view style="display: inline-block;padding-left: 10px;font-size: 32rpx;">
					입금
				</view>
			</view>
		</view>
		<view
			style="display: flex;align-items: center;justify-content: space-around;border-bottom: 1px solid #F1f1f1;margin:20px 0 10px 0">
			<block v-for="(item,index) in ['신청', '출금']" :key="index">
				<view style="padding:6px 16px;margin:6px;border-radius: 6px;text-align: center;"
					:style="{color:index==curTab? '#121212':'#666',backgroundColor:curTab==index? '#f9e80e':'#e5e5e5'}"
					@click="changeTab(index)">{{item}}</view>
			</block>
		</view>
		<view class="common_block" style="padding: 10px;margin-bottom: 20px;box-shadow: none;border: none;">
			<view style="padding:0px;">
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;padding-left: 20px;">

					<input v-model="amount" type="number" placeholder="투자금액을 입력하세요"
						:placeholder-style="$util.setPlaceholder()" maxlength="11" style="width: 90%;"></input>
					<view style="color:#999">원</view>
				</view>
			</view>

			<template v-if="curTab!=1">
				<view style="padding-left: 20px;" :style="{color:'#999999'}">기간을 선택하세요</view>
				<view style="display: flex;align-items: center;flex-wrap: wrap;padding:0 10px;">
					<block v-for="(item,index) in cycleData" :key="index">
						<view
							style="border-radius: 6px;flex:10%;margin:10px;padding:10px;line-height: 1.6;text-align: center;"
							:style="{color:curCycle==item? '#121212' :'#999',backgroundColor:curCycle==item?'#fffbdb'
							:'#F1F1F1'}" @click="changeCurCycle(item)">
							{{item}}
						</view>
					</block>
				</view>
			</template>


			<view class="common_btn btn_primary" @click="handleBuy()"
				style="border-radius: 20rpx;text-align: center;margin: 20px;">
				{{ ['신청', '출금'][curTab]}}
			</view>

			<!-- <view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#959393;">
				<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
				<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
					<view style="padding-bottom: 6px;">{{item}}</view>
				</block>
			</view> -->
			<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
				:showCancelButton='true' content="투자 금액 확인해주세요" cancel-text="취소" confirm-text="확인">
			</u-modal>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TradeAIBuy',
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				amount: '',
				showBuyConfirm: false,
				curTab: 0, // AI交易，转入，转出
				cycleData: [], // 周期预置值
				curCycle: 0, // 当前选中预置值
			}
		},
		created() {
			this.getUserInfo();
			this.getTradeAICycleData();
		},
		methods: {
			// 转入，转出
			changeTab(val) {
				this.curTab = val;
			},
			// 切换转入周期预置值
			changeCurCycle(val) {
				this.curCycle = val;
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			linkDeposit() {
				uni.navigateTo({
					url: `/pages/my/components/certificateBank/silver`
				})
			},
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast(`투자금액을 입력하세요`);
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await await this.$http.post(`api/user/transfer`, {
					money: this.amount,
					type: this.curTab + 1, // 1:转入;2:转出。
					day: this.curTab == 1 ? '' : this.curCycle,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.amount = '';
					this.getUserInfo();
					// 1 为驱动父事件，实现切换Tab效果
					this.$emit('action', 1);
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			// 获取周期预置值
			async getTradeAICycleData() {
				const result = await this.$http.get(`api/user/Aizhouqi`);
				console.log(result);
				if (result.data.code == 0) {
					this.cycleData = result.data.data;
					this.curCycle = this.cycleData[0];
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			async getUserInfo() {
				const result = await this.$http.get(`api/user/info`);
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>