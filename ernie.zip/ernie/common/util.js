import LANGUAGE_DATA from '@/common/language.js';
const THEME = {
	PRIMARY: '#f9e80e',
	SECONDARY: '#3c1f20',
	RISE: '#ff0f0f', // #910191
	FALL: '#0f97ff', // #FFA500
}

const calcStyleActive = (active = true) => {
	return {
		color: active ? THEME.PRIMARY_TEXT : THEME.SECONDARY_TEXT,
		backgroundColor: active ? THEME.SECONDARY : '',
	}
}

const calcStyleRiseFall = (val = true) => {
	return {
		color: val ? THEME.RISE : THEME.FALL,
	}
}

const calcImageSize = (val) => {
	return {
		width: `${val}px`,
		height: `${val}px`,
	};
};

// setImageSize
// 设置图片尺寸（自定义size）
const setImageSize = (w = 0, h = 0) => {
	const _w = w > 0 ? w : 20;
	const _h = h > 0 ? h : _w;
	return {
		width: `${_w}rpx`,
		// 若为设置h值，则视为高=宽
		height: `${_h}rpx`,
	};
};

const calcPageHeight = () => {
	const systemInfo = uni.getSystemInfoSync();
	const tabBarHeight = systemInfo.screenHeight - systemInfo.windowHeight;
	return systemInfo.screenHeight - tabBarHeight;
};

const calcBodyHeight = () => {
	return parseInt(calcPageHeight() - 70);
};

const formatNumber = (value, fixed = 0) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

const formatDate = (timeString) => {
	// console.log('fmt:',fmt);
	const date = new Date(timeString);
	const year = date.getUTCFullYear();
	const month = String(date.getUTCMonth() + 1).padStart(2, '0');
	const day = String(date.getUTCDate()).padStart(2, '0');
	const h = String(date.getUTCHours()).padStart(2, '0');
	const m = String(date.getUTCMinutes()).padStart(2, '0');
	const s = String(date.getUTCSeconds()).padStart(2, '0');

	return `${year}.${month}.${day} ${h}:${m}:${s}`;
}

// 主页功能按钮组配置
const businessBtnsConfig = () => {
	return [{
			name: '집중매매',
			icon: 'top1',
			url: '/pages/trade/day',
		}, {
			name: '블록딜',
			icon: 'top2',
			url: '/pages/index/components/newShares/newShares?index=1',
		}, {
			name: 'AI트레이딩',
			icon: 'top3',
			url: '/pages/trade/ai',
		}, {
			name: '공모주/IPO',
			icon: 'top4',
			url: '/pages/index/components/newShares/newShares?index=3',
		}, {
			name: '입금',
			icon: 'top5',
			url: '/pages/my/components/certificateBank/silver',
		},
		// {
		// 	name: '자금인출',
		// 	icon: 'top6',
		// 	url: '/pages/my/components/certificateBank/prove',
		// }, 
		{
			name: '실명인증',
			icon: 'top7',
			url: '/pages/marketQuotations/authentication',
		}, {
			name: '출금',
			icon: 'top9',
			url: '/pages/my/components/certificateBank/prove',
		}, {
			name: '시장 정보',
			icon: 'top6',
			url: '/pages/marketQuotations/marketQuotations',
		}
	]
};

const mqBtnsConfig = () => {
	return [{
			name: LANGUAGE_DATA.FULL_INFO,
			url: '',
			icon: 'maket1'
		}, {
			name: LANGUAGE_DATA.HOT_GOODS,
			url: '',
			icon: 'maket2'
		}, {
			name: LANGUAGE_DATA.MARKET_INDICATORS,
			url: '',
			icon: 'maket3'
		}
		// , {
		// 	name: LANGUAGE_DATA.MARKET_ISSUES,
		// 	url: '',
		// 	icon: 'maket4'
		// },
	];
}

const TRADE_LOG_STATUS = [{
		label: '심사중',
		color: 'gray'
	},
	{
		label: '통과',
		color: 'red'
	},
	{
		label: '거부',
		color: 'green'
	}
];
// 1是通过   0是待审核   2是拒绝     通过红色   拒绝绿色   待审核灰色
const calcTradeLogStatusLabel = (val) => {
	return TRADE_LOG_STATUS[val].label;
}
const calcTradeLogStatusColor = (val) => {
	return TRADE_LOG_STATUS[val].color;
}

// 设置input的placeholder样式
const setPlaceholder = (color = '', fontsize = '') => {
	return `color:${color == '' ? '#999999' : color};font-size:${fontsize==''?24:fontsize}rpx`;
};

// 涨跌值样式设置
// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? '#E82D28' : '#FF8C00',
		backgroundColor: !isbg ? '' : val ? '#E82D28' : '#FF8C00',
	}
};

const UTIL = {
	THEME,
	calcStyleActive,
	calcStyleRiseFall,
	calcImageSize,
	setImageSize,
	formatNumber,
	formatDate,
	calcPageHeight,
	calcBodyHeight,
	businessBtnsConfig,
	mqBtnsConfig,
	calcTradeLogStatusLabel,
	calcTradeLogStatusColor,
	setPlaceholder,
	setStockRiseFall,
}

export default UTIL;