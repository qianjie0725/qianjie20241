<template>
	<view  >
		<CustomHeader title="블록딜 내역" @action="home()"></CustomHeader>
		<view class="common_block"  >
			<view class="" v-for="(item,index) in list" :key="index">
				<view style="margin: 30rpx; word-wrap:break-word;">
					<view class="display">
						<view class="">
							<view class="did-not">
								{{item.goods_info.name}}
								<text>매수 성공</text>
							</view>

						</view>
						<view class="did-not">
							매수가격 <text>{{$util.formatNumber(item.order_buy.price)}}</text>
						</view>
					</view>

					<view class="display quantity">
						<view class="display">
							<view class="">매수수량</view>
							<view class="red-mark">{{item.order_buy.num}}</view>
						</view>
						<view class="display">
							<view class="">투자 원금</view>
							<view class="red-mark">{{$util.formatNumber(item.order_buy.amount)}}</view>
						</view>
					</view>
					<!-- <view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
						<view >레버리지</view>
						<view style="text-align: right;">X{{item.double}}</view>
					</view> -->
					<!-- <view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
						<view >승인 상태</view>
						<view style="text-align: right;" :style="{color:$util.calcTradeLogStatusColor(item.admin_status)}">{{$util.calcTradeLogStatusLabel(item.admin_status)}}</view>
					</view> -->
					<view class="display">
						<view class="">매수시간</view>
						<view class="" style="text-align: right;color:#999">{{item.created_at}}</view>
					</view>

					<u-divider></u-divider>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				list: [],
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async shengou(e) {
				let list = await this.$http.post('api/goods-bigbill/user-order-log', {
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>