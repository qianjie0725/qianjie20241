<template>
	<view>
		<Header :title="$lang.HOME"></Header>
		<view>
			<ButtonGroup :btns="$util.businessBtnsConfig()" col="25%"></ButtonGroup>
		<!-- 	<view
				style="padding:10px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
				<text style="font-size: 13px;" :style="{color:$util.THEME.SECONDARY}">{{ $lang.FAVORITES}}</text>
				<view style="font-size: 14px;" @click="handleFreeList()" :style="{color:$util.THEME.SECONDARY}">
					추가
					<!-- <u-icon name="arrow-right" size="14" :bold="true" style="display: inline-block;"></u-icon> -->
				<!-- </view> -->
			<!-- </view> -->
			<!-- <Favorites :list="freeList"></Favorites> -->
			<view
				style="padding:10px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
				<text style="font-size: 13px;" :style="{color:$util.THEME.SECONDARY}">{{ $lang.ALL_MSG}}</text>
				<view style="font-size: 14px;" @click="handleFreeList()" :style="{color:$util.THEME.SECONDARY}">
					추가
					<u-icon name="arrow-right" size="14" :bold="true" style="display: inline-block;"></u-icon>
				</view>
			</view>
			<GoodsList :list="goodsList"></GoodsList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				userinfo: [],
				goodsList: [],
				page: 1,
				gp_index: 0,
				keyword: "",
				freeList: []
			}
		},

		methods: {
			handleFreeList() {
				uni.switchTab({
					url: '/pages/free/free'
				});
			},
			qiehuan(index) {
				this.gp_index = index
				this.good_list()
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			// 银转证
			async silver() {
				// if (bank_card_info && idno !== null) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/components/customer/customer'
				});


				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }

			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let list = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.goodsList = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.freeList = list.data.data.list
			},


		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		onLoad() {

		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			this.free()
			this.startTimer()
		},

		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		}

	}
</script>