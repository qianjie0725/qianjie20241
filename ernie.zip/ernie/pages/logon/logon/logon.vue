<template>
	<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:10vh;">
		<image style="width: 200px; height: 200px;" mode="aspectFit" src="/static/logo.png"></image>

		<view class="common_input_wrapper">
			<image mode="aspectFit" src="/static/user.png" :style="$util.calcImageSize(20)">
			</image>
			<input v-model="user" type="number" :placeholder="$lang.USER_NAME" maxlength="11"></input>
		</view>

		<view class="common_input_wrapper">
			<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
			</image>
			<input v-model="password" type="password" :placeholder="$lang.PASSWORD"></input>
		</view>

		<view v-if="!isSignIn" class="common_input_wrapper">
			<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
			</image>
			<input v-model="password2" type="password" :placeholder="$lang.PASSWORD_CONFIRM"></input>
		</view>

		<view v-if="!isSignIn" class="common_input_wrapper">
			<image mode="aspectFit" src="/static/code.png" :style="$util.calcImageSize(20)">
			</image>
			<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE"></input>
		</view>

		<view style="width: 60%;position: relative;height: 24px;line-height: 24px;">
			<u-checkbox-group v-if="isSignIn">
				<u-checkbox :activeColor="$util.THEME.SECONDARY" label="로그인 상태 유지" v-model="checked"></u-checkbox>
			</u-checkbox-group>
			<view style="display: flex;align-items: center;position: absolute;right: 0;top: 0;" @click="handleChange()">
				<text style="font-size: 14px;color:#FFF;">{{isSignIn?$lang.SIGN_UP:$lang.SIGN_IN}}</text>
				<image mode="aspectFit" src="/static/arrow-right.png" :style="$util.calcImageSize(16)"
					style="padding:0 10px;"></image>
			</view>
		</view>
		
		<view class="common_btn" style="width:50%;margin-top: 20px;" @click="handleConfirm()">
			{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user: "",
				password: '',
				password2: '',
				code: '',
				isSignIn: true,
				checked: false,

			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput');
			let passinput = uni.getStorageSync('passinput');
			console.log(userinput);

			if (userinput) {
				this.user = userinput
			}
			if (passinput) {
				this.password = passinput
			}
		},
		methods: {
			handleChange() {
				this.isSignIn = !this.isSignIn;
				// this.user = "";
				// this.password = "";
				// this.password2 = "";
				// this.code = "";
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.password2 == '') {
					uni.$u.toast(this.$lang.PASSWORD_CONFIRM);
					return false;
				}
				if (!this.isSignIn && this.password2 != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.INVITATION_CODE);
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNIN_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_IN, {
					username: this.user,
					password: this.password,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					const token = result.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async register() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNUP_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_UP, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.password,
					invite: this.code,
					code: 123456,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.signIn();
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>