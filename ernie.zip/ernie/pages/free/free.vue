<template>
	<view>
		<Header :title="$lang.FAVORITES"></Header>
		<view >
			<view class="box common_block">
				<view class="top flex flex-b" style="height:24px;">
					<view class="flex-2">코드/종목명</view>
					<view class="flex-1 t-r"></view>
					<view class="flex-1 t-r">등락률</view>
					<view class="t-r" style="margin-left: 10px;">최신</view>
				</view>
				<view style="min-height: 82vh;">
					<view class="box-item flex flex-b" v-for="(item,index) in business"
						@click="$u.route('/pages/marketQuotations/productDetails',{code:item.goods.number_code});">
						<view class="list-name flex-2">
							<view style="display: inline-block;padding-right: 16px;font-weight: 900;"
								:style="{color:$util.THEME.SECONDARY}">
								{{item.goods.number_code}}
							</view>
							<view style="display: inline-block;" class="list-name-txt "
								:style="$util.calcStyleRiseFall(item.goods.rate>0)">
								{{item.goods.name}}</view>
						</view>
						<view class="flex-1 t-c num-font" style="text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{$util.formatNumber(item.goods.current_price)}}
						</view>
						<view class="per flex-1 t-r"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
						</view>
						<image mode="aspectFit" src="/static/star.png" :style="$util.calcImageSize(24)"
							@click.stop="handleClickDelProduct(item.goods.gid)"></image>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	export default {
		components: {
			Header
		},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: '',
				updata: true,
				exchange: '',
				timerId: null
			}
		},
		methods: {

			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//产品세부
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			//跳转行情
			marketQuotations() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/marketQuotations'
				});
			},


			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: gid,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = false
					this.updata = true
					this.free()
					// this.$router.go(0)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			async market() {
				let list = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 10,
				})
				//上证指数
				this.exchange = list.data.data.zhishu
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			//版本更新
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(list.data.data, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('선택적 요청');
					this.free();
					this.market()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},

		},

		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			this.free()
			this.market()
			this.is_token()
			this.startTimer()
		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	.top {
		height: 55px;
		border-bottom: 1px solid #e5e8f6;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
	}

	.box .top {
		padding: 10px;

		view {
			color: #91a2b1;
		}

	}

	.box .box-item {
		padding: 10px;

		.list-name-txt {
			font-weight: 700;
			color: #333;

			span {
				background: #f0f3fa;
				border-radius: 5px;
				padding: 2px 5px;
				margin-left: 5px;
				font-size: 12px;
				font-weight: 400;
				color: #333;
			}
		}

		.per {
			font-weight: 700;
			border-radius: 10px;
			padding: 5px;
		}

		.per.bg-red {
			background-color: #ff3636;
			color: #fff;
			border-radius: 5px;
			text-align: center;
			padding: 3px 0px;
		}

		.red {
			font-weight: 700;
			color: #ff3636;

		}

		.per.bg-green {
			background-color: #014b8d;
			color: #fff;
			border-radius: 5px;
			text-align: center;
			padding: 3px 0px;
		}

		.green {
			font-weight: 700;
			color: #014b8d;

		}
	}
</style>