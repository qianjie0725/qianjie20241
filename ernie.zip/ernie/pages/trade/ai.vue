<template>
	<view>
		<CustomHeader title="AI트레이딩" @action="handleBack()"></CustomHeader>

		<view style="display: flex;align-items: center;justify-content: space-around;margin-bottom:30px;">
			<view style="border-radius: 4px; padding: 4px 10px;" @click="changeTab(0)"
				:style="{color:curTab==0?'#FFF':'#121212',backgroundColor:curTab==0?'#3c1f20':'#fbfaa9'}">
				AI트레이딩</view>
			<view style="border-radius: 4px; padding: 4px 10px;" @click="changeTab(1)"
				:style="{color:curTab==1?'#FFF':'#121212',backgroundColor:curTab==1?'#3c1f20':'#fbfaa9'}">
				거래내역</view>
		</view>

		<view class="common_block" style="padding:0 6px 20px 6px;background-color: #fff;min-height:80vh;">

			<template v-if="curTab==0">
				<TradeAIBuy @action="changeTab"></TradeAIBuy>
			</template>
			<template v-else>
				<TradeAIOrderList></TradeAIOrderList>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeAIBuy from '@/components/trade/TradeAIBuy.vue';
	import TradeAIOrderList from '@/components/trade/TradeAIOrderList.vue';
	export default {
		components: {
			CustomHeader,
			TradeAIBuy,
			TradeAIOrderList,
		},
		data() {
			return {
				options: {},
				curTab: 0,
			}
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		onLoad(opts) {
			this.options = opts;
		},

		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>

<style>
</style>