<template>
	<view>
		<Header :title="$lang.USER_CENTER"></Header>

		<view class="common_block">
			<view style="display:flex;align-items: center;padding:10px 20px;">
				<image mode="aspectFit" :src="avatar" :style="$util.calcImageSize(80)"></image>
				<view>
					<view class="text-center bold font-size-20">
						{{userInfo.real_name}}
					</view>
					<view class="text-center" style="color: #bcbec2;margin:10px 30px;">
						{{userInfo.mobile}}
					</view>
				</view>
				<image mode="aspectFit" :src="`/static/Vip${userInfo.vip}.png`" :style="$util.calcImageSize(80)"></image>
			</view>

			<view
				style="width: 90%;background-color: #fff9a8;border: 1px solid #e5c686;margin-left: 5%;border-radius: 10px;margin-bottom: 10px;"
				class="flex">
				<view class="padding-10 flex-1">
					<view class="flex align-center">
						총자산
						<u-image src="/static/my/biyan.png" style="margin-left: 5px;" width="20px" height="auto"
							mode="widthFix" @click="yan_show=false" v-if="yan_show"></u-image>

						<u-image src="/static/my/zhengyan.png" style="margin-left: 5px;" width="20px" height="auto"
							mode="widthFix" @click="yan_show=true" v-if="!yan_show"></u-image>
					</view>

					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{$util.formatNumber(userInfo.totalZichan)}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
				</view>
				<view class="padding-10 flex-1">
					<view class="flex align-center">
						사용가능금액
					</view>

					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{$util.formatNumber(userInfo.money)}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
				</view>
			</view>
		</view>
		<view class="common_block" style="margin-top: 20px;">
			<u-cell-group>
				<u-cell title="실명 인증 안되었습니다" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#e82d28"
					v-if="userInfo.is_check==-1" @tap="notCertified()">
					<u-icon slot="icon" size="32" name="/static/sm.png" :bold="true"></u-icon>
				</u-cell>

				<u-cell title="확인됨[검토중]" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#77cfad"
					v-if="userInfo.is_check==0" @tap="notCertified()">
					<u-icon slot="icon" size="32" name="/static/sm.png" :bold="true"></u-icon>
				</u-cell>

				<u-cell title="확인됨[감사 실패]" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#e82d28"
					v-if="userInfo.is_check==2" @tap="notCertified()">
					<u-icon slot="icon" size="32" name="/static/sm.png" :bold="true"></u-icon>
				</u-cell>

				<u-cell title="고객센터" titleStyle="margin-left:10px;font-weight:700;color:#3c1f20;" @click="customer()">
					<u-icon slot="icon" size="32" name="/static/kefu.png" :bold="true"></u-icon>
				</u-cell>
			</u-cell-group>
		</view>

		<view class="common_block" style="margin-top: 20px;">
			<u-cell-group>

				<u-cell title="로그인 비밀번호 변경" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#3c1f20;"
					@tap="changePassword()">
					<u-icon slot="icon" size="32" name="/static/yaoshi.png" :bold="true"></u-icon>
				</u-cell>


				<u-cell title="출금 비밀번호 설정" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#3c1f20;"
					@tap="fundPassword()">
					<u-icon slot="icon" size="32" name="/static/suo.png" :bold="true"></u-icon>
				</u-cell>

				<u-cell title="입출금 계좌 연동" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#3c1f20;"
					@tap="manages()">
					<u-icon slot="icon" size="32" name="/static/ka.png" :bold="true"></u-icon>
				</u-cell>


				<u-cell title="입출금 내역" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#3c1f20;"
					@tap="capitalDetails()">
					<u-icon slot="icon" size="32" name="/static/jilu.png" :bold="true"></u-icon>
				</u-cell>

				<u-cell title="회사 소개" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#3c1f20;"
					@tap="aboutUs()">
					<u-icon slot="icon" size="32" name="/static/about.png" :bold="true"></u-icon>
				</u-cell>


			</u-cell-group>
		</view>
		<view
			style="width: 100%;display: flex;justify-content: space-evenly;margin-top: 20px;">
			<!-- <view @click="silver()" class="common_btn"
				style="padding:10px;border-radius: 10px;text-align: center;flex:35%;margin:0 20px 10px 20px"
				:style="{color:$util.THEME.PRIMARY}">
				충전</view> -->
			<view @click="clear()" class="common_btn"
				style="padding:10px;border-radius: 10px;text-align: center;flex:35%;margin:0 20px 10px 10px;background-color: #3C1E20;color: #FFF;" >계정 로그아웃</view>
		</view>

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	export default {
		components: {
			Header
		},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInfo: {},
				is_check: '',
				cardManagement: '',
				item: '',
				yan_show: true
			}
		},
		computed: {
			avatar() {
				return this.userInfo.avatar || "/static/avatar.png";
			}
		},
		onShow() {
			this.phoneNumShow()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('로그아웃 성공');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			//客服
			async customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
				// let kefu = await this.$http.get('api/app/config', {})
				// window.open(kefu.data.data[8].value, '_blank');
			},
			//隐藏手机号
			phoneNumShow() {
				let that = this;
				let number = this.tel; //获取到手机号码字段
				let mphone = number.substring(0, 3) + '****' + number.substring(7);
				that.tel = mphone
			},
			// 跳转到设置
			setUp(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/setUp/setUp'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			// 银转证
			silver() {
				uni.navigateTo({
					url: "/pages/my/components/certificateBank/silver"
				})
			},
			// 실시간 이체
			prove(money) {
				uni.navigateTo({
					url: '/pages/my/components/certificateBank/prove' + `?money=${money}`
				});
			},
			//修改密码
			changePassword() {
				uni.navigateTo({
					url: '/pages/my/components/commonFunctions/changePassword'
				});
			},
			//펀드 비밀번호
			fundPassword() {
				uni.navigateTo({
					url: '/pages/my/components/commonFunctions/fundPassword'
				});
			},
			//资金流水
			capitalDetails() {
				uni.navigateTo({
					url: '/pages/my/components/commonFunctions/capitalDetails?index=0'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
			},
			manages() {
				if (this.cardManagement) {
					uni.navigateTo({
						url: '/pages/my/components/bankCard/binding'
					});
				} else {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/bankCard/renewal'
					});
				}
			},
			//版本更新
			Update() {
				uni.navigateTo({
					url: '/pages/my/components/other/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					url: '/pages/my/components/other/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					url: '/pages/my/components/other/privacyAgreement'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					url: '/pages/my/components/other/aboutUs'
				});
			},
			//实名认证
			notCertified() {
				console.log('?');
				uni.navigateTo({
					url: '/pages/marketQuotations/authentication'
				});
			},


			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInfo =result.data.data;
				this.cardManagement = result.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},

		onShow() {
			this.gaint_info()
			this.is_token()
		},
	}
</script>