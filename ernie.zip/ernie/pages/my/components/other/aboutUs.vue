<!-- 关于我们 -->
<template>
	<view >
		<CustomHeader :title="about.title" @action="home()"></CustomHeader>
		<view class="common_block" >
			<view v-html="about.content" style="font-size: 14px;white-space: break-spaces;line-height: 1.5;padding:10px;" :style="{color:$util.THEME.PRIMARY_COLOR}"></view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				about: ''
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//关于我们
			async about_us() {
				let list = await this.$http.get('api/article/about-us', {
					// language: this.$i18n.locale
				})
				this.about = list.data.data
				// console.log(list.data.data, '关于我们');
			},
		},
		mounted() {
			this.about_us()
		},
	}
</script>

<style lang="scss">
	.college-bg {

		padding: 20rpx;

		height: 80rpx;

		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

	}
</style>