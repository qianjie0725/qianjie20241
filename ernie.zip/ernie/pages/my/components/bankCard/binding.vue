<!-- 绑定银行卡 -->
<template>
	<view>
		<CustomHeader title="입출금 계좌 연동" @action="home()"></CustomHeader>

		<view
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:10vh;">
			<view style="width:60%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;background-color: rgba(255,255,255,0.75);border-radius: 100px;" :style="{color:$util.THEME.SECONDARY}">
				<view style="width: 60px;display: inline-block;">성명:</view>
				<view style="display: inline-block;border-bottom: 1px solid #e5c686;font-size: 18px;font-weight: 700;"> {{cardManagement.realname}}
				</view>
			</view>

			<view style="width:60%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 10px;background-color: rgba(255,255,255,0.75);border-radius: 100px;" :style="{color:$util.THEME.SECONDARY}">
				<view style="width: 60px;display: inline-block;">은행명:</view>
				<view style="display: inline-block;border-bottom: 1px solid #e5c686;font-size: 18px;font-weight: 700;"> {{cardManagement.bank_name}}
				</view>
			</view>

			<view style="width:60%;height: 30px;line-height: 30px;padding-left: 10px;background-color: rgba(255,255,255,0.75);border-radius: 100px;" :style="{color:$util.THEME.SECONDARY}">
				<view style="width: 60px;display: inline-block;">계좌번호:</view>
				<view style="display: inline-block;border-bottom: 1px solid #e5c686;font-size: 18px;font-weight: 700;"> {{cardManagement.card_sn}}</view>
			</view>

			<view class="common_btn" style="width:60%;margin-top: 20px;" @click="renewal()">확인</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				cardManagement: '',
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			renewal() {
				uni.navigateTo({
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.cardManagement = list.data.data.bank_card_info
			},
		},
		onLoad() {
			this.gaint_info()
		},
	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		// font-weight: 700;
		background-color: #f5f5f5;
		display: flex;
		font-size: 28rpx;
		margin-top: 10px;
		border: 2rpx solid #f4f4f4;
		border-radius: 10px;

		view {
			width: 30%;
		}

		text {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}

	.xian {
		height: 2rpx;
		width: 100%;
		background: #fff;
	}
</style>