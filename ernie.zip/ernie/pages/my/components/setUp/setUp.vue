<template>
	<view>
		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">설정</view>
			<view class=""></view>
		</view>

		<view class="head" @tap="sculpture()">
			<view class="sculpture">프로필</view>
			<!-- <image class="picture" src="../../../../static/logo.png" mode=""></image> -->
			<u-avatar size='50' :src="userInformation.avatar" shape="circle"></u-avatar>
		</view>
		<view class="head">
			<view class="sculpture">전화 번호</view>
			<view class="">{{userInformation.mobile}}</view>
		</view>
		<view class="head">
			<view class="sculpture">로그아웃</view>
			<!-- <image class="withdraw" @click="clear" src="../../../../static/my/tuichu.png" mode=""></image> -->
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInformation: ""

			};
		},
		methods: {

			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				// this.cardManagement = list.data.data.bank_card_info
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			sculpture() {
				uni.navigateTo({
					url: '/pages/my/components/setUp/modifyAvatar'
				});
			},
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.clearStorageSync();
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('로그아웃 성공');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},

		},

		onLoad(option) {
			this.gaint_info()
			this.userInformation = {
				mobile: option.mobile || '',
				avatar: option.avatar || ','
			}
			// console.log(option.avatar, '1111'); //打印出上个页面传递的参数。
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color:  #045097;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	}

	.head {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx;
		border-bottom: 2rpx solid #e9e9e9;

		.picture {
			width: 120rpx;
			height: 120rpx;
			border-radius: 50%;
		}

		.withdraw {
			width: 40rpx;
			height: 40rpx
		}
	}
</style>
