<!-- 펀드 비밀번호 -->
<template>
	<view >
		<CustomHeader title="출금 비밀번호 설정" @action="home()"></CustomHeader>
		<view
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:10vh;">
			<u--input placeholder="새 비밀번호를 입력 해주세요" prefixIcon="lock-fill" :color='$util.THEME.SECONDARY' shape="circle"
				placeholderStyle="font-size: 10px;color: #ababab"
				prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value2" type="password"
				style="margin-top:30px;background-color: rgba(255,255,255,0.75);"></u--input>

			<u--input placeholder="새 비밀번호를 다시 입력 해주세요" prefixIcon="lock-fill" :color='$util.THEME.SECONDARY' shape="circle"
				placeholderStyle="font-size: 10px;color: #ababab"
				prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value3" type="password"
				style="margin-top:30px;background-color: rgba(255,255,255,0.75);"></u--input>

			<view class="common_btn" style="width:50%;margin-top: 20px;" @click="transactionPassword">확인</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {

				value2: "",
				value3: "",
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//修改交易密码
			async transactionPassword() {
				let list = await this.$http.post('api/user/updatePayPassword', {

					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('수정되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		}
	}
</script>