<template>
	<!-- 新股申购 -->
	<view style="margin:10px">
		<view v-if="newShares_list.length==0" class="flex justify-center" style="margin-top: 40%;">
			<view class="text-center">
				<image src="/static/no.png" mode="widthFix" style="width: 120px;"></image>
				<view class="bold font-size-20 margin-top-10">데이터 없음</view>
			</view>
			
		</view>
		<view style="background-color: #FFF;height: 60vh;margin-top: 10px;padding-top:5px;overflow-y: scroll;"  v-if="newShares_list.length>0">
			<view class="" v-show="content == 0">
				<view class="" v-for="(item,index) in newShares_list" :key="item.index">
					<view style="border-bottom: 0.01rem solid #e0e0e0;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
							</view>
							<view>
								<view class="zero" @click="to_skip(item.id)">
									<view>청약 신청</view>
									<!-- <view>신청</view> -->
								</view>
								<!-- <view class="display thousand">
								<view>100万可用</view>
								<view>配送</view>
							</view> -->
							</view>
						</view>
						<view class="subscription-time">청약 날짜<text>{{item.shengou_date}}</text> </view>
						<view class="display">
							<view class="display price">청약
								금액<text>{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
							</view>
							<view class="display price">
								수익률<text>{{item.shiying.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
							</view>
						</view>
						<!-- <view class="display price">순환<text>{{item.fa_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text> </view> -->
					</view>
				</view>
		
				<view class="finished-text" v-if="newShares_list.length<=0">
					거래 내역 없음
				</view>
		
			</view>
			<view class="" v-show="content == 1">
		
				<view class="" v-for="(item,index) in newShares_list2" :key="item.index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
								<view class="area" v-if="item.goods.locate=='깊은'">
									<view class="deep">{{item.goods.locate}}</view>
									<view class="deep-number">{{item.goods.code}}</view>
								</view>
								<view class="area" v-if="item.goods.locate=='북쪽'">
									<view class="north">{{item.goods.locate}}</view>
									<view class="north-number">{{item.goods.code}}</view>
								</view>
								<view class="area" v-if="item.goods.locate=='상하이'">
									<view class="shanghai">{{item.goods.locate}}</view>
									<view class="shanghai-number">{{item.goods.code}}</view>
								</view>
							</view>
							<!-- 	<view>
							<view class="zero" @click="to_skip(item.gid)">
								<view>0원으로 구독 가능</view>
								<view>申购</view>
							</view>
							<view class="display thousand">
								<view>100万可用</view>
								<view>配送</view>
							</view>
						</view> -->
							<view class="subscription-times">구독 시간<text>{{item.shengou_date}}</text> </view>
						</view>
		
						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">구독
								가격<text>{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
							</view>
							<view class="display price">
								주가수익비율<text>{{item.shiying.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
							</view>
						</view>
						<view class="display price">
							순환<text>{{item.fa_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
						</view>
					</view>
				</view>
				<view class="finished-text" v-if="newShares_list2.length<=0">내역 없음</view>
		
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['newShares_list', 'newShares_list2'],
		data() {
			return {
				content: 0,
				items: ['구매 내역', '배정 수량'],
				value1:'',
			};
		},
		onLoad(item) {
			// console.log('?');
		},
		
		methods: {
			//구독기록
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
				});
			},
			//우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},

			to_skip(id) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/nullElement/nullElement' +
						`?id=${id}`
				});
				// console.log(gid, fa_price, '携带');

			},

			// nullElement(gid) {
			// 	uni.navigateTo({
			// 		url: '/pages/index/components/newShares/nullElement/nullElement?gid=${gid}'
			// 	});
			// },
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	// 没有更多
	.finished-text {
		color: #969799;
		font-size: 28rpx;
		margin: 30rpx auto;
		text-align: center;
		padding: 30rpx 0;
	}

	// 新购申购 开始
	// .white-background {
	// 	background: #fff;
	// 	margin-top: -50rpx;
	// 	border-radius: 20rpx 20rpx 0 0;

	// .take-notes {
	// 	display: flex;
	// 	justify-content: space-around;
	// 	align-items: center;
	// 	text-align: center;
	// 	padding: 60rpx 60rpx 30rpx;

	// 	.purchase {
	// 		font-size: 28rpx;

	// 		image {
	// 			width: 40px;
	// 			height: 40px;
	// 		}
	// 	}
	// }

	// }

	.tab-header {
		background-color: #aac0ff;
		height: 60rpx;
		display: flex;
	}

	.tab-content {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #363636;
		height: 60rpx;
		line-height: 60rpx;
		position: relative;
	}

	.content-selection {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #f85050;
	}

	.approve {
		padding: 30rpx 30rpx 0;

		.corporation {
			font-size: 30rpx;
			font-weight: 800;
			margin-bottom: 10rpx;
		}

		.zero {
			display: flex;
			justify-content: space-around;
			align-items: center;
			background-image: url('../../static/erceng/sheng1.png');
			background-size: cover;
			color: #fff;
			margin: 20rpx 0rpx 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;

		}

		.thousand {
			display: flex;
			justify-content: space-around;
			align-items: center;
			background-image: url('../../static/erceng/shen2.png');
			background-size: cover;
			color: #fff;
			margin: 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;
		}
	}

	.treat {
		display: flex;
		justify-content: flex-start;
		align-items: center;

		.subscription {
			margin-right: 100rpx;
		}
	}

	.subscription-time {
		margin: 6rpx 30rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;

		text {
			color: #f85252;
			margin-left: 10rpx;
		}
	}

	.subscription-times {
		// margin: 10rpx 20rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 44%;

		text {
			color: #f85252;
			// margin-left: 10rpx;
		}
	}

	.price {
		margin: 6rpx 30rpx;
		width: 42%;
		font-size: 28rpx;

		text {
			color: #f85252;
			// margin-left: 10rpx;
		}
	}

	// 新购申购 结束
</style>