<template>
	<view class="page">
		<view class="flex" style="background-color: #e8a841;padding: 10px;">
			<view class="flex-1" style="color: #fff;font-size: 38rpx;">실시간현황</view>
			<view class="flex-2 flex" @click="$u.route({url:'/pages/searchFor/searchFor'});">
				<u--input shape="circle"
						suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
						suffixIcon="/static/sousuo.png"
						type="number"
						maxlength="11"
						border="none"
						:disabled="true"
						style="pointer-events: none"
						customStyle="background: #fff;height:60rpx;width:50%;margin-left: auto;pointer-events: none"
						
					></u--input>
			</view>
			
			
		</view>
		<view class="flex padding-10" style="gap: 10px;">
			<view class="flex-1  text-center" :class="current==index?'top-a':'top'"  v-for="(item,index) in tablist" @click="change(index)">
				{{item.name}}
			</view>
		</view>
		<!-- <u-tabs :list="tablist" lineColor="#014bab"  activeStyle="color:#014bab;font-size:18px;font-weight: 700;"  inactiveStyle="font-size:18px;font-weight: 700;" @change="change" :current="current"></u-tabs> -->
		
		<TabOne v-if="current==0"></TabOne>
		<TabTwo v-if="current==1"></TabTwo>
		<TabThree v-if="current==2"></TabThree>
		<TabFour v-if="current==3"></TabFour>
	</view>
</template>

<script>
	// import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import  TabOne   from '@/components/market/TabOne.vue'
	import  TabTwo   from '@/components/market/TabTwo.vue'
	import  TabThree   from '@/components/market/TabThree.vue'
	import  TabFour   from '@/components/market/TabFour.vue'
	export default {
		components: {
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				tablist: [{
					name: '전체요약'
				}, {
					name: '인기종목'
				}, {
					name: '시장지표'
				}, {
					name: '시장이슈'
				}],
				current:0
			}
		},
		onShow() {},
	
		
		methods: {
			change(index) {
				console.log(index)
				this.current = index;
			},
		},

		mounted() {},
		
		onLoad(op) {
			if(op.type){
				this.current=op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">

	view, text {
	    box-sizing: border-box;
	}
	page{
		background-color: #F3F4F8;
	}
	.home{
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */  
		background-size: cover;  
	  /* 让背景图片始终位于容器的中心 */  
		background-position: center;  
	  /* 不重复背景图片 */  
		background-repeat: no-repeat;  
		height: 600rpx;
		margin-left: -10px;
	}
	.top-a{
		background-image: url(/static/market/top1.png);
		background-repeat: repeat;
		color: #F1A640;
		font-weight: 700;
		height: 38px;
		line-height: 34px;
	}
	.top{
		background-color: #fff;
		color: #666666;
		height: 34px;
		line-height: 34px;
		margin-top: -4px;
	}
</style>