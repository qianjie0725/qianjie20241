<template>
	<!-- 登录 -->
	<view >
		
		<view class="logo1" style="margin-top: 26%;">
			<view class="border flex flex-c">
				<view class="icon logo"></view>
			</view>
		</view>
		<view style="margin-top: 5%;" >
			<view style="margin-left: 10%;">
				<view class="padding-10" style="color: #000;font-size: 36rpx;">로그인 시작</view>
				<view class="flex">
					<view class="padding-left-10 bold" style="color: #000;font-size: 38rpx;">MGI</view>
					<view class="padding-left-5 bold" style="color: #000;font-size: 32rpx;">
						top</view>
				</view>
			</view>
			<view class="flex justify-center margin-top-30">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input 
					customStyle="height:40px;box-shadow: #eed7c2 0px 7px 29px 0px;"
						    placeholder="아이디를 입력"
						    prefixIcon="account-fill"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="value1"
							type="number"
							maxlength="11"
						></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 50px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input 
					customStyle="height:40px;box-shadow: #eed7c2 0px 7px 29px 0px;"
						    placeholder="비밀번호를 입력"
						    prefixIcon="lock-fill"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="value2"
							type="password"
						></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 50px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input 
					customStyle="height:40px;box-shadow: #eed7c2 0px 7px 29px 0px;"
						    placeholder="비밀번호 재입력"
						    prefixIcon="lock-fill"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="value3"
							type="password"
						></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 50px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input 
					customStyle="height:40px;box-shadow: #eed7c2 0px 7px 29px 0px;"
						    placeholder="초대 코드 입력"
						    prefixIcon="attach"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="code"
						></u--input>
				</view>
			</view>
			
			<view class="margin-top-40 text-right flex justify-end" style="margin-right: 10%;">
				<view style="font-size: 12px;color: #ababab" @tap="signIn()">
					로그인
				</view>
				<u-icon name="arrow-right" color="#B3BFD0" size="18" :bold="true"></u-icon>
				
			</view>
			<view class="flex justify-center" style="margin:30px 10%;">
				<view class="radius10 text-center" style="background-color: #e8a946;width: 100%;height: 80rpx;color: #fff;padding: 6px 9px;line-height: 80rpx;" @click="gain_register">
					회원 가입
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name:'',
				value1: '',
				value2: '',
				value3: '',
				code: '',
				checkboxValue1: [],
				showPassword:true
			};
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast('전화번호를 입력해주세요.');
				} else if (this.value2 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('두 개의 비밀번호가 일치하지 않습니다');
				} else if (!this.code) {
					uni.$u.toast('인증번호를 입력해주세요');
				} 
				// else if (this.checkboxValue1.length == 0) {
				// 	uni.$u.toast('請閱讀協議後,在勾選');
				// } 
				else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('등록이 완료되었습니다. 로그인하세요.');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/logon/logon/logon'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
		async mounted() {
			await this.login_liufu()
		}
	}
</script>

<style lang="scss">
	page {
		font-size: 36rpx;
		background-image: url('/static/beijing.png');
		background-size: cover;
		background-repeat: no-repeat;
	}
	
	.logo1{
		width: 100%;
		height: 100%;
		.icon.logo {
			width: 160px;
			height: 120px;
			background: url(/static/chuanggai/logo2.png) no-repeat 50%/100%;
			// border-radius: 50%;
		}
	}
</style>