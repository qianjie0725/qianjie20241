<template>
	<!-- 登录-->
	<view>
		<view>
			<view class="logo1" style="margin-top: 26%;">
				<view class="border flex flex-c">
					<view class="icon logo"></view>
				</view>
			</view>
		</view>
		
		
		<view style="margin-top: 5%;">
			<view style="margin-left: 10%;">
				<view class="padding-10" style="color: #000;font-size: 36rpx;">로그인 시작</view>
				<view class="flex">
					<view class="padding-left-10 bold" style="color: #000;font-size: 38rpx;">MGI</view>
					<view class="padding-left-5 bold" style="color: #000;font-size: 32rpx;">
						top</view>
				</view>
			</view>
			<view class="flex justify-center margin-top-30">
				<view  style="height: 40px;width: 80%;">
					<u--input  placeholder="아이디를 입력" prefixIcon="/static/icon_phone.png"
						placeholderStyle="font-size: 10px;color: #ababab"
						prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value1" type="number" customStyle="height:40px;box-shadow: #eed7c2 0px 7px 29px 0px;" maxlength="11"></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 40px;">
				<view style="height: 40px;width: 80%;">
					<u--input  placeholder="비밀번호를 입력" prefixIcon="/static/icon_passward.png"
						placeholderStyle="font-size: 10px;color: #ababab;" customStyle="height:40px;box-shadow: #eed7c2 0px 7px 29px 0px;"
						prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value2"
						type="password"></u--input>
				</view>
			</view>
			<view class="flex margin-top-30" style="margin-left: 10%;">
				<view class="flex flex-1">
					<u-checkbox-group v-model="checked">
						<u-checkbox  activeColor="#e8a946" label="로그인 상태 유지"></u-checkbox>
					</u-checkbox-group>
				</view>
				<view class=" text-right flex justify-end" style="margin-right: 10%;">
					
					<view style="font-size: 12px;color: #ababab" @tap="register()">
						회원가입
					</view>
					<u-icon name="arrow-right" color="#B3BFD0" size="18" :bold="true"></u-icon>
				
				</view>
			</view>
			
			
			<view class="flex justify-center" style="margin:30px 10%;">
				<view class="radius10 text-center"
					style="background-color: #e8a946;width: 100%;height: 80rpx;color: #fff;padding: 6px 9px;line-height: 80rpx;"
					@click="gain_login">
					로그인
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				showPassword: true,
				checked:false
			};
		},
		onShow() {
			let userinput=uni.getStorageSync('userinput');
			let passinput=uni.getStorageSync('passinput');
			console.log(userinput);
		
			if(userinput){
				this.value1=userinput
			}
			if(passinput){
				this.value2=passinput
			}
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//忘记密码
			forget() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/forgot/forgot'
				});
			},
			// 跳转到注册
			register() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/register/register'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					if(this.checked){
						console.log("2222", this.value1, this.value2);
					
						uni.setStorageSync('userinput', this.value1);
						uni.setStorageSync('passinput', this.value2);
					}
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast('성공적 로그인');
					
					
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
		
		}


	}
</script>

<style lang="scss">
	page {
		font-size: 36rpx;
		background-image: url('/static/beijing.png');
		background-size: cover;
		background-repeat: no-repeat;
	}
	
	.logo1{
		width: 100%;
		height: 100%;
		.icon.logo {
			width: 160px;
			height: 120px;
			background: url(/static/chuanggai/logo2.png) no-repeat 50%/100%;
			// border-radius: 50%;
		}
	}
</style>