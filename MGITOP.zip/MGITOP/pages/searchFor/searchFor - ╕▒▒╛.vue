<template>
	<view class="page">
		<view>
			<view class="header flex flex-b">
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">검색</view>
				<view class="header-right"></view><!---->
			</view>
		</view>
		<view class="toubu">
			<u-tabs :activeStyle="{
		    color: '#fff',
		    fontWeight: 'bold',
			fontSize:'32rpx'
		}"
		:inactiveStyle="{
		    color: '#fff',
			fontSize:'32rpx'
		}" lineColor="#fd0e00" :list="gp_select" :current="gp_index" @click="gp_select_click"></u-tabs>
			
		</view>
		<view class="search-box">
			<u-search placeholder="종목코드 검색" v-model="keyword" :clearabled="true" @clear="keyword=''" actionText="검색"
				@search="searchButton" @custom="searchButton"></u-search>
		</view>
		<view class="keyword-block" v-if="keywords">
			<view class="keyword-list-header">검색 기록</view>
			<view class="keyword" >
				<view v-for="(item,index) in keywords" @click="dianji(item)">{{item}}</view>
			</view>
		</view>
		<view class="box" v-if="searchList.length>0">
			<view class="top flex flex-b">
				<view class="flex-2">주식/코드</view>
				<view class="flex-1 t-r">등락률</view>
				<view class="flex-1 t-r">최신</view>
			</view>
			<view class=" box-item flex flex-b" v-for="(item,index) in searchList"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.number_code});">
				<view class="list-name flex-2">
					<view class="list-name-txt ">{{item.name}}<span>{{item.number_code}}</span></view>
				</view>
				<view class="per flex flex-b flex-1 t-r" :class="item.rate*1>0?'bg-red':'bg-green'">
					<view class="icon" :class="item.rate*1>0?'up':'down'"></view>{{item.rate}}%
				</view>
				<view class="flex-1 t-r flex flex-b " :class="item.rate*1>0?'red':'green'"> 
					<view class="flex-1 t-a num-font">{{item.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<!-- <view class="icon  wzx"></view> -->
				</view>
			</view>
		</view>
		<view v-if="!searchList||searchList.length==0">
			<view class="nodata">
				<view  class="no-img"></view>
				<view  class="txt">데이터 없음</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				searchList: '',
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords:[],
				gp_select: [{
					name: "국내",
				}, {
					name: "해외",
				}
				],
				gp_index:0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords=uni.getStorageSync("keywords")
			if(keywords){
				this.keywords=keywords
			}
			console.log(this.keywords)
		},
		methods: {
			gp_select_click(e){
				this.storehouse=""
				this.gp_index=e.index
			},
			dianji(keyword){
				this.keyword=keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			//搜索
			async searchButton() {
				if (this.keyword == '') {
					uni.$u.toast('검색어는 비워둘 수 없습니다. 다시 검색해 주세요');

				} else {
					uni.showLoading({
						title: "검색...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
						gp_index:this.gp_index
					})
					this.searchList = list.data.data
					console.log(8888,list.data.data)
					uni.hideLoading();
					if(list.data.data.length>0){
						if(this.keywords.indexOf(this.keyword)<0){
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords",this.keywords)
						}
					}
					
					
			
					
					
				}

			},
		
		}
	}
</script>

<style lang="scss">
	.page {
		padding: 50px 0 0;
	}

	.page {
		background: #fff;
		min-height: 100vh;
	}

	view,
	uni-text {
		box-sizing: border-box;
	}
	.toubu {
		width: 100%;
		background-image: linear-gradient(to right, #e8a841, #e8a841);
		display: flex;
		justify-content: space-between;
		color: #fff;
	}
	
	.header {
		height: 50px;
		background: #e8a841;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			width: 9px;
			height: 16px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}
	}

	.search-box {
		height: 38px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		margin: 15px 15px 0;
	}

	.keyword-block {
		padding: 15px;

		.keyword-list-header {
			font-size: 16px;
			font-weight: 500;
			color: #e8a841;
		}

		.keyword {
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-flex-flow: wrap;
			flex-flow: wrap;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;

			view {
				margin: 15px 10px 0 0;
				height: 34px;
				background: #f3f4f8;
				border-radius: 3px;
				display: -webkit-box;
				display: -webkit-flex;
				display: flex;
				-webkit-box-align: center;
				-webkit-align-items: center;
				align-items: center;
				-webkit-box-pack: center;
				-webkit-justify-content: center;
				justify-content: center;
				padding: 0 10px;
				font-size: 14px;
				font-family: PingFangSC-Regular, PingFang SC;
				font-weight: 400;
				color: #000;
			}
		}
	}

	.nodata {
		padding: 100px 0;
	}

	.no-img {
		width: 164px;
		height: 122px;
		background: url(/static/none.png) no-repeat 50%/100%;
		margin: 0 auto 20px;
	}

	.box .top {
		padding: 10px;

		view {
			color: #91a2b1;
		}
	}

	.box .box-item {
		padding: 10px;

		.list-name-txt {
			font-weight: 700;
			color: #333;

			span {
				background: #f0f3fa;
				border-radius: 5px;
				padding: 2px 5px;
				margin-left: 5px;
				font-size: 12px;
				font-weight: 400;
				color: #333;
			}
		}

		.per {
			font-weight: 700;
			border-radius: 10px;
			padding: 5px;
		}

		.per.bg-red {
			background: #f7e7e7;
			color: #ff3636;
		}

		.red {
			font-weight: 700;
			color: #ff3636;

		}

		.per.bg-green {
			background: #e7f1f9;
			color: #e8a841;
		}

		.green {
			font-weight: 700;
			color: #e8a841;
		}

	}
	.txt{
		color: #333;
		text-align: center;
	}
</style>