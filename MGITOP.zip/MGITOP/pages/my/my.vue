<template>
	<view>
		<view class=" header" style="padding: 10px;display: flex;padding-top: 20px;">
			<view style="color: #fff;font-size: 38rpx;flex:1">더보기</view>
			<view  @click="$u.route({url:'/pages/searchFor/searchFor'});" style="flex:2;display: flex;padding-right: 20px;">
				<u--input shape="circle" suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
					suffixIcon="/static/sousuo.png"  type="number" maxlength="11" border="none"
					:disabled="true" style="pointer-events: none"
					customStyle="background: #fff;height:60rpx;width:50%;margin-left: auto;pointer-events: none"></u--input>
			</view>
			

		</view>
		<view style="padding: 10px;margin-top: -300px;">
			<view class="flex margin-left-10">
				<u-avatar size='80' :src="userInformation.avatar" default-url="/static/chuanggai/logo2.png" shape="circle" ></u-avatar>
				<view class="color-white">
					<view class="bold font-size-20" v-if="userInformation.is_check==1">{{userInformation.real_name}}</view>
					<view style="color: #f3d8b4;">{{userInformation.mobile}}</view>
				</view>
			</view>
			
	
		
			<view style="border: 1px #e9a841 solid;border-radius: 10px;margin-bottom: 10px;background-image: url(/static/my_top1.png);height: 150px;" class="flex text-center flex-b">
				<view class="padding-10 flex-1" >
					<view class="flex align-center justify-center">
						총자산
						<u-image src="/static/my/biyan.png" style="margin-left: 5px;" width="20px" height="auto" mode="widthFix" @click="yan_show=false" v-if="yan_show"></u-image>
						
						<u-image src="/static/my/zhengyan.png" style="margin-left: 5px;" width="20px" height="auto" mode="widthFix" @click="yan_show=true" v-if="!yan_show"></u-image>
					</view>
					
					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{userInformation.totalZichan}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
					
					<view style="background-color: #e9a841;" class="padding-5 radius10 color-white bold flex-1 text-center margin-top-10" @click="silver()">
						충전
					</view>
				</view>
				
				<view class="padding-10 flex-1" >
					<view class="flex align-center justify-center">
						가용 자금
					</view>
					
					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{userInformation.money}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
					<view style="background-color: #fff;border: 1px #e9a841 solid;" class="flex-1 radius10 padding-5 text-center margin-top-10" @click="prove">
						자금인출
					</view>
				</view>
			</view>
		</view>
		
		<view style="border: #e9a841 1px solid;margin: 10px;" class="flex flex-b padding-20 background-white">
			<view class="text-center" v-if="userInformation.is_check==1" @tap="notCertified()">
				<image src="/static/my/sm.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12" >실제 이름</view>
			</view>
			<view class="text-center" v-if="userInformation.is_check==-1" @tap="notCertified()">
				<image src="/static/my/sm.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12" >실명인증</view>
			</view>
			<view class="text-center" v-if="userInformation.is_check==0" @tap="notCertified()">
				<image src="/static/my/sm.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12" >확인됨[검토중]</view>
			</view>
			<view class="text-center"  v-if="userInformation.is_check==2" @tap="notCertified()">
				<image src="/static/my/sm.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12" >확인됨[감사 실패]</view>
			</view>
			
			<view class="text-center" @tap="capitalDetails()">
				<image src="/static/my/jilu.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12">입출금 내역</view>
			</view>
			<view class="text-center"  @click="customer()">
				<image src="/static/my/kefu.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12">고객센터</view>
			</view>
			<view class="text-center" @tap="manages()">
				<image src="/static/my/ka.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view class="font-size-12">입출금 계좌 연동</view>
			</view>
			
		</view>
		
		
		<view class="margin-top-10" style="background-color: #fff;">
			<u-cell-group>
				
				<u-cell  title="로그인 비밀번호 변경" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="changePassword()">
					<u-icon slot="icon" size="28" name="/static/my/yaoshi.png" :bold="true"></u-icon>
				</u-cell>
				
				
				<u-cell  title="결제 비밀번호" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="fundPassword()">
					<u-icon slot="icon" size="28" name="/static/my/suo.png" :bold="true"></u-icon>
				</u-cell>
				
				
				<u-cell  title="회사 소개" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="aboutUs()">
					<u-icon slot="icon" size="28" name="/static/my/about.png" :bold="true"></u-icon>
				</u-cell>
				<u-cell  title="로그 아웃" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="clear()">
					<u-icon slot="icon" size="28" name="/static/my/tuichu.png" :bold="true"></u-icon>
				</u-cell>
				
			</u-cell-group>
		</view>
		<!-- <view style="width: 90%;background-color: #e9a841;margin-left: 5%;height: 40px;line-height: 40px;border-radius: 6px;text-align: center;color: #fff;margin-top: 20px;margin-bottom: 100px;" @click="clear">로그인 종료</view> -->
		
	</view>
</template>

<script>
	// import annular from "./components/annular/annular.vue"
	export default {

		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInformation: {},
				is_check: '',
				cardManagement: '',
				item: '',
				yan_show:true
			}
		},
		onShow() {
			this.phoneNumShow()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('성공적으로 종료');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			//客服
			async customer() {
				this.kefu()
			},
			//隐藏手机号
			phoneNumShow() {
				let that = this;
				let number = this.tel; //获取到手机号码字段
				let mphone = number.substring(0, 3) + '****' + number.substring(7);
				that.tel = mphone
			},
			// 跳转到设置
			setUp(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/setUp/setUp'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			async kefu() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			// 银转证
			silver() {
				this.kefu()
			},
			// 실시간 이체
			prove() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove'
				});
			},
			//修改密码
			changePassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/changePassword'
				});
			},
			//펀드 비밀번호
			fundPassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/fundPassword'
				});
			},
			//资金流水
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=0'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			manages() {
				if(this.cardManagement){
					uni.navigateTo({
						url: '/pages/my/components/bankCard/binding'
					});
				}else{
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/bankCard/renewal'
					});
				}
				
			},
			//版本更新
			Update() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/privacyAgreement'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/aboutUs'
				});
			},
			//实名认证
			notCertified() {
				console.log('?');
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/authentication'
				});
			},


			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				const _fmtTotal = list.data.data.totalZichan.toString().length<3?list.data.data.totalZichan:list.data.data.totalZichan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtMoney = list.data.data.money.toString().length<3?list.data.data.money:list.data.data.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				this.userInformation = {...list.data.data,totalZichan :_fmtTotal,money:_fmtMoney}
				this.cardManagement = list.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			

		},

		onShow() {
			this.gaint_info()
			this.is_token()
		},

	}
</script>

<style lang="scss">
	
	.header {
		height: 340px;
		background-image: url('/static/my_top.png');
		background-size: cover;
		background-repeat: no-repeat;
		background-position: center;
	}
</style>