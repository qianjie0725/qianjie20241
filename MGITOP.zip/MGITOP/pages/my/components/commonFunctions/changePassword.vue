<!-- 修改登陆密码 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">비밀번호 재설정</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<view class="cipher">
				<input placeholder="이전 비밀번호를 입력해주세요" type="password" v-model="value"></input>
			</view>
			<view class="cipher">
				<input placeholder="새 비밀번호를 입력 해주세요" type="password" v-model="value2"></input>
			</view>
			<view class="cipher">
				<input placeholder="새 비밀번호를 다시 입력 해주세요" type="password" v-model="value3"></input>
			</view>
		</view>

		<view class="purchase" @click="changePassword">확인</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//修改登录密码
			async changePassword() {
				let list = await this.$http.post('api/user/updateLoginPassword', {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('수정되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
		// 开局就调用请求
		// mounted() {
		// 	this.changePassword()
		// },
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #e8a841);
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #e8a841);
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
</style>
