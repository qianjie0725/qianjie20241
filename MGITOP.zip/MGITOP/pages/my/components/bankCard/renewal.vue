<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">개인 계좌 연동</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<view class="bank-name">
				<view class="">성명 :</view> <input placeholder="성명" v-model="value"> </input>
			</view>
			<view class="bank-name">
				<view class="">은행명:</view> <input placeholder="은행명" v-model="value2"> </input>
			</view>
			<view class="bank-name">
				<view class="">계좌번호: </view> <input placeholder="계좌번호" v-model="value4"> </input>
			</view>
			
		</view>




		<view class="purchase" @click="replaceBank()">
			확인
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {

				value: '',
				value2: '',
				value3: '',
				value4: ''

			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value2,
					bank_sub_name: this.value3,
					card_sn: this.value4,
				})
				if (list.data.code == 0) {
					uni.$u.toast('은행 카드 정보가 성공적으로 제출되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
		// mounted() {
		// 	this.replaceBank()
		// },
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #e8a841;
		// background-image: linear-gradient(to right, #1a73e8, #e8a841);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 30rpx 20rpx;
			// font-weight: 700;
			display: flex;
			font-size: 28rpx;
			border-bottom: 2rpx solid #f4f4f4;

			view {
				width: 30%;
			}

			input {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #e8a841);
		background-color: #e8a841;
		margin: 100rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		// font-weight: 600;
		font-size: 28rpx;
	}
</style>