<template>
	<view class="page">
		<view class=" header" style="padding: 10px;display: flex;padding-top: 20px;">
			<view  style="color: #fff;font-size: 38rpx;flex:1">관심종목</view>
			<view @click="$u.route({url:'/pages/searchFor/searchFor'});" style="flex:2;display: flex">
				<u--input shape="circle"
						suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
						suffixIcon="/static/sousuo.png"
						type="number"
						maxlength="11"
						border="none"
						:disabled="true"
						style="pointer-events: none"
						customStyle="background: #fff;height:60rpx;width:50%;margin-left: auto;pointer-events: none"
						
					></u--input>
			</view>
			
		</view>
		
		
		<view class="box" style="border-radius: 10px;background: #fff;margin: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;margin-top: -80px;">
			<view class="top flex flex-b">
				<view class="flex-2">주식/코드</view>
				<view class="flex-1 t-r"></view>
				<view class="flex-1 t-r">등락률</view>
				<view class="t-r" style="margin-left: 10px;">최신</view>
			</view>
			<view class=" box-item flex flex-b" v-for="(item,index) in business"
				@click="$u.route('/pages/marketQuotations/productDetails',{code:item.goods.number_code});">
				<view class="list-name flex-2">
					<view class="list-name-txt ">{{item.goods.name}}<span>{{item.goods.number_code}}</span></view>
				</view>
				<view class="flex-1 t-c num-font" :class="item.goods.rate>0?'red':'green'">
					{{item.goods.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
				</view>
				<view class="per flex-1 t-r" :class="item.goods.rate>0?'bg-red':'bg-green'">
					{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
				</view>
				<view class="flex justify-end" style="margin-left: 10px;" :class="item.goods.rate>0?'red':'green'">
					<view class="icon yzx " @click.stop="handleClickDelProduct(item.goods.gid)"></view>
				</view>
			</view>

		</view>
	</view>

</template>

<script>
	export default {
		components: {},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: '',
				updata: true,
				exchange: '',
				timerId: null
			}
		},
		methods: {

			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//产品세부
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			//跳转行情
			marketQuotations() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/marketQuotations'
				});
			},


			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: gid,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = false
					this.updata = true
					this.free()
					// this.$router.go(0)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			async market() {
				let list = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 10,
				})
				//上证指数
				this.exchange = list.data.data.zhishu
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			//版本更新
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(list.data.data, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('선택적 요청');
					this.free();
					this.market()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},

		},

		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			this.free()
			this.market()
			this.is_token()
			this.startTimer()
		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}
	page{
		background-color: #f3f4f8;
	}
	.header {
		height: 150px;
		background-image: url('/static/top_bg.png');
		background-size: cover;
		background-repeat: no-repeat;
		padding: 0 15px;
		width: 100vw;
		
		top: 0;
		left: 0;
		z-index: 1;
	}

	.top {
		height: 55px;
		border-bottom: 1px solid #e5e8f6;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
	}

	.box .top {
		padding: 10px;

		view {
			color: #91a2b1;
		}

	}

	.box .box-item {
		padding: 10px;

		.list-name-txt {
			font-weight: 700;
			color: #333;

			span {
				background: #f0f3fa;
				border-radius: 5px;
				padding: 2px 5px;
				margin-left: 5px;
				font-size: 12px;
				font-weight: 400;
				color: #333;
			}
		}

		.per {
			font-weight: 700;
			border-radius: 10px;
			padding: 5px;
		}

		.per.bg-red {
			background-color: #ff3636;
			color: #fff;
			border-radius: 5px;
			text-align: center;
			padding: 3px 0px;
		}

		.red {
			font-weight: 700;
			color: #ff3636;

		}

		.per.bg-green {
			background-color: #e8a841;
			color: #fff;
			border-radius: 5px;
			text-align: center;
			padding: 3px 0px;
		}

		.green {
			font-weight: 700;
			color: #e8a841;

		}
	}
</style>