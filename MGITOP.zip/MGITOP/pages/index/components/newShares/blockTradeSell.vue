<!-- 大宗 订单列表， 快速抛售 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">보유주문</view>
			<view class=""></view>
		</view>

		<view style="background-color:#FFF;margin:10px">
			<!-- <view style="height: 40px;line-height: 40px;font-size: 16px;font-weight: 700;padding-left: 10px;border-bottom: 1px solid #E8E8EF;margin-bottom: 10px;color:#e9a841;"> 订单记录 </view> -->
			<view style="overflow-y:scroll;height: 90vh;">
				<view v-for="(item,index) in list" :key="index"
					style="border-radius: 10px;border:1px solid #ccc;padding:6px 10px;margin-bottom: 10px;background-color: #E8E8EF;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<text style="font-size: 16px;font-weight: 700;flex:80%;">{{item.goods_info.name}}</text>
						<!-- 抛售 -->
						<view
							style="background-color:#e9a841; color: #fff; border-radius:10px; padding: 6px; font-size: 12px;flex:20%;text-align: center;"
							@click="handleSell(item.id)">매도</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
						<!-- 股票代码 -->
						<text style="flex:20%;">종목코드</text>
						<text style="flex:20%;text-align: right;">{{item.goods_info.code}}</text>
						<view style="flex:10%"></view>
						<!-- 时间 -->
						<text style="flex:20%;">매수시간</text>
						<text style="flex:30%;text-align: right;">{{item.date}}</text>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
						<!-- 当前损益 -->
						<text style="flex:20%;">현재손익</text>
						<text style="flex:20%;text-align: right;color:darkred;">{{item.order_buy.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
						<view style="flex:10%"></view>
						<!-- ' -->
						<text style="flex:20%;">현재가</text>
						<text style="flex:30%;text-align: right;color:darkred;">{{item.goods_info.current_price}}</text>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
						<text style="flex:20%;">상승률</text>
						<text style="flex:20%;text-align: right;" :style="{color:item.goods_info.rate>=0?'red':'green'}">{{item.goods_info.rate}}%</text>
						<view style="flex:10%"></view>
						<text style="flex:20%;">상승폭</text>
						<text style="flex:30%;text-align: right;" :style="{color:item.goods_info.rate>=0?'red':'green'}">{{item.goods_info.rate_num}}</text>
					</view>

					<!-- 					<view style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
						<text style="flex:20%;">价格</text>
						<text style="flex:20%;text-align: right;">{{item.goods_info.price}}</text>
						<view style="flex:10"></view>
						<text style="flex:20%;">数量</text>
						<text style="flex:30%;text-align: right;">{{item.goods_info.num}}</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;font-size: 13px;margin-top: 6px;">
						<text style="flex:20%;">杠杆</text>
						<text style="flex:20%;text-align: right;">{{item.goods_info.double}}</text>
						<view style="flex:10"></view>
						<text style="flex:20%;">价值</text>
						<text style="flex:30%;text-align: right;">{{item.buy_time.slice(0,4)}}</text>
					</view> -->
				</view>
			</view>
		</view>
		<view class="" v-for="(item,index) in list" :key="index">
			<view style="margin: 30rpx; word-wrap:break-word;">

				<!-- <view class="display">
					<view class="">
						<view class="did-not">
							{{item.goods_info.name}}
							<text>매수완료</text>
						</view>
					</view>
					<view class="did-not">
						매수가격 <text>{{item.order_buy.price}}</text>
					</view>
					<view class="did-not" style="background-color: bisque;" @click="handleSell(item.id)">快速抛售</view>
				</view>
				<u-divider></u-divider>
				<view class="display quantity">
					<view class="display">
						<view class="">매수수량</view>
						<view class="red-mark">{{item.order_buy.num}}</view>
					</view>
					<view class="display">
						<view class="">매수금액</view>
						<view class="red-mark">{{item.order_buy.amount}}</view>
					</view>
				</view>
				<view>
					<view class="display">
						<view class="">레버리지</view>
						<view class="" style="text-align: right;">X{{item.order_buy.double}}</view>
					</view>
				</view>

				<view class="display">
					<view class="">매수시간</view>
					<view class="" style="text-align: right;">{{item.created_at}}</view>
				</view> -->

			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
				timer: null,
				page: 1, // 分页
			};
		},
		onShow() {
			this.page = 1;
			this.getList(); // 获取列表数据
		},
		onReachBottom() {
			this.page = this.page + 1;
			this.getList()
		},
		mounted() {
			this.startTimer();
		},
		// 在页面销毁前停止定时器，以防止内存泄漏
		beforeDestroy() {
			this.stopTimer();
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 开始定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},
			// 停止定时器
			stopTimer() {
				clearInterval(this.timer);
			},
			// 获取列表数据 
			async getList() {
				// api/goods-bigbill/user-order-log
				const result = await this.$http.post(`api/goods-bigbill/user-order-list`, {
					page: this.page,
				});
				this.list = result.data.data;
			},
			//  大宗交易 快速抛售
			handleSell(val) {
				console.log('val:', val);
				uni.showModal({
					content: "确认抛售吗?",
					cancelText: "취소", // 取消
					confirmText: "확신하는", // 确认
					success: (res) => {
						if (res.confirm) {
							this.quickSell(val)
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}
				})
			},
			// 快速抛售API
			async quickSell(id) {
				// api/user/sell 平仓  api/jijin/sell
				const result = await this.$http.get('api/user/sell', {
					id: id,
				})
				uni.hideLoading();
				if (result.data.code == 1) {
					uni.$u.toast(result.data.message);
				} else {
					uni.$u.toast(result.data.message);
					this.getList()
				}
			}
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #e9a841;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>