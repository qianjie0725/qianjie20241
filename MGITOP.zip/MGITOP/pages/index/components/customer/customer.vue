<!-- 客服 -->
<template>
	<view>
		<!-- 		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">客服</view>
			<view class=""></view>
		</view> -->

		<!-- <view class="college-content"> -->
		<!-- <web-view :fullscreen="full" class="webview" :style="webviewStyles" :webview-styles="webviewStyles"
				:src='list'></web-view> -->
		<!-- 	<web-view :style="webviewStyles" :webview-styles="webview" :fullscreen="full" :src='list'></web-view>
		</view> -->
		<!-- <template>
			<web-view :src="list"></web-view>
		</template> -->
		<image :src="lineimg"  mode="widthFix" style="margin-left: 20%;width: 60%;margin-top: 50px;" ></image>
		<view class="padding-20">
			<view class="text-center font-size-16">QR 코드를 통해 LINE 친구 추가</view>
					<view class="text-center font-size-14 hui">LINE 앱에서 친구 탭을 열고 친구 추가 아이콘을 탭하세요.
			오른쪽 상단에서 'QR 코드'를 선택한 다음 이 QR 코드를 스캔하세요.</view>
		</view>
		 
		
		<u-button type="primary" @click="saveImg()" text="QR 코드 저장" style="width: 90%;margin-left: 5%;" size="large"></u-button>
		<u-button type="success" @click="link()" text="LINE 열기" style="width: 90%;margin-left: 5%;margin-top:20px" size="large"></u-button>
		
		<view class="padding-20">
			 <view class="text-center font-size-14 red" >"LINE 택배" 버튼이 정상적으로 점프되지 않는 경우, 아래 버튼을 클릭하여 모바일 브라우저에 복사하여 열어주세요.</view>
		</view>
		
		<u-button type="error" @click="fuzhi()" text="LINE 링크 복사" style="width: 90%;margin-left: 5%;margin-top:20px" size="large"></u-button>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: "",
				full: false,
				webviewStyles: {
					height: '91vh',
					width: "100%",
				},
				webview: {
					height: '91vh',
					width: "100%",
				},
				lineimg:"/static/kefu/line.png"
			};
		},
		mounted() {
			this.get_url()
		},
		methods: {
			saveImg() {
				var oA = document.createElement("a");
				oA.download = ''; // 设置下载的文件名，默认是'下载'
				oA.href = this.lineimg;
				document.body.appendChild(oA);
				oA.click();
				oA.remove(); // 下载之后把创建的元素删除
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			fuzhi(){
					
				let info=this.list
				// #ifndef H5
				//uni.setClipboardData方法就是讲内容复制到粘贴板
				uni.setClipboardData({
					data: info,//要被复制的内容
					success:() => {//复制成功的回调函数
						uni.showToast({//提示
							title:'복사가 완료되었습니다. 붙여넣고 브라우저에서 열어주세요.' 
						})
					}
				});
				// #endif
				
				 // #ifdef H5 
					let textarea = document.createElement("textarea")
					textarea.value = info
					textarea.readOnly = "readOnly"
					document.body.appendChild(textarea)
					textarea.select() // 选中文本内容
					textarea.setSelectionRange(0, info.length) 
					uni.showToast({//提示
						title:'복사가 완료되었습니다. 붙여넣고 브라우저에서 열어주세요.' 
					})
					result = document.execCommand("copy") 
					textarea.remove()    
				// #endif
							
			},
			link(){
				window.open(this.list, '_blank');
			},
			async get_url() {
				let list = await this.$http.get('api/app/config', {})
				this.list = list.data.data[8].value
				
			},
		},
		
	}
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		background: #007AFF;
		// background: #ea3544;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	iframe {
		width: 600px !important;
	}

	.college-content {
		width: 100%;
		height: 100%;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>