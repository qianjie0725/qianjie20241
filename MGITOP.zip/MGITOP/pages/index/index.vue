<template>
	<view class="page">
		<view class="home" style="padding: 30px 10px 10px 20px;">
			<view class="flex">
				<view class="flex-1" style="color: #fff;font-size: 38rpx;">
					<u-avatar size='40' :src="userinfo.avatar" default-url="/static/chuanggai/logo2.png"
						shape="circle"></u-avatar>
				</view>

				<view class="flex-4 flex" @click="$u.route({url:'/pages/searchFor/searchFor'});">
					<u--input shape="circle" suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
						suffixIcon="/static/sousuo.png" type="number" maxlength="11" border="none" :disabled="true"
						customStyle="background: #fff;height:60rpx;width:70%;margin-left: auto;"></u--input>
				</view>
				<view @click="$u.route({url:'/pages/email/email'});" style="margin-left: 10px;">
					<!-- <u-icon name="/static/laba.png" ></u-icon> -->
					<image src="../../static/laba.png" mode="widthFix" style="width: 20px;"></image>
				</view>
			</view>
			<view style="margin-top: 20px;">
				<image src="/static/banner.png" style="width: 96%;margin-left: 2%;" mode="widthFix"></image>
			</view>
			<view style="border-radius: 23rpx;width: 100%;height: 160px; " class="margin-top-25">
				<view class="flex">
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newShares?index=0')">
						<view
							style="width: 40px;height: 40px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top1.png"></u-icon> -->
							<image src="/static/home/top1.png" style="width: 40px;height: 40px;"></image>
						</view>
						<!-- 倒卖 -->
						<view class="margin-top-5 font-size-14">
							스캘핑
						</view>
					</view>


					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newShares?index=1')">
						<!-- <u-icon name="/static/home/top2.png" style="width: 40px;height: 40px;"></u-icon> -->
						<image src="/static/home/top2.png" style="width: 40px;height: 40px;"></image>
						<view class="margin-top-5 font-size-14">
							블록딜
						</view>
					</view>
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newShares?index=3')">
						<view
							style="width: 40px;height: 40px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.25); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top4.png" ></u-icon> -->
							<image src="/static/home/top4.png" style="width: 40px;height: 40px;"></image>
						</view>
						<view class="margin-top-5 font-size-14">
							주식 청약
						</view>
					</view>
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/commonFunctions/capitalDetails?index=0')">
						<view
							style="width: 40px;height: 40px;background-color: #fbfdff;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(68, 164, 255, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top3.png"></u-icon> -->
							<image src="/static/home/top3.png" style="width: 40px;height: 40px;"></image>
						</view>
						<view class="margin-top-5 font-size-14">
							입출금 내역
						</view>
					</view>
				</view>

				<view class="margin-top-25  flex">
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/silver')">
						<view
							style="width: 40px;height: 40px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top5.png"></u-icon> -->
							<image src="/static/home/top5.png" style="width: 40px;height: 40px;"></image>
						</view>
						<view class="margin-top-5 font-size-14">
							입금
						</view>
					</view>


					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/prove')">
						<view
							style="width: 40px;height: 40px;background-color: #fbfdff;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(68, 164, 255, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top6.png"></u-icon> -->
							<image src="/static/home/top6.png" style="width: 40px;height: 40px;"></image>
						</view>
						<view class="margin-top-5 font-size-14">
							자금인출
						</view>
					</view>

					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/marketQuotations/authentication')">
						<view
							style="width: 40px;height: 40px;background-color: #fbfdff;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(68, 164, 255, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top7.png"></u-icon> -->
							<image src="/static/home/top7.png" style="width: 40px;height: 40px;"></image>
						</view>
						<view class="margin-top-5 font-size-14">
							실명인증
						</view>
					</view>
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="kefu()">
						<view
							style="width: 40px;height: 40px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.25); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top8.png" ></u-icon> -->
							<image src="/static/home/top8.png" style="width: 40px;height: 40px;"></image>

						</view>
						<view class="margin-top-5 font-size-14">
							고객센터
						</view>
					</view>
				</view>
			</view>


			<view class="font-size-16 bold margin-top-20" style="padding:14rpx 10px;">
				종목
			</view>
			<view
				style="border-radius: 23rpx;background-color: #ffffff;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
				<view style="background-color: #e9a841;height: 15px;border-radius: 23rpx 23rpx 0 0;">
					
				</view>

				<view class="padding-10 flex" v-for="(item,index) in list"
					@click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
					<u--image :src="item.logo" shape="circle" width="30px" height="30px"></u--image>
					<view  class="margin-left-10">
						{{item.ko_name}}
					</view>
					<view  class="margin-left-10 hui1 font-size-10">
						{{item.code}}
					</view>
					<view style="margin-left:auto;">
						<view  style="gap: 20px">
							<view :class="item.returns>0?'red bold text-center':'green bold'">{{numberToCurrency(item.close*1)}}
							</view>
							<view style="border-radius: 3px;padding: 2px;color: #fff;font-weight: 700; "
								:class="item.returns>0?'bg-red':'bg-green'">
								{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
							</view>
						</view>

					</view>
				</view>

			</view>
		</view>
		
		<template v-if="isShow && ipoSuccessItem">
			<view class="mask" @click="handleClose">
				<view style="position: fixed;top: 26vh;right: 12vw;z-index: 1000;" @click="handleClose">
					<image src="/static/close.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;justify-content: center;border-radius: 20px;">
						<view
							style="width: 90%;background-color: #fbfdff;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 90px;">
							<view style="font-size: 20px;padding: 10px 0 2px 0;color:#4451da;">
								{{ipoSuccessItem.goods.name}}
							</view>
							<view style="font-size: 11px;color:#999;padding:2px 0 10px 0;">
								{{ipoSuccessItem.goods.number_code}}
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding: 10px 60rpx;">
								<view>배정 수량</view>
								<view style="color:#4451da;">{{numberToCurrency(ipoSuccessItem.success)}}</view>
							</view>
		
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding: 10px 60rpx;">
								<view>납부금</view>
								<view style="color:#4451da;">{{numberToCurrency(ipoSuccessItem.total)}}</view>
							</view>
		
							<view
								style="padding: 10px 0;line-height: 1;background-color: #4451da;border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="handleIPO(ipoSuccessItem.type)">지금 구매</view>
						</view>
					</view>
				</view>
			</view>
		</template>
		
	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js'
	export default {

		data() {
			return {
				isShow: true, // 是否显示ad层,
				ipoSuccessItem: null, // IPO中签弹层
				userinfo: [],
				show_money: true,
				page: 1,
				list: [],
				gp_index: 0,
				keyword: "",
				business: ""
			}
		},

		methods: {
			// AD层关闭
			handleClose() {
				this.isShow = false;
			},
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get('api/goods-shengou/tanchuang', {})
				if (result.data.data[0]) {
					this.isShow = true;
					
					this.ipoSuccessItem = result.data.data[0];
				}
				console.log('抢筹', result.data.data[0]);
			},
			async kefu() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			qiehuan(index) {
				this.gp_index = index
				this.good_list()
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			// 银转证
			async silver() {
				this.kefu()
			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let list = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.list = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list
			},


		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		onLoad() {
			this.ipoSuccess()
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			// this.gaint_info()
			// this.free()
			this.startTimer()
		},

		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		}

	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #fefbf5;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 320rpx;
		margin-left: -10px;
	}
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}
	
	.bg_ad {
		background-image: url(/static/bg_ad.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 30vh;
		width: 80vw;
	}
</style>