<template>
	<view>
		<view style="padding-top: 70%;" class="justify-center flex">
			<image src="/static/chuanggai/logo2.png" mode="widthFix" style="width: 300px;margin-bottom: 10px;"></image>
		</view>
		<view style="width: 80%;margin-left: 10%;margin-top: 30px;">
			<u-line-progress :percentage="progress" activeColor="#5c99ff" height="30"></u-line-progress>
		</view>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				progress: 0,
			};
		},
		onLoad() {
			let kaiping=uni.getStorageSync("kaiping")
			if(kaiping){
				uni.reLaunch({
					url:'/pages/index/index'
				})
			}
		},
		onShow() {
			this.updateProgress();
		},
		methods: {
			updateProgress() {
				const interval = setInterval(() => {
					if (this.progress < 100) {
						this.progress += 5; // 每次增加5%
					} else {
						clearInterval(interval);
						uni.setStorageSync("kaiping",1)
						setTimeout(function(){
							uni.reLaunch({
								url:'/pages/index/index'
							})
						},1000)
						
					}
				}, 100); // 每隔1秒增加一次进度
			}
		},
	}
</script>

<style>
	page {
		background-image: url('/static/kp_bg.png');
		background-size: cover;
		background-repeat: no-repeat;
	}

	progress-bar {
		width: 20px;
		/* 进度条的宽度 */
		height: 200px;
		/* 进度条的高度 */
		background-color: #f0f0f0;
		/* 进度条的背景颜色 */
		border: 1px solid #ccc;
		/* 进度条的边框 */
		position: relative;
	}

	.progress {
		background-color: #537ef7;
		/* 进度条的颜色 */
		position: absolute;
		right: 0;
		bottom: 0;
		width: 100%;
		transition: height 0.5s;
		/* 进度条高度变化的过渡效果 */
	}
</style>