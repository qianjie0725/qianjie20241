<template>
	<view class="page">
		<view style="padding: 10px 10px 10px 20px;background-color: #e9a841;">
			<view class="flex ">
				<u-icon name="/static/zjt.png" class="padding-left-10" @click="$u.route({type:'navigateBack'})"
					imgMode="widthFix"></u-icon>
				<view class="color-white text-center width100 font-size-18">알림</view>
			</view>
		</view>
		<view class="flex padding-10" style="gap: 10px;">
			<view class="flex-1  text-center" :class="current==index?'top-a':'top'" v-for="(item,index) in tablist"
				@click="change(index)">
				{{item.name}}
			</view>
		</view>
		<!-- <u-tabs :list="tablist" lineColor="#014bab"  activeStyle="color:#014bab;font-size:18px;font-weight: 700;"  inactiveStyle="font-size:18px;font-weight: 700;" @change="change" :current="current"></u-tabs> -->

		<TabFrist v-if="current==0"></TabFrist>
		<!-- <TabTwo v-if="current==1"></TabTwo>
		<TabThree v-if="current==2"></TabThree>
		<TabFour v-if="current==3"></TabFour> -->
	</view>
</template>

<script>
	import TabFrist from './TabFrist.vue'
	export default {
		components: {
			TabFrist,
		},
		data() {
			return {
				//
				tablist: [{
					name: '전체'
				}, {
					name: '신호알림'
				}, {
					name: '커뮤니티'
				}, {
					name: '일반'
				}],
				current: 0
			}
		},
		onShow() {},


		methods: {
			change(index) {
				console.log(index)
				this.current = index;
			},
		},

		mounted() {},

		onLoad(op) {
			if (op.type) {
				this.current = op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	page {
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}

	.top-a {
		background-image: url(/static/market/top1.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		color: #fff;
		height: 38px;
		line-height: 34px;
	}

	.top {
		background-color: #fff;
		color: #666666;
		height: 34px;
		line-height: 34px;
		margin-top: -4px;
	}
</style>