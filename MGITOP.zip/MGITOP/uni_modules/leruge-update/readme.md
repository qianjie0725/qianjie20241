# 版本更新UI
> 增加了强制更新，默认是非强制

## 使用说明
1. 需要打开俩个权限
```
<uses-permission android:name="android.permission.INSTALL_PACKAGES"/>,
<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>,
```
2. 在需要的页面写组件`<leruge-update ref="update" downloadUrl="http://baidu.com" updateDesc="更新描述" :force="false"/>`，通过接口判断是否需要升级，如果需要则传入`downloadUrl`和`updateDesc`内容，然后调用 `this.$refs.update.upgrade()`，打开更新提示，剩下的自动完成
3. 如果是安系统，下载地址应该是apk或者aab包的地址，如果是苹果系统，下载地址应该是苹果商店地址

## 参数说明
|参数|释义|必填|
|---|---|---|
|downloadUrl|安卓下载包地址或者苹果商店地址|是|
|updateDesc|更新描述|是|
|force|是否强制更新|否|