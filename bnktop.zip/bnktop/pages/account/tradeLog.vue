<template>
	<view>
		<HeaderSecond :title="$lang.ACCOUNT_TRADE_LOG" color="#CBCBCF"></HeaderSecond>

		<TabsSixth :tabs="tabLabels" @action="changeTab" :acitve="curTab"></TabsSixth>

		<view style="padding: 20px 0;">
			<template v-if="curTab == 0">
				<LogTrade></LogTrade>
			</template>

			<template v-if="curTab == 1">
				<LogDeposit></LogDeposit>
			</template>

			<template v-if="curTab == 2">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsSixth,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				curTab: 0,
			};
		},
		computed: {
			// tabs的明文
			tabLabels() {
				return [
					this.$lang.TRADE_LOG_TRADE,
					this.$lang.TRADE_LOG_DEPOSIT,
					this.$lang.TRADE_LOG_WITHDRAW
				]
			}
		},
		onLoad(opt) {
			console.log(opt);
			this.curTab = Number(opt.code) || 0;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>