<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_AVATAR" color="#CBCBCF"></HeaderSecond>

		<view style="display: flex;align-items: center;justify-content: center;border-radius:100%;">
			<view style="position: relative;">
				<image :src="imgUrl" @click="selectImg()" mode="scaleToFill"
					style="width: 240px;height: 240px;background-image: linear-gradient(90deg, rgb(255, 176, 68), rgb(255, 45, 48));border-radius: 100%;">
				</image>
				<image src="/static/avatar_edit.png" mode="aspectFit"
					style="position: absolute;bottom: 0;left: 50%;width: 32px;height: 32px;transform: translateX(-50%);"
					@click="modAvatar()">
				</image>
			</view>
		</view>

		<view style="margin:80rpx;">
			<view class="common_input_wrapper" style="margin-bottom: 60rpx;">
				<image mode="aspectFit" src="/static/user.png" :style="$util.setImageSize(28)">
				</image>
				<input v-model="nick_name" type="text" :placeholder="$lang.AVATAR_TIP_NICK_NAME"
					:placeholder-style="$util.setPlaceholder()" style="width: 90%;"></input>
			</view>
		</view>
		<view :style="$theme.btnCommon(true,{padding:'11px 26px',width:'50%',margin:'auto'})" @click="submit_list">
			{{$lang.BTN_CONFIRM}}
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import {
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import {
		putAccountInfo,
		userFastInfo
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				avatarUrl: '', //

				fileList6: [],
				is_url: "",
				imgUrl: '',
				nick_name: "",
			};
		},
		created() {
			this.userInfo()
		},
		methods: {
			modAvatar() {
				this.selectImg();
			},

			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFilePaths[0];
				console.log('imageFile:', imageFile);
				// this.upimg(1, imageFile.path)
				const tempBase64 = await pathToBase64(imageFile);
				console.log('base64:', tempBase64);
				this.avatarUrl = tempBase64;
				this.imgUrl = tempBase64;
			},

			async submit_list() {
				const result = await putAccountInfo({
					avatar: this.avatarUrl,
					nickname: this.nick_name,
				})
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					// setTimeout(() => {
					// 	uni.switchTab({
					// 		url: ACCOUNT_CENTER
					// 	});
					// }, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 回调参数为包含columnIndex、value、values
			async userInfo() {
				const result = await userFastInfo();
				this.imgUrl = result.data.avatar ? result.data.avatar : `/static/avatar.png`;
				this.nick_name = result.data.nick_name
			},
		},
	}
</script>