<template>
	<view>
		<!-- <view class="auth_header"> -->
		<HeaderSecond :title="$lang.PAGE_TITLE_AUTH" color="#CBCBCF"></HeaderSecond>
		<!-- </view> -->

		<view style="margin-top: -40px;padding-top: 20px;padding-bottom: 30px;">

			<!-- <view style="background-color: #fef9fe;"> -->
			<!-- <view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/bank_card_bnner.png" :style="$util.setImageSize(600,300)"></image>
			</view> -->

			<view style="margin:0 20px;padding:40rpx 20px 0 20px;">
				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color:#FFFFFF;">
					{{$lang.REAL_NAME}}
				</view>
				<view class="common_input_wrapper" style="padding-left: 10px;margin-bottom: 20px;">
					<input v-model="realName" type="text" :placeholder="$lang.TIP_REAL_NAME"
						style="width: 80%;"></input>
					<!-- <view style="margin-left: 10px;color:#707070;">{{calcSex}}</view> -->
				</view>

				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color:#FFFFFF;">
					{{$lang.AUTH_ID_CARD}}
				</view>
				<view class="common_input_wrapper" style="padding-left: 10px;margin-bottom: 20px;">
					<!-- 韩国专用证件号码输入校验 -->
					<!-- <input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD" maxlength=14
						placeholder-style="font-size:11px" @input="inputChange" style="width: 86%;"></input> -->
					<!-- 非校验 -->
					<template v-if="showPwd">
						<input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"></input>
					</template>
					<template v-else>
						<input v-model="cardNo" type="password" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"></input>
					</template>
					<image mode="aspectFit" :src="`/static/${showPwd?'show':'hide'}_dark.png`" @click="handleShowPwd"
						:style="$util.setImageSize(40)">
					</image>
				</view>
			</view>

			<view style="text-align: center;font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
				{{statusLabels[userInfo.is_check]}}</view>

			<!-- <template v-if="userInfo.is_check!=0"> -->
			<view style="padding:0 0;">
				<view style="padding:10px;font-size: 14px;font-weight: 800;padding-left: 30px;color:#FFFFFF;">
					{{$lang.AUTH_CARD_F}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #3F3384;border-radius: 8rpx;margin: 30rpx;">
					<image :src="!formData.obverseUrl?`/static/card_f.png`:formData.obverseUrl"
						@click="selectImg('obverse')" style="margin: 10px;width: 220px;height: 120px;"></image>
				</view>

				<view style="padding:10px;font-size: 14px;font-weight: 800;padding-left: 30px;color:#FFFFFF;">
					{{$lang.AUTH_CARD_B}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #3F3384;border-radius: 8rpx;margin: 30rpx;">
					<image :src="!formData.reverseUrl?`/static/card_b.png`:formData.reverseUrl"
						@click="selectImg('reverse')" style="margin: 10px;width: 220px;height: 120px;"></image>
				</view>

				<view :style="$theme.btnCommon(true,{padding:'20rpx 30rpx',margin:'auto',width:'60%'})"
					@click="gain_aouonym()">
					{{$lang.BTN_CONFIRM}}
				</view>
				<view style="margin: 10px;padding-bottom: 30px; text-align: center;color:#707070;">
					{{$lang.AUTH_TIP_TEXT}}
				</view>
			</view>

			<!-- </template> -->
		</view>
		<!-- </view> -->
	</view>
</template>

<script>
	import md5 from 'js-md5'
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import {
		BASE_URL,
	} from '@/common/http';
	import {
		HOME
	} from '@/common/paths.js';
	import {
		postAuth,
		userFastInfo
	} from '@/common/api.js';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				realName: '', // 姓名 이정현
				cardNo: '', // 证件号码
				showPwd: false, // 是否显示完整证件号
				fullCardNo: '', // 证件号码完整值

				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				userInfo: {},
			};
		},
		onLoad() {
			this.getUserInfo()
		},
		computed: {
			// 实名认证状态明文
			statusLabels() {
				return [
					this.$lang.AUTH_RESULT_REVIEW,
					this.$lang.AUTH_RESULT_PASS,
					this.$lang.AUTH_RESULT_REPOST,
				]
			},

			// 计算性别
			// calcSex() {
			// 	return this.fullCardNo.length < 7 ? '' : this.fullCardNo[7] == '1' ? '남성' : this.fullCardNo[7] == '2' ?
			// 		'여성' : '';
			// },
		},

		methods: {
			// ID号显隐
			handleShowPwd() {
				this.showPwd = !this.showPwd;
				// this.formatCardNo(this.fullCardNo);
			},

			// // 证件号码格式化
			// formatCardNo() {
			// 	this.cardNo = this.showPwd ? this.fullCardNo : this.fullCardNo.substring(0, 8) + `******`;
			// },

			// // ID号输入值变动
			// inputChange(val) {
			// 	const temp = val.detail.value;
			// 	if (/^[0-9\-\\*]*$/.test(temp)) {
			// 		this.fullCardNo = temp;
			// 		if (temp.length >= 6 && temp.length <= 14) {
			// 			this.cardNo = `${temp.slice(0,6)}-${temp.slice(7,temp.length-7)}`;

			// 			// if (temp.length > 8) {
			// 			// 	// this.cardNo = temp.substring(0, 8) + `*`.repeat(temp.length - 8); // 逐字符替换为*
			// 			// 	// this.cardNo = temp.substring(0, 8) + `******`; // 超出后，一次性替换为******
			// 			// 	// console.log('1', this.cardNo)
			// 			// 	 this.cardNo = this.formatCardNo(temp);
			// 			// }
			// 		}
			// 	} else {
			// 		uni.$u.toast(this.$lang.AUTH_TIP_ID_CARD);
			// 		// 解决数据不更新问题，此处必须这样写。
			// 		setTimeout(() => {
			// 			this.cardNo = "";
			// 			this.fullCardNo = "";
			// 		}, 0);
			// 	}
			// 	console.log('full:', this.fullCardNo);
			// },

			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg(1, imageFile.path)

				} else if (name == "reverse") {
					this.upimg(2, imageFile.path)
				}
			},
			// 上传图片
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					if (type == 1) {
						this.formData.obverseUrl = temp[0].url;
					} else {
						this.formData.reverseUrl = temp[0].url;
					}
				}
			},

			// // 预览
			// previewImage(current = 0) {
			// 	uni.previewImage({
			// 		current,
			// 		urls: [this.obverseUrl, this.reverseUrl],
			// 	});
			// },
			// // 删除
			// del_btn(e) {
			// 	if (e.name == 'obverse') {
			// 		this.formData.obverseUrl = '';
			// 	} else if (e.name == 'reverse') {
			// 		this.formData.reverseUrl = '';
			// 	}
			// },

			// 认证
			async gain_aouonym() {
				// this.fullCardNo 提交时，提交完整证件号码 各别项目需求严格校验身份证，及号码段位隐藏
				const tempCardNo = this.cardNo;
				const result = await postAuth({
					real_name: this.realName,
					// sex: this.calcSex,
					idno: tempCardNo,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				}, this.$lang.STATUS_SUBMIT);

				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: HOME
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			async getUserInfo() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					this.realName = this.userInfo.real_name;
					this.cardNo = this.userInfo.idno;
					// this.fullCardNo = this.userInfo.idno;
					// this.formatCardNo(this.fullCardNo);
					this.formData.obverseUrl = this.userInfo.front_image
					this.formData.reverseUrl = this.userInfo.back_image
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	};
</script>