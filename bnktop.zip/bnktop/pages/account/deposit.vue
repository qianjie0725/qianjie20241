<!-- 银转证  存款 -->
<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_DEPOSIT" color="#CBCBCF"></HeaderSecond>

		<DepositPrimary></DepositPrimary>
		
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import DepositPrimary from '@/components/account/deposit/DepositPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			DepositPrimary,
		},
	}
</script>