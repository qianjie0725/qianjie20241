<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_WITHDRAW" color="#CBCBCF"></HeaderSecond>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="home_card_bg home_card_bg_1" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view style="padding:20px;margin-top: 10px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
			</view>
			<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;"></input>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper" style="margin-bottom: 30px;padding-left: 30px;">
				<template v-if="isShow">
					<input v-model="password" type="text" :placeholder="$lang.TIP_WITHDRAW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<view :style="setBtnStyle" @click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>


		<view style="margin:10px; padding: 20px;" :style="{color:$theme.LOG_LABEL}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?'#FF6700' :$theme.LOG_LABEL}">
					{{item}}
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		postWithdarw,
		accountInfo
	} from '@/common/api.js';
	import {
		ACCOUNT_CENTER,
		ACCOUNT_TRADE_LOG
	} from '@/common/paths.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			CardItemPrimary,
		},
		data() {
			return {
				isShow: false, // 密码显隐
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
				cardData: {},
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL
				];
			},
			setBtnStyle() {
				return this.$theme.btnCommon(true, {
					...this.$theme.LG_THIRD,
					padding: '20rpx 30rpx',
					width: '80%',
					margin: '30rpx auto',
				})
			},
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				const result = await postWithdarw({
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				}, this.$lang.WITHDRAWING_POST_TIP)
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						// uni.switchTab({
						// 	url: ACCOUNT_CENTER
						// });
						uni.navigateTo({
							url: ACCOUNT_TRADE_LOG + `?code=2`,
						})
					}, 500)
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.money, // 可提
						value2: this.userInfo.freeze, // 冻结
						value3: this.userInfo.totalZichan, // 总资产
					};
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>