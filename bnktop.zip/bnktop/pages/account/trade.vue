<template>
	<view>
		<HeaderPrimary isSearch></HeaderPrimary>

		<TabsSixth :tabs="curTabs" @action="changeTab" :acitve="curTab"></TabsSixth>
		<view style="padding:40rpx 30rpx;">
			<template v-if="curTab==0">
				<AccountTradeInfo></AccountTradeInfo>
				<view style="padding:30rpx 0;">
					<CustomTitle :title="$lang.TRADE_TITLE">
						<view style="font-size: 13px;" @click="changeTab(1)" :style="{color:$theme.PRIMARY}">
							{{$lang.MORE}}
							<view class="arrow rotate_45" :style="$util.setImageSize(12)"></view>
						</view>
					</CustomTitle>
					<view style="background-color: #211E42;padding:6px 24rpx;border-radius: 6px;">
						<AccountTradeHoldList></AccountTradeHoldList>
					</view>
				</view>
			</template>
			<template v-else-if="curTab==1">
				<AccountTradeHoldList></AccountTradeHoldList>
			</template>
			<template v-else>
				<AccountTradeSellList></AccountTradeSellList>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountTradeInfo from '@/components/account/trade/AccountTradeInfo.vue';
	import AccountTradeHoldList from '@/components/account/trade/AccountTradeHoldList.vue';
	import AccountTradeSellList from '@/components/account/trade/AccountTradeSellList.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsSixth,
			CustomTitle,
			AccountTradeInfo,
			AccountTradeHoldList,
			AccountTradeSellList,
		},
		data() {
			return {
				curTab: 0, // 

				// radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				// isHold: true, // 是否是持股状态，否则为销售历史
				// isSelf: true, // 国内，false:海外
				// list: [],
				// info: {},
				// isShow: false, // 买卖弹出
				// curPage: 1, // 当前页码	
				// maxPage: 1, // 最大页码
				// flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			curTabs() {
				return [
					this.$lang.TRADE_TITLE,
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
		},

		onLoad() {
			// this.getUserInfo();
		},
		onShow() {
			// this.getData();
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.curPage = 1; // 从第一页重新开始
			// this.list = []; // 清空所有翻页后内中数据
			// this.getData();
			// uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
			},
		},
	}
</script>