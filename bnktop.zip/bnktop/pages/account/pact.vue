<template>
	<view>
		<HeaderSecond :title="pact.title" color="#CBCBCF"></HeaderSecond>
		<view style="padding: 40rpx;">
			<view v-html="pact.content" style="color:#CBCBCF"></view>
		</view>
	</view>
</template>

<script>
	import {
		getPactInfo
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				pact: {},
			};
		},
		onLoad() {
			this.getData();
		},
		methods: {
			// 获取数据
			async getData() {
				const result = await getPactInfo();
				console.log('result:', result);
				if (result.code == 0) {
					this.pact = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			}
		}
	}
</script>

<style>
</style>