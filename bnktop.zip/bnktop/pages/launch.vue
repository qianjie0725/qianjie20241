<template>
	<view class="launch">

		<view style="display: flex;align-items: center;justify-content: center;padding: 13vh 0;">
			<image src='/static/logo_dark.png' :style="$util.setImageSize(210,270)">
			</image>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/launch_img.png" mode="aspectFit" :style="$util.setImageSize(512)"></image>

		</view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 48rpx;font-family: 700;color:#FFFFFF;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view>

		<ProgressThird></ProgressThird>

	</view>
</template>

<script>
	import ProgressThird from '@/components/progress/ProgressThird.vue';
	export default {
		components: {
			ProgressThird
		},
	}
</script>

<style lang="scss" scoped>
	/* 启动页 */
	.launch {
		width: 100%;
		height: 100vh;
		padding-top: 0;
		background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
	}
</style>