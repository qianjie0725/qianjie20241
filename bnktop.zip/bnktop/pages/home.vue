<template>
	<view>
		<HeaderPrimary isSearch isLang> </HeaderPrimary>

		<CardPrimary></CardPrimary>

		<view style="display: flex;justify-content: space-between;margin:30rpx 60rpx;">
			<view :style="$theme.btnCommon(false,{borderRadius:'16rpx',lineHeight: '2.4',margin: '6rpx 12rpx'})" @click="linkDeposit()">
				<image src="/static/center_left.png" mode="aspectFit" :style="$util.setImageSize(28)"
					style="padding-right: 20px;"></image>
				{{$lang.PAGE_TITLE_DEPOSIT}}
			</view>
			<view :style="$theme.btnCommon(true,{borderRadius:'16rpx',lineHeight: '2.4',margin: '6rpx 12rpx'})" @click="linkWithdraw()">
				<image src="/static/center_right.png" mode="aspectFit" :style="$util.setImageSize(28)"
					style="padding-right: 20px;"></image>
				{{$lang.PAGE_TITLE_WITHDRAW}}
			</view>
		</view>

		<ButtonGroup :btns="$util.homeBtns()"></ButtonGroup>

		<!-- <template v-if="isNotify">
			<NotifyPrimary @action="choseNotify"></NotifyPrimary>
		</template> -->
		<NotifyPrimary></NotifyPrimary>

		<CustomTitle :title="$lang.MARKET_NEWS_TITLE">
			<view style="font-size: 13px;" @click="linkMarketNews()" :style="{color:$theme.PRIMARY}">
				{{$lang.MORE}}
				<view class="arrow rotate_45" :style="$util.setImageSize(12)"></view>
			</view>
		</CustomTitle>

		<view style="padding-bottom: 16px;">
			<MarketNewsTop></MarketNewsTop>
		</view>


		<!-- <FollowList ref="follow"></FollowList> -->

		<CustomTitle :title="$lang.STOCK_ALL">
			<view style="font-size: 13px;" @click="linkAllList()" :style="{color:$theme.PRIMARY}">
				{{$lang.MORE}}
				<view class="arrow rotate_45" :style="$util.setImageSize(12)"></view>
			</view>
		</CustomTitle>

		<!-- <GoodsList ref="goods"></GoodsList> -->
		<view style="padding-bottom:20px;">
			<MarketHot></MarketHot>
		</view>

		<template v-if="isShow">
			<view class="mask" @click="handleClose()">
				<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;"
					@click="handleClose()">
					<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;padding: 20px 0;">
						<view style="font-size: 32rpx;font-weight: 700;color: #121212;">
							<!-- {{$lang.DIALOG_IPO_SUCCESS_TIP_TITLE}} -->
						</view>

						<view>
							<image src="/static/dialog_icon.png" mode="aspectFit" :style="$util.setImageSize(480,320)">
							</image>
						</view>
						<!-- <template v-if="userInfo.nick_name || userInfo.real_name">
							<view
								style="text-align: center;font-size: 36rpx;    color: rgb(0, 180, 90);padding-bottom: 16px;">
								{{userInfo.real_name}}
							</view>
						</template> -->
						<view
							style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
							<view style="font-size: 40rpx;font-weight: 700;color: #121212;padding:4px 40px;">
								{{ipoInfo.name}}
							</view>
							<view style="font-size: 28rpx;font-weight: 700;color: #666;padding:4px 40px;">
								{{ipoInfo.code}}
							</view>

							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
								{{$lang.DIALOG_IPO_SUCCESS_TIP_TEXT}}
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_QTY}}</view>
								<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
									{{$util.formatNumber(ipoInfo.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_TOTAL}}</view>
								<text
									style="font-weight: 700;color:#ff3636;font-size: 16px;">{{$util.formatNumber(ipoInfo.total)}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1.5;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="linkIPOSuccessLog()">{{$lang.BTN_DETAIL_NOW}}</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		getIPOSuccessItem,
	} from '@/common/api.js';
	import {
		TRADE_IPO,
		MARKET_OVERVIEW,
		ACCOUNT_DEPOSIT,
		ACCOUNT_WITHDRAW,
	} from '@/common/paths.js';
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	// import GoodsList from '@/components/GoodsList.vue';
	// import FollowList from '@/components/FollowList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import CardPrimary from '@/components/card/CardPrimary.vue';
	import NotifyPrimary from '@/components/notify/NotifyPrimary.vue';
	import MarketNewsTop from '@/components/market/MarketNewsTop.vue';
	import MarketHot from '@/components/market/MarketHot.vue';
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			// GoodsList,
			// FollowList,
			CustomTitle,
			CardPrimary,
			NotifyPrimary,
			MarketNewsTop,
			MarketHot,
		},
		data() {
			return {
				ipoInfo: {}, // 
				isShow: false, // 是否显示中签弹层
				// isNotify: true, // 显示横向滚动通知
			}
		},

		onLoad() {
			// console.log('onLoad', this.$refs.goods);
			// console.log('onLoad', this.$refs.follow);
			this.ipoSuccess();
		},

		onShow() {
			// console.log('onShow', this.$refs.goods);
			// console.log('onShow', this.$refs.follow);
			// if (this.$refs.goods) {
			// 	this.$refs.goods.onSetTimeout();
			// }
			// if (this.$refs.follow) {
			// 	this.$refs.follow.onSetTimeout();
			// }
		},
		onReady() {
			// console.log('onReady', this.$refs.goods);
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			// console.log('onHide', this.$refs.goods);
			// console.log('onHide', this.$refs.follow);
			// this.$refs.goods.clearTimer();
			// this.$refs.follow.clearTimer();
		},
		deactivated() {
			// console.log('deactivated', this.$refs.goods);
			// console.log('deactivated', this.$refs.follow);
			// this.$refs.goods.clearTimer();
			// this.$refs.follow.clearTimer();
		},

		methods: {
			// // 关闭滚动通知
			// choseNotify(val) {
			// 	this.isNotify = false;
			// },
			// 跳转到充值
			linkDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},
			// 跳转到提款
			linkWithdraw() {
				uni.navigateTo({
					url: ACCOUNT_WITHDRAW
				})
			},

			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: `${MARKET_OVERVIEW}?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: `${MARKET_OVERVIEW}?type=3`,
				})
			},
			// 关闭中签提醒
			handleClose(val) {
				console.log(val);
				this.isShow = val;
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: `${TRADE_IPO}?type=2`,
				})
			},

			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await getIPOSuccessItem();
				console.log(result);
				// if (result.code == 0) {
				// 	if (result.data.length > 0) {
				// 		const temp = result.data[0];
				// 		this.ipoInfo = {
				// 			code: temp.goods.code,
				// 			name: temp.goods.name,
				// 			success: temp.success,
				// 			total: temp.total,
				// 		};
				// 		this.isShow = true;
				// 	}
				// } else {
				// 	uni.$u.toast(result.data.message);
				// }
			},
		},
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}
</style>