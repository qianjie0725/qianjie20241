<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_NOTIFICATION" color="#CBCBCF"></HeaderSecond>

		<view
			style="width: 100%;display:flex;flex-direction: column;justify-items: center;align-items: center;padding: 10vh 0;">
			<image src="/static/empty_search.png" :style="$util.setImageSize(500,600)"></image>
			<view style="font-size: 32rpx;padding-top:30px;text-align: center;" :style="{color:$theme.LOG_LABEL}">
				{{$lang.EMPTY_NOTIFIY}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
	}
</script>