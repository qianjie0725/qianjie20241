<!-- 折价交易 -->
<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_DISCOUNT" color="#CBCBCF"></HeaderSecond>

		<TabsSixth :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsSixth>

		<template v-if="curTab==0">
			<TradeDiscountList></TradeDiscountList>
		</template>
		<template v-else>
			<TradeDiscountLog></TradeDiscountLog>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TradeDiscountList from '@/components/trade/discount/TradeDiscountList.vue';
	import TradeDiscountLog from '@/components/trade/discount/TradeDiscountLog.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';

	export default {
		components: {
			HeaderSecond,
			TradeDiscountList,
			TradeDiscountLog,
			TabsSixth,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
			}
		},

		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>