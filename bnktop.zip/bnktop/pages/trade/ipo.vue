<!-- 新股申购 -->
<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_IPO" color="#CBCBCF"></HeaderSecond>

		<TabsSixth :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsSixth>

		<template v-if="curTab ==0">
			<TradeIPOList></TradeIPOList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPOLog></TradeIPOLog>
		</template>
		<template v-else>
			<TradeIPOSuccessLog></TradeIPOSuccessLog>
		</template>

	</view>
</template>

<script>
	import {
		getIPOList,
		postBuyIPO
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import TradeIPOList from '@/components/trade/ipo/TradeIPOList.vue';
	import TradeIPOLog from '@/components/trade/ipo/TradeIPOLog.vue';
	import TradeIPOSuccessLog from '@/components/trade/ipo/TradeIPOSuccessLog.vue';

	export default {
		components: {
			HeaderSecond,
			TabsSixth,
			TradeIPOList,
			TradeIPOLog,
			TradeIPOSuccessLog,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
			};
		},
		onLoad(opt) {
			this.curTab = Number(opt.type) || 0;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>

<style lang="scss">
	// /deep/.u-popup__content {
	// 	background-color: #29205E !important;
	// }
</style>