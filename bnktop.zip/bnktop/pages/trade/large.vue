<!-- 大宗交易 -->
<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_LARGE" color="#CBCBCF"></HeaderSecond>

		<TabsSixth :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsSixth>

		<template v-if="curTab==0">
			<TradeLargeList></TradeLargeList>
		</template>
		<template v-else>
			<TradeLargeLog></TradeLargeLog>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import TradeLargeList from '@/components/trade/large/TradeLargeList.vue';
	import TradeLargeLog from '@/components/trade/large/TradeLargeLog.vue';

	export default {
		components: {
			HeaderSecond,
			TabsSixth,
			TradeLargeList,
			TradeLargeLog,
		},
		data() {
			return {
				curTab: 0,
			}
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},

		},
	}
</script>