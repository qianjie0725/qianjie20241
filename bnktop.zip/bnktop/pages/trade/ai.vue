<template>
	<view>
		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_DAY" color="#CBCBCF"></HeaderSecond>

		<TabsSixth :tabs="$lang.TRADE_AI_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsSixth>

		<template v-if="curTab==0">
			<TradeAIBuy @action="changeTab"></TradeAIBuy>
		</template>
		<template v-else>
			<TradeAIOrderList></TradeAIOrderList>
		</template>
		<!-- <template v-else>
			<TradeAILog></TradeAILog>
		</template> -->
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import TradeAIBuy from '@/components/trade/ai/TradeAIBuy.vue';
	import TradeAIOrderList from '@/components/trade/ai/TradeAIOrderList.vue';
	// import TradeAILog from '@/components/trade/ai/TradeAILog.vue';
	export default {
		components: {
			HeaderSecond,
			TabsSixth,
			TradeAIBuy,
			TradeAIOrderList,
			// TradeAILog,
		},
		data() {
			return {
				options: {},
				curTab: 0,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>