<template>
	<view style="display: flex;align-items: center;padding:4px 20px;">
		<image src="/static/kr.png" mode="aspectFit" :style="$util.setImageSize(60)"
			style="border-radius: 100px;background-color:#bdd8ffa1;padding:6px;"></image>
		<view style="padding-left: 10px;" :style="{color:$theme.TITLE}">KRW</view>
	</view>
	<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
		<view style="font-size: 28px;font-weight: 900;" :style="{color:$theme.PRIMARY}">
			<text style="margin-right: 20px;">{{showAmount?$util.formatNumber(info.money)+'원':hideAmount}}</text>
			<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
				:style="$util.setImageSize(40)" style="margin-left: auto;">
			</image>
		</view>
		<view style="padding:20px;" :style="{color:$theme.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		<view class="common_btn" style="width: 60%;margin:auto;" @click="linkCustomer()">
			{{$lang.BTN_SEND_SERVICE}}
		</view>
	</view>
</template>

<script>
	import {
		userFastInfo,
	} from '@/common/api.js';
	export default {
		// desc:入金模式 之 仅提供跳转客服按钮
		name: 'DepositSecond',
		data() {
			return {
				info: {},
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			};
		},
		created() {
			this.getInfo()
		},
		methods: {
			// 资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			async linkCustomer() {
				this.$util.linkCustomerService();
			},
			async getInfo() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.info = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>

<style>
</style>