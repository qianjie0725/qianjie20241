<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="home_card_bg home_card_bg_3" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>


		<view style="padding:30px  20px 10px 20px;">
			<CustomTitle :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT"></CustomTitle>
			<view class="common_input_wrapper">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view style="display: flex;flex-wrap:wrap;align-items: center;padding:10px;">
				<block v-for="(item,index) in amountList" :key="index">
					<view :style="setStyle(curPos==index)" @click="quantity(item,index)">
						{{$util.formatNumber(item)}}
					</view>
				</block>
			</view>
			<view :style="setBtnStyle" @click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>

		<view style="padding: 10px 20px;">
			<view style="font-size: 14px;font-weight: 700;text-align: center;" :style="{color:$theme.LOG_LABEL}">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view>
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="padding-bottom:6px;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import {
		accountInfo,
		postDeposit
	} from '@/common/api.js';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		// desc:入金模式 之  带有输入项提交等
		name: 'DepositPrimary',
		components: {
			CustomTitle,
			AccountAssets,
			CardItemPrimary,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				userInfo: {}, //
				cardData: {},
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			// 入金金额预置值
			amountList() {
				return [1000000, 3000000, 5000000, 10000000];;
			},
			// 按钮样式
			setBtnStyle() {
				return this.$theme.btnCommon(true, {
					...this.$theme.LG_FOURTH,
					padding: '20rpx 30rpx',
					width: '80%',
					margin: '30rpx auto'
				});
			},
		},
		created() {
			this.getInfo()
			this.amount = this.amountList[0];
		},
		methods: {
			// 设置数值选中及非选中样式
			setStyle(val, isMR = false) {
				return this.$theme.btnCommon(val,
					val ? {
						// borderRadius: '44rpx',
						marginRight: isMR ? '' : '20rpx',
						...this.$theme.LG_FOURTH,
						flex: '30%',
						marginBottom: '30rpx',
						color: '#FFFFFF',
						padding: '20rpx 30rpx',
					} : {
						border: 'none',
						color: '#FFFFFF',
						marginRight: isMR ? '' : '20rpx',
						...this.$theme.linerGradient(90, '#454175', '#454175'),
						flex: '30%',
						marginBottom: '30rpx',
						padding: '20rpx 30rpx',
					});
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 
			async handleSubmit() {
				const result = await postDeposit({
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				}, this.$lang.DEPOSIT_POST_TIP);

				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						this.$util.linkCustomerService();
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			//个人信息
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.money, // 可提
						value2: this.userInfo.freeze, // 冻结
						value3: this.userInfo.totalYingli, // 总盈利
					};
				} else {
					uni.$u.toast(result.message);
				}
			},

			// //凭证
			// deletePic(event) {
			// 	this[`fileList${event.name}`].splice(event.index, 1)
			// },
			// // 新增图片
			// async afterRead(event) {
			// 	// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
			// 	let lists = [].concat(event.file)
			// 	let fileListLen = this[`fileList${event.name}`].length
			// 	lists.map((item) => {
			// 		this[`fileList${event.name}`].push({
			// 			...item,
			// 		})
			// 	})
			// 	for (let i = 0; i < lists.length; i++) {
			// 		const result = await this.uploadFilePromise(lists[i].url)
			// 		let item = this[`fileList${event.name}`][fileListLen]
			// 		this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
			// 			status: 'success',
			// 			message: '',
			// 			url: result
			// 		}))
			// 		fileListLen++
			// 	}
			// },

		},
	}
</script>

<style>
</style>