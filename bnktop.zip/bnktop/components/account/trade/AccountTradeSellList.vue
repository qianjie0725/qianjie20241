<template>
	<view>

		<view>
			<view style="line-height: 2.4;display: flex;align-items: center;border-radius: 8px 8px 0 0;">
				<view style="flex:0 0 16%;text-align: center;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 20rpx;">{{$lang.TRADE_SELL_LABEL_1ST}}</view>
				</view>
				<view style="flex:0 0 30%;text-align: right;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 20rpx;">{{$lang.TRADE_SELL_LABEL_2ND}}</view>
					<view style="color: #F5B71C;font-size: 20rpx;">{{$lang.TRADE_SELL_LABEL_3RD}}</view>
				</view>
				<view style="flex:0 0 34%;text-align: right;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 20rpx;">{{$lang.TRADE_SELL_LABEL_4TH}}</view>
					<view style="color: #F5B71C;">{{$lang.TRADE_SELL_LABEL_5TH}}</view>
				</view>
				<view style="flex:0 0 20%; text-align: center;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 20rpx;">{{$lang.TRADE_SELL_LABEL_6TH}}</view>
					<view style="color: #F5B71C;font-size: 20rpx;">{{$lang.TRADE_SELL_LABEL_7TH}}</view>
				</view>
			</view>
			<template v-if="list && list.length<=0">
				<EmptyData></EmptyData>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="display: flex;align-items: center;line-height: 1.8;margin:6px;"
						:class="index<list.length-1?'line':'' " @tap="handleShowModal(item)">
						<view style="flex:0 0 16%;text-align: center;padding:4px 0;">
							<view :style="{color:$theme.LOG_VALUE}"> {{item.goods_info.name}} </view>
							<!-- <view :style="{color:$theme.LOG_LABEL}"> {{item.goods_info.code}} </view> -->
						</view>
						<view style="flex:0 0 30%;padding:4px 0;">
							<!-- <template v-if="item.order_sell"> -->
							<view :style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)">
								{{$util.formatNumber(item.order_sell.yingkui*1)}}
							</view>
							<view style="text-align: right;"
								:style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)">
								<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
								{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
							</view>
							<!-- </template> -->
						</view>

						<view style="flex:0 0 34%;padding:4px 0;">
							<view style="text-align: right;padding-right:6px;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.num)}}
							</view>
							<!-- <template v-if="item.order_sell"> -->
							<view style="text-align: right;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
							</view>
							<!-- </template> -->
						</view>

						<view style="flex:0 0 20%; text-align: center;padding:4px 0;">
							<view style="" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.price)}}{{$lang.CURRENCY_UNIT}}
							</view>
							<!-- <template v-if="item.order_sell"> -->
							<view style="" :style="{color:$theme.RISE}">
								{{$util.formatNumber(item.order_sell.price)}}{{$lang.CURRENCY_UNIT}}
							</view>
							<!-- </template> -->
						</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<AccountTradeSellInfo :info="itemInfo" @action="handleClose"></AccountTradeSellInfo>
		</template>
	</view>
</template>

<script>
	import {
		getTradeList,
	} from '@/common/api.js';
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import AccountTradeSellInfo from '@/components/account/trade/AccountTradeSellInfo.vue';
	export default {
		name: 'AccountTradeSellList',
		components: {
			CustomTitle,
			EmptyData,
			AccountTradeSellInfo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getData();
		},
		methods: {
			handleShowModal(item) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getData() {
				const result = await getTradeList({
					status: 2, // 1持仓，2历史
					gp_index: 0,
				});
				if (result.code == 0 && result.data) {
					console.log('sell List:', result.data);
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>

<style>
</style>