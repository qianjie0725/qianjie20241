<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="home_card_bg home_card_bg_2" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view style="display: flex;justify-content: space-between;margin:30rpx 60rpx;">
			<view :style="setStyle(false)" @click="linkDeposit()">
				{{$lang.PAGE_TITLE_DEPOSIT}}
			</view>
			<view :style="setStyle(true)" @click="linkWithdraw()">
				{{$lang.PAGE_TITLE_WITHDRAW}}
			</view>
		</view>

		<view style="background-color: #211E42;padding:6px 24rpx;border-radius: 6px;">
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_TOTAL_BUY_AMOUNT}}</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(userInfo.frozen)}}{{$lang.CURRENCY_UNIT}}
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_VALUATION_GAIN_LOSS}}</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(userInfo.holdYingli)}}{{$lang.CURRENCY_UNIT}}
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_VALUATION_GAIN_LOSS_AMOUNT}}</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(userInfo.guzhi)}}{{$lang.CURRENCY_UNIT}}
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_RATE_RESPONSE}}</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{userInfo.huibao}}%
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.ACCOUNT_AMOUNT_TOTAL}}</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(userInfo.totalZichan)}}{{$lang.CURRENCY_UNIT}}
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
				<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_TOTAL_GAIN}}</view>
				<view :style="$util.setStockRiseFall(userInfo.totalYingli>0)">
					{{$util.formatNumber(userInfo.totalYingli)}}{{$lang.CURRENCY_UNIT}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		accountInfo
	} from '@/common/api.js';
	import {
		ACCOUNT_DEPOSIT,
		ACCOUNT_WITHDRAW
	} from '@/common/paths.js';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'AccountTradeInfo',
		components: {
			CardItemPrimary,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				cardData: {}, // 资产相关数据
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_TOTAL,
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT
				];
			},
			// 是否显示饼图
			isPieChart() {
				return this.cardData && Object.keys(this.cardData).length > 0;
			}
		},
		created() {
			this.getUserInfo();
		},
		methods: {
			// 入金 提款 按钮样式
			setStyle(val) {
				return val ? this.$theme.btnCommon(true, {
					borderRadius: '16rpx',
					lineHeight: '2.4',
					margin: '6rpx 12rpx',
					...this.$theme.LG_FIFTH,
				}) : this.$theme.btnCommon(false, {
					borderRadius: '16rpx',
					lineHeight: '2.4',
					margin: '6rpx 12rpx',
					borderColor: '#BA44FF',
					color: '#BA44FF'
				});
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},

			async getUserInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.totalZichan * 1, // 
						value2: this.userInfo.money, // 
						value3: this.userInfo.freeze, // 
					};
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		// width: 720rpx;
		// height: 500rpx;
		width: 680upx;
		height: 500upx;
	}
</style>