<template>
	<view>
		<view>
			<view style="line-height: 1.6;display: flex;align-items: center;border-radius: 8px 8px 0 0;">
				<view style="flex:0 0 16%;text-align: center;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_1ST}}</view>
				</view>
				<view style="flex:0 0 30%;text-align: right;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_2ND}}</view>
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_3RD}}</view>
				</view>
				<view style="flex:0 0 34%;text-align: right;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_4TH}}</view>
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_5TH}}</view>
				</view>
				<view style="flex:0 0 20%; text-align: center;padding:4px 0;">
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_6TH}}</view>
					<view style="color: #F5B71C;font-size: 24rpx;">{{$lang.TRADE_HOLD_LABEL_7TH}}</view>
				</view>
			</view>
			<template v-if="list && list.length<=0">
				<EmptyData></EmptyData>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="display: flex;align-items: center;line-height: 1.8;margin:6px;"
						:class="index<list.length-1?'line':'' " @tap="handleShowModal(item)">
						<view style="flex:0 0 16%;">
							<view :style="{color:$theme.LOG_VALUE}" style="font-size: 24rpx;"> {{item.goods_info.name}}
							</view>
							<!-- <view :style="{color:$theme.LOG_LABEL}"> {{item.goods_info.code}} </view> -->
						</view>

						<view style="flex:0 0 30%;">
							<view style="text-align: right;"
								:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
								<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
								{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
							</view>
							<view style="text-align: right;"
								:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
								{{$util.formatNumber(item.order_buy.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<view style="flex:0 0 34%;">
							<view style="text-align: right;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.num)}}
							</view>
							<view style="text-align: right;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<view style="flex:0 0 20%; text-align: center;">
							<view style="" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.order_buy.price)}}{{$lang.CURRENCY_UNIT}}
							</view>
							<view style="" :style="{color:$theme.RISE}">
								{{$util.formatNumber(item.goods_info.current_price)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<AccountTradeHoldInfo :info="itemInfo" @action="handleClose"></AccountTradeHoldInfo>
		</template>
	</view>
</template>

<script>
	import {
		getTradeList,
	} from '@/common/api.js';
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import AccountTradeHoldInfo from '@/components/account/trade/AccountTradeHoldInfo.vue';
	export default {
		name: 'AccountTradeHoldList',
		components: {
			CustomTitle,
			EmptyData,
			AccountTradeHoldInfo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getData();
		},
		methods: {
			handleShowModal(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				this.getData();
			},

			async getData() {
				const result = await getTradeList({
					status: 1, // 1持仓，2历史
					gp_index: 0,
				});
				if (result.code == 0 && result.data) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>

<style>
</style>