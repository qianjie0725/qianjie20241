<template>
	<view>
		<view style="text-align: center;color: #FFFFFF;font-size: 32rpx;margin-top: 120rpx;">
			{{`${$lang.STATUS_LOADING} `}} {{`${percentage} %`}}
		</view>
		<view
			style="position:relative;margin: 120rpx;margin-top: 30rpx; background-color:rgba(255,255,255,0.15);height:10px;border-radius: 20rpx;border: 1px solid #FFFFFF;padding:0 3px;">
			<view :style="setStyle"></view>
			<view style="background-image: url('/static/launch_loading.png');
		background-repeat: no-repeat;
		background-position: center center;
		background-size: cover;width: 100%;height: 100%;position: absolute;left: 0;right: 0;top: 0;bottom: 0;z-index: 99;">
			</view>
		</view>
	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	// 横向进度条，带有蒙层，上部带有进度值
	export default: {
		name: 'ProgressSecond',
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},

		computed: {
			setStyle() {
				const temp = {
					position: 'absolute',
					bottom: 0,
					left: 0,
					height: '10px',
					width: `${this.percentage}%`,
					backgroundImage: `linear-gradient(90deg, #FBED7B ,#FF533B)`,
					borderRadius: '20rpx',
				};
				return temp;
			}
		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						uni.$u.sleep(1500).then(() => {
							uni.switchTab({
								url: HOME,
							})
						})
					}
					console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>