<template>
	<view>
		<view class="common_block"
			style="padding-bottom: 10px;background-color: #3F3384;border-radius: 8rpx;box-shadow: none;">
			<view style="display: flex;align-items: center;padding: 20px;padding-bottom: 0;">
				<view style="flex:18%">
					<StockLogo :logo="info.logo" :name="info.name"></StockLogo>
				</view>
				<view style="flex:72%">
					<view style="margin-bottom: 2px;font-weight: 700;font-size: 40rpx;color:#FFFFFF;">
						{{info.name}}
						<image :src="`/static/arrow_${info.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$util.setImageSize(32)" style="margin-left: 10px;"></image>
					</view>
					<view style="color:#CBCBCF;"> {{info.number_code}} {{info.ct_name}}</view>
				</view>
				<view style="flex:10%;text-align: right;" @click="handleUnFollow(info.gid)">
					<image :src="`/static/${info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
						:style="$util.setImageSize(40)"></image>
				</view>
			</view>
			<view
				style="display: flex;align-items: center;padding: 10px 20px;padding-bottom: 0;justify-content:space-between;"
				:style="$util.setStockRiseFall(info.rate>0)">
				<view style="font-size: 32rpx;">
					{{$util.formatNumber(info.current_price)}} {{$lang.CURRENCY_UNIT}}
				</view>
				<view style="text-align: right;font-size: 32rpx;">
					{{$util.formatNumber(info.rate_num)}}
				</view>
				<view style="text-align: right;font-size: 32rpx;">
					{{$util.formatNumber(info.rate)}}%
				</view>
			</view>
		</view>
		<view class="common_block"
			style="padding-bottom: 10px;background-color: #3F3384;border-radius: 8rpx;box-shadow: none;">
			<block v-for="(item,index) in $lang.STOCK_INFO_TITLES" :key="index">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 30px;padding:0 10px;">
					<view style="color: #CBCBCF;">{{item}}</view>
					<view style="color: #FFFFFF;font-size: 28rpx;">
						{{setInfo[index]}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		updateFollow
	} from '@/common/api.js';
	import StockLogo from '@/components/stock/StockLogo.vue';
	export default {
		name: 'StockInfoPrimary',
		components: {
			StockLogo
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {
			setInfo() {
				return [
					this.$util.formatNumber(this.info.info.open) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.prev_close) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.high) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.low) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.volume / 10000),
					this.$util.formatNumber(this.info.info.volume_valued / 10000) + ` ` + this.$lang.CURRENCY_UNIT,
				]
			}
		},

		methods: {
			// 取关
			async handleUnFollow(id) {
				const result = await updateFollow({
					gid: id,
				})
				if (result.code == 0) {
					uni.$u.toast(result.message);
					//按键样式判断
					this.info.is_collected = this.info.is_collected == 1 ? 0 : 1
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>