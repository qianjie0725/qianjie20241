<template>
	<view>
		<view style="line-height: 2;color:#FFFFFF;padding-left: 30rpx;font-size: 28rpx;">
			{{$lang.STOCK_TRADE_TREND_RECENT_TITLE}}
		</view>
		<view style="border-radius: 8px;">
			<view style="border-radius: 8px 8px 0 0;display: flex;align-items: center;padding:10px;">
				<block v-for="(item,index) in $lang.STOCK_TRADE_TREND_RECENT_LABELS">
					<view style="color:#FFB044;" :style="{flex:index==0?'20%':'26%',textAlign:index==0?'':'right'}">
						{{item}}
					</view>
				</block>
			</view>
		</view>
		<block v-for="(item,index) in list" :key="index">
			<view style="display: flex;align-items: center;padding:10px;">
				<view style="flex:20%;font-size: 20rpx;color:#CBCBCF;">{{item.dt}}</view>
				<view :style="$util.setStockRiseFall(item.net_vol_individual>0)" style="flex:26%;text-align: right;">
					{{$util.formatNumber(item.net_vol_individual)}}
				</view>
				<view :style="$util.setStockRiseFall(item.net_vol_institutional>0)" style="flex:26%;text-align: right;">
					{{$util.formatNumber(item.net_vol_institutional)}}
				</view>
				<view :style="$util.setStockRiseFall(item.net_vol_foreigner>0)" style="flex:26%;text-align: right;">
					{{$util.formatNumber(item.net_vol_foreigner)}}
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'StockTrendList',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>