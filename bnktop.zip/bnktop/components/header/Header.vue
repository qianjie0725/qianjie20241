<template>
	<header class="common_header">
		<template v-if="back">
			<view @click="actionEvent()">
				<view class="arrow rotate_225" :style="arrowStyle"></view>
			</view>
		</template>
		<text :style="{color:color}">{{title}}</text>
		<template v-if="search">
			<view class="header_search" @click="linkSearch()">
				<image mode="aspectFit" src="/static/search.png" :style="$util.setImageSize(30)"></image>
			</view>
		</template>
		<template v-if="notify">
			<image mode="aspectFit" src="/static/notification.png" :style="$util.setImageSize(40)"
				@click="linkNotifiy()" style="padding-right: 8rpx;"></image>
		</template>
		<template v-if="translate">
			<Translate></Translate>
		</template>
	</header>
</template>

<script>
	import {
		NOTIFICATION,
		// SERVICE,
		SEARCH
	} from '@/common/paths.js';
	import Translate from '@/components/Translate.vue';
	/*
	是否需要回退按钮。回退按钮箭头颜色同文字颜色
	是否需要标题，标题文字颜色，
	是否需要搜索，
	是否需要语言切换，
	文字颜色，背景颜色
	
	一级 ：<header> 标题 搜索 功能 语言 </header>
	二级 ：<header> 回退 标题 </header>
	
	*/

	export default {
		name: 'Header',
		components: {
			Translate
		},
		props: {
			// 标题			
			title: {
				type: String,
				default: '',
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#333333'
			},
			// 背景色
			bg: {
				type: String,
				default: 'transparent',
			},
			// 是否需要回退
			back: {
				type: Boolean,
				default: true,
			},
			//search 顶级页面通常需要搜索
			search: {
				type: Boolean,
				default: false,
			},
			// 是否需要语言
			translate: {
				type: Boolean,
				default: false,
			},
			// 是否需要通知
			notify: {
				type: Boolean,
				default: false,
			}
		},
		computed: {
			// 设置回退箭头的样式
			arrowStyle() {
				return {
					...this.$util.setImageSize(20),
					// 通常与标题文字同色
					borderColor: this.color
				}
			}
		},
		methods: {
			actionEvent() {
				// 默认回退一级
				uni.navigateBack({
					delta: 1,
				})
				// 特殊回退，外部使用该事件
				this.$emit('action', '');
			},
			// 跳转到通知页面
			linkNotifiy() {
				uni.navigateTo({
					url: NOTIFICATION
				})
			},

			// // 跳转到客服
			// linkService() {
			// 	this.$util.linkCustomerService();
			// },
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: SEARCH
				})
			},
		}
	}
</script>