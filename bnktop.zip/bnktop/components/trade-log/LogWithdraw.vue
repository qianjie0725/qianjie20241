<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="background-color: #3F3384; padding:10px 16px;border-radius: 8rpx;line-height: 1.8;margin:0 20px 20px 20px;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_WITHDRAW_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view :style="{color:$theme.PRIMARY}" style="flex:40%;font-size: 18px;">
						{{$util.formatNumber(item.money)}}
					</view>
					<view style="margin-left: auto;" :style="{color:$theme.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_ORDER_SN}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_CREATE_TIME}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_DW_DESC}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.reason}}
					</view>
				</view>

				<template v-if="item.status==0">
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<view :style="item.style"> {{item.text}} </view>
						<view style="color:#FC4C76;" @click="handleCancel(item.id)">
							{{$lang.BTN_CANCEL}}
							<view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$util.setImageSize(12)"></view>
						</view>
					</view>
				</template>
				<template v-else-if="item.status==2">
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<view :style="item.style"> {{item.text}} </view>
						<view style="color:#FC4C76;" @click="handleService()">
							{{$lang.BTN_SEND_SERVICE}}
							<view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$util.setImageSize(12)"></view>
						</view>
					</view>
				</template>
				<template v-else>
					<view :style="item.style"> {{item.text}} </view>
				</template>
			</view>
		</block>
	</view>
</template>

<script>
	import {
		getAccountWithdraw,
		postCancelWithdraw
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},

			// 取消提现
			async handleCancel(id) {
				const result = await uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.cancelWithdraw(id);
				}
			},
			async cancelWithdraw(id) {
				const result = await postCancelWithdraw({
					id
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.getList()
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getList() {
				this.list = []; // 每次请求前，清空数组。
				const result = await getAccountWithdraw();
				console.log(result.data);
				if (result.code == 0) {
					this.list = result.data.map(item => {
						return {
							...item,
							...this.$util.setStatusPrimary(item.status),
							style: this.$theme.setStatusPrimary(item.status),
						}
					})
					console.log(this.list);
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>

</style>