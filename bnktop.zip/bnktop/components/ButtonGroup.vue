<template>
	<view class="btns " style="">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(110)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns'],
		data() {
			return {};
		},

		methods: {
			actionEvent(url, index) {
				if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>

<style lang="scss">
	.btns {
		display: flex;
		flex-wrap: wrap;
		padding-bottom: 6px;
		padding: 10px 0;

		.item {
			width: 25%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: #CBCBCF;
			padding: 4px 0;
		}
	}
</style>