<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
		<view style="display: flex;justify-content: space-between;margin:0 10rpx;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view :style="setStyle(acitve ==index)" @click="handleChange(index)">
					{{item}}
				</view>
			</block>
		</view>
	</scroll-view>
</template>

<script>
	export default {
		name: 'TabsFifth',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		methods: {
			// 设置样式
			setStyle(val, isMR = false) {
				return this.$theme.btnCommon(val,
					val ? {
						borderRadius: '16rpx',
						padding: '6px 20px',
						// marginRight: isMR ? '' : '20rpx'
					} : {
						// border: 'none',
						color: this.$theme.PRIMARY,
						padding: '6px 20px',
						// marginRight: isMR ? '' : '20rpx'
					});
			},
			handleChange(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
		}
	}
</script>