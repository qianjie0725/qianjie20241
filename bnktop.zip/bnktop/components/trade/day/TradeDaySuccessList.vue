<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #3F3384;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_DAY_BUY_AMOUNT}}
						</view>
						<view style="font-size: 16px;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.money)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}
						</view>
						<view style="font-size: 16px;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.success)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_DAY_BUY_PRICE}}
						</view>
						<view style="font-size: 16px;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_ORDER_SN}}</view>
						<view>{{item.ordersn}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_CREATE_TIME}}</view>
						<view> {{item.created_at}} </view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						<view> {{item.zt}} </view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import {
		getTradeDaySuccessList,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDaySuccessList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getData();
		},
		methods: {
			// 申请列表
			async getData() {
				const result = await getTradeDaySuccessList();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>