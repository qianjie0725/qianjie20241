<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #3F3384;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						<view :style="item.style"> {{item.zt}} </view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_BUY_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{$util.formatNumber(item.money)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{$util.formatNumber(item.success)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_ORDER_SN}}</view>
						<view>{{item.ordersn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_CREATE_TIME}}</view>
						<view>{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import {
		getTradeDayOrderList,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getData();
		},
		methods: {
			// 申请列表
			async getData() {
				this.list = []; // 每次请求前，清空数组。
				const result = await getTradeDayOrderList();
				if (result.code == 0) {
					result.data.forEach((item, index) => {
						this.list.push({
							...item,
							// 状态值明文、icon
							...this.$util.setStatusPrimary(item.status),
							// 状态值 样式:字号、字色、背景等
							style: this.$theme.setStatusPrimary(item.status),
						})
					});

				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>