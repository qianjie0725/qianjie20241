<template>
	<view>
		<view style="padding:20px;">
			<view style="text-align: center;margin-bottom: 30px;">
				<image src="/static/trade_day_header.png" mode="aspectFit" :style="$util.setImageSize(300)"></image>
			</view>
			<view class="common_input_wrapper" style="padding-left: 20px;">
				<input v-model="amount" type="number" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
					:placeholder-style="$util.setPlaceholder()" maxlength="11" style="width: 90%;"></input>
				<view style="color:#999">{{$lang.CURRENCY_UNIT}}</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: flex-end;" :style="{color:$theme.LOG_LABEL}">
				<view style="padding-right: 10px;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
				<view>{{userInfo.money<=0?0: $util.formatNumber(userInfo.money)}} [{{$lang.CURRENCY_UNIT}}]</view>
				<view style="padding-left: 10px;" :style="{color:$theme.PRIMARY}" @click="linkDeposit">
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
			</view>
		</view>
		<view :style="$theme.btnCommon(true,{padding:'20rpx 30rpx',margin:'auto',width:'60%'})" @click="handleBuy()">
			{{$lang.TRADE_DAY_BUY}}
		</view>

		<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#CBCBCF;">
			<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
			<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;">{{item}}</view>
			</block>
		</view>
		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' :content="$lang.TRADE_DAY_MODAL_CONTENT" :cancel-text="$lang.BTN_CANCEL"
			:confirm-text="$lang.BTN_CONFIRM" :confirmColor="this.$theme.PRIMARY" cancelColor="#999999">
		</u-modal>
	</view>
</template>

<script>
	import {
		ACCOUNT_DEPOSIT
	} from '@/common/paths.js';
	import {
		postTradeDayBuy,
		userFastInfo,
	} from '@/common/api.js';
	export default {
		name: 'TradeDayBuy',
		data() {
			return {
				amount: '',
				showBuyConfirm: false,
				userInfo: {},
			}
		},
		created() {
			this.getUserInfo();
		},
		methods: {
			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},

			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast($lang.TRADE_DAY_TIP_INPUT_AMOUNT);
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await postTradeDayBuy({
					money: this.amount,
				}, this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.amount = '';
					// 1 为驱动父事件，实现切换Tab效果
					this.$emit('action', 1);
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getUserInfo() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>