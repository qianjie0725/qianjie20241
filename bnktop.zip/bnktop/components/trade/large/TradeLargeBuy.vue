<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto">
			<view class="popup_header" style="">
				{{info.name}}
				<image src="/static/close.png" mode="aspectFit" :style="$util.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view style="padding-bottom: 30rpx;">
				<view
					style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_BUY_AMOUNT}}</text>
					<text :style="{color:'#FF6700'}">
						{{$util.formatNumber(info.price)}}{{$lang.CURRENCY_UNIT}}</text>
				</view>
				<view class="common_input_wrapper" style="padding-left: 20px;margin:30rpx 40rpx;">
					<input v-model="amount" :placeholder="$lang.TRADE_LARGE_TIP_BUY_COUNT" type="number"
						style="width: 80%;" :placeholder-style="$util.setPlaceholder()"></input>
					<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
				</view>

				<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>1">
					<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;"
						:style="{color:$theme.LOG_LABEL}">
						{{$lang.LEVER}}
					</view>
					<view class="common_input_wrapper" style="margin:30rpx 40rpx;">
						<image mode="aspectFit" src='/static/leverage.png' :style="$util.setImageSize(36)">
						</image>
						<block v-for="(item,index) in leverList" :key="index">
							<text @click="chgangeLever(index)" style="display: inline-block;padding:0 16px;"
								:style="{borderBottom:`2px solid ${index==current? '#FF6700':'transparent'}`,color:index==current?'#FF6700':$theme.LOG_VALUE}">{{item.name}}</text>
						</block>
					</view>
				</template>

				<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_BUY_TOTAL_AMOUNT}}</view>
					<view :style="{color:'#FF6700'}">
						{{$util.formatNumber(buyAmount)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>

				<!-- <view class="common_input_wrapper" style="margin:30rpx 40rpx;padding-left: 20px;">
					<input v-model="password" :placeholder="$lang.TRADE_LARGE_TIP_BUY_PWD" type="password"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view> -->

				<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.TIP_AMOUNT_AVAIL}}</text>
					<text :style="{color:'#FF6700'}">
						{{availBal}} {{$lang.CURRENCY_UNIT}}</text>
				</view>

				<view :style="setStyle" @tap.stop="handleConfirm()">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		postTradeLargeBuy,
		userFastInfo,
	} from '@/common/api.js';
	export default {
		name: 'TradeLargeBuy',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
				amount: "", // 金额
				password: '', // 支付密码
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		computed: {
			// 设置按钮样式
			setStyle() {
				return this.$theme.btnCommon(true, {
					padding: '20rpx 30rpx',
					margin: '40rpx auto',
					width: '60%'
				})
			},
			// 当前杠杆值。无论是否显示杠杆，此处都无需注释
			curLever() {
				return this.leverList[this.current];
			},
			// 金额计算
			buyAmount() {
				return !this.curLever ? 0 : this.info.price * this.amount / Number(this.curLever.index);
			},
		},
		created() {
			this.gerUserInfo();
		},
		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);

			},
			// 选择杠杆
			chgangeLever(val) {
				this.current = val;
			},

			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async buy() {
				const result = await postTradeLargeBuy({
					id: this.info.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever.index,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.actionEvent();
				} else {
					uni.$u.toast(result.message);
				}
			},
			async gerUserInfo() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.availBal = this.$util.formatNumber(result.data.money);
					this.leverList = [{
						name: 1,
						index: 1
					}];
					if (result.data.ganggan) {
						this.leverList.push(...result.data.ganggan);
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>