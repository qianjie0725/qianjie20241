<template>
	<view>
		<template v-if="list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding: 10px;">
				<block v-for="(item,index) in list" :key="index">
					<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #3F3384;border-radius: 8rpx;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_VALUE}" style="font-size: 36rpx;">{{item.goods.name}}</view>
							<text style="color:#12F6B8">{{$lang.TRADE_LARGE_LOG_FINISH}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_PRICE}}</view>
							<text :style="{color:$theme.LOG_VALUE}">{{$util.formatNumber(item.price)}}
								{{` ${$lang.CURRENCY_UNIT}`}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_NUM}}</view>
							<text style="color:#12F6B8">{{item.num}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_AMOUNT}}</view>
							<text :style="{color:$theme.LOG_VALUE}">{{$util.formatNumber(item.amount)}}
								{{` ${$lang.CURRENCY_UNIT}`}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_LEVER}}</view>
							<text :style="{color:$theme.LOG_VALUE}">{{item.double}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;"
							:style="{color:$theme.LOG_LABEL}">
							<view>{{$lang.TRADE_LARGE_LOG_CREATE_TIME}}</view>
							<text>{{item.created_at}}</text>
						</view>
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		getTradeLargeOrderLog
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				const result = await getTradeLargeOrderLog();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>