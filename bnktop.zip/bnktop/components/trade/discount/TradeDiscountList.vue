<template>
	<view>
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #3F3384;border-radius: 8rpx;">
					<TradeStockItem :item="item" @action="handleDetail"></TradeStockItem>
				</view>
			</block>
		</view>
		<template v-if="isShow">
			<TradeDiscountBuy :info="itemInfo" @action="handleClose"></TradeDiscountBuy>
		</template>
	</view>
</template>

<script>
	import {
		getTradeDiscountList,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeStockItem from '@/components/trade/TradeStockItem.vue';
	import TradeDiscountBuy from '@/components/trade/discount/TradeDiscountBuy.vue';
	export default {
		name: 'TradeDiscountList',
		components: {
			EmptyData,
			TradeStockItem,
			TradeDiscountBuy,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			handleDetail(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				this.list = [];
				const result = await getTradeDiscountList();
				if (result.code == 0) {
					// 过滤掉不合格数据，当前以【gid】字段来判定。
					result.data.forEach(item => {
						if (item.gid && item.gid > 0) {
							this.list.push({
								logo: item.goods.logo,
								name: item.goods.name,
								code: item.goods.code,
								id: item.id,
								price: item.price,
								shiying: item.shiying,
								shengou_date: item.shengou_date,
								fa_amount: item.fa_amount,
								fa_muji_zijin: item.fa_muji_zijin,
								rate_num: item.goods.rate_num,
								rate: item.goods.rate,
								min_num: item.min_num,
								max_num: item.max_num,
								day: item.day,
							})
						}
					});
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>

<style>
</style>