<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;margin-top: 30rpx;">
			<view class="home_card_bg home_card_bg_1" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view
			style="display: flex;align-items: center;justify-content: space-around;border-bottom: 1px solid #F1f1f1;margin:20px 0 10px 0">
			<block v-for="(item,index) in $lang.TRADE_AI_TRANSFER" :key="index">
				<view style="padding:6px 16px;margin:6px;border-radius: 6px;text-align: center;"
					:style="{color:index==curTab? '#121212':'#666',backgroundColor:curTab==index? '#ebdcff':''}"
					@click="changeTab(index)">{{item}}</view>
			</block>
		</view>

		<view style="padding: 10px;margin-bottom: 20px;">
			<view style="padding:20px;">
				<view class="common_input_wrapper" style="padding-left: 20px;">
					<input v-model="amount" type="number" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
						:placeholder-style="$util.setPlaceholder()" maxlength="11" style="width: 90%;"></input>
					<view style="color:#999">{{$lang.CURRENCY_UNIT}}</view>
				</view>
			</view>

			<template v-if="curTab!=1">
				<view style="padding-left: 20px;" :style="{color:$theme.LOG_VALUE}">{{$lang.TRADE_AI_CYCLE_TITLE}}
				</view>
				<view style="display: flex;align-items: center;flex-wrap: wrap;padding:0 10px;">
					<block v-for="(item,index) in cycleData" :key="index">
						<view
							style="border-radius: 6px;flex:10%;margin:10px;padding:10px;line-height: 1.6;text-align: center;"
							:style="{color:curCycle==item? '#121212' :'#999',backgroundColor:curCycle==item?'#ebdbff'
							:'#F1F1F1'}" @click="changeCurCycle(item)">
							{{item}}
						</view>
					</block>
				</view>
			</template>


			<view :style="$theme.btnCommon(true,{padding:'20rpx 30rpx',margin:'30rpx auto',width:'60%'})"
				@click="handleBuy()">
				{{$lang.TRADE_AI_TRANSFER[curTab]}}
			</view>

			<!-- <view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#959393;">
				<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
				<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
					<view style="padding-bottom: 6px;">{{item}}</view>
				</block>
			</view> -->
			<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
				:showCancelButton='true' :content="$lang.TRADE_DAY_MODAL_CONTENT" :cancel-text="$lang.BTN_CANCEL"
				:confirm-text="$lang.BTN_CONFIRM">
			</u-modal>
		</view>
	</view>
</template>

<script>
	import {
		postTradeAIBuy,
		accountInfo,
		getTradeAICycle
	} from '@/common/api.js';
	import {
		ACCOUNT_DEPOSIT
	} from '@/common/paths.js';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		name: 'TradeAIBuy',
		components: {
			CardItemPrimary
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				amount: '',
				showBuyConfirm: false,
				curTab: 0, // AI交易，转入，转出
				cycleData: [], // 周期预置值
				curCycle: 0, // 当前选中预置值
				cardData: {},
			}
		},

		computed: {
			cardLabels() {
				return [this.$lang.TRADE_AI_AMOUNT,
					this.$lang.TRADE_AI_PROFIT,
					this.$lang.TRADE_AI_AMOUNT_TOTAL
				];
			},
		},
		created() {
			this.getUserInfo();
			this.getTradeAICycleData();
		},
		methods: {
			// 转入，转出
			changeTab(val) {
				this.curTab = val;
			},
			// 切换转入周期预置值
			changeCurCycle(val) {
				this.curCycle = val;
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			linkDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast($lang.TRADE_DAY_TIP_INPUT_AMOUNT);
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await postTradeAIBuy({
					money: this.amount,
					type: this.curTab + 1, // 1:转入;2:转出。
					day: this.curTab == 1 ? '' : this.curCycle,
				}, this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.amount = '';
					this.getUserInfo();
					// 1 为驱动父事件，实现切换Tab效果
					this.$emit('action', 1);
				} else {
					uni.$u.toast(result.message);
				}
			},

			// 获取周期预置值
			async getTradeAICycleData() {
				const result = await getTradeAICycle();
				console.log(result);
				if (result.code == 0) {
					this.cycleData = result.data;
					this.curCycle = this.cycleData[0];
				} else {
					uni.$u.toast(result.message);
				}
			},

			async getUserInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.aiMoney,
						value2: this.userInfo.aiShouyi,
						value3: this.userInfo.aiZong,
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>