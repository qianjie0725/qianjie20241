<template>

</template>

<script>
	import {
		postBuyIPO
	} from '@/common/api.js';
	export default {
		name: 'TradeIPOBuy',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: false, // 购买前二次确认的弹层
			}
		},
		created() {
			this.handleShowModal();
		},
		methods: {
			// 平仓/卖出
			async handleShowModal() {
				const result = await uni.showModal({
					title: this.$lang.TRADE_IPO_MODAL_TITLE,
					content: this.$lang.TRADE_IPO_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.purchase();
				}
			},

			// //点击取消
			// cancel() {
			// 	this.show = false;
			// },
			// // 点击确认
			// confirm() {
			// 	this.purchase()
			// 	this.show = false;
			// },

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				const result = await postBuyIPO({
					// num: this.value,
					id: this.info.id,
					// price: this.price
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						this.changeTab(1);
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>