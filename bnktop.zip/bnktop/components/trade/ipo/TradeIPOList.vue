<template>
	<view>
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #3F3384;border-radius: 8rpx;">
					<TradeStockItem :item="item" @action="handleDetail"></TradeStockItem>
				</view>
			</block>
		</view>

		<template v-if="isShow">
			<TradeIPOBuy :info="itemInfo" @action="handleClose"></TradeIPOBuy>
		</template>
	</view>
</template>

<script>
	import {
		getIPOList,
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeStockItem from '@/components/trade/TradeStockItem.vue';
	import TradeIPOBuy from '@/components/trade/ipo/TradeIPOBuy.vue';
	export default {
		name: 'TradeIPOList',
		components: {
			EmptyData,
			TradeStockItem,
			TradeIPOBuy,
		},
		data() {
			return {
				list: [],
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.isShow = true;
				this.itemInfo = val;
				// this.curId = val;
				// this.show = true;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				this.list = []; // 请求前清除数据。
				const result = await getIPOList({
					type: 1, // 传参 1或2
				})
				if (result.code == 0) {
					// 过滤掉不合格数据，当前以【gid】字段来判定。
					this.list = result.data.map(item => {
						if (item.gid && item.gid > 0) {
							return {
								logo: item.goods.logo,
								name: item.goods.name,
								code: item.goods.code,
								id: item.id,
								price: item.price,
								shiying: item.shiying,
								shengou_date: item.shengou_date,
								fa_amount: item.fa_amount,
								fa_muji_zijin: item.fa_muji_zijin,
								rate_num: item.goods.rate_num,
								rate: item.goods.rate,
								min_num: item.min_num,
								max_num: item.max_num,
								day: item.day,
							}
						}
					});
				} else {
					uni.$u.toast(result.message);
				}
			},
		}

	}
</script>

<style>
</style>