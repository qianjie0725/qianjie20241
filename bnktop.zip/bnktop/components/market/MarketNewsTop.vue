<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;" scroll-left="10" @touchmove.stop>
		<template v-if="article && article.length>0">
			<block v-for="(item,index) in article" :key="index">
				<view style="display: inline-block;height: 280rpx;width: 360rpx;margin-left: 10px;"
					@click="open(item.url)">
					<view style="text-align: center;">
						<image :src="item.pic" mode="scaleToFill" style="border-radius: 8px;"
							:style="$util.setImageSize(360,220)">
						</image>
					</view>
					<view style="color: #FFFFFF;width:340rpx;white-space: break-spaces;padding-left: 10px;">
						{{setText(item.title)}}
					</view>
					<view style="padding-right: 10px;color:#999;text-align: right;">
						{{item.created_at}}
					</view>
				</view>
			</block>
		</template>
	</scroll-view>
</template>

<script>
	import {
		getMarketOverview,
	} from '@/common/api.js';
	export default {
		name: 'MarketNewsTop',
		data() {
			return {
				article: []
			}
		},
		created() {
			this.getData();
		},
		methods: {
			open(url) {
				window.open(url)
			},
			// 文字超出一行。转换为...
			setText(val) {
				let temp = '';
				return temp = val.length <= 13 ? val : val.slice(0, 13) + '...'
			},

			async getData() {
				const result = await getMarketOverview({})
				if (result.code == 0) {
					this.article = result.data.article
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>