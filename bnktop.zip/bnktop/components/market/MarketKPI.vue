<template>
	<view>
		<view style="padding:24rpx 0;">
			<TabsFifth :tabs="$lang.MARKET_INDEX_TABS" @action="changeTab" :acitve="curTab"></TabsFifth>
		</view>
		<ListFourth :list="list"></ListFourth>

		<view style="text-align: center;color: #999;line-height: 1.8;">{{$lang.MARKET_NEWS_TIP}}</view>
	</view>
</template>

<script>
	import {
		getMarketIndex
	} from '@/common/api.js';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import ListFourth from '@/components/list/ListFourth.vue';
	export default {
		name: 'MarketKPI',
		components: {
			ListFourth,
			TabsFifth,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			async getData() {
				const result = await getMarketIndex({
					current: this.curTab
				})
				console.log('?', result);
				if (result.code == 0) {
					this.list = Object.values(result.data).map(item => {
						return {
							logo: item.logo,
							name: item.ko_name,
							code: item.code,
							price: item.close,
							rate: item.returns,
							follow: item.sc,
							gid: item.gid,
							close: item.close,
						}
					});
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>