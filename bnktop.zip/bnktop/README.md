# bnktop

## 当前尚未使用

![LOGO](https://github.com/github1413/bnktop/raw/main/static/logo.png)

<!-- 确认 -->
```
<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
```

# TODO
- 完全替换uview-ui。

# Update Log 2024.05.23
- 跳转到客服，分为两种模式：
- - 上架：点击按钮，直接跳转到第三方客服页面；
- - 运行：点击按钮，进入软件内客服页面。
- 以上，皆在按钮事件中调用`util.js`文件的`linkCustomerService`函数，按照提示进行注释。
 
# Update Log 2024.05.22
- 更新`auth`照片上传逻辑。
- 变更 `avatar`头像上传逻辑，移除u-upload。

# Update Log 2024.05.16
~~添加`servicePush`页面，及相关逻辑。用于上架的客服系统。(更改客服系统，只需对应启用或注释`common/paths.js`相关代码)~~

# Update Log 2024.05.15
- 在`index.html`中添加媒体查询样式，使其桌面浏览器情况下，内容居中。(未真机测试)
- uniapp内置`scroll-view`不支持桌面端鼠标移动。

# Update Log 2024.05.14
- 添加AI交易

# Update Log 2024.05.13
- auth:保留并注释严格校验韩国证件号码，以及自动计算性别。
- 默认提供正反面照片上传。

# Update Log 2024.05.12
- Launch页面，竖向加载条功能

# Update Log 2024.05.09
- 首页的页首吸顶
- 语言切换移出header容器
- 首页添加IPO中签提醒


# Update Log 2024.05.05
- 添加股权交易

# Update Log 2024.05.03
- 日内交易，添加可用金额

# Update Log 2024.05.01
- 优化`access`页面，记住密码及用户隐私协议完整逻辑。